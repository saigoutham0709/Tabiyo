import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const workspaces = sqliteTable('workspaces', {
  owner: text('owner').primaryKey(),
  state: text('state').notNull(),
  version: integer('version').notNull().default(0),
  updatedAt: text('updated_at').notNull(),
});
export const rateLimits=sqliteTable('rate_limits',{
 owner:text('owner').primaryKey(),
 window:integer('window').notNull(),
 hits:integer('hits').notNull(),
});
