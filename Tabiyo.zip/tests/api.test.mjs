import test,{beforeEach} from 'node:test';
import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {today,addDays} from '../lib/domain.ts';
const db=new DatabaseSync(':memory:');
for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())db.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
globalThis.__tabiyoHeaders=new Headers({'oai-authenticated-user-id':'owner-A','oai-authenticated-user-email':'a@example.test'});
globalThis.__tabiyoEnv={DB:{prepare(sql){return {bind(...params){const stmt=db.prepare(sql);return {async first(){return stmt.get(...params)??null;},async run(){const result=stmt.run(...params);return {meta:{changes:Number(result.changes)}};}};}};}}};
registerHooks({resolve(specifier,context,next){if(specifier==='cloudflare:workers')return {url:'data:text/javascript,export const env=globalThis.__tabiyoEnv;',shortCircuit:true};if(specifier==='next/headers')return {url:'data:text/javascript,export async function headers(){return globalThis.__tabiyoHeaders}',shortCircuit:true};if(specifier==='next/navigation')return {url:'data:text/javascript,export function redirect(path){throw new Error(path)}',shortCircuit:true};try{return next(specifier,context);}catch(error){if(specifier.startsWith('.')&&!/\.[a-z]+$/.test(specifier))return next(specifier+'.ts',context);throw error;}}});
const {GET,POST}=await import('../app/api/workspace/route.ts');
const {saveWorkspace,loadWorkspace}=await import('../lib/repository.ts');
beforeEach(()=>{db.exec('DELETE FROM workspaces; DELETE FROM rate_limits;');globalThis.__tabiyoHeaders=new Headers({'oai-authenticated-user-id':'owner-A','oai-authenticated-user-email':'a@example.test'});});
async function snapshot(){const r=await GET();assert.equal(r.status,200);return r.json();}
function request(body,origin='https://pilot.example'){return new Request('https://pilot.example/api/workspace',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)});}
function envelope(version,command,requestId=crypto.randomUUID()){return {version,requestId,command};}
const booking=()=>({type:'book',patientId:'p1',doctorId:'rao',date:addDays(today(),1),time:'09:00',source:'phone'});
test('API rejects anonymous reads and writes',async()=>{globalThis.__tabiyoHeaders=new Headers();assert.equal((await GET()).status,401);assert.equal((await POST(request(envelope(0,booking())))).status,401);});
test('API isolates records between signed-in accounts',async()=>{const a=await snapshot();const r=await POST(request(envelope(a.version,booking())));assert.equal(r.status,200);assert.equal((await snapshot()).state.appointments.length,7);globalThis.__tabiyoHeaders=new Headers({'oai-authenticated-user-id':'owner-B','oai-authenticated-user-email':'b@example.test'});const b=await snapshot();assert.equal(b.state.appointments.length,6);assert.equal(b.version,0);});
test('cross-origin writes fail before mutation',async()=>{const original=await snapshot();assert.equal((await POST(request(envelope(original.version,booking()),'https://attacker.example'))).status,403);assert.equal((await snapshot()).state.appointments.length,6);});
test('replaying a completed request produces no duplicate booking',async()=>{const original=await snapshot();const body=envelope(original.version,booking());assert.equal((await POST(request(body))).status,200);assert.equal((await POST(request(body))).status,200);assert.equal((await snapshot()).state.appointments.length,7);});
test('stale clients get a conflict and cannot overwrite newer state',async()=>{const original=await snapshot();await POST(request(envelope(original.version,booking())));const r=await POST(request(envelope(original.version,{type:'delay',doctorId:'rao',minutes:60})));assert.equal(r.status,409);assert.equal((await snapshot()).state.doctors[0].delay,15);});
test('database compare-and-swap admits one winner for simultaneous snapshots',async()=>{const {state,version}=await loadWorkspace('owner-A');const results=await Promise.allSettled([saveWorkspace('owner-A',state,version),saveWorkspace('owner-A',state,version)]);assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(results.filter(r=>r.status==='rejected').length,1);});
test('invalid commands do not create new state',async()=>{const original=await snapshot();const r=await POST(request(envelope(original.version,{...booking(),time:'99:99'})));assert.equal(r.status,422);assert.equal((await snapshot()).version,original.version);});
test('API rejects non-JSON and excessive input',async()=>{const r=await POST(new Request('https://pilot.example/api/workspace',{method:'POST',headers:{Origin:'https://pilot.example','Content-Type':'text/plain'},body:'test'}));assert.equal(r.status,415);assert.equal((await POST(request({padding:'x'.repeat(13000)}))).status,413);});
test('read responses explicitly prevent caching',async()=>{const r=await GET();assert.equal(r.headers.get('cache-control'),'no-store');assert.equal(r.headers.get('x-content-type-options'),'nosniff');});
test('per-account request quotas are enforced in SQLite',async()=>{for(let i=0;i<120;i++)assert.equal((await GET()).status,200);assert.equal((await GET()).status,429);});
