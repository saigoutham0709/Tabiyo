-- Synthetic local/staging fixtures only. Never seed real patient data.
insert into public.clinics (id,name,address) values
('20000000-0000-4000-8000-000000000001','Tabiyo Demo Clinic','Synthetic location, Hyderabad');

insert into public.doctors (id,clinic_id,name,specialty) values
('30000000-0000-4000-8000-000000000001','20000000-0000-4000-8000-000000000001','Demo Doctor One','General medicine'),
('30000000-0000-4000-8000-000000000002','20000000-0000-4000-8000-000000000001','Demo Doctor Two','Pediatrics');

insert into public.patients (id,clinic_id,mobile_e164,name,date_of_birth,language)
select ('40000000-0000-4000-8000-' || lpad(n::text,12,'0'))::uuid,
  '20000000-0000-4000-8000-000000000001'::uuid,
  '+9190000000' || lpad((case when n=2 then 1 else n end)::text,2,'0'),
  'Demo Patient ' || n,
  date '1990-01-01' + n,
  (array['en','te','hi'])[1 + (n % 3)]
from generate_series(1,10) as n;

-- No fake staff login, password or consent grant is seeded. Auth users must be provisioned separately.
