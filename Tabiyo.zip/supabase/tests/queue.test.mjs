import test,{before,beforeEach,after} from 'node:test';
import assert from 'node:assert/strict';
import {fixture,ids} from './helpers.mjs';
let f,today;
const doctor='30000000-0000-4000-8000-000000000001',otherDoctor='30000000-0000-4000-8000-000000000002';
const family='40000000-0000-4000-8000-000000000002',third='40000000-0000-4000-8000-000000000003',doctorUser='10000000-0000-4000-8000-000000000097';
before(async()=>{
  f=await fixture();today=(await f.db.query("select (clock_timestamp() at time zone 'Asia/Kolkata')::date::text as date_value")).rows[0].date_value;
  await f.db.query('insert into auth.users values($1)',[doctorUser]);
  await f.db.query("insert into public.staff_users(id,clinic_id,name,role) values($1,$2,'Synthetic Queue Doctor','doctor')",[doctorUser,ids.clinicA]);
  await f.db.query('update public.doctors set staff_user_id=$1 where id=$2',[doctorUser,doctor]);
});
after(()=>f?.db.close());
beforeEach(async()=>{
  await f.db.exec('truncate public.queue_tokens,public.staff_operation_requests,public.api_requests,public.consents,public.message_log,public.mock_deliveries,public.delivery_receipts,public.staff_alerts,public.events,public.audit_log,public.outbox,public.appointments,public.doctor_schedules,public.doctor_leaves,public.conversations cascade; delete from public.clinic_features; update public.clinics set settings=\'{}\';');
  await f.db.query("insert into public.doctor_schedules(clinic_id,doctor_id,weekday,start_time,end_time) select d.clinic_id,d.id,w,'00:00','24:00' from public.doctors d cross join generate_series(0,6) w");
});
const run=(action,input={},key=null,user=ids.frontA)=>f.asUser(user,async tx=>(await tx.query('select public.tabiyo_queue($1,$2::jsonb,$3) result',[action,JSON.stringify(input),key])).rows[0].result);
const enable=()=>f.db.query("insert into public.clinic_features(clinic_id,feature,enabled) values($1,'walk_in_tokens',true)",[ids.clinicA]);
const add=(patient=ids.patientA,key=crypto.randomUUID(),selectedDoctor=doctor,user=ids.frontA)=>run('add',{doctor_id:selectedDoctor,patient_id:patient},key,user);
const read=(selectedDoctor=doctor,user=ids.frontA)=>run('read',{doctor_id:selectedDoctor},null,user);
const call=(next,current=null,key=crypto.randomUUID())=>run('call_next',{doctor_id:doctor,expected_called_id:current,expected_next_id:next},key);
test('queue is default-off, with a safe status endpoint and no mutation when disabled',async()=>{
  assert.equal((await run('status')).enabled,false);
  await assert.rejects(add(),/FEATURE_DISABLED/);await assert.rejects(read(),/FEATURE_DISABLED/);
  await assert.rejects(run('status',{doctor_id:doctor,id:crypto.randomUUID()},crypto.randomUUID()),/INPUT_INVALID/);
});
test('tokens are monotonic and idempotent, distinguishing shared-phone family identities',async()=>{
  await enable();const key=crypto.randomUUID(),a=await add(ids.patientA,key),b=await add(family);
  assert.equal(a.token.token_number,1);assert.equal(b.token.token_number,2);assert.equal((await add(ids.patientA,key)).replayed,true);
  const rows=(await read()).tokens;assert.equal(rows.length,2);assert.ok(rows.every(row=>row.patient_name));
  await assert.rejects(add(ids.patientA),/PATIENT_ALREADY_QUEUED/);
  await assert.rejects(add(ids.patientA,crypto.randomUUID(),otherDoctor),/PATIENT_ALREADY_QUEUED/);
});
test('call-next completes only the current token and rejects a stale operator view',async()=>{
  await enable();const a=await add(),b=await add(family),c=await add(third);
  const first=await call(a.token.id);assert.equal(first.token.status,'called');assert.equal(first.notice_state,'review_required');
  const key=crypto.randomUUID(),next=await call(b.token.id,a.token.id,key);assert.equal(next.token.status,'called');
  assert.equal((await call(b.token.id,a.token.id,key)).replayed,true);
  await assert.rejects(call(b.token.id,a.token.id),/QUEUE_CHANGED/);
  const rows=(await read()).tokens;assert.equal(rows.find(row=>row.id===a.token.id).status,'done');assert.equal(rows.find(row=>row.id===c.token.id).status,'waiting');
});
test('skip and complete enforce terminal states without reviving prior tokens',async()=>{
  await enable();const a=await add(),b=await add(family);
  await assert.rejects(run('complete',{doctor_id:doctor,id:a.token.id},crypto.randomUUID()),/QUEUE_STATE_INVALID/);
  await call(a.token.id);await run('complete',{doctor_id:doctor,id:a.token.id},crypto.randomUUID());
  await assert.rejects(run('skip',{doctor_id:doctor,id:a.token.id},crypto.randomUUID()),/QUEUE_STATE_INVALID/);
  await run('skip',{doctor_id:doctor,id:b.token.id},crypto.randomUUID());
  await assert.rejects(call(b.token.id),/QUEUE_EMPTY/);
  const again=await add(ids.patientA);assert.equal(again.token.token_number,3);
});
test('doctor-own scope, clinic membership, source identity and direct-write boundaries are enforced',async()=>{
  await enable();await add();
  assert.equal((await read(doctor,doctorUser)).tokens.length,1);
  await assert.rejects(read(otherDoctor,doctorUser),/DOCTOR_NOT_FOUND/);
  await assert.rejects(add(ids.patientB),/PATIENT_NOT_FOUND/);
  await assert.rejects(read(doctor,ids.inactive),/STAFF_FORBIDDEN/);
  assert.equal((await f.asUser(ids.adminB,tx=>tx.query('select * from public.queue_tokens'))).rows.length,0);
  await assert.rejects(f.asUser(ids.frontA,tx=>tx.query('delete from public.queue_tokens')),/permission denied/);
  await assert.rejects(f.asUser(null,tx=>tx.query("select public.tabiyo_queue('status')"),'anon'),/permission denied/);
});
test('leave and breaks block calling but keep waiting tokens intact',async()=>{
  await enable();const a=await add();
  await f.db.query('insert into public.doctor_leaves(clinic_id,doctor_id,date_from,date_to) values($1,$2,$3,$3)',[ids.clinicA,doctor,today]);
  await assert.rejects(call(a.token.id),/DOCTOR_UNAVAILABLE/);
  assert.equal((await read()).tokens[0].status,'waiting');
});
test('without approved copy, the next-patient notice becomes an actionable staff task',async()=>{
  await enable();const a=await add();await add(family);await call(a.token.id);
  assert.equal((await f.db.query('select count(*)::integer n from public.outbox')).rows[0].n,0);
  const alert=(await f.db.query('select * from public.staff_alerts')).rows[0];assert.equal(alert.code,'QUEUE_NOTICE_REVIEW');assert.equal(alert.patient_id,family);assert.deepEqual(alert.context,{doctor_id:doctor});
});
async function prepareNotice(){
  await enable();
  await f.db.query("insert into public.clinic_features(clinic_id,feature,enabled) values($1,'lang_hi',true)",[ids.clinicA]);
  await f.db.query('update public.clinics set settings=$1 where id=$2',[{approved_queue_notice:{hi:{approved:true,version:'synthetic-v1',text:'Synthetic token {token_number}'}}},ids.clinicA]);
  await f.db.query("insert into public.consents(clinic_id,patient_id,version,status,channel) values($1,$2,'synthetic','granted','phone')",[ids.clinicA,family]);
  await f.db.query("insert into public.conversations(clinic_id,mobile_e164,last_inbound_at) values($1,'+919000000001',clock_timestamp())",[ids.clinicA]);
  const a=await add(),b=await add(family);await call(a.token.id);return {a,b};
}
test('approved eligible notice is durable and emitted only once for a called/next pair',async()=>{
  const {a}=await prepareNotice();await add(third);
  const rows=(await f.db.query('select * from public.outbox')).rows;assert.equal(rows.length,1);
  assert.equal(rows[0].kind,'text');assert.equal(rows[0].payload.text,'Synthetic token 2');assert.equal(rows[0].payload.called_token_id,a.token.id);
});
test('a queue change fences a prepared next-patient notice before mock acceptance',async()=>{
  const {a,b}=await prepareNotice();const instant=today+'T04:30:00Z';
  await f.db.query('update public.outbox set not_before=$1',[instant]);await f.db.query('update public.conversations set last_inbound_at=$1',[instant]);
  const rpc=(action,input)=>f.asUser(null,async tx=>(await tx.query('select public.tabiyo_delivery($1,$2::jsonb,$3) result',[action,JSON.stringify(input),instant])).rows[0].result,'service_role');
  const claim=await rpc('claim',{worker_id:crypto.randomUUID()});assert.equal((await rpc('prepare',claim)).action,'send');
  await call(b.token.id,a.token.id);
  const result=await rpc('mock_accept',claim);assert.equal(result.action,'skip');assert.equal(result.code,'QUEUE_CHANGED');
  assert.equal((await f.db.query('select count(*)::integer n from public.mock_deliveries')).rows[0].n,0);
});
test('request-key conflicts and disabled feature cannot bypass writes or requeue notices',async()=>{
  await enable();const key=crypto.randomUUID();await add(ids.patientA,key);
  await assert.rejects(add(family,key),/IDEMPOTENCY_CONFLICT/);
  await f.db.exec("update public.clinic_features set enabled=false where feature='walk_in_tokens'");
  await assert.rejects(add(ids.patientA,key),/FEATURE_DISABLED/);
});
test('revoking approved wording after preparation prevents acceptance and creates a review alert',async()=>{
  await prepareNotice();const instant=today+'T04:30:00Z';
  await f.db.query('update public.outbox set not_before=$1',[instant]);await f.db.query('update public.conversations set last_inbound_at=$1',[instant]);
  const rpc=(action,input)=>f.asUser(null,async tx=>(await tx.query('select public.tabiyo_delivery($1,$2::jsonb,$3) result',[action,JSON.stringify(input),instant])).rows[0].result,'service_role');
  const claim=await rpc('claim',{worker_id:crypto.randomUUID()});assert.equal((await rpc('prepare',claim)).action,'send');
  await f.db.query('update public.clinics set settings=$1 where id=$2',[{approved_queue_notice:{hi:{approved:false,version:'synthetic-v1',text:'Synthetic token {token_number}'}}},ids.clinicA]);
  assert.equal((await rpc('mock_accept',claim)).code,'QUEUE_NOTICE_UNAPPROVED');
  assert.equal((await f.db.query('select count(*)::integer n from public.mock_deliveries')).rows[0].n,0);
});
test('invalid copy shapes and disabled recipient language become review tasks rather than messages',async()=>{
  const {a,b}=await prepareNotice();
  await f.db.exec('delete from public.outbox; delete from public.staff_alerts;');
  await f.db.query('update public.clinics set settings=$1 where id=$2',[{approved_queue_notice:{hi:{approved:true,version:'synthetic-v1',text:{bad:'not approved text'}}}},ids.clinicA]);
  await add(third);
  assert.equal((await f.db.query('select count(*)::integer n from public.outbox')).rows[0].n,0);
  await f.db.query('update public.clinics set settings=$1 where id=$2',[{approved_queue_notice:{hi:{approved:true,version:'synthetic-v1',text:'Synthetic token {token_number}'}}},ids.clinicA]);
  await f.db.exec("update public.clinic_features set enabled=false where feature='lang_hi'");
  await run('skip',{doctor_id:doctor,id:(await read()).tokens.find(token=>token.patient_id===third).id},crypto.randomUUID());
  assert.equal((await f.db.query('select count(*)::integer n from public.outbox')).rows[0].n,0);
  assert.equal((await read()).tokens.find(token=>token.id===a.token.id).status,'called');assert.equal((await read()).tokens.find(token=>token.id===b.token.id).status,'waiting');
});
