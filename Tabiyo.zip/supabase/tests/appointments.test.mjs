import test,{before,beforeEach,after} from 'node:test';
import assert from 'node:assert/strict';
import {fixture,ids} from './helpers.mjs';
let f,day;
const doctor='30000000-0000-4000-8000-000000000001',otherDoctor='30000000-0000-4000-8000-000000000002';
const doctorUser='10000000-0000-4000-8000-000000000098',family='40000000-0000-4000-8000-000000000002';
before(async()=>{
  f=await fixture();day=(await f.db.query("select ((clock_timestamp() at time zone 'Asia/Kolkata')::date+1)::text as booking_date")).rows[0].booking_date;
  await f.db.query('insert into auth.users values($1)',[doctorUser]);
  await f.db.query("insert into public.staff_users(id,clinic_id,name,role) values($1,$2,'Synthetic Booking Doctor','doctor')",[doctorUser,ids.clinicA]);
  await f.db.query('update public.doctors set staff_user_id=$1 where id=$2',[doctorUser,doctor]);
});
after(()=>f?.db.close());
beforeEach(async()=>{
  await f.db.exec('truncate public.staff_operation_requests,public.api_requests,public.consents,public.message_log,public.mock_deliveries,public.delivery_receipts,public.staff_alerts,public.events,public.audit_log,public.outbox,public.appointments,public.doctor_schedules,public.doctor_leaves cascade;');
  await f.db.query("insert into public.doctor_schedules(clinic_id,doctor_id,weekday,start_time,end_time,break_start,break_end) select $1,d.id,w,'09:00','17:00','13:00','14:00' from public.doctors d cross join generate_series(0,6) w where d.clinic_id=$1",[ids.clinicA]);
  await f.db.query("update public.clinics set settings='{}'");
});
const at=(time='04:30')=>`${day}T${time}:00.000Z`;
const read=(user,action,input={})=>f.asUser(user,async tx=>(await tx.query('select public.tabiyo_appointment_read($1,$2::jsonb) result',[action,JSON.stringify(input)])).rows[0].result);
const write=(user,action,input,key=crypto.randomUUID())=>f.asUser(user,async tx=>(await tx.query('select public.tabiyo_appointment_write($1,$2::jsonb,$3) result',[action,JSON.stringify(input),key])).rows[0].result);
const book=(options={},user=ids.frontA,key)=>write(user,'create',{doctor_id:doctor,patient_id:ids.patientA,starts_at:at(),source:'phone',...options},key);
const count=async table=>(await f.db.query(`select count(*)::integer n from public.${table}`)).rows[0].n;
test('availability respects slot duration, IST hours, breaks, leave and clinic holidays',async()=>{
  let slots=(await read(ids.frontA,'slots',{doctor_id:doctor,date:day})).slots;assert.equal(slots.length,14);
  assert.equal(new Date(slots[0].starts_at).toISOString(),at('03:30'));
  assert.ok(!slots.some(slot=>new Date(slot.starts_at).toISOString()===at('07:30')));
  await f.db.query('insert into public.doctor_leaves(clinic_id,doctor_id,date_from,date_to) values($1,$2,$3,$3)',[ids.clinicA,doctor,day]);
  assert.equal((await read(ids.frontA,'slots',{doctor_id:doctor,date:day})).slots.length,0);
  await f.db.exec('delete from public.doctor_leaves');
  await f.db.query('update public.clinics set settings=$1 where id=$2',[{holidays:[day]},ids.clinicA]);
  assert.equal((await read(ids.frontA,'slots',{doctor_id:doctor,date:day})).slots.length,0);
});
test('booking is atomic, audited and idempotent with one confirmation queue record',async()=>{
  const key=crypto.randomUUID(),a=await book({},ids.frontA,key),b=await book({},ids.frontA,key);
  assert.equal(a.appointment.id,b.appointment.id);assert.equal(b.replayed,true);
  assert.equal(await count('appointments'),1);assert.equal((await f.db.query("select count(*)::integer n from public.outbox where purpose='appointment'")).rows[0].n,1);assert.equal(await count('events'),1);
  assert.equal(a.appointment.clinic_id,ids.clinicA);assert.equal(a.appointment.source,'phone');
  assert.equal((await f.db.query('select payload from public.outbox')).rows[0].payload.template_name,'appointment_confirmed');
  await assert.rejects(book({starts_at:at('05:00')},ids.frontA,key),/IDEMPOTENCY_CONFLICT/);
});
test('competing bookings yield one success and up to three available alternatives',async()=>{
  const results=await Promise.all([book(),book({patient_id:family})]);
  assert.equal(results.filter(result=>!result.conflict).length,1);assert.equal(await count('appointments'),1);
  const conflict=results.find(result=>result.conflict);assert.equal(conflict.alternatives.length,3);
  assert.ok(conflict.alternatives.every(slot=>new Date(slot.starts_at).toISOString()!==at()));
});
test('database exclusions independently reject doctor and patient overlap, allowing adjacent slots',async()=>{
  await book();
  const insert=(patient,selectedDoctor,start,end)=>f.db.query("insert into public.appointments(clinic_id,patient_id,doctor_id,starts_at,ends_at,source) values($1,$2,$3,$4,$5,'phone')",[ids.clinicA,patient,selectedDoctor,start,end]);
  await assert.rejects(insert(family,doctor,at('04:45'),at('05:15')),/exclusion constraint/);
  await assert.rejects(insert(ids.patientA,otherDoctor,at(),at('05:00')),/exclusion constraint/);
  await insert(family,doctor,at('05:00'),at('05:30'));assert.equal(await count('appointments'),2);
});
test('patient cannot book simultaneous visits with different doctors',async()=>{
  await book();const conflict=await book({doctor_id:otherDoctor});assert.equal(conflict.conflict,true);
  assert.ok(conflict.alternatives.every(slot=>new Date(slot.starts_at).toISOString()!==at()));
});
test('reschedule preserves original on conflict, then skips stale queued confirmations on success',async()=>{
  const a=await book(),b=await book({patient_id:family,starts_at:at('05:00')});
  const conflict=await write(ids.frontA,'reschedule',{id:a.appointment.id,starts_at:at('05:00')});assert.equal(conflict.conflict,true);
  let row=(await f.db.query('select * from public.appointments where id=$1',[a.appointment.id])).rows[0];assert.equal(new Date(row.starts_at).toISOString(),at());
  const moved=await write(ids.frontA,'reschedule',{id:a.appointment.id,starts_at:at('05:30')});assert.equal(new Date(moved.appointment.starts_at).toISOString(),at('05:30'));
  assert.notEqual(a.appointment.id,b.appointment.id);
  assert.equal((await f.db.query("select count(*)::integer n from public.outbox where status='skipped' and purpose='appointment'")).rows[0].n,1);
});
test('past, malformed, beyond-horizon and unaligned bookings cannot commit',async()=>{
  await assert.rejects(book({starts_at:'2000-01-01T04:30:00Z'}),/APPOINTMENT_TIME_INVALID/);
  await assert.rejects(book({starts_at:'not-a-date'}),/invalid input syntax/);
  const far=(await f.db.query("select (clock_timestamp()+interval '100 days')::text t")).rows[0].t;
  await assert.rejects(book({starts_at:far}),/APPOINTMENT_TIME_INVALID/);
  assert.equal((await book({starts_at:at('04:45')})).conflict,true);assert.equal(await count('appointments'),0);
});
test('cross-clinic references and doctor access to another schedule are denied',async()=>{
  await assert.rejects(book({patient_id:ids.patientB}),/PATIENT_NOT_FOUND/);
  await assert.rejects(book({},ids.adminB),/PATIENT_NOT_FOUND/);
  assert.equal((await read(doctorUser,'doctors')).doctors.length,1);
  await assert.rejects(book({doctor_id:otherDoctor},doctorUser),/DOCTOR_NOT_FOUND/);
  await assert.rejects(read(doctorUser,'slots',{doctor_id:otherDoctor,date:day}),/DOCTOR_NOT_FOUND/);
  const row=await book({patient_id:family,doctor_id:otherDoctor});
  await assert.rejects(write(doctorUser,'cancel',{id:row.appointment.id}),/DOCTOR_NOT_FOUND/);
});
test('day view includes all family identities with audited reads but only the doctor’s own schedule',async()=>{
  await book();await book({patient_id:family,doctor_id:otherDoctor});
  const result=await read(ids.frontA,'day',{date:day});assert.equal(result.appointments.length,2);
  assert.ok(result.appointments.every(item=>item.patient_name));
  assert.equal((await read(doctorUser,'day',{date:day})).appointments.length,1);
  assert.equal((await read(ids.adminB,'day',{date:day})).appointments.length,0);
});
test('invalid status transitions and checking in a future day are blocked',async()=>{
  const a=await book();
  for(const action of ['complete','no_show','check_in'])await assert.rejects(write(ids.frontA,action,{id:a.appointment.id}),/APPOINTMENT_STATE_INVALID/);
  const cancelled=await write(ids.frontA,'cancel',{id:a.appointment.id});assert.equal(cancelled.appointment.status,'cancelled');
  await assert.rejects(write(ids.frontA,'reschedule',{id:a.appointment.id,starts_at:at('05:00')}),/APPOINTMENT_STATE_INVALID/);
});
test('same-day check-in and completion work; completed visits cannot be resurrected',async()=>{
  const row=(await f.db.query("insert into public.appointments(clinic_id,patient_id,doctor_id,starts_at,ends_at,source) values($1,$2,$3,clock_timestamp()-interval '2 hours',clock_timestamp()-interval '1 hour','walk_in') returning id",[ids.clinicA,ids.patientA,doctor])).rows[0];
  // The fixture uses UTC/IST mid-day; a day-boundary run uses the clinic-day beginning instead.
  await f.db.query("update public.appointments set starts_at=((clock_timestamp() at time zone 'Asia/Kolkata')::date)::timestamp at time zone 'Asia/Kolkata',ends_at=clock_timestamp()+interval '1 minute' where id=$1",[row.id]);
  assert.equal((await write(ids.frontA,'check_in',{id:row.id})).appointment.status,'checked_in');
  assert.equal((await write(ids.frontA,'complete',{id:row.id})).appointment.status,'completed');
  await assert.rejects(write(ids.frontA,'cancel',{id:row.id}),/APPOINTMENT_STATE_INVALID/);
});
test('cancellation skips queued messages and creates a staff notice task without inventing approved copy',async()=>{
  const a=await book(),key=crypto.randomUUID();
  await write(ids.frontA,'cancel',{id:a.appointment.id},key);
  assert.equal((await f.db.query('select status from public.outbox')).rows[0].status,'skipped');
  assert.equal((await f.db.query('select code from public.staff_alerts')).rows[0].code,'APPOINTMENT_CANCEL_NOTICE_REQUIRED');
  assert.equal((await write(ids.frontA,'cancel',{id:a.appointment.id},key)).replayed,true);
  assert.equal(await count('staff_alerts'),1);
});
test('direct writes, source spoofing, inactive staff and anonymous calls are denied',async()=>{
  await assert.rejects(book({source:'whatsapp'}),/INPUT_INVALID/);
  await assert.rejects(book({},ids.inactive),/STAFF_FORBIDDEN/);
  await assert.rejects(f.asUser(ids.frontA,tx=>tx.query('delete from public.appointments')),/permission denied/);
  await assert.rejects(f.asUser(ids.frontA,tx=>tx.query('insert into public.doctor_schedules(clinic_id,doctor_id,weekday,start_time,end_time) values($1,$2,1,$3,$4)',[ids.clinicA,doctor,'09:00','17:00'])),/permission denied/);
  await assert.rejects(f.asUser(null,tx=>tx.query("select public.tabiyo_appointment_read('doctors','{}')"),'anon'),/permission denied/);
});

test('24-hour and two-hour reminders are atomic and durable, with stale jobs skipped on reschedule',async()=>{
  const later=(await f.db.query("select ((clock_timestamp() at time zone 'Asia/Kolkata')::date+3)::text as booking_date")).rows[0].booking_date;
  const key=crypto.randomUUID(),a=await book({starts_at:later+'T04:30:00.000Z'},ids.frontA,key);
  await book({starts_at:later+'T04:30:00.000Z'},ids.frontA,key);
  const reminders=(await f.db.query("select * from public.outbox where purpose='reminder' order by not_before")).rows;
  assert.equal(reminders.length,2);
  assert.deepEqual(reminders.map(row=>row.payload.reminder_hours),[24,2]);
  assert.equal(new Date(reminders[0].not_before).getTime(),Date.parse(a.appointment.starts_at)-24*3600_000);
  await write(ids.frontA,'reschedule',{id:a.appointment.id,starts_at:later+'T05:00:00.000Z'});
  assert.equal((await f.db.query("select count(*)::integer n from public.outbox where purpose='reminder' and status='skipped'")).rows[0].n,2);
  assert.equal((await f.db.query("select count(*)::integer n from public.outbox where purpose='reminder' and status='queued'")).rows[0].n,2);
});

test('prepared confirmation is fenced if staff cancel before mock acceptance',async()=>{
  const a=await book();
  await f.db.query("insert into public.consents(clinic_id,patient_id,version,status,channel) values($1,$2,'synthetic-v1','granted','phone')",[ids.clinicA,ids.patientA]);
  await f.db.query('update public.clinics set settings=$1 where id=$2',[{approved_templates:{'appointment_confirmed:te':true}},ids.clinicA]);
  await f.db.query("insert into public.clinic_features(clinic_id,feature,enabled) values($1,'lang_te',true) on conflict(clinic_id,feature) do update set enabled=true",[ids.clinicA]);
  const time=day+'T03:30:00.000Z';
  const delivery=(action,input)=>f.asUser(null,async tx=>(await tx.query('select public.tabiyo_delivery($1,$2::jsonb,$3::timestamptz) result',[action,JSON.stringify(input),time])).rows[0].result,'service_role');
  const claim=await delivery('claim',{worker_id:crypto.randomUUID()});
  assert.equal((await delivery('prepare',claim)).action,'send');
  await write(ids.frontA,'cancel',{id:a.appointment.id});
  const result=await delivery('mock_accept',claim);
  assert.equal(result.action,'skip');assert.equal(result.code,'APPOINTMENT_CANCELLED');assert.equal(await count('mock_deliveries'),0);
});
