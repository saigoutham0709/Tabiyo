import test,{before,beforeEach,after} from 'node:test';
import assert from 'node:assert/strict';
import {fixture,ids} from './helpers.mjs';
let f;
const doctor='10000000-0000-4000-8000-000000000099';
before(async()=>{
  f=await fixture();
  await f.db.query('insert into auth.users values($1)',[doctor]);
  await f.db.query("insert into public.staff_users(id,clinic_id,name,role) values($1,$2,'Synthetic Doctor','doctor')",[doctor,ids.clinicA]);
});
after(()=>f?.db.close());
beforeEach(()=>f.db.exec('truncate public.staff_operation_requests,public.consents,public.message_log,public.delivery_receipts,public.mock_deliveries,public.staff_alerts,public.events,public.audit_log,public.api_requests,public.outbox;'));
const run=(user,action,input={})=>f.asUser(user,async tx=>(await tx.query('select public.tabiyo_staff_operations($1,$2::jsonb) result',[action,JSON.stringify(input)])).rows[0].result);
const count=async table=>(await f.db.query(`select count(*)::integer n from public.${table}`)).rows[0].n;
async function alert(clinic=ids.clinicA,key=crypto.randomUUID()){
  return (await f.db.query("insert into public.staff_alerts(clinic_id,code,dedup_key) values($1,'SYNTHETIC_ALERT',$2) returning id",[clinic,key])).rows[0].id;
}
async function uncertain(evidence=false){
  const id=(await f.db.query(`insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key,status,attempts,prepared_at)
    values($1,$2,'template','appointment','{"private":"never returned"}',$3,'uncertain',1,clock_timestamp()) returning id`,[ids.clinicA,ids.patientA,crypto.randomUUID()])).rows[0].id;
  if(evidence)await f.db.query("insert into public.mock_deliveries values($1,$2,$3,'{}',clock_timestamp())",[id,ids.clinicA,'wamid.review.'+id]);
  await alert(ids.clinicA,'failure/'+id+'/WA_ACCEPTANCE_UNKNOWN');
  return id;
}
test('alert lists are clinic-scoped, bounded, sanitized and audited',async()=>{
  const id=await alert();await alert(ids.clinicB);await alert();
  const result=await run(ids.frontA,'alerts',{limit:1});
  assert.equal(result.alerts.length,1);assert.equal(result.alerts[0].clinic_id,ids.clinicA);
  assert.ok(!('dedup_key' in result.alerts[0]));assert.equal(await count('audit_log'),1);
  const own=await run(ids.adminB,'alerts');assert.equal(own.alerts.length,1);assert.notEqual(own.alerts[0].id,id);
});
test('front desk can resolve ordinary alerts once with idempotent audit and actor proof',async()=>{
  const id=await alert(),input={id,request_id:crypto.randomUUID(),resolution_code:'investigated'};
  const first=await run(ids.frontA,'resolve_alert',input),second=await run(ids.frontA,'resolve_alert',input);
  assert.equal(first.status,'resolved');assert.equal(second.replayed,true);
  assert.equal(await count('events'),1);assert.equal(await count('audit_log'),1);
  const row=(await f.db.query('select * from public.staff_alerts where id=$1',[id])).rows[0];
  assert.equal(row.resolved_by,ids.frontA);assert.ok(row.resolved_at);
  await assert.rejects(run(ids.adminA,'resolve_alert',input),/IDEMPOTENCY_CONFLICT/);
  await assert.rejects(run(ids.frontA,'resolve_alert',{...input,request_id:crypto.randomUUID()}),/ALERT_ALREADY_RESOLVED/);
});
test('cross-clinic alert writes and inactive staff are denied without side effects',async()=>{
  const id=await alert(ids.clinicB),input={id,request_id:crypto.randomUUID(),resolution_code:'investigated'};
  await assert.rejects(run(ids.adminA,'resolve_alert',input),/ALERT_NOT_FOUND/);
  await assert.rejects(run(ids.inactive,'alerts'),/STAFF_FORBIDDEN/);
  assert.equal(await count('staff_operation_requests'),0);
});
test('doctor operational scope and front-desk delivery review default to denied',async()=>{
  const id=await uncertain();
  await assert.rejects(run(doctor,'alerts'),/OPERATION_FORBIDDEN/);
  await assert.rejects(run(ids.frontA,'uncertain'),/OPERATION_FORBIDDEN/);
  await assert.rejects(run(ids.frontA,'reconcile_mock',{id,request_id:crypto.randomUUID()}),/OPERATION_FORBIDDEN/);
});
test('admin uncertainty listing exposes no provider payload, phone, or message body',async()=>{
  await uncertain();const result=await run(ids.adminA,'uncertain',{limit:10});
  assert.equal(result.deliveries.length,1);assert.equal(result.deliveries[0].has_mock_evidence,false);
  assert.ok(!JSON.stringify(result).includes('never returned'));assert.ok(!JSON.stringify(result).includes('+91'));
});
test('missing acceptance proof stays uncertain and cannot be hidden by ordinary alert resolution',async()=>{
  const id=await uncertain(),input={id,request_id:crypto.randomUUID()};
  const result=await run(ids.adminA,'reconcile_mock',input);
  assert.equal(result.resolution,'held');assert.equal(result.status,'uncertain');
  const a=(await f.db.query('select id from public.staff_alerts')).rows[0].id;
  await assert.rejects(run(ids.adminA,'resolve_alert',{id:a,request_id:crypto.randomUUID(),resolution_code:'no_action_required'}),/DELIVERY_REVIEW_REQUIRED/);
  assert.equal(await count('message_log'),0);assert.equal(await count('mock_deliveries'),0);
  assert.equal((await run(ids.adminA,'reconcile_mock',input)).replayed,true);
});
test('durable mock acceptance completes without sending again even after STOP',async()=>{
  const id=await uncertain(true),input={id,request_id:crypto.randomUUID()};
  await f.db.query('update public.patients set opted_out=true where id=$1',[ids.patientA]);
  const result=await run(ids.adminA,'reconcile_mock',input);
  assert.equal(result.status,'sent');assert.equal(result.resolution,'accepted');
  assert.equal(await count('mock_deliveries'),1);assert.equal(await count('message_log'),1);
  assert.equal((await f.db.query('select status from public.staff_alerts')).rows[0].status,'resolved');
  assert.equal((await run(ids.adminA,'reconcile_mock',input)).replayed,true);
  assert.equal(await count('message_log'),1);
  assert.equal((await f.db.query('select attempts from public.outbox')).rows[0].attempts,1);
  await f.db.query('update public.patients set opted_out=false where id=$1',[ids.patientA]);
});
test('accepted evidence cannot be discarded through manual closure',async()=>{
  const id=await uncertain(true);
  await assert.rejects(run(ids.adminA,'close_without_resend',{id,request_id:crypto.randomUUID(),resolution_code:'patient_contacted'}),/ACCEPTANCE_EVIDENCE_EXISTS/);
  assert.equal((await f.db.query('select status from public.outbox')).rows[0].status,'uncertain');
  assert.equal(await count('staff_operation_requests'),0);
});
test('reason-required manual closure never queues a resend and remains idempotent',async()=>{
  const id=await uncertain(),input={id,request_id:crypto.randomUUID(),resolution_code:'patient_contacted'};
  await assert.rejects(run(ids.adminA,'close_without_resend',{...input,resolution_code:undefined}),/INPUT_INVALID/);
  const result=await run(ids.adminA,'close_without_resend',input);
  assert.equal(result.status,'failed');assert.equal(result.resolution,'closed_without_resend');
  const row=(await f.db.query('select * from public.outbox')).rows[0];assert.equal(row.last_error,'MANUAL_NO_RESEND');
  assert.equal(await count('mock_deliveries'),0);assert.equal(await count('message_log'),0);
  assert.equal((await run(ids.adminA,'close_without_resend',input)).replayed,true);
  await assert.rejects(run(ids.adminA,'reconcile_mock',{id,request_id:crypto.randomUUID()}),/DELIVERY_NOT_UNCERTAIN/);
});
test('request keys reject changed inputs and cannot be reused for another target',async()=>{
  const id=await uncertain(),other=await uncertain(),key=crypto.randomUUID();
  await run(ids.adminA,'reconcile_mock',{id,request_id:key});
  await assert.rejects(run(ids.adminA,'reconcile_mock',{id:other,request_id:key}),/IDEMPOTENCY_CONFLICT/);
});
test('direct RPC inputs and ledger writes cannot bypass the operation contract',async()=>{
  for(const input of [{limit:101},{clinic_id:ids.clinicB},{status:'all'}])await assert.rejects(run(ids.adminA,'alerts',input),/INPUT_INVALID/);
  await assert.rejects(run(ids.adminA,'uncertain',{status:'open'}),/INPUT_INVALID/);
  await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('select * from public.staff_operation_requests')),/permission denied/);
  await assert.rejects(f.asUser(null,tx=>tx.query("select public.tabiyo_staff_operations('alerts','{}')"),'anon'),/permission denied/);
  await assert.rejects(f.asUser(null,tx=>tx.query("delete from public.staff_operation_requests"),'service_role'),/permission denied/);
});
