import test,{before,beforeEach,after} from 'node:test';
import assert from 'node:assert/strict';
import {fixture,ids} from './helpers.mjs';
let f,day,weekday;
const doctor='30000000-0000-4000-8000-000000000001';
before(async()=>{f=await fixture();const date=(await f.db.query("select ((clock_timestamp() at time zone 'Asia/Kolkata')::date+1)::text as day_value,extract(dow from (clock_timestamp() at time zone 'Asia/Kolkata')::date+1)::integer as weekday")).rows[0];day=date.day_value;weekday=date.weekday;});
after(()=>f?.db.close());
beforeEach(async()=>{
  await f.db.exec('truncate public.staff_operation_requests,public.api_requests,public.consents,public.message_log,public.mock_deliveries,public.delivery_receipts,public.staff_alerts,public.events,public.audit_log,public.outbox,public.appointments,public.doctor_schedules,public.doctor_leaves cascade; update public.doctors set schedule_revision=0;');
});
const run=(action,input={},key=null,user=ids.adminA)=>f.asUser(user,async tx=>(await tx.query('select public.tabiyo_doctor_management($1,$2::jsonb,$3) result',[action,JSON.stringify({doctor_id:doctor,...input}),key])).rows[0].result);
const schedule=(changes={},key=crypto.randomUUID())=>run('schedule',{expected_revision:0,weekday,start_time:'09:00',end_time:'17:00',...changes},key);
async function book(){return f.asUser(ids.frontA,async tx=>(await tx.query("select public.tabiyo_appointment_write('create',$1::jsonb,$2) result",[JSON.stringify({doctor_id:doctor,patient_id:ids.patientA,starts_at:day+'T04:30:00Z',source:'phone'}),crypto.randomUUID()])).rows[0].result);}
test('admin configures hours and breaks without SQL access; revision and request replay are stable',async()=>{
  const key=crypto.randomUUID(),first=await schedule({break_start:'13:00',break_end:'14:00'},key);
  assert.equal(first.revision,1);assert.equal((await schedule({break_start:'13:00',break_end:'14:00'},key)).replayed,true);
  const config=await run('read');assert.equal(config.schedules.length,1);assert.equal(config.schedules[0].start_time,'09:00:00');assert.equal(config.schedules[0].break_start,'13:00:00');
  assert.equal(config.revision,1);assert.equal(config.affected_count,0);
});
test('stale revision and reused request keys reject lost updates',async()=>{
  const key=crypto.randomUUID();await schedule({},key);
  await assert.rejects(schedule({end_time:'16:00'}),/AVAILABILITY_CHANGED/);
  await assert.rejects(schedule({end_time:'16:00'},key),/IDEMPOTENCY_CONFLICT/);
  assert.equal((await run('read')).schedules[0].end_time,'17:00:00');
});
test('front desk and foreign clinic admins cannot manage or inspect this availability',async()=>{
  await assert.rejects(run('read',{},null,ids.frontA),/OPERATION_FORBIDDEN/);
  await assert.rejects(run('read',{},null,ids.adminB),/DOCTOR_NOT_FOUND/);
  await assert.rejects(run('read',{},null,ids.inactive),/STAFF_FORBIDDEN/);
});
test('invalid hours, partial breaks and arbitrary fields roll back the revision',async()=>{
  for(const input of [{end_time:'08:00'},{break_start:'13:00'},{break_start:'08:00',break_end:'10:00'},{start_time:'24:00'},{clinic_id:ids.clinicB}]){
    await assert.rejects(schedule(input));assert.equal((await run('read')).revision,0);
  }
});
test('hours changes preserve bookings and raise an actionable review alert',async()=>{
  await schedule();const a=await book();
  const changed=await schedule({expected_revision:1,start_time:'11:00'});assert.equal(changed.affected_count,1);assert.ok(changed.notice_alert_id);
  const config=await run('read');assert.equal(config.affected_appointments[0].id,a.appointment.id);assert.ok(config.affected_appointments[0].patient_name);
  assert.equal((await f.db.query('select status from public.appointments')).rows[0].status,'booked');
  const alerts=await f.asUser(ids.frontA,async tx=>(await tx.query("select public.tabiyo_staff_operations('alerts','{}') result")).rows[0].result);
  assert.deepEqual(alerts.alerts[0].context,{doctor_id:doctor});
});
test('leave changes are reason-coded, idempotent, bounded and reversible without deleting appointments',async()=>{
  await schedule();await book();const key=crypto.randomUUID(),input={expected_revision:1,date_from:day,date_to:day,reason:'planned_leave'};
  const changed=await run('leave',input,key);assert.equal(changed.affected_count,1);
  assert.equal((await run('leave',input,key)).replayed,true);
  const config=await run('read');assert.equal(config.leaves.length,1);
  await assert.rejects(run('leave',{...input,expected_revision:2},crypto.randomUUID()),/LEAVE_ALREADY_EXISTS/);
  await run('delete_leave',{expected_revision:2,leave_id:config.leaves[0].id},crypto.randomUUID());
  assert.equal((await run('read')).affected_count,0);assert.equal((await f.db.query('select count(*)::integer n from public.appointments')).rows[0].n,1);
  await assert.rejects(run('leave',{expected_revision:3,date_from:'2000-01-01',date_to:'2000-01-02',reason:'planned_leave'},crypto.randomUUID()),/INPUT_INVALID/);
});
test('closing a weekday removes availability and preserves the affected appointment',async()=>{
  await schedule();await book();const result=await run('delete_schedule',{expected_revision:1,weekday},crypto.randomUUID());
  assert.equal(result.affected_count,1);assert.equal((await run('read')).schedules.length,0);
  assert.equal((await f.db.query('select status from public.appointments')).rows[0].status,'booked');
});
test('new availability restrictions fence an already-prepared confirmation before acceptance',async()=>{
  await schedule();await book();
  await f.db.query("insert into public.consents(clinic_id,patient_id,version,status,channel) values($1,$2,'synthetic','granted','phone')",[ids.clinicA,ids.patientA]);
  await f.db.query('update public.clinics set settings=$1 where id=$2',[{approved_templates:{'appointment_confirmed:te':true}},ids.clinicA]);
  await f.db.query("insert into public.clinic_features(clinic_id,feature,enabled) values($1,'lang_te',true)",[ids.clinicA]);
  const rpc=(action,input)=>f.asUser(null,async tx=>(await tx.query('select public.tabiyo_delivery($1,$2::jsonb,$3) result',[action,JSON.stringify(input),day+'T03:30:00Z'])).rows[0].result,'service_role');
  const claim=await rpc('claim',{worker_id:crypto.randomUUID()});assert.equal((await rpc('prepare',claim)).action,'send');
  await schedule({expected_revision:1,start_time:'11:00'});
  const result=await rpc('mock_accept',claim);assert.equal(result.code,'DOCTOR_UNAVAILABLE');assert.equal(result.action,'skip');
  assert.equal((await f.db.query('select count(*)::integer n from public.mock_deliveries')).rows[0].n,0);
});
test('alert context refuses arbitrary data and anonymous RPC access is denied',async()=>{
  await assert.rejects(f.db.query("insert into public.staff_alerts(clinic_id,code,dedup_key,context) values($1,'SYNTHETIC','bad',$2)",[ids.clinicA,{body:'private text'}]),/check constraint/);
  await assert.rejects(f.db.query("insert into public.staff_alerts(clinic_id,code,dedup_key,context) values($1,'SYNTHETIC','bad-null',$2)",[ids.clinicA,{doctor_id:null}]),/check constraint/);
  await assert.rejects(f.asUser(null,tx=>tx.query("select public.tabiyo_doctor_management('read','{}')"),'anon'),/permission denied/);
});
test('availability alerts cannot be closed while affected bookings still conflict',async()=>{
  await schedule();await book();const changed=await schedule({expected_revision:1,start_time:'11:00'});
  const input={id:changed.notice_alert_id,request_id:crypto.randomUUID(),resolution_code:'investigated'};
  const resolve=()=>f.asUser(ids.frontA,async tx=>(await tx.query("select public.tabiyo_staff_operations('resolve_alert',$1::jsonb) result",[JSON.stringify(input)])).rows[0].result);
  await assert.rejects(resolve(),/AVAILABILITY_REVIEW_REQUIRED/);
  await schedule({expected_revision:2});
  assert.equal((await resolve()).status,'resolved');assert.equal((await resolve()).replayed,true);
});
