import test, {before, beforeEach, after} from 'node:test';
import assert from 'node:assert/strict';
import {fixture, ids} from './helpers.mjs';
let f;
before(async () => { f = await fixture(); });
after(() => f?.db.close());
beforeEach(async () => {
  await f.db.exec('truncate public.consents,public.message_log,public.delivery_receipts,public.mock_deliveries,public.staff_alerts,public.events,public.audit_log,public.api_requests,public.outbox,public.gateway_security,public.gateway_maintenance;');
});
const service = (sql, parameters = []) => f.asUser(null, tx => tx.query(sql, parameters), 'service_role');
const retention = async () => (await service('select public.tabiyo_retention() as result')).rows[0].result;
const count = async table => (await f.db.query(`select count(*)::integer as n from public.${table}`)).rows[0].n;
async function outbox(status = 'sent', age = 91, wa = null) {
  return (await f.db.query(`insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key,status,last_activity_at,wa_message_id)
    values($1,$2,'template','appointment','{}',$3,$4,clock_timestamp()-$5*interval '1 day',$6) returning id`,
  [ids.clinicA, ids.patientA, crypto.randomUUID(), status, age, wa])).rows[0].id;
}
async function message(outboxId, wa, body = null) {
  await f.db.query(`insert into public.message_log(clinic_id,patient_id,outbox_id,wa_message_id,type,body_preview,created_at)
    values($1,$2,$3,$4,'template',$5,clock_timestamp()-interval '2 years')`, [ids.clinicA,ids.patientA,outboxId,wa,body]);
}
async function receipt(wa, status = 'read') {
  return (await service("select public.tabiyo_delivery('receipt',$1::jsonb) as result",
    [JSON.stringify({clinic_id:ids.clinicA,wa_message_id:wa,status,occurred_at:'2026-01-01T00:00:00Z'})])).rows[0].result;
}

test('retention denies staff and anonymous execution; service cannot erase records directly', async () => {
  await assert.rejects(f.asUser(ids.adminA, tx => tx.query('select public.tabiyo_retention()')), /permission denied/);
  await assert.rejects(f.asUser(null, tx => tx.query('select public.tabiyo_retention()'), 'anon'), /permission denied/);
  await assert.rejects(service('delete from public.api_requests'), /permission denied/);
  await retention();
});

test('expired replay responses are redacted while request keys block duplicate patient creation', async () => {
  const key = crypto.randomUUID(), input = {name:'Synthetic Retention Patient',mobile_e164:'+919000000002',language:'en'};
  const first = await f.write(ids.adminA,'create',input,key);
  await f.db.query("update public.api_requests set created_at=clock_timestamp()-interval '91 days' where request_id=$1", [key]);
  await assert.rejects(f.write(ids.adminA,'create',input,key), /REQUEST_REPLAY_EXPIRED/);
  const patients = await count('patients');
  assert.equal((await retention()).replay_responses, 1);
  const ledger = (await f.db.query('select * from public.api_requests where request_id=$1',[key])).rows[0];
  assert.deepEqual(ledger.response,{expired:true});
  assert.equal(ledger.patient_id,first.patient.id);
  assert.ok(ledger.response_expired_at);
  await assert.rejects(f.write(ids.adminA,'create',input,key), /REQUEST_REPLAY_EXPIRED/);
  assert.equal(await count('patients'),patients);
  assert.equal((await retention()).replay_responses,0);
});

test('only aged terminal outbox payloads and their mock evidence expire; accepted history remains', async () => {
  const old = await outbox('sent',91,'wamid.retained');
  await message(old,'wamid.retained');
  await f.db.query("insert into public.mock_deliveries values($1,$2,$3,'{}',clock_timestamp()-interval '91 days')",[old,ids.clinicA,'wamid.retained']);
  for (const status of ['queued','processing','uncertain']) await outbox(status,400);
  await outbox('sent',1);
  await outbox('failed',91);
  await outbox('skipped',91);
  assert.equal((await retention()).outbox,3);
  assert.equal(await count('outbox'),4);
  assert.equal(await count('mock_deliveries'),0);
  assert.equal(await count('message_log'),1);
  assert.equal((await f.db.query('select outbox_id from public.message_log')).rows[0].outbox_id,old);
});

test('outbox activity resets its expiry window even when original creation is old', async () => {
  const id = await outbox('failed',200);
  await f.db.query("update public.outbox set last_error='SYNTHETIC_REVIEW' where id=$1",[id]);
  assert.equal((await retention()).outbox,0);
});

test('late receipts after payload expiry retain events, deduplication, and monotonic delivery state', async () => {
  const id = await outbox('sent',91,'wamid.late');
  await message(id,'wamid.late');
  await retention();
  assert.equal((await receipt('wamid.late')).status,'read');
  assert.equal((await receipt('wamid.late','failed')).status,'read');
  assert.equal((await receipt('wamid.late')).duplicate,true);
  assert.equal(await count('delivery_receipts'),2);
  assert.equal((await f.db.query("select count(*)::integer n from public.events where type like 'message.%'")).rows[0].n,2);
  assert.equal(await count('staff_alerts'),0);
  assert.equal((await retention()).orphan_receipts,0);
});

test('old orphan receipts expire but pending acceptance evidence remains protected', async () => {
  await receipt('wamid.orphan');
  const pending = await outbox('uncertain',200);
  await f.db.query("insert into public.mock_deliveries values($1,$2,'wamid.pending','{}',clock_timestamp()-interval '200 days')",[pending,ids.clinicA]);
  await receipt('wamid.pending');
  assert.equal((await retention()).orphan_receipts,1);
  assert.equal(await count('delivery_receipts'),1);
  assert.equal(await count('mock_deliveries'),1);
});

test('replayed late failure never recreates a resolved and expired alert', async () => {
  const id=await outbox('sent',91,'wamid.late-failure');
  await message(id,'wamid.late-failure');
  await retention();
  assert.equal((await receipt('wamid.late-failure','failed')).status,'failed');
  assert.equal(await count('staff_alerts'),1);
  await f.db.exec("update public.staff_alerts set status='resolved'; update public.staff_alerts set resolved_at=clock_timestamp()-interval '91 days'");
  assert.equal((await retention()).resolved_alerts,1);
  await receipt('wamid.late-failure','failed');
  await receipt('wamid.late-failure','sent');
  assert.equal(await count('staff_alerts'),0);
});

test('one-year body redaction retains message identity and consent source proof', async () => {
  const id = await outbox('sent',1,'wamid.body');
  await message(id,'wamid.body','Synthetic private body');
  await f.db.query("insert into public.consents(clinic_id,patient_id,version,status,channel,source_message_id) values($1,$2,'v1','granted','whatsapp','wamid.body')",[ids.clinicA,ids.patientA]);
  assert.equal((await retention()).message_bodies,1);
  assert.equal((await f.db.query('select body_preview from public.message_log')).rows[0].body_preview,null);
  assert.equal(await count('consents'),1);
});

test('alert expiry uses resolution time and preserves open or legacy undated alerts', async () => {
  for (const [key,status,age] of [['old','resolved',100],['recent','resolved',1],['open','open',100],['legacy','resolved',null]]) {
    await f.db.query(`insert into public.staff_alerts(clinic_id,code,dedup_key,status,resolved_at,created_at)
      values($1,'SYNTHETIC',$2,$3,clock_timestamp()-$4*interval '1 day',clock_timestamp()-interval '400 days')`,[ids.clinicA,key,status,age]);
  }
  assert.equal((await retention()).resolved_alerts,1);
  await f.db.exec("update public.staff_alerts set status='resolved' where dedup_key='open'");
  assert.ok((await f.db.query("select resolved_at from public.staff_alerts where dedup_key='open'")).rows[0].resolved_at);
  assert.equal((await retention()).resolved_alerts,0);
  assert.equal(await count('staff_alerts'),3);
});

test('security and maintenance cleanup is bounded and leaves count-only evidence', async () => {
  await f.db.exec("insert into public.gateway_security(gateway_id,hour_start,failures) select 'synthetic-'||n,clock_timestamp()-interval '8 days',1 from generate_series(1,501) n");
  await f.db.exec("insert into public.gateway_maintenance(occurred_at,action,meta) select clock_timestamp()-interval '100 days','synthetic','{}' from generate_series(1,501)");
  const result = await retention();
  assert.equal(result.security_counters,500);
  assert.equal(result.maintenance_records,500);
  assert.equal(await count('gateway_security'),1);
  const evidence = (await f.db.query("select meta from public.gateway_maintenance where action='technical.retention'")).rows[0].meta;
  assert.ok(Object.values(evidence).every(value => typeof value === 'number'));
  await retention();
  assert.equal(await count('gateway_security'),0);
});
