import test,{before,after} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {PGlite} from '@electric-sql/pglite';
import {btree_gist} from '@electric-sql/pglite/contrib/btree_gist';

const db=new PGlite({extensions:{btree_gist}});
const clinicA='20000000-0000-4000-8000-000000000001',clinicB='20000000-0000-4000-8000-000000000002';
const adminA='10000000-0000-4000-8000-000000000001',doctorA='10000000-0000-4000-8000-000000000002',frontA='10000000-0000-4000-8000-000000000003',inactiveA='10000000-0000-4000-8000-000000000004',adminB='10000000-0000-4000-8000-000000000005',outsider='10000000-0000-4000-8000-000000000006';
const patientA='40000000-0000-4000-8000-000000000001',patientB='40000000-0000-4000-8000-000000000011';
before(async()=>{
  // Supabase-owned Auth objects/roles are represented only in this isolated test engine.
  await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
    create schema auth; create table auth.users(id uuid primary key);
    create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
    grant usage on schema public,auth to anon,authenticated,service_role;
    grant execute on function auth.uid() to anon,authenticated,service_role;`);
  for(const file of readdirSync(new URL('../migrations/',import.meta.url)).filter(name=>name.endsWith('.sql')).sort()){
    await db.exec(readFileSync(new URL('../migrations/'+file,import.meta.url),'utf8'));
  }
  // Exercise defense-in-depth RLS independently of the production table ACLs, now restricted to RPCs.
  await db.exec(`create role rls_probe; grant authenticated to rls_probe;
    grant select,insert,update on public.patients to rls_probe;
    grant select,insert on public.consents to rls_probe;`);
  await db.exec(readFileSync(new URL('../seed.sql',import.meta.url),'utf8'));
  await db.query('insert into public.clinics(id,name) values ($1,$2)',[clinicB,'Other Synthetic Clinic']);
  for(const [id,clinic,role,active] of [[adminA,clinicA,'admin',true],[doctorA,clinicA,'doctor',true],[frontA,clinicA,'front_desk',true],[inactiveA,clinicA,'admin',false],[adminB,clinicB,'admin',true]]){
    await db.query('insert into auth.users(id) values ($1)',[id]);
    await db.query('insert into public.staff_users(id,clinic_id,name,role,active) values ($1,$2,$3,$4,$5)',[id,clinic,'Synthetic Staff',role,active]);
  }
  await db.query('insert into public.doctors(clinic_id,name) values ($1,$2)',[clinicB,'Other Synthetic Doctor']);
  await db.query('insert into public.patients(id,clinic_id,name,mobile_e164) values ($1,$2,$3,$4)',[patientB,clinicB,'Other Synthetic Patient','+919000000011']);
  await db.query('insert into public.consents(clinic_id,patient_id,version,status,channel,created_by) values ($1,$2,$3,$4,$5,$6)',[clinicA,patientA,'fixture-v1','granted','dashboard',adminA]);
  await db.query('insert into public.consents(clinic_id,patient_id,version,status,channel,created_by) values ($1,$2,$3,$4,$5,$6)',[clinicB,patientB,'fixture-v1','granted','dashboard',adminB]);
});
after(()=>db.close());
async function asUser(user,run,role='rls_probe'){
  return db.transaction(async tx=>{
    // Role names are fixed test constants, never untrusted values.
    await tx.exec(role==='service_role'?'set local role service_role':role==='anon'?'set local role anon':role==='rls_probe'?'set local role rls_probe':'set local role authenticated');
    await tx.query("select set_config('request.jwt.claim.sub',$1,true)",[user??'']);
    return run(tx);
  });
}

test('seed creates required two doctors and ten fake patients; family shares phone',async()=>{
  assert.equal((await db.query('select count(*)::integer as n from public.doctors where clinic_id=$1',[clinicA])).rows[0].n,2);
  assert.equal((await db.query('select count(*)::integer as n from public.patients where clinic_id=$1',[clinicA])).rows[0].n,10);
  assert.equal((await db.query('select count(*)::integer as n from public.patients where clinic_id=$1 and mobile_e164=$2',[clinicA,'+919000000001'])).rows[0].n,2);
});
for(const table of ['clinics','staff_users','doctors','patients','consents']){
  test('RLS: clinic A cannot read clinic B through '+table,async()=>{
    const rows=(await asUser(adminA,tx=>tx.query('select * from public.'+table))).rows;
    assert(rows.length>0);assert(rows.every(row=>table==='clinics'?row.id===clinicA:row.clinic_id===clinicA));
    const reverse=(await asUser(adminB,tx=>tx.query('select * from public.'+table))).rows;
    assert(reverse.length>0);assert(reverse.every(row=>table==='clinics'?row.id===clinicB:row.clinic_id===clinicB));
  });
  test('RLS: inactive and nonmember cannot read '+table,async()=>{
    for(const user of [inactiveA,outsider])assert.equal((await asUser(user,tx=>tx.query('select * from public.'+table))).rows.length,0);
  });
}
test('doctor and front desk can read patients in own clinic',async()=>{
  for(const user of [doctorA,frontA])assert.equal((await asUser(user,tx=>tx.query('select * from public.patients'))).rows.length,10);
});
test('anonymous role has no table access',async()=>{
  for(const table of ['clinics','staff_users','doctors','patients','consents'])await assert.rejects(asUser(null,tx=>tx.query('select * from public.'+table),'anon'),/permission denied/);
});
test('same-phone create succeeds in own clinic; cross-clinic create denied',async()=>{
  await asUser(frontA,async tx=>{await tx.query('insert into public.patients(clinic_id,name,mobile_e164) values ($1,$2,$3)',[clinicA,'Synthetic Family Three','+919000000001']);});
  await assert.rejects(asUser(frontA,tx=>tx.query('insert into public.patients(clinic_id,name,mobile_e164) values ($1,$2,$3)',[clinicB,'Attempted Cross Clinic','+919000000001'])),/row-level security/);
});
test('cross-clinic update affects no rows; tenant reassignment fails WITH CHECK',async()=>{
  const result=await asUser(adminA,tx=>tx.query('update public.patients set name=$1 where id=$2 returning id',['Not Allowed',patientB]));assert.equal(result.rows.length,0);
  await assert.rejects(asUser(adminA,tx=>tx.query('update public.patients set clinic_id=$1 where id=$2',[clinicB,patientA])),/row-level security/);
});
test('staff cannot self-elevate, activate themselves or create membership',async()=>{
  await assert.rejects(asUser(frontA,tx=>tx.query("update public.staff_users set role='admin' where id=$1",[frontA])),/permission denied/);
  await assert.rejects(asUser(inactiveA,tx=>tx.query('update public.staff_users set active=true where id=$1',[inactiveA])),/permission denied/);
  await assert.rejects(asUser(outsider,tx=>tx.query('insert into public.staff_users(id,clinic_id,name,role) values ($1,$2,$3,$4)',[outsider,clinicA,'Self Invite','admin'])),/permission denied/);
});
test('consent insert is scoped and append-only, including service role',async()=>{
  await asUser(frontA,tx=>tx.query('insert into public.consents(clinic_id,patient_id,version,status,channel,created_by) values ($1,$2,$3,$4,$5,$6)',[clinicA,patientA,'fixture-v2','revoked','dashboard',frontA]));
  for(const role of ['authenticated','service_role']){
    await assert.rejects(asUser(adminA,tx=>tx.query("update public.consents set status='granted'"),role),/permission denied/);
    await assert.rejects(asUser(adminA,tx=>tx.query('delete from public.consents'),role),/permission denied/);
    await assert.rejects(asUser(adminA,tx=>tx.query('truncate public.consents'),role),/permission denied/);
  }
});
test('consent cannot reference another clinic patient or forged actor',async()=>{
  await assert.rejects(asUser(adminA,tx=>tx.query('insert into public.consents(clinic_id,patient_id,version,status,channel,created_by) values ($1,$2,$3,$4,$5,$6)',[clinicA,patientB,'fixture','granted','dashboard',adminA])),/foreign key/);
  await assert.rejects(asUser(frontA,tx=>tx.query('insert into public.consents(clinic_id,patient_id,version,status,channel,created_by) values ($1,$2,$3,$4,$5,$6)',[clinicA,patientA,'fixture','granted','dashboard',adminA])),/row-level security/);
});
test('merge and doctor staff links cannot cross tenant foreign keys',async()=>{
  await assert.rejects(db.query('update public.patients set merged_into=$1 where id=$2',[patientB,patientA]),/foreign key/);
  await assert.rejects(db.query('insert into public.doctors(clinic_id,staff_user_id,name) values ($1,$2,$3)',[clinicA,adminB,'Invalid Doctor Link']),/foreign key/);
});
test('all new tables have RLS enabled',async()=>{
  const rows=(await db.query("select relname,relrowsecurity from pg_class where relnamespace='public'::regnamespace and relkind='r'")).rows;
  assert.equal(rows.length,29);assert(rows.every(row=>row.relrowsecurity));
});
