import {readFileSync,readdirSync} from 'node:fs';
import {PGlite} from '@electric-sql/pglite';
import {btree_gist} from '@electric-sql/pglite/contrib/btree_gist';
export const ids={
  clinicA:'20000000-0000-4000-8000-000000000001',clinicB:'20000000-0000-4000-8000-000000000002',
  adminA:'10000000-0000-4000-8000-000000000001',frontA:'10000000-0000-4000-8000-000000000002',
  inactive:'10000000-0000-4000-8000-000000000003',adminB:'10000000-0000-4000-8000-000000000004',outsider:'10000000-0000-4000-8000-000000000005',
  patientA:'40000000-0000-4000-8000-000000000001',patientB:'40000000-0000-4000-8000-000000000011',
};
export async function fixture(){
  const db=new PGlite({extensions:{btree_gist}});
  await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
    create schema auth; create table auth.users(id uuid primary key);
    create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
    grant usage on schema public,auth to anon,authenticated,service_role;
    grant execute on function auth.uid() to anon,authenticated,service_role;`);
  for(const file of readdirSync(new URL('../migrations/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort()){
    await db.exec(readFileSync(new URL('../migrations/'+file,import.meta.url),'utf8'));
  }
  await db.exec(readFileSync(new URL('../seed.sql',import.meta.url),'utf8'));
  await db.query('insert into public.clinics(id,name) values ($1,$2)',[ids.clinicB,'Other Synthetic Clinic']);
  for(const [id,clinic,role,active] of [[ids.adminA,ids.clinicA,'admin',true],[ids.frontA,ids.clinicA,'front_desk',true],[ids.inactive,ids.clinicA,'admin',false],[ids.adminB,ids.clinicB,'admin',true]]){
    await db.query('insert into auth.users(id) values ($1)',[id]);
    await db.query('insert into public.staff_users(id,clinic_id,name,role,active) values ($1,$2,$3,$4,$5)',[id,clinic,'Synthetic Staff',role,active]);
  }
  await db.query('insert into public.patients(id,clinic_id,name,mobile_e164) values ($1,$2,$3,$4)',[ids.patientB,ids.clinicB,'Other Patient','+919000000001']);
  await db.exec(`insert into public.clinic_features(clinic_id,feature) select id,'ai_faq' from public.clinics;`);
  const asUser=(user,run,role='authenticated')=>db.transaction(async tx=>{
    await tx.exec(role==='service_role'?'set local role service_role':role==='anon'?'set local role anon':'set local role authenticated');
    await tx.query("select set_config('request.jwt.claim.sub',$1,true)",[user??'']);
    return run(tx);
  });
  const search=(user,mobile='+919000000001')=>asUser(user,async tx=>(await tx.query('select public.tabiyo_patient_search($1) as result',[mobile])).rows[0].result);
  const write=(user,operation,input,requestId=crypto.randomUUID(),patientId=null)=>asUser(user,async tx=>(await tx.query('select public.tabiyo_patient_write($1,$2::jsonb,$3::uuid,$4::uuid) as result',[operation,JSON.stringify(input),requestId,patientId])).rows[0].result);
  return {db,asUser,search,write};
}
