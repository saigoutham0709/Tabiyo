import test,{before,after} from 'node:test';
import assert from 'node:assert/strict';
import {fixture,ids} from './helpers.mjs';
let f;
before(async()=>{f=await fixture();});after(()=>f?.db.close());
const input={name:'Synthetic Family Member',mobile_e164:'+919000000001',language:'en'};
const count=async(table)=>(await f.db.query('select count(*)::integer as n from public.'+table)).rows[0].n;

test('search returns all family members only in caller clinic and audits every returned record',async()=>{
  const before=await count('audit_log');const patients=await f.search(ids.adminA);
  assert.equal(patients.length,2);assert(patients.every(p=>p.clinic_id===ids.clinicA));assert.equal(await count('audit_log'),before+2);
  assert.equal((await f.search(ids.adminB)).length,1);
});
test('new patient, consent-request outbox, event, audit and request ledger commit together',async()=>{
  const key=crypto.randomUUID();const result=await f.write(ids.frontA,'create',input,key);
  assert.equal(result.patient.clinic_id,ids.clinicA);assert.equal(result.patient.mobile_e164,input.mobile_e164);assert.equal(result.replayed,false);
  const outbox=(await f.db.query('select * from public.outbox where patient_id=$1',[result.patient.id])).rows;
  assert.equal(outbox.length,1);assert.equal(outbox[0].purpose,'consent_request');assert.equal(outbox[0].status,'queued');
  assert.equal((await f.db.query('select * from public.consents where patient_id=$1',[result.patient.id])).rows.length,0);
  assert.equal((await f.db.query('select * from public.events where patient_id=$1',[result.patient.id])).rows.length,1);
  assert.equal((await f.db.query('select * from public.audit_log where request_id=$1',[key])).rows.length,1);
  assert.equal((await f.db.query('select * from public.api_requests where request_id=$1',[key])).rows.length,1);
});
test('repeated create sends no duplicate logical consent request and preserves patient identity',async()=>{
  const key=crypto.randomUUID();const a=await f.write(ids.adminA,'create',input,key);const b=await f.write(ids.adminA,'create',input,key);
  assert.equal(a.patient.id,b.patient.id);assert.equal(b.replayed,true);
  assert.equal((await f.db.query('select * from public.outbox where patient_id=$1',[a.patient.id])).rows.length,1);
  assert.equal((await f.db.query('select * from public.events where patient_id=$1',[a.patient.id])).rows.length,1);
});
test('the same request UUID is isolated between clinics',async()=>{
  const key=crypto.randomUUID();const a=await f.write(ids.adminA,'create',input,key),b=await f.write(ids.adminB,'create',input,key);
  assert.notEqual(a.patient.id,b.patient.id);assert.equal(a.patient.clinic_id,ids.clinicA);assert.equal(b.patient.clinic_id,ids.clinicB);
});
test('request key cannot be reused with another body, operation or actor',async()=>{
  const key=crypto.randomUUID();const a=await f.write(ids.adminA,'create',input,key);
  await assert.rejects(f.write(ids.adminA,'create',{...input,name:'Other'},key),/IDEMPOTENCY_CONFLICT/);
  await assert.rejects(f.write(ids.frontA,'create',input,key),/IDEMPOTENCY_CONFLICT/);
  await assert.rejects(f.write(ids.adminA,'update',{name:'Other'},key,a.patient.id),/IDEMPOTENCY_CONFLICT/);
});
test('outbox failure rolls back patient, event, audit and replay ledger',async()=>{
  const sizes=await Promise.all(['patients','events','audit_log','api_requests'].map(count));
  await f.db.exec(`create function private.test_fail_outbox() returns trigger language plpgsql as $$ begin raise exception 'fixture outbox failure'; end $$;
    create trigger test_outbox_failure before insert on public.outbox for each row execute function private.test_fail_outbox();`);
  try{await assert.rejects(f.write(ids.adminA,'create',input),/fixture outbox failure/);}finally{await f.db.exec('drop trigger test_outbox_failure on public.outbox; drop function private.test_fail_outbox();');}
  assert.deepEqual(await Promise.all(['patients','events','audit_log','api_requests'].map(count)),sizes);
});
test('failed read audit prevents patient data from being returned',async()=>{
  await f.db.exec(`create function private.test_fail_audit() returns trigger language plpgsql as $$ begin raise exception 'fixture audit failure'; end $$;
    create trigger test_audit_failure before insert on public.audit_log for each row execute function private.test_fail_audit();`);
  try{await assert.rejects(f.search(ids.adminA),/fixture audit failure/);}finally{await f.db.exec('drop trigger test_audit_failure on public.audit_log; drop function private.test_fail_audit();');}
});
test('patient edit is scoped, audited and replayable; mobile changes need verification',async()=>{
  const key=crypto.randomUUID();const result=await f.write(ids.frontA,'update',{name:'Updated Synthetic Name',date_of_birth:'1991-02-03'},key,ids.patientA);
  assert.equal(result.patient.name,'Updated Synthetic Name');assert.equal(result.patient.date_of_birth,'1991-02-03');
  assert.equal((await f.write(ids.frontA,'update',{name:'Updated Synthetic Name',date_of_birth:'1991-02-03'},key,ids.patientA)).replayed,true);
  await assert.rejects(f.write(ids.frontA,'update',{mobile_e164:'+919000000099'},crypto.randomUUID(),ids.patientA),/CONTACT_CHANGE_REQUIRES_VERIFICATION/);
  await assert.rejects(f.write(ids.adminA,'update',{name:'Cross Clinic'},crypto.randomUUID(),ids.patientB),/PATIENT_NOT_FOUND/);
});
test('consent revoke appends proof and skips queued messages; grant never revives skipped sends',async()=>{
  const patient=(await f.write(ids.adminA,'create',input)).patient;
  const grant=await f.write(ids.frontA,'consent',{status:'granted',version:'review-fixture-v1',channel:'phone'},crypto.randomUUID(),patient.id);
  assert.equal(grant.patient.opted_out,false);assert.equal(grant.consent.created_by,ids.frontA);
  const revokeKey=crypto.randomUUID();const revokeInput={status:'revoked',version:'review-fixture-v1',channel:'dashboard'};
  const revoke=await f.write(ids.frontA,'consent',revokeInput,revokeKey,patient.id);assert.equal(revoke.patient.opted_out,true);
  await f.write(ids.frontA,'consent',revokeInput,revokeKey,patient.id);
  assert.equal((await f.db.query('select * from public.consents where patient_id=$1',[patient.id])).rows.length,2);
  const message=(await f.db.query('select * from public.outbox where patient_id=$1',[patient.id])).rows[0];assert.equal(message.status,'skipped');assert.equal(message.last_error,'WA_OPTED_OUT');
  await f.write(ids.adminA,'consent',{status:'granted',version:'review-fixture-v2',channel:'paper'},crypto.randomUUID(),patient.id);
  assert.equal((await f.db.query('select status from public.outbox where id=$1',[message.id])).rows[0].status,'skipped');
});
test('inactive, anonymous and nonmember identities cannot invoke patient operations',async()=>{
  for(const user of [ids.inactive,ids.outsider,null]){
    await assert.rejects(f.search(user),/STAFF_FORBIDDEN/);await assert.rejects(f.write(user,'create',input),/STAFF_FORBIDDEN/);
  }
  await assert.rejects(f.asUser(null,tx=>tx.query('select public.tabiyo_patient_search($1)',['+919000000001']),'anon'),/permission denied/);
});
test('database functions independently reject forged fields and invalid patient data',async()=>{
  for(const bad of [{...input,clinic_id:ids.clinicB},{...input,name:4},{...input,language:null},{...input,date_of_birth:'2026-02-30'},{...input,date_of_birth:'2999-01-01'}])await assert.rejects(f.write(ids.adminA,'create',bad));
  await assert.rejects(f.write(ids.adminA,'consent',{status:'granted',version:'v1',channel:'whatsapp'},crypto.randomUUID(),ids.patientA),/INPUT_INVALID/);
  await assert.rejects(f.write(ids.adminA,'consent',{status:'granted',version:'v1',channel:'phone',created_by:ids.adminB},crypto.randomUUID(),ids.patientA),/INPUT_INVALID/);
});
test('direct patient and consent table access cannot bypass audit and transactions',async()=>{
  for(const table of ['patients','consents']){
    await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('select * from public.'+table)),/permission denied/);
    await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('delete from public.'+table)),/permission denied/);
  }
});
for(const table of ['events','outbox','webhook_raw','conversations','api_requests']){
  test(table+' denies direct staff reads and writes',async()=>{
    await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('select * from public.'+table)),/permission denied/);
    await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('delete from public.'+table)),/permission denied/);
  });
}
test('features and admin audit reads are tenant-scoped; staff cannot forge audit or flags',async()=>{
  for(const [user,clinic] of [[ids.adminA,ids.clinicA],[ids.adminB,ids.clinicB]]){
    assert((await f.asUser(user,tx=>tx.query('select * from public.clinic_features'))).rows.every(row=>row.clinic_id===clinic));
    assert((await f.asUser(user,tx=>tx.query('select * from public.audit_log'))).rows.every(row=>row.clinic_id===clinic));
  }
  assert.equal((await f.asUser(ids.frontA,tx=>tx.query('select * from public.audit_log'))).rows.length,0);
  await assert.rejects(f.asUser(ids.adminA,tx=>tx.query("insert into public.audit_log(clinic_id,action,table_name) values ($1,'forged','patients')",[ids.clinicA])),/permission denied/);
  await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('update public.clinic_features set enabled=true')),/permission denied/);
});
test('application service role cannot modify append-only events, audit or replay records',async()=>{
  for(const table of ['events','audit_log','api_requests'])for(const command of ['delete from ','truncate '])await assert.rejects(f.asUser(null,tx=>tx.query(command+'public.'+table),'service_role'),/permission denied/);
});
test('raw webhook routing rejects a known wrong clinic and protects quarantine from staff',async()=>{
  await f.db.query('update public.clinics set whatsapp_phone_number_id=$1 where id=$2',['fixture-phone-A',ids.clinicA]);
  await assert.rejects(f.db.query('insert into public.webhook_raw(clinic_id,phone_number_id,payload) values ($1,$2,$3)',[ids.clinicB,'fixture-phone-A','{}']),/foreign key/);
  await f.db.query('insert into public.webhook_raw(phone_number_id,payload) values ($1,$2)',['unmapped-fixture','{}']);
  await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('select * from public.webhook_raw')),/permission denied/);
});
test('privileged functions are private, pinned to empty search path and revoked from PUBLIC',async()=>{
  const funcs=(await f.db.query("select n.nspname,p.proname,p.proconfig,has_function_privilege('anon',p.oid,'execute') as anon_execute from pg_proc p join pg_namespace n on n.oid=p.pronamespace where p.prosecdef and n.nspname in ('public','private')")).rows;
  assert(funcs.length>=3);assert(funcs.every(fn=>fn.nspname==='private'&&fn.proconfig.includes('search_path=""')&&!fn.anon_execute));
});
