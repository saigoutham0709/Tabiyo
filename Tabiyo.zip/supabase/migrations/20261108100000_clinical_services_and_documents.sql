-- Migration: Clinical Services, Visits, Prescriptions, Medication Schedules, FAQs, and Documents
-- Tables: visits, prescriptions, medication_schedules, dose_events, faqs, dob_lockouts

CREATE TABLE IF NOT EXISTS public.visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id uuid NOT NULL REFERENCES public.clinics(id) ON DELETE RESTRICT,
  appointment_id uuid NOT NULL REFERENCES public.appointments(id) ON DELETE RESTRICT,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE RESTRICT,
  notes text NOT NULL DEFAULT '',
  slip_file_path text,
  completed_at timestamptz NOT NULL DEFAULT timezone('utc', now()),
  created_at timestamptz NOT NULL DEFAULT timezone('utc', now()),
  UNIQUE(appointment_id)
);

CREATE TABLE IF NOT EXISTS public.prescriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id uuid NOT NULL REFERENCES public.clinics(id) ON DELETE RESTRICT,
  visit_id uuid REFERENCES public.visits(id) ON DELETE SET NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE RESTRICT,
  created_by uuid NOT NULL REFERENCES public.staff_users(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT timezone('utc', now())
);

CREATE TABLE IF NOT EXISTS public.medication_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id uuid NOT NULL REFERENCES public.clinics(id) ON DELETE RESTRICT,
  prescription_id uuid NOT NULL REFERENCES public.prescriptions(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE RESTRICT,
  medicine text NOT NULL CHECK (char_length(trim(medicine)) >= 1),
  dose text NOT NULL CHECK (char_length(trim(dose)) >= 1),
  times text[] NOT NULL CHECK (cardinality(times) >= 1),
  food_relation text NOT NULL CHECK (food_relation IN ('before_food', 'after_food', 'with_food', 'no_relation')),
  start_date date NOT NULL,
  end_date date NOT NULL CHECK (end_date >= start_date),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'stopped', 'completed')),
  created_at timestamptz NOT NULL DEFAULT timezone('utc', now())
);

CREATE TABLE IF NOT EXISTS public.dose_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id uuid NOT NULL REFERENCES public.clinics(id) ON DELETE RESTRICT,
  schedule_group_key text NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE RESTRICT,
  due_at timestamptz NOT NULL,
  sent_at timestamptz,
  response text NOT NULL DEFAULT 'none' CHECK (response IN ('taken', 'later', 'none', 'stopped')),
  responded_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT timezone('utc', now())
);

CREATE TABLE IF NOT EXISTS public.faqs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id uuid NOT NULL REFERENCES public.clinics(id) ON DELETE RESTRICT,
  question text NOT NULL CHECK (char_length(trim(question)) >= 2),
  answer text NOT NULL CHECK (char_length(trim(answer)) >= 2),
  language text NOT NULL DEFAULT 'en' CHECK (language IN ('en', 'te', 'hi')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT timezone('utc', now()),
  updated_at timestamptz NOT NULL DEFAULT timezone('utc', now())
);

CREATE TABLE IF NOT EXISTS public.dob_lockouts (
  clinic_id uuid NOT NULL REFERENCES public.clinics(id) ON DELETE RESTRICT,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE RESTRICT,
  failed_attempts integer NOT NULL DEFAULT 0,
  locked_until timestamptz,
  updated_at timestamptz NOT NULL DEFAULT timezone('utc', now()),
  PRIMARY KEY (clinic_id, patient_id)
);

-- Indexes for performance & query patterns
CREATE INDEX IF NOT EXISTS idx_visits_patient_completed ON public.visits(clinic_id, patient_id, completed_at DESC);
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient ON public.prescriptions(clinic_id, patient_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_medication_schedules_patient ON public.medication_schedules(clinic_id, patient_id, status);
CREATE INDEX IF NOT EXISTS idx_dose_events_patient ON public.dose_events(clinic_id, patient_id, due_at);
CREATE INDEX IF NOT EXISTS idx_faqs_clinic_active ON public.faqs(clinic_id, active, language);

-- Enable Row-Level Security on all new tables
ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medication_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dose_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dob_lockouts ENABLE ROW LEVEL SECURITY;

-- RLS Policies: visits
CREATE POLICY visits_clinic_read ON public.visits FOR SELECT TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = visits.clinic_id));
CREATE POLICY visits_clinic_write ON public.visits FOR INSERT TO authenticated
  WITH CHECK (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = visits.clinic_id));
CREATE POLICY visits_clinic_update ON public.visits FOR UPDATE TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = visits.clinic_id))
  WITH CHECK (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = visits.clinic_id));

-- RLS Policies: prescriptions (Doctors and Admins write; Front desk reads only if permitted)
CREATE POLICY prescriptions_clinic_read ON public.prescriptions FOR SELECT TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = prescriptions.clinic_id));
CREATE POLICY prescriptions_doctor_insert ON public.prescriptions FOR INSERT TO authenticated
  WITH CHECK (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = prescriptions.clinic_id and s.role IN ('doctor', 'admin')));

-- RLS Policies: medication_schedules
CREATE POLICY schedules_clinic_read ON public.medication_schedules FOR SELECT TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = medication_schedules.clinic_id));
CREATE POLICY schedules_doctor_write ON public.medication_schedules FOR ALL TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = medication_schedules.clinic_id and s.role IN ('doctor', 'admin')))
  WITH CHECK (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = medication_schedules.clinic_id and s.role IN ('doctor', 'admin')));

-- RLS Policies: dose_events
CREATE POLICY dose_events_clinic_read ON public.dose_events FOR SELECT TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = dose_events.clinic_id));
CREATE POLICY dose_events_service_all ON public.dose_events FOR ALL TO service_role
  USING (true) WITH CHECK (true);
CREATE POLICY dose_events_staff_write ON public.dose_events FOR ALL TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = dose_events.clinic_id))
  WITH CHECK (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = dose_events.clinic_id));

-- RLS Policies: faqs (Admins manage, all staff read)
CREATE POLICY faqs_clinic_read ON public.faqs FOR SELECT TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = faqs.clinic_id));
CREATE POLICY faqs_admin_write ON public.faqs FOR ALL TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = faqs.clinic_id and s.role = 'admin'))
  WITH CHECK (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = faqs.clinic_id and s.role = 'admin'));

-- RLS Policies: dob_lockouts (Service and staff managed)
CREATE POLICY lockouts_clinic_all ON public.dob_lockouts FOR ALL TO authenticated
  USING (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = dob_lockouts.clinic_id))
  WITH CHECK (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = dob_lockouts.clinic_id));
CREATE POLICY lockouts_service_all ON public.dob_lockouts FOR ALL TO service_role
  USING (true) WITH CHECK (true);

-- Table privileges for authenticated and service_role
GRANT ALL ON public.visits, public.prescriptions, public.medication_schedules, public.dose_events, public.faqs, public.dob_lockouts TO authenticated, service_role;

ALTER TABLE public.outbox DROP CONSTRAINT IF EXISTS outbox_purpose_check;
ALTER TABLE public.outbox ADD CONSTRAINT outbox_purpose_check CHECK (purpose IN ('consent_request','appointment','reminder','slip','medication','medication_reminder','staff_reply','doctor_summary','queue'));

CREATE OR REPLACE FUNCTION private.clinical(
  p_action text,
  p_input jsonb DEFAULT '{}'::jsonb,
  p_request_id uuid DEFAULT NULL
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
declare
  s public.staff_users;
  p public.patients;
  source_p public.patients;
  target_p public.patients;
  rx public.prescriptions;
  ms public.medication_schedules;
  v public.visits;
  a public.appointments;
  lock public.dob_lockouts;
  t timestamptz := clock_timestamp();
  items jsonb := '[]'::jsonb;
  item jsonb;
  row_item jsonb;
  faqs_arr jsonb := '[]'::jsonb;
  adherence_arr jsonb := '[]'::jsonb;
  taken_count integer;
  missed_count integer;
  stopped_count integer;
  total_due_count integer;
  rate numeric;
  denom numeric;
  booked_count integer;
  attended_count integer;
  no_show_count integer;
  reminders_count integer;
  confirmations_count integer;
  cost numeric;
  imported_count integer := 0;
  duplicate_count integer := 0;
  imported_patients jsonb := '[]'::jsonb;
  phone text;
  source_id uuid;
  target_id uuid;
  file_path text;
begin
  select * into s from public.staff_users where id = (select auth.uid()) and active;
  if s.id is null then
    raise exception 'STAFF_FORBIDDEN' using errcode = '42501';
  end if;

  p_input := coalesce(p_input, '{}'::jsonb);

  if p_action = 'create_prescription' then
    if s.role not in ('doctor', 'admin') then
      raise exception 'OPERATION_FORBIDDEN' using errcode = 'P0001';
    end if;

    select * into p from public.patients where id = (p_input->>'patient_id')::uuid and clinic_id = s.clinic_id and merged_into is null;
    if p.id is null then
      raise exception 'PATIENT_NOT_FOUND' using errcode = 'P0001';
    end if;

    if p_input->>'visit_id' is not null then
      select * into v from public.visits where id = (p_input->>'visit_id')::uuid and clinic_id = s.clinic_id;
      if v.id is null then
        raise exception 'VISIT_NOT_FOUND' using errcode = 'P0001';
      end if;
    end if;

    insert into public.prescriptions(clinic_id, visit_id, patient_id, created_by, created_at)
    values (s.clinic_id, (p_input->>'visit_id')::uuid, p.id, s.id, t)
    returning * into rx;

    for item in select * from jsonb_array_elements(p_input->'items') loop
      insert into public.medication_schedules(
        clinic_id, prescription_id, patient_id, medicine, dose, times, food_relation, start_date, end_date, status, created_at
      ) values (
        s.clinic_id,
        rx.id,
        p.id,
        item->>'medicine',
        item->>'dose',
        array(select jsonb_array_elements_text(item->'times')),
        item->>'food_relation',
        (item->>'start_date')::date,
        (item->>'end_date')::date,
        'active',
        t
      ) returning * into ms;
      items := items || jsonb_build_array(to_jsonb(ms));
    end loop;

    insert into public.events(clinic_id, patient_id, appointment_id, type, occurred_at, meta)
    values (s.clinic_id, p.id, case when v.id is not null then v.appointment_id else null end, 'prescription_created', t, jsonb_build_object('prescription_id', rx.id, 'items_count', jsonb_array_length(p_input->'items')));

    insert into public.audit_log(clinic_id, user_id, action, table_name, record_id, request_id, created_at)
    values (s.clinic_id, s.id, 'prescription.create', 'prescriptions', rx.id, p_request_id, t);

    return jsonb_build_object(
      'prescription',
      to_jsonb(rx) || jsonb_build_object('items', items)
    );

  elsif p_action = 'get_adherence' then
    select * into p from public.patients where id = (p_input->>'patient_id')::uuid and clinic_id = s.clinic_id;
    if p.id is null then
      raise exception 'PATIENT_NOT_FOUND' using errcode = 'P0001';
    end if;

    for ms in select * from public.medication_schedules where clinic_id = s.clinic_id and patient_id = p.id order by created_at desc loop
      select
        coalesce(count(*) filter (where response = 'taken'), 0),
        coalesce(count(*) filter (where response = 'none'), 0),
        coalesce(count(*) filter (where response = 'stopped'), 0),
        coalesce(count(*) filter (where response in ('taken', 'none', 'later', 'stopped')), 0)
      into taken_count, missed_count, stopped_count, total_due_count
      from public.dose_events
      where clinic_id = s.clinic_id and patient_id = p.id and (schedule_group_key = ms.id::text or schedule_group_key like ms.id::text || '%' or lower(schedule_group_key) = lower(ms.medicine));

      rate := case when total_due_count > 0 then round((taken_count::numeric / total_due_count::numeric) * 100.0, 2) else 0.0 end;

      adherence_arr := adherence_arr || jsonb_build_array(jsonb_build_object(
        'medicine', ms.medicine,
        'dose', ms.dose,
        'taken', taken_count,
        'missed', missed_count,
        'stopped', stopped_count,
        'total_due', total_due_count,
        'adherence_rate', rate,
        'status', ms.status
      ));
    end loop;

    insert into public.audit_log(clinic_id, user_id, action, table_name, record_id, request_id, created_at)
    values (s.clinic_id, s.id, 'patient.adherence_read', 'medication_schedules', p.id, p_request_id, t);

    return jsonb_build_object(
      'patient_id', p.id,
      'clinic_id', s.clinic_id,
      'adherence', adherence_arr
    );

  elsif p_action = 'save_visit_slip' then
    select * into a from public.appointments
    where clinic_id = s.clinic_id and (
      id = (p_input->>'id')::uuid or
      id = (p_input->>'appointment_id')::uuid or
      (p_input->>'patient_id' is not null and patient_id = (p_input->>'patient_id')::uuid)
    )
    order by starts_at desc limit 1;

    if a.id is null then
      select * into v from public.visits where clinic_id = s.clinic_id and id = (p_input->>'id')::uuid;
      if v.id is not null then
        select * into a from public.appointments where id = v.appointment_id and clinic_id = s.clinic_id;
      end if;
    end if;

    if a.id is null then
      raise exception 'APPOINTMENT_NOT_FOUND' using errcode = 'P0001';
    end if;

    file_path := coalesce(p_input->>'slip_file_path', 'slips/' || s.clinic_id::text || '/' || a.patient_id::text || '/' || a.id::text || '.pdf');

    insert into public.visits(clinic_id, appointment_id, patient_id, notes, slip_file_path, completed_at, created_at)
    values (s.clinic_id, a.id, a.patient_id, coalesce(p_input->>'notes', 'Consultation completed. Visit slip issued.'), file_path, t, t)
    on conflict (appointment_id) do update set
      slip_file_path = excluded.slip_file_path,
      notes = case when length(excluded.notes) > 0 then excluded.notes else visits.notes end,
      completed_at = t
    returning * into v;

    update public.appointments set status = 'completed' where id = a.id and status <> 'completed';

    insert into public.events(clinic_id, patient_id, appointment_id, type, occurred_at, meta)
    values (s.clinic_id, v.patient_id, v.appointment_id, 'slip_generated', t, jsonb_build_object('visit_id', v.id, 'slip_file_path', v.slip_file_path));

    insert into public.audit_log(clinic_id, user_id, action, table_name, record_id, request_id, created_at)
    values (s.clinic_id, s.id, 'visit.slip_generated', 'visits', v.id, p_request_id, t);

    return jsonb_build_object(
      'visit_id', v.id,
      'clinic_id', s.clinic_id,
      'appointment_id', v.appointment_id,
      'patient_id', v.patient_id,
      'slip_file_path', v.slip_file_path
    );

  elsif p_action = 'get_visit_slip' then
    select * into v from public.visits
    where clinic_id = s.clinic_id and (id = (p_input->>'id')::uuid or appointment_id = (p_input->>'id')::uuid);

    if v.id is null then
      raise exception 'VISIT_NOT_FOUND' using errcode = 'P0001';
    end if;

    if p_input->>'dob' is not null then
      select * into lock from public.dob_lockouts where clinic_id = s.clinic_id and patient_id = v.patient_id;
      if lock.locked_until is not null and lock.locked_until > t then
        raise exception 'ID_CHECK_LOCKED' using errcode = 'P0001';
      end if;

      select * into p from public.patients where id = v.patient_id and clinic_id = s.clinic_id;
      if p.date_of_birth is null or p.date_of_birth::text <> (p_input->>'dob') then
        insert into public.dob_lockouts(clinic_id, patient_id, failed_attempts, updated_at)
        values (s.clinic_id, v.patient_id, 1, t)
        on conflict (clinic_id, patient_id) do update set
          failed_attempts = dob_lockouts.failed_attempts + 1,
          updated_at = t
        returning * into lock;

        if lock.failed_attempts >= 3 then
          update public.dob_lockouts set locked_until = t + interval '1 hour' where clinic_id = s.clinic_id and patient_id = v.patient_id;
          perform private.delivery_alert(s.clinic_id, v.patient_id, 'ID_CHECK_LOCKED', 'lockout/' || v.patient_id::text, t);
          raise exception 'ID_CHECK_LOCKED' using errcode = 'P0001';
        else
          raise exception 'DOB_VERIFICATION_FAILED' using errcode = 'P0001';
        end if;
      else
        update public.dob_lockouts set failed_attempts = 0, locked_until = null where clinic_id = s.clinic_id and patient_id = v.patient_id;
      end if;
    end if;

    insert into public.audit_log(clinic_id, user_id, action, table_name, record_id, request_id, created_at)
    values (s.clinic_id, s.id, 'visit.slip_read', 'visits', v.id, p_request_id, t);

    return jsonb_build_object(
      'visit_id', v.id,
      'clinic_id', s.clinic_id,
      'patient_id', v.patient_id,
      'slip_file_path', v.slip_file_path
    );

  elsif p_action = 'list_faqs' then
    select coalesce(jsonb_agg(to_jsonb(f) order by f.created_at desc), '[]'::jsonb)
    into faqs_arr
    from public.faqs f
    where f.clinic_id = s.clinic_id
      and (p_input->>'active' is null or p_input->>'active' = 'all' or f.active = (p_input->>'active')::boolean)
      and (p_input->>'language' is null or f.language = p_input->>'language');

    return jsonb_build_object('clinic_id', s.clinic_id, 'faqs', faqs_arr);

  elsif p_action = 'upsert_faqs' then
    if s.role <> 'admin' then
      raise exception 'OPERATION_FORBIDDEN' using errcode = 'P0001';
    end if;

    if p_input?'faqs' then
      for item in select * from jsonb_array_elements(p_input->'faqs') loop
        if (item->>'id') is not null and exists(select 1 from public.faqs where id = (item->>'id')::uuid and clinic_id = s.clinic_id) then
          update public.faqs set
            question = item->>'question',
            answer = item->>'answer',
            language = coalesce(item->>'language', language),
            active = coalesce((item->>'active')::boolean, active),
            updated_at = t
          where id = (item->>'id')::uuid and clinic_id = s.clinic_id;
        else
          insert into public.faqs(clinic_id, question, answer, language, active, created_at, updated_at)
          values (s.clinic_id, item->>'question', item->>'answer', coalesce(item->>'language', 'en'), coalesce((item->>'active')::boolean, true), t, t);
        end if;
      end loop;
    else
      item := p_input;
      if (item->>'id') is not null and exists(select 1 from public.faqs where id = (item->>'id')::uuid and clinic_id = s.clinic_id) then
        update public.faqs set
          question = item->>'question',
          answer = item->>'answer',
          language = coalesce(item->>'language', language),
          active = coalesce((item->>'active')::boolean, active),
          updated_at = t
        where id = (item->>'id')::uuid and clinic_id = s.clinic_id;
      else
        insert into public.faqs(clinic_id, question, answer, language, active, created_at, updated_at)
        values (s.clinic_id, item->>'question', item->>'answer', coalesce(item->>'language', 'en'), coalesce((item->>'active')::boolean, true), t, t);
      end if;
    end if;

    insert into public.audit_log(clinic_id, user_id, action, table_name, record_id, request_id, created_at)
    values (s.clinic_id, s.id, 'faq.upsert', 'faqs', null, p_request_id, t);

    select coalesce(jsonb_agg(to_jsonb(f) order by f.created_at desc), '[]'::jsonb)
    into faqs_arr
    from public.faqs f
    where f.clinic_id = s.clinic_id;

    return jsonb_build_object('clinic_id', s.clinic_id, 'faqs', faqs_arr);

  elsif p_action = 'reports_summary' then
    select
      coalesce(count(*) filter (where type in ('appointment.booked', 'appointment_booked')), 0),
      coalesce(count(*) filter (where type in ('appointment.completed', 'appointment_completed', 'appointment.attended', 'appointment_attended')), 0),
      coalesce(count(*) filter (where type in ('appointment.no_show', 'appointment_no_show')), 0),
      coalesce(count(*) filter (where type in ('reminder.sent', 'reminder_sent', 'message.reminder_sent') or (type in ('message.sent', 'message.accepted') and (meta->>'purpose' = 'reminder' or meta->>'template_name' like '%reminder%'))), 0),
      coalesce(count(*) filter (where type in ('confirmation.received', 'confirmation_received', 'appointment.confirmed', 'appointment_confirmed') or (type = 'message.received' and (meta->>'intent' in ('confirmation', 'confirm') or meta->>'type' = 'confirmation'))), 0)
    into booked_count, attended_count, no_show_count, reminders_count, confirmations_count
    from public.events
    where clinic_id = s.clinic_id
      and occurred_at >= (p_input->>'from')::date at time zone 'Asia/Kolkata'
      and occurred_at < ((p_input->>'to')::date + 1) at time zone 'Asia/Kolkata';

    denom := coalesce(nullif(attended_count + no_show_count, 0), nullif(booked_count, 0), 0);
    rate := case when denom > 0 then round((no_show_count::numeric / denom::numeric) * 100.0, 2) else 0.0 end;

    select coalesce(sum(
      case
        when (meta->>'cost_inr') is not null then (meta->>'cost_inr')::numeric
        when (meta->>'cost') is not null then (meta->>'cost')::numeric
        when type in ('reminder.sent', 'reminder_sent') or meta->>'purpose' = 'reminder' or meta->>'kind' = 'template' or (meta->>'template_name') is not null then 0.75
        else 0.35
      end
    ), 0.0)
    into cost
    from public.events
    where clinic_id = s.clinic_id
      and occurred_at >= (p_input->>'from')::date at time zone 'Asia/Kolkata'
      and occurred_at < ((p_input->>'to')::date + 1) at time zone 'Asia/Kolkata'
      and (type like 'message.%' or type like 'reminder.%');

    return jsonb_build_object(
      'clinic_id', s.clinic_id,
      'from', p_input->>'from',
      'to', p_input->>'to',
      'appointments_booked', booked_count,
      'appointments_attended', attended_count,
      'no_shows', no_show_count,
      'no_show_rate', rate,
      'reminders_sent', reminders_count,
      'confirmations_received', confirmations_count,
      'estimated_wa_cost_inr', round(cost, 2)
    );

  elsif p_action = 'import_patients' then
    for row_item in select * from jsonb_array_elements(p_input->'rows') loop
      phone := row_item->>'mobile_e164';
      if exists (select 1 from public.patients where clinic_id = s.clinic_id and mobile_e164 = phone and merged_into is null) then
        duplicate_count := duplicate_count + 1;
      else
        insert into public.patients(
          clinic_id, name, mobile_e164, date_of_birth, gender, language, created_at
        ) values (
          s.clinic_id,
          row_item->>'name',
          phone,
          (row_item->>'date_of_birth')::date,
          coalesce(row_item->>'gender', 'undisclosed'),
          coalesce(row_item->>'language', 'en'),
          t
        ) returning * into p;
        imported_count := imported_count + 1;
        imported_patients := imported_patients || jsonb_build_array(to_jsonb(p));

        insert into public.audit_log(clinic_id, user_id, action, table_name, record_id, request_id, created_at)
        values (s.clinic_id, s.id, 'patient.import', 'patients', p.id, p_request_id, t);
      end if;
    end loop;

    return jsonb_build_object(
      'imported', imported_count,
      'imported_count', imported_count,
      'duplicates', duplicate_count,
      'duplicate_count', duplicate_count,
      'errors', '[]'::jsonb,
      'patients', imported_patients
    );

  elsif p_action = 'merge_patients' then
    if s.role <> 'admin' then
      raise exception 'OPERATION_FORBIDDEN' using errcode = 'P0001';
    end if;

    source_id := (p_input->>'source_patient_id')::uuid;
    target_id := (p_input->>'target_patient_id')::uuid;

    if source_id = target_id then
      raise exception 'INPUT_INVALID' using errcode = '22023';
    end if;

    select * into source_p from public.patients where id = source_id and clinic_id = s.clinic_id;
    select * into target_p from public.patients where id = target_id and clinic_id = s.clinic_id;

    if source_p.id is null or target_p.id is null then
      raise exception 'PATIENT_NOT_FOUND' using errcode = 'P0001';
    end if;

    if source_p.merged_into is not null or target_p.merged_into is not null then
      raise exception 'PATIENT_STATE_INVALID' using errcode = 'P0001';
    end if;

    update public.patients set merged_into = target_id where id = source_id and clinic_id = s.clinic_id;

    update public.appointments set patient_id = target_id where patient_id = source_id and clinic_id = s.clinic_id;
    update public.prescriptions set patient_id = target_id where patient_id = source_id and clinic_id = s.clinic_id;
    update public.medication_schedules set patient_id = target_id where patient_id = source_id and clinic_id = s.clinic_id;
    update public.visits set patient_id = target_id where patient_id = source_id and clinic_id = s.clinic_id;
    update public.dose_events set patient_id = target_id where patient_id = source_id and clinic_id = s.clinic_id;

    insert into public.events(clinic_id, patient_id, type, occurred_at, meta)
    values (s.clinic_id, target_id, 'patient.merged', t, jsonb_build_object('source_patient_id', source_id, 'target_patient_id', target_id, 'reason', p_input->>'reason'));

    insert into public.audit_log(clinic_id, user_id, action, table_name, record_id, request_id, reason, created_at)
    values (s.clinic_id, s.id, 'patient.merge', 'patients', source_id, p_request_id, p_input->>'reason', t);

    return jsonb_build_object(
      'success', true,
      'source_patient_id', source_id,
      'target_patient_id', target_id,
      'merged_at', t
    );

  else
    raise exception 'INPUT_INVALID' using errcode = '22023';
  end if;
end $$;

REVOKE ALL ON FUNCTION private.clinical(text, jsonb, uuid) FROM public, anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION private.clinical(text, jsonb, uuid) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.tabiyo_clinical(
  p_action text,
  p_input jsonb DEFAULT '{}'::jsonb,
  p_request_id uuid DEFAULT NULL
) RETURNS jsonb
LANGUAGE sql
SECURITY INVOKER
SET search_path = ''
AS $$
  SELECT private.clinical(p_action, p_input, p_request_id);
$$;

REVOKE ALL ON FUNCTION public.tabiyo_clinical(text, jsonb, uuid) FROM public, anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.tabiyo_clinical(text, jsonb, uuid) TO authenticated, service_role;
