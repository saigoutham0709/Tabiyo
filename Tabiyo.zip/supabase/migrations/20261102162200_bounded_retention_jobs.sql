-- Technical retention only. Clinical records, consent proof, events and audit history remain held.
alter table public.api_requests add column response_expired_at timestamptz;
alter table public.outbox add column last_activity_at timestamptz not null default clock_timestamp();
alter table public.staff_alerts add column resolved_at timestamptz;

create function private.retention_activity() returns trigger
language plpgsql set search_path='' as $$
begin
  if tg_table_name='outbox' then new.last_activity_at:=clock_timestamp();
  elsif new.status='resolved' and old.status is distinct from 'resolved' then new.resolved_at:=clock_timestamp();
  elsif new.status='open' then new.resolved_at:=null;
  end if;
  return new;
end $$;
revoke all on function private.retention_activity() from public,anon,authenticated,service_role;
create trigger outbox_activity before update on public.outbox for each row execute function private.retention_activity();
create trigger alert_resolution_time before update on public.staff_alerts for each row execute function private.retention_activity();
create index outbox_retention on public.outbox(last_activity_at,id) where status in ('sent','failed','skipped');
create index api_requests_retention on public.api_requests(created_at) where response_expired_at is null;

-- Keep historical outbox UUIDs in immutable message history after queue payload deletion.
alter table public.message_log drop constraint message_log_outbox_id_fkey;

alter function private.patient_write(text,jsonb,uuid,uuid) rename to patient_write_with_contact_lock;
revoke all on function private.patient_write_with_contact_lock(text,jsonb,uuid,uuid) from public,anon,authenticated,service_role;
create function private.patient_write(p_operation text,p_input jsonb,p_request_id uuid,p_patient_id uuid default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; mobile text; cached public.api_requests;
begin
  s:=private.require_staff();
  if p_operation='create' then mobile:=p_input->>'mobile_e164';
  else select mobile_e164 into mobile from public.patients where clinic_id=s.clinic_id and id=p_patient_id; end if;
  if mobile is not null then perform pg_advisory_xact_lock(hashtextextended('contact/'||s.clinic_id::text||'/'||mobile,0)); end if;
  perform pg_advisory_xact_lock(hashtextextended(s.clinic_id::text||':'||p_request_id::text,0));
  select * into cached from public.api_requests where clinic_id=s.clinic_id and request_id=p_request_id for share;
  if found and (cached.response_expired_at is not null or cached.created_at<clock_timestamp()-interval '90 days') then
    raise exception 'REQUEST_REPLAY_EXPIRED' using errcode='P0001';
  end if;
  return private.patient_write_with_contact_lock(p_operation,p_input,p_request_id,p_patient_id);
end $$;
revoke all on function private.patient_write(text,jsonb,uuid,uuid) from public,anon,authenticated,service_role;
grant execute on function private.patient_write(text,jsonb,uuid,uuid) to authenticated;

-- Receipts may arrive after the queue payload expires. Preserve and apply them to historical proof.
alter function private.delivery(text,jsonb,timestamptz) rename to delivery_with_contact_lock;
revoke all on function private.delivery_with_contact_lock(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
create function private.delivery(p_action text,p_input jsonb,p_now timestamptz default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare result jsonb; m public.message_log; next_status text; failures integer; t timestamptz:=coalesce(p_now,clock_timestamp());
begin
  result:=private.delivery_with_contact_lock(p_action,p_input,p_now);
  if p_action='receipt' and result->>'matched'='false' then
    select * into m from public.message_log where clinic_id=(p_input->>'clinic_id')::uuid
      and wa_message_id=p_input->>'wa_message_id' and direction='out';
    if found then
      select status into next_status from public.delivery_receipts where clinic_id=m.clinic_id and wa_message_id=m.wa_message_id
        order by case status when 'read' then 4 when 'delivered' then 3 when 'failed' then 2 when 'sent' then 1 else 0 end desc limit 1;
      with new_events as (insert into public.events(clinic_id,patient_id,type,occurred_at,meta)
        select m.clinic_id,m.patient_id,'message.'||r.status,r.occurred_at,jsonb_build_object('outbox_id',m.outbox_id,'receipt_id',r.id)
        from public.delivery_receipts r where r.clinic_id=m.clinic_id and r.wa_message_id=m.wa_message_id on conflict do nothing returning type)
        select count(*) into failures from new_events where type='message.failed';
      if next_status='failed' and failures>0 then perform private.delivery_alert(m.clinic_id,m.patient_id,'WA_DELIVERY_FAILED','delivery/'||m.outbox_id::text,t); end if;
      result:=result||jsonb_build_object('matched',true,'status',next_status);
    end if;
  end if;
  return result;
end $$;
revoke all on function private.delivery(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
grant execute on function private.delivery(text,jsonb,timestamptz) to service_role;

create function private.retention(p_now timestamptz default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare t timestamptz:=coalesce(p_now,clock_timestamp()); r record; counts jsonb:='{}'; n integer;
begin
  -- Redact cached PHI, retain keys/hash/ownership so an old retry never creates a second patient.
  n:=0;
  for r in select * from public.api_requests where created_at<t-interval '90 days' and response_expired_at is null
      order by created_at,clinic_id,request_id for update skip locked limit 500 loop
    update public.api_requests set response='{"expired":true}',response_expired_at=t where clinic_id=r.clinic_id and request_id=r.request_id;
    insert into public.audit_log(clinic_id,action,table_name,request_id,created_at) values(r.clinic_id,'retention.replay_redacted','api_requests',r.request_id,t);
    n:=n+1;
  end loop;
  counts:=counts||jsonb_build_object('replay_responses',n); n:=0;
  for r in select * from public.outbox where status in ('sent','failed','skipped') and last_activity_at<t-interval '90 days'
      order by last_activity_at,id for update skip locked limit 500 loop
    delete from public.mock_deliveries where outbox_id=r.id;
    delete from public.outbox where id=r.id;
    insert into public.audit_log(clinic_id,action,table_name,record_id,created_at) values(r.clinic_id,'retention.outbox_deleted','outbox',r.id,t);
    n:=n+1;
  end loop;
  counts:=counts||jsonb_build_object('outbox',n); n:=0;
  for r in select d.* from public.delivery_receipts d where occurred_at<t-interval '90 days'
      and not exists(select 1 from public.message_log m where m.clinic_id=d.clinic_id and m.wa_message_id=d.wa_message_id)
      and not exists(select 1 from public.outbox o where o.clinic_id=d.clinic_id and o.wa_message_id=d.wa_message_id)
      and not exists(select 1 from public.mock_deliveries m where m.clinic_id=d.clinic_id and m.wa_message_id=d.wa_message_id)
      order by occurred_at,id for update skip locked limit 500 loop
    delete from public.delivery_receipts where id=r.id;
    insert into public.audit_log(clinic_id,action,table_name,record_id,created_at) values(r.clinic_id,'retention.orphan_receipt_deleted','delivery_receipts',r.id,t);
    n:=n+1;
  end loop;
  counts:=counts||jsonb_build_object('orphan_receipts',n); n:=0;
  for r in select * from public.message_log where body_preview is not null and created_at<t-interval '1 year'
      order by created_at,id for update skip locked limit 500 loop
    update public.message_log set body_preview=null where id=r.id;
    insert into public.audit_log(clinic_id,action,table_name,record_id,created_at) values(r.clinic_id,'retention.body_cleared','message_log',r.id,t);
    n:=n+1;
  end loop;
  counts:=counts||jsonb_build_object('message_bodies',n); n:=0;
  for r in select * from public.staff_alerts where status='resolved' and resolved_at<t-interval '90 days'
      order by resolved_at,id for update skip locked limit 500 loop
    delete from public.staff_alerts where id=r.id;
    insert into public.audit_log(clinic_id,action,table_name,record_id,created_at) values(r.clinic_id,'retention.resolved_alert_deleted','staff_alerts',r.id,t);
    n:=n+1;
  end loop;
  counts:=counts||jsonb_build_object('resolved_alerts',n);
  with expired as (select gateway_id,hour_start from public.gateway_security where hour_start<t-interval '7 days' order by hour_start for update skip locked limit 500)
    delete from public.gateway_security s using expired e where s.gateway_id=e.gateway_id and s.hour_start=e.hour_start;
  get diagnostics n=row_count; counts:=counts||jsonb_build_object('security_counters',n);
  with expired as (select id from public.gateway_maintenance where occurred_at<t-interval '90 days' order by occurred_at,id for update skip locked limit 500)
    delete from public.gateway_maintenance m using expired e where m.id=e.id;
  get diagnostics n=row_count; counts:=counts||jsonb_build_object('maintenance_records',n);
  insert into public.gateway_maintenance(occurred_at,action,meta) values(t,'technical.retention',counts);
  return counts;
end $$;
revoke all on function private.retention(timestamptz) from public,anon,authenticated,service_role;
grant execute on function private.retention(timestamptz) to service_role;
create function public.tabiyo_retention(p_now timestamptz default null) returns jsonb
language sql security invoker set search_path='' as $$ select private.retention(p_now) $$;
revoke all on function public.tabiyo_retention(timestamptz) from public,anon,authenticated,service_role;
grant execute on function public.tabiyo_retention(timestamptz) to service_role;

-- Bound the previously unbounded signature-counter cleanup as well as raw intake deletion.
alter function private.gateway(text,jsonb,timestamptz) rename to gateway_before_bounded_cleanup;
revoke all on function private.gateway_before_bounded_cleanup(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
create function private.gateway(p_action text,p_input jsonb,p_now timestamptz default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare t timestamptz:=coalesce(p_now,clock_timestamp()); r public.webhook_raw; deleted integer:=0;
begin
  if p_action is distinct from 'cleanup' then return private.gateway_before_bounded_cleanup(p_action,p_input,p_now); end if;
  for r in select * from public.webhook_raw where received_at<t-interval '7 days'
      and (status<>'processing' or locked_at<=t-interval '5 minutes') order by received_at,id for update skip locked limit 500 loop
    if r.clinic_id is not null then
      if r.status in ('queued','processing') then perform private.delivery_alert(r.clinic_id,null,'WEBHOOK_RETENTION_EXPIRED','retention/'||r.id::text,t); end if;
      insert into public.audit_log(clinic_id,action,table_name,record_id,created_at) values(r.clinic_id,'webhook.retention_delete','webhook_raw',r.id,t);
    end if;
    delete from public.webhook_raw where id=r.id; deleted:=deleted+1;
  end loop;
  with expired as (select gateway_id,hour_start from public.gateway_security where hour_start<t-interval '7 days' order by hour_start for update skip locked limit 500)
    delete from public.gateway_security s using expired e where s.gateway_id=e.gateway_id and s.hour_start=e.hour_start;
  insert into public.gateway_maintenance(occurred_at,action,meta) values(t,'webhook.cleanup',jsonb_build_object('deleted',deleted));
  return jsonb_build_object('deleted',deleted);
end $$;
revoke all on function private.gateway(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
grant execute on function private.gateway(text,jsonb,timestamptz) to service_role;
