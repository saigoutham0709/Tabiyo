begin;

alter table public.webhook_raw add column intake_key text unique;
alter table public.webhook_raw add column status text not null default 'queued' check(status in ('queued','processing','processed','quarantined','failed'));
alter table public.webhook_raw add column attempts integer not null default 0;
alter table public.webhook_raw add column not_before timestamptz not null default now();
alter table public.webhook_raw add column lock_owner uuid;
alter table public.webhook_raw add column lease_token uuid;
alter table public.webhook_raw add column locked_at timestamptz;
alter table public.webhook_raw add column processed_at timestamptz;
alter table public.webhook_raw add column last_error text;
create index webhook_raw_due_idx on public.webhook_raw(status,not_before);
alter table public.conversations add constraint conversations_id_clinic_unique unique(id,clinic_id);
alter table public.conversations add column channel_stopped boolean not null default false;
alter table public.conversations add column stopped_at timestamptz;
alter table public.conversations add column last_command_at timestamptz;
alter table public.conversations add column resume_patient_ids uuid[] not null default '{}';
alter table public.message_log alter column patient_id drop not null;
alter table public.message_log alter column outbox_id drop not null;
alter table public.message_log drop constraint message_log_direction_check;
alter table public.message_log drop constraint message_log_status_check;
alter table public.message_log add constraint message_log_direction_check check(direction in ('in','out'));
alter table public.message_log add constraint message_log_status_check check((direction='in' and status='received') or (direction='out' and status='accepted'));
alter table public.message_log add column source_hash text;
alter table public.message_log add column source_raw_id uuid;
alter table public.message_log add column conversation_id uuid;
alter table public.message_log add foreign key(conversation_id,clinic_id) references public.conversations(id,clinic_id);
alter table public.consents add column source_message_id text references public.message_log(wa_message_id);
create unique index consent_source_unique on public.consents(clinic_id,patient_id,source_message_id) where source_message_id is not null;

create table public.gateway_security (
  gateway_id text not null,
  hour_start timestamptz not null,
  failures integer not null,
  alert boolean not null default false,
  primary key(gateway_id,hour_start)
);
create table public.gateway_maintenance (
  id uuid primary key default gen_random_uuid(),
  occurred_at timestamptz not null default now(),
  action text not null,
  meta jsonb not null
);
alter table public.gateway_security enable row level security;
alter table public.gateway_maintenance enable row level security;
revoke all on public.gateway_security,public.gateway_maintenance from public,anon,authenticated,service_role;
grant select on public.gateway_security,public.gateway_maintenance to service_role;
revoke insert,update,delete on public.webhook_raw from service_role;

-- Global STOP is a contact control; patient-specific withdrawal stays patient-specific.
create or replace function private.delivery_policy(o public.outbox,p_now timestamptz) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare p public.patients; c public.clinics; consent text; required_feature text; lang text;
  template_key text; used integer; local_now timestamp; start_at time; end_at time; next_at timestamp;
begin
  select * into p from public.patients where id=o.patient_id and clinic_id=o.clinic_id;
  select * into c from public.clinics where id=o.clinic_id for no key update;
  insert into public.audit_log(clinic_id,action,table_name,record_id,created_at)
    values(o.clinic_id,'outbox.policy_check','patients',o.patient_id,p_now);
  if p.id is null or p.merged_into is not null then return jsonb_build_object('action','skip','code','PATIENT_UNAVAILABLE'); end if;
  if p.opted_out or p.whatsapp_status='blocked' or exists(
    select 1 from public.conversations f where f.clinic_id=p.clinic_id and f.mobile_e164=p.mobile_e164 and f.channel_stopped
  ) then return jsonb_build_object('action','skip','code','WA_OPTED_OUT'); end if;
  if p.whatsapp_status='not_on_whatsapp' then return jsonb_build_object('action','skip','code','WA_NOT_ON_WHATSAPP'); end if;
  select status into consent from public.consents where clinic_id=p.clinic_id and patient_id=p.id order by recorded_order desc limit 1;
  if consent is distinct from 'granted' then
    if o.purpose<>'consent_request' or o.kind<>'template' or c.settings->'allow_consent_request' is distinct from 'true'::jsonb
      or o.payload->>'template_name' is distinct from 'consent_request' then
      return jsonb_build_object('action','skip','code','WA_CONSENT_REQUIRED');
    end if;
  end if;
  if o.purpose='consent_request' and (o.kind<>'template' or o.payload->>'template_name' is distinct from 'consent_request') then
    return jsonb_build_object('action','skip','code','WA_TEMPLATE_UNAVAILABLE');
  end if;
  required_feature:=case o.purpose when 'medication' then 'med_reminders' when 'queue' then 'walk_in_tokens' when 'doctor_summary' then 'doctor_summary' end;
  if required_feature is not null and not exists(select 1 from public.clinic_features where clinic_id=c.id and clinic_features.feature=required_feature and enabled) then
    return jsonb_build_object('action','skip','code','FEATURE_DISABLED');
  end if;
  lang:=coalesce(o.payload->>'language','en');
  if lang not in ('en','te','hi') then return jsonb_build_object('action','skip','code','CONFIG_INVALID'); end if;
  if lang<>'en' and not exists(select 1 from public.clinic_features where clinic_id=c.id and clinic_features.feature='lang_'||lang and enabled) then
    return jsonb_build_object('action','skip','code','FEATURE_DISABLED');
  end if;
  if o.kind='template' then
    template_key:=coalesce(o.payload->>'template_name','')||':'||lang;
    if c.settings->'approved_templates'->template_key is distinct from 'true'::jsonb
      or c.settings->'unavailable_templates'->template_key='true'::jsonb then
      return jsonb_build_object('action','skip','code','WA_TEMPLATE_UNAVAILABLE');
    end if;
  elsif not exists(select 1 from public.conversations where clinic_id=p.clinic_id and mobile_e164=p.mobile_e164
      and last_inbound_at<=p_now and last_inbound_at>p_now-interval '24 hours') then
    return jsonb_build_object('action','skip','code','WA_WINDOW_CLOSED');
  end if;
  if o.purpose in ('reminder','medication','doctor_summary','queue') and p_now-o.not_before>interval '30 minutes' then
    return jsonb_build_object('action','skip','code','JOB_STALE');
  end if;
  local_now:=p_now at time zone 'Asia/Kolkata';
  if o.purpose<>'staff_reply' and c.settings->'quiet_hours'->'enabled' is distinct from 'false'::jsonb then
    if coalesce(c.settings->'quiet_hours'->>'start','21:00')!~'^([01][0-9]|2[0-3]):[0-5][0-9]$'
      or coalesce(c.settings->'quiet_hours'->>'end','07:00')!~'^([01][0-9]|2[0-3]):[0-5][0-9]$' then
      return jsonb_build_object('action','skip','code','CONFIG_INVALID');
    end if;
    start_at:=coalesce(c.settings->'quiet_hours'->>'start','21:00')::time;
    end_at:=coalesce(c.settings->'quiet_hours'->>'end','07:00')::time;
    if start_at=end_at then return jsonb_build_object('action','skip','code','CONFIG_INVALID'); end if;
    if (start_at>end_at and (local_now::time>=start_at or local_now::time<end_at))
      or (start_at<end_at and local_now::time>=start_at and local_now::time<end_at) then
      next_at:=local_now::date+end_at;
      if start_at>end_at and local_now::time>=start_at then next_at:=next_at+interval '1 day'; end if;
      return jsonb_build_object('action','defer','code','QUIET_HOURS','not_before',next_at at time zone 'Asia/Kolkata');
    end if;
  end if;
  select count(*) into used from public.outbox x where x.clinic_id=c.id and x.id<>o.id and x.cap_date=local_now::date
    and (x.status in ('sent','uncertain') or (x.status='processing' and x.prepared_at is not null));
  if used>=c.daily_send_cap then
    perform private.delivery_alert(c.id,null,'SEND_CAP_REACHED','cap/'||c.id::text||'/'||local_now::date::text||'/100',p_now);
    return jsonb_build_object('action','defer','code','SEND_CAP_REACHED','not_before',(local_now::date+1)::timestamp at time zone 'Asia/Kolkata');
  end if;
  return jsonb_build_object('action','send','used',used,'cap',c.daily_send_cap);
end $$;

-- All contact mutations and mock send boundaries use the same contact-before-patient lock order.
alter function private.patient_write(text,jsonb,uuid,uuid) rename to patient_write_without_contact_lock;
revoke all on function private.patient_write_without_contact_lock(text,jsonb,uuid,uuid) from public,anon,authenticated,service_role;
create function private.patient_write(p_operation text,p_input jsonb,p_request_id uuid,p_patient_id uuid default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; mobile text; result jsonb;
begin
  s:=private.require_staff();
  if p_operation='create' then mobile:=p_input->>'mobile_e164';
  else select mobile_e164 into mobile from public.patients where clinic_id=s.clinic_id and id=p_patient_id; end if;
  if mobile is not null then perform pg_advisory_xact_lock(hashtextextended('contact/'||s.clinic_id::text||'/'||mobile,0)); end if;
  result:=private.patient_write_without_contact_lock(p_operation,p_input,p_request_id,p_patient_id);
  if p_operation='consent' and p_input->>'status'='revoked' then
    update public.conversations set resume_patient_ids=array_remove(resume_patient_ids,p_patient_id)
      where clinic_id=s.clinic_id and mobile_e164=mobile;
  end if;
  return result;
end $$;
revoke all on function private.patient_write(text,jsonb,uuid,uuid) from public,anon,authenticated,service_role;
grant execute on function private.patient_write(text,jsonb,uuid,uuid) to authenticated;

alter function private.delivery(text,jsonb,timestamptz) rename to delivery_without_contact_lock;
revoke all on function private.delivery_without_contact_lock(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
create function private.delivery(p_action text,p_input jsonb,p_now timestamptz default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare clinic uuid; mobile text; o public.outbox; t timestamptz:=coalesce(p_now,clock_timestamp());
begin
  if p_action in ('prepare','mock_accept','lookup','complete','failure') then
    select x.clinic_id,p.mobile_e164 into clinic,mobile from public.outbox x join public.patients p on p.id=x.patient_id and p.clinic_id=x.clinic_id where x.id=(p_input->>'id')::uuid;
    if mobile is not null then perform pg_advisory_xact_lock(hashtextextended('contact/'||clinic::text||'/'||mobile,0)); end if;
    if p_action in ('prepare','mock_accept') and exists(select 1 from public.conversations where clinic_id=clinic and mobile_e164=mobile and channel_stopped) then
      select * into o from public.outbox where id=(p_input->>'id')::uuid for update;
      if o.status='processing' and o.lock_owner=(p_input->>'worker_id')::uuid and o.lease_token=(p_input->>'lease_token')::uuid and o.locked_at>t-interval '5 minutes'
        and not exists(select 1 from public.mock_deliveries where outbox_id=o.id) then
        update public.outbox set status='skipped',last_error='WA_OPTED_OUT',lock_owner=null,lease_token=null,locked_at=null,prepared_at=null where id=o.id;
        insert into public.audit_log(clinic_id,action,table_name,record_id,created_at) values(clinic,'outbox.contact_suppressed','patients',o.patient_id,t);
        return jsonb_build_object('action','skip','code','WA_OPTED_OUT');
      end if;
    end if;
  end if;
  return private.delivery_without_contact_lock(p_action,p_input,p_now);
end $$;
revoke all on function private.delivery(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
grant execute on function private.delivery(text,jsonb,timestamptz) to service_role;

create function private.gateway_message(p_clinic uuid,p_raw uuid,m jsonb,t timestamptz) returns void
language plpgsql security invoker set search_path='' as $$
declare mobile text; provider text; at timestamptz; kind text; command text; fingerprint text;
  c public.conversations; p public.patients; latest public.consents; old public.message_log;
  inserted uuid; family_count integer; selected_patient uuid; notice text; approved boolean; state_after text;
begin
  provider:=m->>'id'; kind:=m->>'type';
  if jsonb_typeof(m)<>'object' or provider is null or length(provider) not between 1 and 200
    or jsonb_typeof(m->'from')<>'string' or (m->>'from')!~'^91[6-9][0-9]{9}$'
    or jsonb_typeof(m->'timestamp')<>'string' or (m->>'timestamp')!~'^[0-9]{1,12}$' then
    raise exception 'WEBHOOK_EVENT_INVALID' using errcode='22023';
  end if;
  at:=to_timestamp((m->>'timestamp')::double precision);
  if at>t+interval '5 minutes' then raise exception 'WEBHOOK_EVENT_INVALID' using errcode='22023'; end if;
  mobile:='+'||(m->>'from');
  fingerprint:=encode(sha256(convert_to(p_clinic::text||':'||m::text,'UTF8')),'hex');
  perform pg_advisory_xact_lock(hashtextextended('contact/'||p_clinic::text||'/'||mobile,0));
  select count(*),case when count(*)=1 then (array_agg(id))[1] else null end into family_count,selected_patient
    from public.patients where clinic_id=p_clinic and mobile_e164=mobile and merged_into is null;
  state_after:=case when family_count=0 then 'new' when family_count>1 then 'choose_patient' else 'awaiting_consent' end;
  insert into public.conversations(clinic_id,patient_id,mobile_e164,state,last_inbound_at)
    values(p_clinic,selected_patient,mobile,state_after,at)
    on conflict(clinic_id,mobile_e164) do update set last_inbound_at=greatest(conversations.last_inbound_at,excluded.last_inbound_at)
    returning * into c;
  insert into public.message_log(clinic_id,patient_id,conversation_id,direction,wa_message_id,type,status,cost_category,source_hash,source_raw_id,created_at)
    values(p_clinic,selected_patient,c.id,'in',provider,coalesce(kind,'unknown'),'received','inbound_unpriced',fingerprint,p_raw,at)
    on conflict(wa_message_id) do nothing returning id into inserted;
  if inserted is null then
    select * into old from public.message_log where wa_message_id=provider;
    if old.clinic_id<>p_clinic or old.direction<>'in' or old.source_hash is distinct from fingerprint then
      raise exception 'WEBHOOK_MESSAGE_CONFLICT' using errcode='22023';
    end if;
    return;
  end if;
  insert into public.audit_log(clinic_id,action,table_name,record_id,request_id,created_at)
    select p_clinic,'gateway.patient_lookup','patients',id,p_raw,t from public.patients where clinic_id=p_clinic and mobile_e164=mobile and merged_into is null;
  command:=lower(trim(case kind when 'text' then m->'text'->>'body' when 'interactive' then coalesce(m->'interactive'->'button_reply'->>'id',m->'interactive'->'list_reply'->>'id') when 'button' then m->'button'->>'payload' end));
  if command in ('stop','unsubscribe','opt out','बंद','ఆపు') then
    if not c.channel_stopped then
      select coalesce(array_agg(x.id),'{}'::uuid[]) into c.resume_patient_ids from public.patients x
        where x.clinic_id=p_clinic and x.mobile_e164=mobile and x.merged_into is null and not x.opted_out
        and (select status from public.consents where clinic_id=p_clinic and patient_id=x.id order by recorded_order desc limit 1)='granted';
    end if;
    update public.conversations set channel_stopped=true,stopped_at=greatest(stopped_at,at),last_command_at=greatest(last_command_at,at),
      resume_patient_ids=c.resume_patient_ids,state='closed',patient_id=null where id=c.id;
    for p in select * from public.patients where clinic_id=p_clinic and mobile_e164=mobile and merged_into is null order by id for update loop
      select * into latest from public.consents where clinic_id=p_clinic and patient_id=p.id order by recorded_order desc limit 1;
      insert into public.consents(clinic_id,patient_id,version,status,channel,source_message_id)
        values(p_clinic,p.id,coalesce(latest.version,'unversioned-stop'),'revoked','whatsapp',provider);
      update public.patients set opted_out=true where id=p.id;
      update public.outbox x set status='skipped',last_error='WA_OPTED_OUT',locked_at=null,lock_owner=null,lease_token=null,prepared_at=null
        where x.clinic_id=p_clinic and x.patient_id=p.id and (x.status='queued' or (x.status='processing' and not exists(select 1 from public.mock_deliveries d where d.outbox_id=x.id)));
      insert into public.events(clinic_id,patient_id,type,occurred_at,meta) values(p_clinic,p.id,'consent.revoked',at,jsonb_build_object('source_message_id',provider));
      insert into public.audit_log(clinic_id,action,table_name,record_id,request_id,created_at) values(p_clinic,'gateway.stop','patients',p.id,p_raw,t);
    end loop;
  elsif command in ('start','शुरू','ప్రారంభించు') then
    -- Stale/tied START never overrides a later STOP or an already-processed command.
    if (c.last_command_at is null or at>c.last_command_at) and (c.stopped_at is null or at>c.stopped_at) then
      select settings->>'consent_version',settings->'consent_notice_approved'='true'::jsonb into notice,approved from public.clinics where id=p_clinic;
      if approved and notice is not null and length(trim(notice)) between 1 and 100 then
        for p in select * from public.patients where clinic_id=p_clinic and mobile_e164=mobile and merged_into is null and id=any(c.resume_patient_ids) order by id for update loop
          select * into latest from public.consents where clinic_id=p_clinic and patient_id=p.id order by recorded_order desc limit 1;
          if latest.status='revoked' and latest.channel='whatsapp' and latest.version=notice then
            insert into public.consents(clinic_id,patient_id,version,status,channel,source_message_id) values(p_clinic,p.id,notice,'granted','whatsapp',provider);
            update public.patients set opted_out=false where id=p.id;
            insert into public.events(clinic_id,patient_id,type,occurred_at,meta) values(p_clinic,p.id,'consent.granted',at,jsonb_build_object('source_message_id',provider));
            insert into public.audit_log(clinic_id,action,table_name,record_id,request_id,created_at) values(p_clinic,'gateway.start','patients',p.id,p_raw,t);
          end if;
        end loop;
        update public.conversations set channel_stopped=false,last_command_at=at,resume_patient_ids='{}',
          state=case when family_count>1 then 'choose_patient' else 'awaiting_consent' end,patient_id=selected_patient where id=c.id;
      else
        update public.conversations set state='awaiting_consent',last_command_at=at where id=c.id;
      end if;
    end if;
  elsif kind not in ('text','interactive','button') or kind is null then
    update public.conversations set handoff=true,state='handoff' where id=c.id and not channel_stopped;
    perform private.delivery_alert(p_clinic,selected_patient,'CONV_UNSUPPORTED_TYPE','inbound/'||provider,t);
  end if;
  insert into public.events(clinic_id,patient_id,type,occurred_at,meta)
    values(p_clinic,selected_patient,'message.received',at,jsonb_build_object('wa_message_id',provider,'conversation_id',c.id));
end $$;

create function private.gateway(p_action text,p_input jsonb,p_now timestamptz default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare t timestamptz:=coalesce(p_now,clock_timestamp()); g jsonb; r public.webhook_raw; clinic uuid; phone text; fingerprint text;
  worker uuid; fence uuid; accepted integer:=0; duplicate integer:=0; deleted integer:=0; n integer; incident boolean;
  m jsonb; s jsonb; at timestamptz; receipt jsonb; code text; error_state text; mobile text;
begin
  if p_input is null or jsonb_typeof(p_input)<>'object' then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  if p_action='bad_signature' then
    if length(coalesce(p_input->>'gateway_id','')) not between 1 and 100 then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    insert into public.gateway_security(gateway_id,hour_start,failures) values(p_input->>'gateway_id',date_trunc('hour',t),1)
      on conflict(gateway_id,hour_start) do update set failures=gateway_security.failures+1,alert=(gateway_security.failures+1>10)
      returning failures,alert into n,incident;
    return jsonb_build_object('failures',n,'alert',incident);
  elsif p_action='intake' then
    if jsonb_typeof(p_input->'groups') is distinct from 'array' or jsonb_array_length(p_input->'groups') not between 1 and 100 then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    for g in select value from jsonb_array_elements(p_input->'groups') loop
      if jsonb_typeof(g->'payload') is distinct from 'object' then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
      phone:=coalesce(g->>'phone_number_id','unrouted');
      if length(phone) not between 1 and 100 then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
      if g->>'phone_number_id' is not null and (phone!~'^[0-9]{1,80}$' or phone is distinct from g->'payload'->'metadata'->>'phone_number_id') then
        raise exception 'INPUT_INVALID' using errcode='22023';
      end if;
      select id into clinic from public.clinics where whatsapp_phone_number_id=phone;
      fingerprint:=encode(sha256(convert_to(phone||':'||(g->'payload')::text,'UTF8')),'hex');
      insert into public.webhook_raw(clinic_id,phone_number_id,payload,intake_key,status,received_at,not_before)
        values(clinic,phone,g->'payload',fingerprint,case when clinic is null then 'quarantined' else 'queued' end,t,t)
        on conflict(intake_key) do nothing;
      if found then accepted:=accepted+1; else duplicate:=duplicate+1; end if;
    end loop;
    return jsonb_build_object('accepted',accepted,'duplicates',duplicate);
  elsif p_action='claim' then
    worker:=(p_input->>'worker_id')::uuid;
    if worker is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    select * into r from public.webhook_raw where (status='queued' and not_before<=t) or (status='processing' and locked_at<=t-interval '5 minutes')
      order by received_at,id for update skip locked limit 1;
    if not found then return null; end if;
    update public.webhook_raw set status='processing',lock_owner=worker,lease_token=gen_random_uuid(),locked_at=t where id=r.id returning * into r;
    return jsonb_build_object('id',r.id,'worker_id',worker,'lease_token',r.lease_token);
  elsif p_action='cleanup' then
    for r in select * from public.webhook_raw where received_at<t-interval '7 days' and (status<>'processing' or locked_at<=t-interval '5 minutes') order by received_at,id for update skip locked limit 500 loop
      if r.clinic_id is not null then
        if r.status in ('queued','processing') then perform private.delivery_alert(r.clinic_id,null,'WEBHOOK_RETENTION_EXPIRED','retention/'||r.id::text,t); end if;
        insert into public.audit_log(clinic_id,action,table_name,record_id,created_at) values(r.clinic_id,'webhook.retention_delete','webhook_raw',r.id,t);
      end if;
      delete from public.webhook_raw where id=r.id; deleted:=deleted+1;
    end loop;
    delete from public.gateway_security where hour_start<t-interval '7 days';
    insert into public.gateway_maintenance(occurred_at,action,meta) values(t,'webhook.cleanup',jsonb_build_object('deleted',deleted));
    return jsonb_build_object('deleted',deleted);
  elsif p_action='replay' then
    select * into r from public.webhook_raw where id=(p_input->>'id')::uuid for update;
    if not found or r.clinic_id is null or r.status='processing' or r.received_at<t-interval '7 days'
      or not exists(select 1 from public.clinics where id=r.clinic_id and whatsapp_phone_number_id=r.phone_number_id) then raise exception 'REPLAY_FORBIDDEN' using errcode='42501'; end if;
    update public.webhook_raw set status='queued',not_before=t,last_error=null where id=r.id;
    insert into public.audit_log(clinic_id,action,table_name,record_id,created_at) values(r.clinic_id,'webhook.replay','webhook_raw',r.id,t);
    return jsonb_build_object('action','queued');
  elsif p_action<>'process' or p_action is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;

  worker:=(p_input->>'worker_id')::uuid; fence:=(p_input->>'lease_token')::uuid;
  select * into r from public.webhook_raw where id=(p_input->>'id')::uuid for update;
  if not found or r.status<>'processing' or worker is null or fence is null or r.lock_owner<>worker or r.lease_token<>fence or r.locked_at<=t-interval '5 minutes' then raise exception 'LEASE_LOST' using errcode='P0001'; end if;
  if r.clinic_id is null or not exists(select 1 from public.clinics where id=r.clinic_id and whatsapp_phone_number_id=r.phone_number_id) then
    update public.webhook_raw set status='quarantined',last_error='WEBHOOK_ROUTE_UNKNOWN',lock_owner=null,lease_token=null,locked_at=null where id=r.id;
    return jsonb_build_object('action','quarantined');
  end if;
  begin
    if (r.payload?'messages' and (jsonb_typeof(r.payload->'messages')<>'array' or jsonb_array_length(r.payload->'messages')>100))
      or (r.payload?'statuses' and (jsonb_typeof(r.payload->'statuses')<>'array' or jsonb_array_length(r.payload->'statuses')>100)) then raise exception 'WEBHOOK_EVENT_INVALID' using errcode='22023'; end if;
    for mobile in select distinct '+'||(value->>'from') from jsonb_array_elements(coalesce(r.payload->'messages','[]'::jsonb)) where value->>'from' is not null order by 1 loop
      perform pg_advisory_xact_lock(hashtextextended('contact/'||r.clinic_id::text||'/'||mobile,0));
    end loop;
    for m in select value from jsonb_array_elements(coalesce(r.payload->'messages','[]'::jsonb)) loop
      perform private.gateway_message(r.clinic_id,r.id,m,t);
    end loop;
    for s in select value from jsonb_array_elements(coalesce(r.payload->'statuses','[]'::jsonb)) loop
      if jsonb_typeof(s->'timestamp') is distinct from 'string' or (s->>'timestamp')!~'^[0-9]{1,12}$' then raise exception 'WEBHOOK_EVENT_INVALID' using errcode='22023'; end if;
      at:=to_timestamp((s->>'timestamp')::double precision);
      receipt:=jsonb_build_object('clinic_id',r.clinic_id,'wa_message_id',s->>'id','status',s->>'status','occurred_at',at);
      if s->'errors'->0->>'code' is not null then receipt:=receipt||jsonb_build_object('error_code',s->'errors'->0->>'code'); end if;
      perform private.delivery('receipt',receipt,t);
    end loop;
    update public.webhook_raw set status='processed',processed_at=t,attempts=attempts+1,last_error=null,lock_owner=null,lease_token=null,locked_at=null where id=r.id;
    return jsonb_build_object('action','processed');
  exception when others then
    get stacked diagnostics code=MESSAGE_TEXT,error_state=RETURNED_SQLSTATE;
    code:=case when code in ('WEBHOOK_EVENT_INVALID','WEBHOOK_MESSAGE_CONFLICT','INPUT_INVALID') then code else 'WEBHOOK_PROCESS_FAILED' end;
    update public.webhook_raw set status=case when error_state='22023' or attempts>=2 then 'failed' else 'queued' end,
      attempts=attempts+1,not_before=t+interval '1 minute',last_error=code,lock_owner=null,lease_token=null,locked_at=null where id=r.id returning * into r;
    if r.status='failed' then perform private.delivery_alert(r.clinic_id,null,code,'gateway/'||r.id::text,t); end if;
    return jsonb_build_object('action',r.status,'code',code);
  end;
end $$;

create function public.tabiyo_gateway(p_action text,p_input jsonb,p_now timestamptz default null) returns jsonb
language sql security invoker set search_path='' as $$ select private.gateway(p_action,p_input,p_now) $$;
revoke all on function private.gateway_message(uuid,uuid,jsonb,timestamptz),private.gateway(text,jsonb,timestamptz),public.tabiyo_gateway(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
grant execute on function private.gateway(text,jsonb,timestamptz),public.tabiyo_gateway(text,jsonb,timestamptz) to service_role;

commit;
