begin;

create table public.clinic_features (
  clinic_id uuid not null references public.clinics(id),
  feature text not null check (feature in ('med_reminders','ai_faq','walk_in_tokens','doctor_summary','lang_te','lang_hi')),
  enabled boolean not null default false,
  updated_by uuid,
  updated_at timestamptz not null default now(),
  primary key (clinic_id,feature),
  foreign key (updated_by,clinic_id) references public.staff_users(id,clinic_id)
);
create table public.events (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id),
  patient_id uuid,
  appointment_id uuid,
  type text not null check (length(type) between 1 and 100),
  occurred_at timestamptz not null default now(),
  meta jsonb not null default '{}'::jsonb,
  foreign key (patient_id,clinic_id) references public.patients(id,clinic_id)
);
create index events_clinic_type_time_idx on public.events(clinic_id,type,occurred_at);
create table public.audit_log (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id),
  user_id uuid,
  action text not null,
  table_name text not null,
  record_id uuid,
  request_id uuid,
  reason text,
  created_at timestamptz not null default now(),
  foreign key (user_id,clinic_id) references public.staff_users(id,clinic_id)
);
create index audit_log_clinic_time_idx on public.audit_log(clinic_id,created_at);
create table public.outbox (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id),
  patient_id uuid not null,
  kind text not null check (kind in ('template','text','interactive','document')),
  purpose text not null check (purpose in ('consent_request','appointment','reminder','slip','medication','staff_reply','doctor_summary','queue')),
  payload jsonb not null,
  idempotency_key text not null unique,
  not_before timestamptz not null default now(),
  status text not null default 'queued' check (status in ('queued','processing','sent','failed','skipped')),
  attempts integer not null default 0 check (attempts>=0),
  last_error text,
  wa_message_id text unique,
  locked_at timestamptz,
  lock_owner uuid,
  created_at timestamptz not null default now(),
  foreign key (patient_id,clinic_id) references public.patients(id,clinic_id)
);
create index outbox_due_idx on public.outbox(status,not_before);
-- Unknown number IDs are quarantined with no staff access; gateway routing will split payloads by number.
alter table public.clinics add constraint clinics_id_phone_unique unique(id,whatsapp_phone_number_id);
create table public.webhook_raw (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid references public.clinics(id),
  received_at timestamptz not null default now(),
  phone_number_id text not null,
  payload jsonb not null,
  foreign key (clinic_id,phone_number_id) references public.clinics(id,whatsapp_phone_number_id)
);
create index webhook_raw_received_idx on public.webhook_raw(received_at);
create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id),
  patient_id uuid,
  mobile_e164 text not null check (mobile_e164 ~ '^\+91[6-9][0-9]{9}$'),
  state text not null default 'new' check (state in ('new','awaiting_consent','choose_patient','menu','booking','my_appointments','slip_verify','slip_select','faq','handoff','closed')),
  context jsonb not null default '{}'::jsonb,
  language text not null default 'en' check (language in ('en','te','hi')),
  last_inbound_at timestamptz,
  handoff boolean not null default false,
  assigned_to uuid,
  unique (clinic_id,mobile_e164),
  foreign key (patient_id,clinic_id) references public.patients(id,clinic_id),
  foreign key (assigned_to,clinic_id) references public.staff_users(id,clinic_id)
);
-- Support table beyond the handbook's 21 domain tables: durable, actor-bound API replay records.
create table public.api_requests (
  clinic_id uuid not null references public.clinics(id),
  request_id uuid not null,
  actor_id uuid not null,
  patient_id uuid not null,
  operation text not null,
  request_hash text not null,
  response jsonb not null,
  created_at timestamptz not null default now(),
  primary key(clinic_id,request_id),
  foreign key (actor_id,clinic_id) references public.staff_users(id,clinic_id),
  foreign key (patient_id,clinic_id) references public.patients(id,clinic_id)
);

alter table public.clinic_features enable row level security;
alter table public.events enable row level security;
alter table public.audit_log enable row level security;
alter table public.outbox enable row level security;
alter table public.webhook_raw enable row level security;
alter table public.conversations enable row level security;
alter table public.api_requests enable row level security;

create policy features_read_member on public.clinic_features for select to authenticated
using (exists(select 1 from public.staff_users s where s.id=(select auth.uid()) and s.active and s.clinic_id=clinic_features.clinic_id));
create policy audit_read_admin on public.audit_log for select to authenticated
using (exists(select 1 from public.staff_users s where s.id=(select auth.uid()) and s.active and s.role='admin' and s.clinic_id=audit_log.clinic_id));
-- No end-user grants on raw payloads, replay responses, outbox or conversations in this increment.
revoke all on public.clinic_features,public.events,public.audit_log,public.outbox,public.webhook_raw,public.conversations,public.api_requests from public,anon,authenticated,service_role;
grant select on public.clinic_features,public.audit_log to authenticated;
grant select,insert,update,delete on public.clinic_features,public.outbox,public.webhook_raw,public.conversations to service_role;
grant select,insert on public.events,public.audit_log,public.api_requests to service_role;

-- Patient data goes through audited, transactional operations. RLS stays enabled as defense in depth.
revoke all on public.patients,public.consents from anon,authenticated;
create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

create function private.require_staff() returns public.staff_users
language plpgsql security definer set search_path='' as $$
declare s public.staff_users;
begin
  if auth.uid() is null then raise exception 'STAFF_FORBIDDEN' using errcode='42501'; end if;
  select * into s from public.staff_users where id=auth.uid() and active for share;
  if not found then raise exception 'STAFF_FORBIDDEN' using errcode='42501'; end if;
  return s;
end $$;

create function private.validate_patient_input(p_input jsonb,p_partial boolean) returns void
language plpgsql security invoker set search_path='' as $$
declare k text;
begin
  if p_input is null or jsonb_typeof(p_input)<>'object' or p_input='{}'::jsonb
    or p_input-array['name','mobile_e164','date_of_birth','gender','language']<>'{}'::jsonb then
    raise exception 'INPUT_INVALID' using errcode='22023';
  end if;
  if not p_partial and (not p_input?'name' or not p_input?'mobile_e164') then
    raise exception 'INPUT_INVALID' using errcode='22023';
  end if;
  for k in select jsonb_object_keys(p_input) loop
    if jsonb_typeof(p_input->k)<>'string' and not (k in ('date_of_birth','gender') and p_input->k='null'::jsonb) then
      raise exception 'INPUT_INVALID' using errcode='22023';
    end if;
  end loop;
  if p_input?'name' and length(trim(p_input->>'name')) not between 1 and 200 then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  if p_input?'mobile_e164' and (p_input->>'mobile_e164')!~'^\+91[6-9][0-9]{9}$' then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  if p_input?'language' and p_input->>'language' not in ('en','te','hi') then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  if p_input?'gender' and p_input->>'gender' not in ('female','male','other','undisclosed') then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  if p_input?'date_of_birth' and p_input->>'date_of_birth' is not null then
    if (p_input->>'date_of_birth')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$' or (p_input->>'date_of_birth')::date>(now() at time zone 'Asia/Kolkata')::date then
      raise exception 'INPUT_INVALID' using errcode='22023';
    end if;
  end if;
end $$;

-- These private definer functions exist to enforce mandatory audit/outbox writes without granting
-- clients the ability to forge those records. Every operation resolves identity/clinic itself.
create function private.patient_search(p_mobile text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; result jsonb;
begin
  s:=private.require_staff();
  if p_mobile is null or p_mobile!~'^\+91[6-9][0-9]{9}$' then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  -- Build the result and audit exactly the same rows in one SQL statement/snapshot.
  with matches as materialized (
    select * from public.patients where clinic_id=s.clinic_id and mobile_e164=p_mobile and merged_into is null
    order by created_at,id
  ), access_audit as (
    insert into public.audit_log(clinic_id,user_id,action,table_name,record_id)
    select s.clinic_id,s.id,'patient.read','patients',id from matches returning id
  ) select coalesce(jsonb_agg(to_jsonb(matches)),'[]'::jsonb) into result from matches;
  return result;
end $$;

create function private.patient_write(p_operation text,p_input jsonb,p_request_id uuid,p_patient_id uuid default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; p public.patients; c public.consents; cached public.api_requests;
  fingerprint text; result jsonb; clinic_language text; consent_status text;
begin
  s:=private.require_staff();
  if p_request_id is null or p_operation not in ('create','update','consent') or p_operation is null then
    raise exception 'INPUT_INVALID' using errcode='22023';
  end if;
  if (p_operation='create' and p_patient_id is not null) or (p_operation<>'create' and p_patient_id is null) then
    raise exception 'INPUT_INVALID' using errcode='22023';
  end if;
  fingerprint:=encode(sha256(convert_to(jsonb_build_object('input',p_input,'patient_id',p_patient_id)::text,'UTF8')),'hex');
  perform pg_advisory_xact_lock(hashtextextended(s.clinic_id::text||':'||p_request_id::text,0));
  select * into cached from public.api_requests where clinic_id=s.clinic_id and request_id=p_request_id;
  if found then
    if cached.actor_id<>s.id or cached.operation<>p_operation or cached.request_hash<>fingerprint then
      raise exception 'IDEMPOTENCY_CONFLICT' using errcode='23505';
    end if;
    insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id)
      values(s.clinic_id,s.id,'patient.request_replayed','patients',cached.patient_id,p_request_id);
    return cached.response||jsonb_build_object('replayed',true);
  end if;

  if p_operation='create' then
    perform private.validate_patient_input(p_input,false);
    select default_language into clinic_language from public.clinics where id=s.clinic_id;
    insert into public.patients(clinic_id,name,mobile_e164,date_of_birth,gender,language)
      values(s.clinic_id,trim(p_input->>'name'),p_input->>'mobile_e164',(p_input->>'date_of_birth')::date,
        p_input->>'gender',coalesce(p_input->>'language',clinic_language)) returning * into p;
    insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key)
      values(s.clinic_id,p.id,'template','consent_request',jsonb_build_object('template_name','consent_request','language',p.language),
        'consent-request/'||s.clinic_id::text||'/'||p_request_id::text);
  else
    select * into p from public.patients where clinic_id=s.clinic_id and id=p_patient_id and merged_into is null for update;
    if not found then raise exception 'PATIENT_NOT_FOUND' using errcode='P0002'; end if;
    if p_operation='update' then
      perform private.validate_patient_input(p_input,true);
      if p_input?'mobile_e164' and p_input->>'mobile_e164'<>p.mobile_e164 then
        raise exception 'CONTACT_CHANGE_REQUIRES_VERIFICATION' using errcode='22023';
      end if;
      update public.patients set
        name=case when p_input?'name' then trim(p_input->>'name') else name end,
        date_of_birth=case when p_input?'date_of_birth' then (p_input->>'date_of_birth')::date else date_of_birth end,
        gender=case when p_input?'gender' then p_input->>'gender' else gender end,
        language=case when p_input?'language' then p_input->>'language' else language end
        where id=p.id and clinic_id=s.clinic_id returning * into p;
    else
      if p_input is null or jsonb_typeof(p_input)<>'object' or p_input-array['version','status','channel']<>'{}'::jsonb
        or not p_input?&array['version','status','channel']
        or jsonb_typeof(p_input->'version')<>'string' or jsonb_typeof(p_input->'status')<>'string' or jsonb_typeof(p_input->'channel')<>'string'
        or length(trim(p_input->>'version')) not between 1 and 100
        or p_input->>'status' not in ('granted','revoked') or p_input->>'channel' not in ('phone','whatsapp','paper','dashboard') then
        raise exception 'INPUT_INVALID' using errcode='22023';
      end if;
      -- Staff cannot impersonate an inbound WhatsApp consent; that channel is reserved for the gateway.
      if p_input->>'channel'='whatsapp' then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
      insert into public.consents(clinic_id,patient_id,version,status,channel,created_by)
        values(s.clinic_id,p.id,trim(p_input->>'version'),p_input->>'status',p_input->>'channel',s.id) returning * into c;
      consent_status:=c.status;
      update public.patients set opted_out=(c.status='revoked') where clinic_id=s.clinic_id and id=p.id returning * into p;
      if c.status='revoked' then
        update public.outbox set status='skipped',last_error='WA_OPTED_OUT',locked_at=null,lock_owner=null
          where clinic_id=s.clinic_id and patient_id=p.id and status='queued';
      end if;
    end if;
  end if;

  insert into public.events(clinic_id,patient_id,type,meta)
    values(s.clinic_id,p.id,case when p_operation='consent' then 'consent.'||consent_status when p_operation='create' then 'patient.created' else 'patient.updated' end,
      jsonb_build_object('request_id',p_request_id));
  insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id)
    values(s.clinic_id,s.id,'patient.'||p_operation,'patients',p.id,p_request_id);
  if p_operation='consent' then
    insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id)
      values(s.clinic_id,s.id,'consent.'||consent_status,'consents',c.id,p_request_id);
  end if;
  result:=jsonb_build_object('patient',to_jsonb(p),'replayed',false);
  if p_operation='consent' then result:=result||jsonb_build_object('consent',to_jsonb(c)); end if;
  insert into public.api_requests(clinic_id,request_id,actor_id,patient_id,operation,request_hash,response)
    values(s.clinic_id,p_request_id,s.id,p.id,p_operation,fingerprint,result);
  return result;
end $$;

-- Only invoker wrappers are exposed over the Data API. Their private implementation has explicit grants.
create function public.tabiyo_patient_search(p_mobile text) returns jsonb
language sql security invoker set search_path='' as $$ select private.patient_search(p_mobile) $$;
create function public.tabiyo_patient_write(p_operation text,p_input jsonb,p_request_id uuid,p_patient_id uuid default null) returns jsonb
language sql security invoker set search_path='' as $$ select private.patient_write(p_operation,p_input,p_request_id,p_patient_id) $$;

revoke all on function private.require_staff(),private.validate_patient_input(jsonb,boolean),private.patient_search(text),private.patient_write(text,jsonb,uuid,uuid) from public,anon,authenticated,service_role;
revoke all on function public.tabiyo_patient_search(text),public.tabiyo_patient_write(text,jsonb,uuid,uuid) from public,anon,authenticated,service_role;
grant execute on function private.patient_search(text),private.patient_write(text,jsonb,uuid,uuid) to authenticated;
grant execute on function public.tabiyo_patient_search(text),public.tabiyo_patient_write(text,jsonb,uuid,uuid) to authenticated;

commit;
