begin;
alter table public.doctors add column schedule_revision integer not null default 0 check(schedule_revision>=0);
alter table public.staff_alerts add column context jsonb not null default '{}' check(
  jsonb_typeof(context)='object' and context-array['doctor_id','appointment_id','outbox_id']='{}'::jsonb
  and (not context?'doctor_id' or (jsonb_typeof(context->'doctor_id')='string' and (context->>'doctor_id')~'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'))
  and (not context?'appointment_id' or (jsonb_typeof(context->'appointment_id')='string' and (context->>'appointment_id')~'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'))
  and (not context?'outbox_id' or (jsonb_typeof(context->'outbox_id')='string' and (context->>'outbox_id')~'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'))
);
create index appointments_doctor_future on public.appointments(doctor_id,starts_at) where status in ('booked','checked_in');

create function private.appointment_interval_available(a public.appointments) returns boolean
language sql stable security invoker set search_path='' as $$
  select exists(select 1 from public.doctors d join public.doctor_schedules s on s.doctor_id=d.id and s.clinic_id=d.clinic_id
    join public.clinics c on c.id=d.clinic_id where d.id=a.doctor_id and d.clinic_id=a.clinic_id and d.active
    and s.weekday=extract(dow from a.starts_at at time zone 'Asia/Kolkata')
    and (a.starts_at at time zone 'Asia/Kolkata')::date=(a.ends_at at time zone 'Asia/Kolkata')::date
    and (a.starts_at at time zone 'Asia/Kolkata')::time>=s.start_time and (a.ends_at at time zone 'Asia/Kolkata')::time<=s.end_time
    and date_trunc('minute',a.starts_at)=a.starts_at and a.ends_at-a.starts_at=make_interval(mins=>d.slot_minutes)
    and extract(epoch from ((a.starts_at at time zone 'Asia/Kolkata')::time-s.start_time))::bigint%(d.slot_minutes*60)=0
    and (s.break_start is null or not tstzrange(a.starts_at,a.ends_at,'[)') && tstzrange(
      ((a.starts_at at time zone 'Asia/Kolkata')::date+s.break_start) at time zone 'Asia/Kolkata',
      ((a.starts_at at time zone 'Asia/Kolkata')::date+s.break_end) at time zone 'Asia/Kolkata','[)'))
    and not exists(select 1 from public.doctor_leaves l where l.doctor_id=d.id and (a.starts_at at time zone 'Asia/Kolkata')::date between l.date_from and l.date_to)
    and not coalesce(c.settings->'holidays','[]'::jsonb)?((a.starts_at at time zone 'Asia/Kolkata')::date)::text)
$$;
revoke all on function private.appointment_interval_available(public.appointments) from public,anon,authenticated,service_role;

create function private.doctor_management(p_action text,p_input jsonb,p_request_id uuid default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; d public.doctors; cached public.staff_operation_requests; result jsonb; fingerprint text;
  schedule jsonb; leaves jsonb; affected jsonb:='[]'; row public.appointments; affected_count integer; alert_id uuid;
  selected_weekday integer; starts time; ends time; break_start time; break_end time; selected_from date; selected_to date; revision integer;
  queue_date date:=(clock_timestamp() at time zone 'Asia/Kolkata')::date;
begin
  s:=private.require_staff();
  if s.role<>'admin' then raise exception 'OPERATION_FORBIDDEN' using errcode='42501'; end if;
  if p_input is null or jsonb_typeof(p_input)<>'object' or p_action is null or p_action not in ('read','schedule','delete_schedule','leave','delete_leave') then
    raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  if p_action='read' then
    if p_input-array['doctor_id']<>'{}'::jsonb then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    select * into d from public.doctors where clinic_id=s.clinic_id and id=(p_input->>'doctor_id')::uuid;
    if not found then raise exception 'DOCTOR_NOT_FOUND' using errcode='P0001'; end if;
    select coalesce(jsonb_agg(to_jsonb(x) order by x.weekday),'[]') into schedule from public.doctor_schedules x where x.doctor_id=d.id and x.clinic_id=s.clinic_id;
    select coalesce(jsonb_agg(to_jsonb(x) order by x.date_from,x.id),'[]') into leaves from
      (select * from public.doctor_leaves where doctor_id=d.id and clinic_id=s.clinic_id and date_to>=(clock_timestamp() at time zone 'Asia/Kolkata')::date-30 order by date_from,id limit 200) x;
    for row in select * from public.appointments x where x.doctor_id=d.id and x.clinic_id=s.clinic_id and x.status in ('booked','checked_in')
      and x.starts_at>clock_timestamp() and not private.appointment_interval_available(x) order by x.starts_at,x.id limit 100 loop
      affected:=affected||jsonb_build_array(to_jsonb(row)||jsonb_build_object('patient_name',(select name from public.patients where id=row.patient_id and clinic_id=s.clinic_id)));
      insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'appointment.read','appointments',row.id);
      insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'patient.read','patients',row.patient_id);
    end loop;
    select count(*) into affected_count from public.appointments x where x.doctor_id=d.id and x.clinic_id=s.clinic_id and x.status in ('booked','checked_in')
      and x.starts_at>clock_timestamp() and not private.appointment_interval_available(x);
    insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'doctor.availability_read','doctors',d.id);
    return jsonb_build_object('doctor_id',d.id,'clinic_id',d.clinic_id,'revision',d.schedule_revision,'schedules',schedule,'leaves',leaves,
      'affected_appointments',affected,'affected_count',affected_count);
  end if;
  if p_request_id is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  fingerprint:=md5('doctor.'||p_action||':'||p_input::text);
  perform pg_advisory_xact_lock(hashtextextended('staff-operation/'||s.clinic_id::text||'/'||p_request_id::text,0));
  select * into cached from public.staff_operation_requests where clinic_id=s.clinic_id and request_id=p_request_id;
  if found then
    if cached.actor_id<>s.id or cached.fingerprint<>fingerprint then raise exception 'IDEMPOTENCY_CONFLICT' using errcode='P0001'; end if;
    return cached.response||jsonb_build_object('replayed',true);
  end if;
  perform pg_advisory_xact_lock(hashtextextended('queue/'||s.clinic_id::text||'/'||((p_input->>'doctor_id')::uuid)::text||'/'||queue_date::text,0));
  if queue_date<>(clock_timestamp() at time zone 'Asia/Kolkata')::date then raise exception 'AVAILABILITY_CHANGED' using errcode='P0001'; end if;
  select * into d from public.doctors where clinic_id=s.clinic_id and id=(p_input->>'doctor_id')::uuid for update;
  if not found then raise exception 'DOCTOR_NOT_FOUND' using errcode='P0001'; end if;
  revision:=(p_input->>'expected_revision')::integer;
  if revision is null or revision<>d.schedule_revision then raise exception 'AVAILABILITY_CHANGED' using errcode='P0001'; end if;
  if p_action in ('schedule','delete_schedule') then
    if p_input-array['doctor_id','expected_revision','weekday','start_time','end_time','break_start','break_end']<>'{}'::jsonb
      or (p_action='delete_schedule' and p_input-array['doctor_id','expected_revision','weekday']<>'{}'::jsonb) then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    selected_weekday:=(p_input->>'weekday')::integer;
    if selected_weekday is null or selected_weekday not between 0 and 6 then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    if p_action='delete_schedule' then
      delete from public.doctor_schedules where doctor_id=d.id and clinic_id=s.clinic_id and doctor_schedules.weekday=selected_weekday;
      if not found then raise exception 'SCHEDULE_NOT_FOUND' using errcode='P0001'; end if;
    else
      if coalesce(p_input->>'start_time','')!~'^([01][0-9]|2[0-3]):[0-5][0-9]$' or coalesce(p_input->>'end_time','')!~'^([01][0-9]|2[0-3]):[0-5][0-9]$'
        or (p_input->>'break_start' is not null and (p_input->>'break_start')!~'^([01][0-9]|2[0-3]):[0-5][0-9]$')
        or (p_input->>'break_end' is not null and (p_input->>'break_end')!~'^([01][0-9]|2[0-3]):[0-5][0-9]$') then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
      starts:=(p_input->>'start_time')::time;ends:=(p_input->>'end_time')::time;break_start:=(p_input->>'break_start')::time;break_end:=(p_input->>'break_end')::time;
      insert into public.doctor_schedules(clinic_id,doctor_id,weekday,start_time,end_time,break_start,break_end)
        values(s.clinic_id,d.id,selected_weekday,starts,ends,break_start,break_end)
        on conflict(doctor_id,weekday) do update set start_time=excluded.start_time,end_time=excluded.end_time,break_start=excluded.break_start,break_end=excluded.break_end;
    end if;
  elsif p_action='leave' then
    if p_input-array['doctor_id','expected_revision','date_from','date_to','reason']<>'{}'::jsonb or
      coalesce(p_input->>'reason','') not in ('planned_leave','clinic_change','other') or p_input->>'date_from' is null or p_input->>'date_to' is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    selected_from:=(p_input->>'date_from')::date;selected_to:=(p_input->>'date_to')::date;
    if selected_from<(clock_timestamp() at time zone 'Asia/Kolkata')::date or selected_to<selected_from or selected_to>selected_from+366 then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    if exists(select 1 from public.doctor_leaves l where l.doctor_id=d.id and l.clinic_id=s.clinic_id and l.date_from=selected_from and l.date_to=selected_to) then
      raise exception 'LEAVE_ALREADY_EXISTS' using errcode='P0001'; end if;
    insert into public.doctor_leaves(clinic_id,doctor_id,date_from,date_to,reason) values(s.clinic_id,d.id,selected_from,selected_to,p_input->>'reason');
  else
    if p_input-array['doctor_id','expected_revision','leave_id']<>'{}'::jsonb then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    delete from public.doctor_leaves where clinic_id=s.clinic_id and doctor_id=d.id and id=(p_input->>'leave_id')::uuid;
    if not found then raise exception 'LEAVE_NOT_FOUND' using errcode='P0001'; end if;
  end if;
  update public.doctors set schedule_revision=schedule_revision+1 where id=d.id returning schedule_revision into revision;
  select count(*) into affected_count from public.appointments x where x.doctor_id=d.id and x.clinic_id=s.clinic_id and x.status in ('booked','checked_in')
    and x.starts_at>clock_timestamp() and not private.appointment_interval_available(x);
  if affected_count>0 then
    -- No patient row locks while holding the doctor lock: booking acquires patient before doctor.
    perform private.delivery_alert(s.clinic_id,null,'DOCTOR_AVAILABILITY_REVIEW','doctor-availability/'||p_request_id::text,clock_timestamp());
    update public.staff_alerts set context=jsonb_build_object('doctor_id',d.id) where clinic_id=s.clinic_id and dedup_key='doctor-availability/'||p_request_id::text returning id into alert_id;
  end if;
  insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id) values(s.clinic_id,s.id,'doctor.'||p_action,'doctors',d.id,p_request_id);
  insert into public.events(clinic_id,type,meta) values(s.clinic_id,'doctor.availability_changed',jsonb_build_object('doctor_id',d.id,'revision',revision,'affected_count',affected_count));
  result:=jsonb_build_object('doctor_id',d.id,'clinic_id',s.clinic_id,'revision',revision,'affected_count',affected_count,'notice_alert_id',alert_id,'replayed',false);
  insert into public.staff_operation_requests(clinic_id,request_id,actor_id,action,fingerprint,response) values(s.clinic_id,p_request_id,s.id,'doctor.'||p_action,fingerprint,result);
  return result;
end $$;
revoke all on function private.doctor_management(text,jsonb,uuid) from public,anon,authenticated,service_role;
grant execute on function private.doctor_management(text,jsonb,uuid) to authenticated;
create function public.tabiyo_doctor_management(p_action text,p_input jsonb,p_request_id uuid default null) returns jsonb
language sql security invoker set search_path='' as $$ select private.doctor_management(p_action,p_input,p_request_id) $$;
revoke all on function public.tabiyo_doctor_management(text,jsonb,uuid) from public,anon,authenticated,service_role;
grant execute on function public.tabiyo_doctor_management(text,jsonb,uuid) to authenticated;

alter function private.staff_operations(text,jsonb) rename to staff_operations_without_context;
revoke all on function private.staff_operations_without_context(text,jsonb) from public,anon,authenticated,service_role;
create function private.staff_operations(p_action text,p_input jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
declare result jsonb; items jsonb; s public.staff_users;
begin
  s:=private.require_staff();
  if p_action='resolve_alert' and s.role in ('admin','front_desk') and exists(
    select 1 from public.staff_alerts a join public.appointments x on x.clinic_id=a.clinic_id and x.doctor_id::text=a.context->>'doctor_id'
      where a.id=(p_input->>'id')::uuid and a.clinic_id=s.clinic_id and a.status='open' and a.code='DOCTOR_AVAILABILITY_REVIEW'
      and x.status in ('booked','checked_in') and x.starts_at>clock_timestamp() and not private.appointment_interval_available(x)) then
    raise exception 'AVAILABILITY_REVIEW_REQUIRED' using errcode='P0001';
  end if;
  result:=private.staff_operations_without_context(p_action,p_input);
  if p_action='alerts' then
    select coalesce(jsonb_agg(x.value||jsonb_build_object('context',a.context) order by x.ordinality),'[]') into items
      from jsonb_array_elements(result->'alerts') with ordinality x(value,ordinality)
      join public.staff_alerts a on a.id=(x.value->>'id')::uuid and a.clinic_id=s.clinic_id;
    result:=jsonb_build_object('alerts',items);
  end if;
  return result;
end $$;
revoke all on function private.staff_operations(text,jsonb) from public,anon,authenticated,service_role;
grant execute on function private.staff_operations(text,jsonb) to authenticated;

alter function private.delivery_policy(public.outbox,timestamptz) rename to delivery_policy_before_availability_controls;
revoke all on function private.delivery_policy_before_availability_controls(public.outbox,timestamptz) from public,anon,authenticated,service_role;
create function private.delivery_policy(o public.outbox,p_now timestamptz) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare a public.appointments;
begin
  if o.purpose in ('appointment','reminder') and o.payload?'appointment_id' then
    select * into a from public.appointments where id=(o.payload->>'appointment_id')::uuid and clinic_id=o.clinic_id and patient_id=o.patient_id;
    if found and a.status not in ('booked','checked_in','cancelled') then return jsonb_build_object('action','skip','code','APPOINTMENT_STATE_INVALID'); end if;
    if found and a.status in ('booked','checked_in') and not private.appointment_interval_available(a) then return jsonb_build_object('action','skip','code','DOCTOR_UNAVAILABLE'); end if;
  end if;
  return private.delivery_policy_before_availability_controls(o,p_now);
end $$;
revoke all on function private.delivery_policy(public.outbox,timestamptz) from public,anon,authenticated,service_role;
commit;
