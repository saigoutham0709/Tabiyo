begin;
create schema if not exists extensions;
create extension if not exists btree_gist with schema extensions;
create table public.doctor_schedules (
  id uuid primary key default gen_random_uuid(),clinic_id uuid not null references public.clinics(id),doctor_id uuid not null,
  weekday integer not null check(weekday between 0 and 6),start_time time not null,end_time time not null,
  break_start time,break_end time,unique(doctor_id,weekday),
  foreign key(doctor_id,clinic_id) references public.doctors(id,clinic_id),
  check(start_time<end_time),check((break_start is null and break_end is null) or
    (break_start is not null and break_end is not null and start_time<=break_start and break_start<break_end and break_end<=end_time))
);
create table public.doctor_leaves (
  id uuid primary key default gen_random_uuid(),clinic_id uuid not null references public.clinics(id),doctor_id uuid not null,
  date_from date not null,date_to date not null,reason text not null default '' check(length(reason)<=200),
  foreign key(doctor_id,clinic_id) references public.doctors(id,clinic_id),check(date_from<=date_to)
);
create table public.appointments (
  id uuid primary key default gen_random_uuid(),clinic_id uuid not null references public.clinics(id),patient_id uuid not null,doctor_id uuid not null,
  starts_at timestamptz not null,ends_at timestamptz not null,
  status text not null default 'booked' check(status in ('booked','checked_in','completed','no_show','cancelled')),
  source text not null check(source in ('phone','whatsapp','walk_in')),created_by uuid,created_at timestamptz not null default now(),
  unique(id,clinic_id),check(starts_at<ends_at),
  foreign key(patient_id,clinic_id) references public.patients(id,clinic_id),
  foreign key(doctor_id,clinic_id) references public.doctors(id,clinic_id),
  foreign key(created_by,clinic_id) references public.staff_users(id,clinic_id),
  exclude using gist(doctor_id extensions.gist_uuid_ops with =,tstzrange(starts_at,ends_at,'[)') with &&) where(status in ('booked','checked_in')),
  exclude using gist(patient_id extensions.gist_uuid_ops with =,tstzrange(starts_at,ends_at,'[)') with &&) where(status in ('booked','checked_in'))
);
create index appointments_day on public.appointments(clinic_id,starts_at,doctor_id);
create index doctor_leaves_dates on public.doctor_leaves(doctor_id,date_from,date_to);
alter table public.events add foreign key(appointment_id,clinic_id) references public.appointments(id,clinic_id);
alter table public.doctor_schedules enable row level security;
alter table public.doctor_leaves enable row level security;
alter table public.appointments enable row level security;
revoke all on public.doctor_schedules,public.doctor_leaves,public.appointments from public,anon,authenticated,service_role;
grant select on public.doctor_schedules,public.doctor_leaves,public.appointments to authenticated,service_role;
create policy schedules_member on public.doctor_schedules for select to authenticated using(exists(
  select 1 from public.staff_users s join public.doctors d on d.clinic_id=s.clinic_id where s.id=(select auth.uid()) and s.active
    and s.clinic_id=doctor_schedules.clinic_id and d.id=doctor_schedules.doctor_id and (s.role<>'doctor' or d.staff_user_id=s.id)));
create policy leaves_member on public.doctor_leaves for select to authenticated using(exists(
  select 1 from public.staff_users s join public.doctors d on d.clinic_id=s.clinic_id where s.id=(select auth.uid()) and s.active
    and s.clinic_id=doctor_leaves.clinic_id and d.id=doctor_leaves.doctor_id and (s.role<>'doctor' or d.staff_user_id=s.id)));
create policy appointments_member on public.appointments for select to authenticated using(exists(
  select 1 from public.staff_users s join public.doctors d on d.clinic_id=s.clinic_id where s.id=(select auth.uid()) and s.active
    and s.clinic_id=appointments.clinic_id and d.id=appointments.doctor_id and (s.role<>'doctor' or d.staff_user_id=s.id)));

create function private.appointment_slots(p_clinic uuid,p_doctor uuid,p_date date,p_except uuid default null,p_patient uuid default null) returns jsonb
language sql security invoker set search_path='' as $$
  select coalesce(jsonb_agg(jsonb_build_object('starts_at',slots.starts_at,'ends_at',slots.ends_at) order by slots.starts_at),'[]'::jsonb)
  from (
    select at_time as starts_at,at_time+make_interval(mins=>d.slot_minutes) as ends_at
    from public.doctors d join public.doctor_schedules s on s.doctor_id=d.id and s.clinic_id=d.clinic_id
    join public.clinics c on c.id=d.clinic_id
    cross join lateral generate_series((p_date+s.start_time) at time zone 'Asia/Kolkata',
      (p_date+s.end_time) at time zone 'Asia/Kolkata'-make_interval(mins=>d.slot_minutes),make_interval(mins=>d.slot_minutes)) at_time
    where d.id=p_doctor and d.clinic_id=p_clinic and d.active and s.weekday=extract(dow from p_date)
      and p_date between (clock_timestamp() at time zone 'Asia/Kolkata')::date and (clock_timestamp() at time zone 'Asia/Kolkata')::date+90
      and at_time>clock_timestamp()
      and not coalesce(c.settings->'holidays','[]'::jsonb)?p_date::text
      and not exists(select 1 from public.doctor_leaves l where l.doctor_id=d.id and p_date between l.date_from and l.date_to)
      and (s.break_start is null or not tstzrange(at_time,at_time+make_interval(mins=>d.slot_minutes),'[)') &&
        tstzrange((p_date+s.break_start) at time zone 'Asia/Kolkata',(p_date+s.break_end) at time zone 'Asia/Kolkata','[)'))
      and not exists(select 1 from public.appointments a where a.clinic_id=p_clinic and (a.doctor_id=d.id or a.patient_id=p_patient)
        and a.id is distinct from p_except and a.status in ('booked','checked_in') and
        tstzrange(a.starts_at,a.ends_at,'[)') && tstzrange(at_time,at_time+make_interval(mins=>d.slot_minutes),'[)'))
  ) slots
$$;
revoke all on function private.appointment_slots(uuid,uuid,date,uuid,uuid) from public,anon,authenticated,service_role;

create function private.appointment_read(p_action text,p_input jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; d public.doctors; a public.appointments; day date; items jsonb:='[]'; patient uuid;
begin
  s:=private.require_staff();
  if p_action='doctors' and p_input='{}'::jsonb then
    for d in select * from public.doctors where clinic_id=s.clinic_id and active and (s.role<>'doctor' or staff_user_id=s.id) order by name,id loop
      items:=items||jsonb_build_array(jsonb_build_object('id',d.id,'clinic_id',d.clinic_id,'name',d.name,'specialty',d.specialty,'slot_minutes',d.slot_minutes));
    end loop;
    return jsonb_build_object('doctors',items);
  end if;
  if p_input->>'date' is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  day:=(p_input->>'date')::date;
  if p_action='slots' and p_input-array['date','doctor_id','patient_id']='{}'::jsonb then
    select * into d from public.doctors where id=(p_input->>'doctor_id')::uuid and clinic_id=s.clinic_id and active;
    if not found or (s.role='doctor' and d.staff_user_id is distinct from s.id) then raise exception 'DOCTOR_NOT_FOUND' using errcode='P0001'; end if;
    patient:=(p_input->>'patient_id')::uuid;
    if patient is not null then
      if not exists(select 1 from public.patients where clinic_id=s.clinic_id and id=patient and merged_into is null) then raise exception 'PATIENT_NOT_FOUND' using errcode='P0001'; end if;
      insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'appointment.availability_read','patients',patient);
    end if;
    return jsonb_build_object('slots',private.appointment_slots(s.clinic_id,d.id,day,null,patient));
  elsif p_action='day' and p_input-array['date']='{}'::jsonb then
    for a in select x.* from public.appointments x join public.doctors selected_doctor on selected_doctor.id=x.doctor_id and selected_doctor.clinic_id=x.clinic_id
      where x.clinic_id=s.clinic_id and (s.role<>'doctor' or selected_doctor.staff_user_id=s.id)
        and x.starts_at>=day::timestamp at time zone 'Asia/Kolkata' and x.starts_at<(day+1)::timestamp at time zone 'Asia/Kolkata'
      order by x.starts_at,x.id limit 1000 loop
      items:=items||jsonb_build_array(to_jsonb(a)||jsonb_build_object('patient_name',(select name from public.patients where id=a.patient_id and clinic_id=s.clinic_id)));
      insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'appointment.read','appointments',a.id);
      insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'patient.read','patients',a.patient_id);
    end loop;
    return jsonb_build_object('appointments',items);
  end if;
  raise exception 'INPUT_INVALID' using errcode='22023';
end $$;
revoke all on function private.appointment_read(text,jsonb) from public,anon,authenticated,service_role;
grant execute on function private.appointment_read(text,jsonb) to authenticated;

create function private.appointment_write(p_action text,p_input jsonb,p_request_id uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; a public.appointments; old_a public.appointments; d public.doctors; p public.patients;
  cached public.staff_operation_requests; fingerprint text; t timestamptz:=clock_timestamp(); starts timestamptz; ends timestamptz;
  doctor uuid; patient uuid; day date; slots jsonb; alternatives jsonb:='[]'; result jsonb; reminder_hours integer;
begin
  s:=private.require_staff();
  if p_request_id is null or p_input is null or jsonb_typeof(p_input)<>'object' or p_action is null
    or p_action not in ('create','reschedule','cancel','check_in','complete','no_show') then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  fingerprint:=md5('appointment.'||p_action||':'||p_input::text);
  perform pg_advisory_xact_lock(hashtextextended('staff-operation/'||s.clinic_id::text||'/'||p_request_id::text,0));
  select * into cached from public.staff_operation_requests where clinic_id=s.clinic_id and request_id=p_request_id;
  if found then
    if cached.actor_id<>s.id or cached.fingerprint<>fingerprint then raise exception 'IDEMPOTENCY_CONFLICT' using errcode='P0001'; end if;
    return cached.response||jsonb_build_object('replayed',true);
  end if;
  if p_action='create' then
    if p_input-array['patient_id','doctor_id','starts_at','source']<>'{}'::jsonb or p_input->>'source' not in ('phone','walk_in') or p_input->>'source' is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    patient:=(p_input->>'patient_id')::uuid;doctor:=(p_input->>'doctor_id')::uuid;
  else
    if p_input->>'id' is null or (p_action='reschedule' and p_input-array['id','starts_at','doctor_id']<>'{}'::jsonb)
      or (p_action<>'reschedule' and p_input-array['id']<>'{}'::jsonb) then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    select * into old_a from public.appointments where id=(p_input->>'id')::uuid and clinic_id=s.clinic_id;
    if not found then raise exception 'APPOINTMENT_NOT_FOUND' using errcode='P0001'; end if;
    patient:=old_a.patient_id;doctor:=coalesce((p_input->>'doctor_id')::uuid,old_a.doctor_id);
  end if;
  select * into p from public.patients where id=patient and clinic_id=s.clinic_id and merged_into is null;
  if not found then raise exception 'PATIENT_NOT_FOUND' using errcode='P0001'; end if;
  perform pg_advisory_xact_lock(hashtextextended('contact/'||s.clinic_id::text||'/'||p.mobile_e164,0));
  select * into p from public.patients where id=patient and clinic_id=s.clinic_id and merged_into is null for update;
  if not found then raise exception 'PATIENT_NOT_FOUND' using errcode='P0001'; end if;
  select * into d from public.doctors where id=doctor and clinic_id=s.clinic_id and active for update;
  if not found or (s.role='doctor' and d.staff_user_id is distinct from s.id) or
    (s.role='doctor' and old_a.id is not null and not exists(select 1 from public.doctors where id=old_a.doctor_id and staff_user_id=s.id)) then
    raise exception 'DOCTOR_NOT_FOUND' using errcode='P0001'; end if;
  if old_a.id is not null then
    select * into old_a from public.appointments where id=old_a.id and clinic_id=s.clinic_id for update;
  end if;
  if p_action in ('create','reschedule') then
    if p_action='reschedule' and old_a.status<>'booked' then raise exception 'APPOINTMENT_STATE_INVALID' using errcode='P0001'; end if;
    starts:=(p_input->>'starts_at')::timestamptz;ends:=starts+make_interval(mins=>d.slot_minutes);day:=(starts at time zone 'Asia/Kolkata')::date;
    if starts is null or starts<=t or day>(t at time zone 'Asia/Kolkata')::date+90 then raise exception 'APPOINTMENT_TIME_INVALID' using errcode='22023'; end if;
    slots:=private.appointment_slots(s.clinic_id,doctor,day,old_a.id,patient);
    if not exists(select 1 from jsonb_to_recordset(slots) as x(starts_at timestamptz,ends_at timestamptz) where x.starts_at=starts) then
      select coalesce(jsonb_agg(value),'[]'::jsonb) into alternatives from (select value from jsonb_array_elements(slots) limit 3) x;
      return jsonb_build_object('conflict',true,'alternatives',alternatives);
    end if;
    begin
      if p_action='create' then
        insert into public.appointments(clinic_id,patient_id,doctor_id,starts_at,ends_at,source,created_by)
          values(s.clinic_id,patient,doctor,starts,ends,p_input->>'source',s.id) returning * into a;
      else update public.appointments set doctor_id=doctor,starts_at=starts,ends_at=ends where id=old_a.id returning * into a; end if;
    exception when exclusion_violation then
      select coalesce(jsonb_agg(value),'[]'::jsonb) into alternatives from
        (select value from jsonb_array_elements(private.appointment_slots(s.clinic_id,doctor,day,old_a.id,patient)) limit 3) x;
      return jsonb_build_object('conflict',true,'alternatives',alternatives);
    end;
    if p_action='reschedule' then
      update public.outbox set status='skipped',last_error='APPOINTMENT_CHANGED' where clinic_id=s.clinic_id and status='queued' and payload->>'appointment_id'=a.id::text;
    end if;
    insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key) values(s.clinic_id,patient,'template','appointment',
      jsonb_build_object('template_name',case when p_action='create' then 'appointment_confirmed' else 'appointment_changed' end,'language',p.language,'appointment_id',a.id,'starts_at',a.starts_at),
      'appointment/'||a.id::text||'/'||p_request_id::text);
    for reminder_hours in select unnest(array[24,2]) loop
      if a.starts_at-make_interval(hours=>reminder_hours)>clock_timestamp() then
        insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key,not_before)
          values(s.clinic_id,patient,'template','reminder',jsonb_build_object('template_name','appointment_reminder','language',p.language,
            'appointment_id',a.id,'starts_at',a.starts_at,'reminder_hours',reminder_hours),
            'appointment-reminder/'||a.id::text||'/'||p_request_id::text||'/'||reminder_hours::text,a.starts_at-make_interval(hours=>reminder_hours));
      end if;
    end loop;
  else
    if (p_action='check_in' and (old_a.status<>'booked' or (old_a.starts_at at time zone 'Asia/Kolkata')::date<>(t at time zone 'Asia/Kolkata')::date))
      or (p_action='complete' and old_a.status<>'checked_in')
      or (p_action='no_show' and (old_a.status<>'booked' or old_a.ends_at>t))
      or (p_action='cancel' and old_a.status not in ('booked','checked_in')) then raise exception 'APPOINTMENT_STATE_INVALID' using errcode='P0001'; end if;
    update public.appointments set status=case p_action when 'check_in' then 'checked_in' when 'complete' then 'completed' when 'no_show' then 'no_show' else 'cancelled' end
      where id=old_a.id returning * into a;
    if p_action='cancel' then
      update public.outbox set status='skipped',last_error='APPOINTMENT_CANCELLED' where clinic_id=s.clinic_id and status='queued' and payload->>'appointment_id'=a.id::text;
      perform private.delivery_alert(s.clinic_id,patient,'APPOINTMENT_CANCEL_NOTICE_REQUIRED','appointment-cancel/'||a.id::text,t);
    end if;
  end if;
  insert into public.events(clinic_id,patient_id,appointment_id,type,meta) values(s.clinic_id,patient,a.id,
    case p_action when 'create' then 'appointment.booked' when 'reschedule' then 'appointment.rescheduled' else 'appointment.'||a.status end,jsonb_build_object('source',a.source,'request_id',p_request_id));
  insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id) values(s.clinic_id,s.id,'appointment.'||p_action,'appointments',a.id,p_request_id);
  insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id) values(s.clinic_id,s.id,'patient.read','patients',patient,p_request_id);
  result:=jsonb_build_object('appointment',to_jsonb(a),'replayed',false,'conflict',false);
  insert into public.staff_operation_requests(clinic_id,request_id,actor_id,action,fingerprint,response) values(s.clinic_id,p_request_id,s.id,'appointment.'||p_action,fingerprint,result);
  return result;
end $$;
revoke all on function private.appointment_write(text,jsonb,uuid) from public,anon,authenticated,service_role;
grant execute on function private.appointment_write(text,jsonb,uuid) to authenticated;
create function public.tabiyo_appointment_read(p_action text,p_input jsonb default '{}') returns jsonb
language sql security invoker set search_path='' as $$ select private.appointment_read(p_action,p_input) $$;
create function public.tabiyo_appointment_write(p_action text,p_input jsonb,p_request_id uuid) returns jsonb
language sql security invoker set search_path='' as $$ select private.appointment_write(p_action,p_input,p_request_id) $$;
revoke all on function public.tabiyo_appointment_read(text,jsonb),public.tabiyo_appointment_write(text,jsonb,uuid) from public,anon,authenticated,service_role;
grant execute on function public.tabiyo_appointment_read(text,jsonb),public.tabiyo_appointment_write(text,jsonb,uuid) to authenticated;

alter function private.delivery_policy(public.outbox,timestamptz) rename to delivery_policy_before_appointments;
revoke all on function private.delivery_policy_before_appointments(public.outbox,timestamptz) from public,anon,authenticated,service_role;
create function private.delivery_policy(o public.outbox,p_now timestamptz) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare a public.appointments;
begin
  if o.purpose in ('appointment','reminder') and o.payload?'appointment_id' then
    select * into a from public.appointments where id=(o.payload->>'appointment_id')::uuid and clinic_id=o.clinic_id and patient_id=o.patient_id;
    if not found or a.status='cancelled' then return jsonb_build_object('action','skip','code','APPOINTMENT_CANCELLED'); end if;
    if (o.payload->>'starts_at')::timestamptz is distinct from a.starts_at then return jsonb_build_object('action','skip','code','APPOINTMENT_CHANGED'); end if;
    if a.starts_at<=p_now then return jsonb_build_object('action','skip','code','APPOINTMENT_EXPIRED'); end if;
    if not exists(select 1 from public.doctors where id=a.doctor_id and clinic_id=a.clinic_id and active)
      or exists(select 1 from public.doctor_leaves where doctor_id=a.doctor_id and (a.starts_at at time zone 'Asia/Kolkata')::date between date_from and date_to)
      or exists(select 1 from public.clinics where id=a.clinic_id and coalesce(settings->'holidays','[]'::jsonb)?((a.starts_at at time zone 'Asia/Kolkata')::date)::text) then
      return jsonb_build_object('action','skip','code','DOCTOR_UNAVAILABLE'); end if;
    if o.purpose='reminder' and a.status<>'booked' then return jsonb_build_object('action','skip','code','APPOINTMENT_STATE_INVALID'); end if;
  end if;
  return private.delivery_policy_before_appointments(o,p_now);
end $$;
revoke all on function private.delivery_policy(public.outbox,timestamptz) from public,anon,authenticated,service_role;
commit;
