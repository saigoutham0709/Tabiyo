begin;
create table public.queue_tokens (
  id uuid primary key default gen_random_uuid(),clinic_id uuid not null references public.clinics(id),doctor_id uuid not null,patient_id uuid not null,
  date date not null,token_number integer not null check(token_number between 1 and 1000),
  status text not null default 'waiting' check(status in ('waiting','called','done','skipped')),called_at timestamptz,finished_at timestamptz,
  created_by uuid not null,created_at timestamptz not null default now(),unique(id,clinic_id),unique(doctor_id,date,token_number),
  check(status<>'called' or called_at is not null),check(status not in ('done','skipped') or finished_at is not null),
  foreign key(doctor_id,clinic_id) references public.doctors(id,clinic_id),foreign key(patient_id,clinic_id) references public.patients(id,clinic_id),
  foreign key(created_by,clinic_id) references public.staff_users(id,clinic_id)
);
create unique index queue_one_called on public.queue_tokens(doctor_id,date) where status='called';
create unique index queue_one_active_patient on public.queue_tokens(clinic_id,patient_id,date) where status in ('waiting','called');
create index queue_waiting_order on public.queue_tokens(doctor_id,date,token_number) where status='waiting';
alter table public.queue_tokens enable row level security;
revoke all on public.queue_tokens from public,anon,authenticated,service_role;
grant select on public.queue_tokens to authenticated,service_role;
create policy queue_member on public.queue_tokens for select to authenticated using(exists(
  select 1 from public.staff_users s join public.doctors d on d.clinic_id=s.clinic_id where s.id=(select auth.uid()) and s.active
    and s.clinic_id=queue_tokens.clinic_id and d.id=queue_tokens.doctor_id and (s.role<>'doctor' or d.staff_user_id=s.id)));

create function private.queue_notice(p_clinic uuid,p_doctor uuid,p_date date,t timestamptz) returns text
language plpgsql security invoker set search_path='' as $$
declare current_token public.queue_tokens; next_token public.queue_tokens; p public.patients; notice jsonb; notice_key text;
begin
  select * into current_token from public.queue_tokens where clinic_id=p_clinic and doctor_id=p_doctor and date=p_date and status='called';
  if not found then return 'none'; end if;
  select * into next_token from public.queue_tokens where clinic_id=p_clinic and doctor_id=p_doctor and date=p_date and status='waiting' order by token_number limit 1;
  if not found then return 'none'; end if;
  notice_key:='queue-next/'||current_token.id::text||'/'||next_token.id::text;
  if exists(select 1 from public.outbox where clinic_id=p_clinic and idempotency_key=notice_key) then return 'existing'; end if;
  select * into p from public.patients where id=next_token.patient_id and clinic_id=p_clinic;
  select settings->'approved_queue_notice'->p.language into notice from public.clinics where id=p_clinic;
  if notice->'approved' is distinct from 'true'::jsonb or jsonb_typeof(notice->'version') is distinct from 'string' or jsonb_typeof(notice->'text') is distinct from 'string'
    or coalesce(length(trim(notice->>'version')),0) not between 1 and 100 or coalesce(length(trim(notice->>'text')),0) not between 1 and 1000
    or (p.language<>'en' and not exists(select 1 from public.clinic_features where clinic_id=p_clinic and feature='lang_'||p.language and enabled))
    or p.opted_out or p.merged_into is not null or p.whatsapp_status in ('blocked','not_on_whatsapp')
    or (select status from public.consents where clinic_id=p_clinic and patient_id=p.id order by recorded_order desc limit 1) is distinct from 'granted'
    or not exists(select 1 from public.conversations where clinic_id=p_clinic and mobile_e164=p.mobile_e164 and not channel_stopped and last_inbound_at>t-interval '24 hours' and last_inbound_at<=t) then
    perform private.delivery_alert(p_clinic,p.id,'QUEUE_NOTICE_REVIEW',notice_key,t);
    update public.staff_alerts set context=jsonb_build_object('doctor_id',p_doctor) where clinic_id=p_clinic and dedup_key=notice_key;
    return 'review_required';
  end if;
  insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key,not_before)
    values(p_clinic,p.id,'text','queue',jsonb_build_object('text',replace(notice->>'text','{token_number}',next_token.token_number::text),'language',p.language,
      'notice_version',notice->>'version','queue_token_id',next_token.id,'called_token_id',current_token.id),notice_key,t);
  return 'queued';
end $$;
revoke all on function private.queue_notice(uuid,uuid,date,timestamptz) from public,anon,authenticated,service_role;

create function private.queue(p_action text,p_input jsonb,p_request_id uuid default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; d public.doctors; q public.queue_tokens; active public.queue_tokens; head public.queue_tokens;
  cached public.staff_operation_requests; fingerprint text; today date:=(clock_timestamp() at time zone 'Asia/Kolkata')::date;
  selected_date date; t timestamptz:=clock_timestamp(); items jsonb:='[]'; result jsonb; notice_state text:='none'; next_number integer;
begin
  s:=private.require_staff();
  if p_input is null or jsonb_typeof(p_input)<>'object' or p_action is null or p_action not in ('status','read','add','call_next','skip','complete') then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  if p_action='status' then
    if p_input<>'{}'::jsonb then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    return jsonb_build_object('clinic_id',s.clinic_id,'enabled',exists(select 1 from public.clinic_features where clinic_id=s.clinic_id and feature='walk_in_tokens' and enabled));
  end if;
  if not exists(select 1 from public.clinic_features where clinic_id=s.clinic_id and feature='walk_in_tokens' and enabled) then raise exception 'FEATURE_DISABLED' using errcode='P0001'; end if;
  if p_action<>'read' then
    if p_request_id is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    fingerprint:=md5('queue.'||p_action||':'||p_input::text);
    perform pg_advisory_xact_lock(hashtextextended('staff-operation/'||s.clinic_id::text||'/'||p_request_id::text,0));
    select * into cached from public.staff_operation_requests where clinic_id=s.clinic_id and request_id=p_request_id;
    if found then
      if cached.actor_id<>s.id or cached.fingerprint<>fingerprint then raise exception 'IDEMPOTENCY_CONFLICT' using errcode='P0001'; end if;
      return cached.response||jsonb_build_object('replayed',true);
    end if;
    perform pg_advisory_xact_lock(hashtextextended('queue/'||s.clinic_id::text||'/'||((p_input->>'doctor_id')::uuid)::text||'/'||today::text,0));
    if today<>(clock_timestamp() at time zone 'Asia/Kolkata')::date then raise exception 'QUEUE_CHANGED' using errcode='P0001'; end if;
    t:=clock_timestamp();
  end if;
  select x.* into d from public.doctors x where x.id=(p_input->>'doctor_id')::uuid and x.clinic_id=s.clinic_id and x.active;
  if not found or (s.role='doctor' and d.staff_user_id is distinct from s.id) then raise exception 'DOCTOR_NOT_FOUND' using errcode='P0001'; end if;
  if p_action='read' then
    if p_input-array['doctor_id','date']<>'{}'::jsonb then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    selected_date:=coalesce((p_input->>'date')::date,today);
    if selected_date<today-31 or selected_date>today then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    for q in select * from public.queue_tokens where clinic_id=s.clinic_id and doctor_id=d.id and date=selected_date order by token_number limit 1000 loop
      items:=items||jsonb_build_array(to_jsonb(q)||jsonb_build_object('patient_name',(select name from public.patients where clinic_id=s.clinic_id and id=q.patient_id)));
      insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'queue.read','queue_tokens',q.id);
      insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'patient.read','patients',q.patient_id);
    end loop;
    return jsonb_build_object('clinic_id',s.clinic_id,'doctor_id',d.id,'date',selected_date,'tokens',items);
  end if;
  if p_action='add' then
    if p_input-array['doctor_id','patient_id']<>'{}'::jsonb then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    if not exists(select 1 from public.patients where id=(p_input->>'patient_id')::uuid and clinic_id=s.clinic_id and merged_into is null) then raise exception 'PATIENT_NOT_FOUND' using errcode='P0001'; end if;
    select coalesce(max(token_number),0)+1 into next_number from public.queue_tokens where doctor_id=d.id and date=today;
    if next_number>1000 then raise exception 'QUEUE_FULL' using errcode='P0001'; end if;
    begin
      insert into public.queue_tokens(clinic_id,doctor_id,patient_id,date,token_number,created_by) values(s.clinic_id,d.id,(p_input->>'patient_id')::uuid,today,next_number,s.id) returning * into q;
    exception when unique_violation then raise exception 'PATIENT_ALREADY_QUEUED' using errcode='P0001'; end;
  elsif p_action='call_next' then
    if p_input-array['doctor_id','expected_called_id','expected_next_id']<>'{}'::jsonb or not p_input?'expected_called_id' or p_input->>'expected_next_id' is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    if exists(select 1 from public.doctor_leaves where doctor_id=d.id and today between date_from and date_to)
      or exists(select 1 from public.clinics where id=s.clinic_id and coalesce(settings->'holidays','[]'::jsonb)?today::text)
      or not exists(select 1 from public.doctor_schedules x where x.doctor_id=d.id and x.weekday=extract(dow from today)
        and (t at time zone 'Asia/Kolkata')::time>=x.start_time and (t at time zone 'Asia/Kolkata')::time<x.end_time
        and (x.break_start is null or (t at time zone 'Asia/Kolkata')::time<x.break_start or (t at time zone 'Asia/Kolkata')::time>=x.break_end)) then raise exception 'DOCTOR_UNAVAILABLE' using errcode='P0001'; end if;
    select * into active from public.queue_tokens where doctor_id=d.id and date=today and status='called' for update;
    select * into head from public.queue_tokens where doctor_id=d.id and date=today and status='waiting' order by token_number limit 1 for update;
    if head.id is null then raise exception 'QUEUE_EMPTY' using errcode='P0001'; end if;
    if active.id is distinct from (p_input->>'expected_called_id')::uuid or head.id is distinct from (p_input->>'expected_next_id')::uuid then raise exception 'QUEUE_CHANGED' using errcode='P0001'; end if;
    if active.id is not null then
      update public.queue_tokens set status='done',finished_at=t where id=active.id;
      insert into public.events(clinic_id,patient_id,type,meta) values(s.clinic_id,active.patient_id,'queue.token_done',jsonb_build_object('token_id',active.id,'doctor_id',d.id));
      insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id) values(s.clinic_id,s.id,'queue.complete','queue_tokens',active.id,p_request_id);
    end if;
    update public.queue_tokens set status='called',called_at=t where id=head.id returning * into q;
  else
    if p_input-array['doctor_id','id']<>'{}'::jsonb then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    select * into q from public.queue_tokens where id=(p_input->>'id')::uuid and clinic_id=s.clinic_id and doctor_id=d.id and date=today for update;
    if not found then raise exception 'TOKEN_NOT_FOUND' using errcode='P0001'; end if;
    if (p_action='complete' and q.status<>'called') or (p_action='skip' and q.status not in ('waiting','called')) then raise exception 'QUEUE_STATE_INVALID' using errcode='P0001'; end if;
    update public.queue_tokens set status=case p_action when 'complete' then 'done' else 'skipped' end,finished_at=t where id=q.id returning * into q;
  end if;
  notice_state:=private.queue_notice(s.clinic_id,d.id,today,t);
  insert into public.events(clinic_id,patient_id,type,meta) values(s.clinic_id,q.patient_id,
    case p_action when 'add' then 'queue.token_added' when 'call_next' then 'queue.token_called' when 'complete' then 'queue.token_done' else 'queue.token_skipped' end,
    jsonb_build_object('token_id',q.id,'doctor_id',d.id,'token_number',q.token_number));
  insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id) values(s.clinic_id,s.id,'queue.'||p_action,'queue_tokens',q.id,p_request_id);
  result:=jsonb_build_object('clinic_id',s.clinic_id,'token',to_jsonb(q),'notice_state',notice_state,'replayed',false);
  insert into public.staff_operation_requests(clinic_id,request_id,actor_id,action,fingerprint,response) values(s.clinic_id,p_request_id,s.id,'queue.'||p_action,fingerprint,result);
  return result;
end $$;
revoke all on function private.queue(text,jsonb,uuid) from public,anon,authenticated,service_role;
grant execute on function private.queue(text,jsonb,uuid) to authenticated;
create function public.tabiyo_queue(p_action text,p_input jsonb default '{}',p_request_id uuid default null) returns jsonb
language sql security invoker set search_path='' as $$ select private.queue(p_action,p_input,p_request_id) $$;
revoke all on function public.tabiyo_queue(text,jsonb,uuid) from public,anon,authenticated,service_role;
grant execute on function public.tabiyo_queue(text,jsonb,uuid) to authenticated;

alter function private.delivery(text,jsonb,timestamptz) rename to delivery_before_queue_controls;
revoke all on function private.delivery_before_queue_controls(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
create function private.delivery(p_action text,p_input jsonb,p_now timestamptz default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare q public.queue_tokens;
begin
  if p_action in ('prepare','mock_accept') then
    select x.* into q from public.queue_tokens x join public.outbox o on o.clinic_id=x.clinic_id and o.patient_id=x.patient_id
      and o.payload->>'queue_token_id'=x.id::text where o.id=(p_input->>'id')::uuid and o.purpose='queue';
    if found then perform pg_advisory_xact_lock(hashtextextended('queue/'||q.clinic_id::text||'/'||q.doctor_id::text||'/'||q.date::text,0)); end if;
  end if;
  return private.delivery_before_queue_controls(p_action,p_input,p_now);
end $$;
revoke all on function private.delivery(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
grant execute on function private.delivery(text,jsonb,timestamptz) to service_role;
alter function private.delivery_policy(public.outbox,timestamptz) rename to delivery_policy_before_queue_controls;
revoke all on function private.delivery_policy_before_queue_controls(public.outbox,timestamptz) from public,anon,authenticated,service_role;
create function private.delivery_policy(o public.outbox,p_now timestamptz) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare q public.queue_tokens; notice jsonb;
begin
  if o.purpose='queue' and o.payload?'queue_token_id' then
    select * into q from public.queue_tokens where id=(o.payload->>'queue_token_id')::uuid and clinic_id=o.clinic_id and patient_id=o.patient_id;
    if not found or q.date<>(p_now at time zone 'Asia/Kolkata')::date or q.status<>'waiting'
      or not exists(select 1 from public.queue_tokens where id=(o.payload->>'called_token_id')::uuid and clinic_id=q.clinic_id and doctor_id=q.doctor_id and date=q.date and status='called')
      or q.id is distinct from (select id from public.queue_tokens where doctor_id=q.doctor_id and date=q.date and status='waiting' order by token_number limit 1) then
      return jsonb_build_object('action','skip','code','QUEUE_CHANGED');
    end if;
    select settings->'approved_queue_notice'->coalesce(o.payload->>'language','en') into notice from public.clinics where id=o.clinic_id;
    if notice->'approved' is distinct from 'true'::jsonb or jsonb_typeof(notice->'version') is distinct from 'string' or jsonb_typeof(notice->'text') is distinct from 'string'
      or (notice->>'version') is distinct from (o.payload->>'notice_version')
      or replace(notice->>'text','{token_number}',q.token_number::text) is distinct from (o.payload->>'text')
      or not exists(select 1 from public.patients where id=o.patient_id and clinic_id=o.clinic_id and language=o.payload->>'language') then
      perform private.delivery_alert(o.clinic_id,o.patient_id,'QUEUE_NOTICE_REVIEW','queue-copy/'||o.id::text,p_now);
      return jsonb_build_object('action','skip','code','QUEUE_NOTICE_UNAPPROVED');
    end if;
    if not exists(select 1 from public.doctors where id=q.doctor_id and clinic_id=q.clinic_id and active)
      or exists(select 1 from public.doctor_leaves where doctor_id=q.doctor_id and q.date between date_from and date_to)
      or exists(select 1 from public.clinics where id=q.clinic_id and coalesce(settings->'holidays','[]'::jsonb)?q.date::text)
      or not exists(select 1 from public.doctor_schedules x where x.doctor_id=q.doctor_id and x.weekday=extract(dow from q.date)
        and (p_now at time zone 'Asia/Kolkata')::time>=x.start_time and (p_now at time zone 'Asia/Kolkata')::time<x.end_time
        and (x.break_start is null or (p_now at time zone 'Asia/Kolkata')::time<x.break_start or (p_now at time zone 'Asia/Kolkata')::time>=x.break_end)) then
      return jsonb_build_object('action','skip','code','DOCTOR_UNAVAILABLE');
    end if;
  end if;
  return private.delivery_policy_before_queue_controls(o,p_now);
end $$;
revoke all on function private.delivery_policy(public.outbox,timestamptz) from public,anon,authenticated,service_role;
commit;
