begin;

alter table public.consents add column recorded_order bigint generated always as identity;
create index consents_latest_idx on public.consents(clinic_id,patient_id,recorded_order desc);
alter table public.outbox drop constraint outbox_status_check;
alter table public.outbox add constraint outbox_status_check check(status in ('queued','processing','sent','failed','skipped','uncertain'));
alter table public.outbox add column lease_token uuid;
alter table public.outbox add column prepared_at timestamptz;
alter table public.outbox add column cap_date date;
alter table public.outbox add column provider_status text check(provider_status in ('accepted','sent','delivered','read','failed'));
create index outbox_cap_idx on public.outbox(clinic_id,cap_date,status);

create table public.message_log (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id),
  patient_id uuid not null,
  outbox_id uuid not null unique references public.outbox(id),
  direction text not null default 'out' check(direction='out'),
  wa_message_id text not null unique,
  type text not null,
  template_name text,
  body_preview text,
  status text not null default 'accepted' check(status='accepted'),
  error_code text,
  cost_category text not null default 'mock',
  created_at timestamptz not null default now(),
  foreign key(patient_id,clinic_id) references public.patients(id,clinic_id)
);
create table public.delivery_receipts (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id),
  wa_message_id text not null,
  status text not null check(status in ('sent','delivered','read','failed')),
  occurred_at timestamptz not null,
  error_code text,
  unique(clinic_id,wa_message_id,status,occurred_at)
);
create unique index events_receipt_unique on public.events((meta->>'receipt_id'))
  where type in ('message.sent','message.delivered','message.read','message.failed') and meta?'receipt_id';
create table public.mock_deliveries (
  outbox_id uuid primary key references public.outbox(id),
  clinic_id uuid not null references public.clinics(id),
  wa_message_id text not null unique,
  payload jsonb not null,
  accepted_at timestamptz not null
);
create table public.staff_alerts (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id),
  patient_id uuid,
  code text not null,
  dedup_key text not null unique,
  status text not null default 'open' check(status in ('open','resolved')),
  created_at timestamptz not null default now(),
  foreign key(patient_id,clinic_id) references public.patients(id,clinic_id)
);
alter table public.message_log enable row level security;
alter table public.delivery_receipts enable row level security;
alter table public.mock_deliveries enable row level security;
alter table public.staff_alerts enable row level security;
create policy alerts_read_member on public.staff_alerts for select to authenticated
using(exists(select 1 from public.staff_users s where s.id=(select auth.uid()) and s.active and s.clinic_id=staff_alerts.clinic_id));
revoke all on public.message_log,public.delivery_receipts,public.mock_deliveries,public.staff_alerts from public,anon,authenticated,service_role;
grant select on public.staff_alerts to authenticated;
grant select on public.message_log,public.delivery_receipts,public.mock_deliveries to service_role;
grant select on public.staff_alerts to service_role;

create function private.delivery_alert(p_clinic uuid,p_patient uuid,p_code text,p_key text,p_now timestamptz) returns void
language plpgsql security invoker set search_path='' as $$
declare inserted uuid;
begin
  insert into public.staff_alerts(clinic_id,patient_id,code,dedup_key,created_at)
  values(p_clinic,p_patient,p_code,p_key,p_now) on conflict(dedup_key) do nothing returning id into inserted;
  if inserted is not null then
    insert into public.events(clinic_id,patient_id,type,occurred_at,meta)
    values(p_clinic,p_patient,'staff.alert',p_now,jsonb_build_object('code',p_code,'alert_id',inserted));
  end if;
end $$;

create function private.delivery_apply_receipts(p_outbox uuid,p_now timestamptz) returns text
language plpgsql security invoker set search_path='' as $$
declare o public.outbox; next_status text;
begin
  select * into o from public.outbox where id=p_outbox for update;
  if exists(select 1 from public.delivery_receipts where clinic_id=o.clinic_id and wa_message_id=o.wa_message_id and status='read') then next_status:='read';
  elsif exists(select 1 from public.delivery_receipts where clinic_id=o.clinic_id and wa_message_id=o.wa_message_id and status='delivered') then next_status:='delivered';
  elsif exists(select 1 from public.delivery_receipts where clinic_id=o.clinic_id and wa_message_id=o.wa_message_id and status='failed') then next_status:='failed';
  elsif exists(select 1 from public.delivery_receipts where clinic_id=o.clinic_id and wa_message_id=o.wa_message_id and status='sent') then next_status:='sent';
  else next_status:='accepted'; end if;
  update public.outbox set provider_status=next_status where id=o.id;
  insert into public.events(clinic_id,patient_id,type,occurred_at,meta)
    select o.clinic_id,o.patient_id,'message.'||r.status,r.occurred_at,jsonb_build_object('outbox_id',o.id,'receipt_id',r.id)
    from public.delivery_receipts r where r.clinic_id=o.clinic_id and r.wa_message_id=o.wa_message_id
    on conflict do nothing;
  if next_status='failed' and o.provider_status is distinct from 'failed' then
    perform private.delivery_alert(o.clinic_id,o.patient_id,'WA_DELIVERY_FAILED','delivery/'||o.id::text,p_now);
  end if;
  return next_status;
end $$;

create function private.delivery_policy(o public.outbox,p_now timestamptz) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare p public.patients; c public.clinics; consent text; required_feature text; lang text;
  template_key text; used integer; local_now timestamp; start_at time; end_at time; next_at timestamp;
begin
  select * into p from public.patients where id=o.patient_id and clinic_id=o.clinic_id;
  select * into c from public.clinics where id=o.clinic_id for no key update;
  insert into public.audit_log(clinic_id,action,table_name,record_id,created_at)
    values(o.clinic_id,'outbox.policy_check','patients',o.patient_id,p_now);
  if p.id is null or p.merged_into is not null then return jsonb_build_object('action','skip','code','PATIENT_UNAVAILABLE'); end if;
  if p.opted_out or p.whatsapp_status='blocked' or exists(
    select 1 from public.patients f where f.clinic_id=p.clinic_id and f.mobile_e164=p.mobile_e164 and f.opted_out
  ) then return jsonb_build_object('action','skip','code','WA_OPTED_OUT'); end if;
  if p.whatsapp_status='not_on_whatsapp' then return jsonb_build_object('action','skip','code','WA_NOT_ON_WHATSAPP'); end if;
  select status into consent from public.consents where clinic_id=p.clinic_id and patient_id=p.id order by recorded_order desc limit 1;
  if consent is distinct from 'granted' then
    if o.purpose<>'consent_request' or o.kind<>'template' or c.settings->'allow_consent_request' is distinct from 'true'::jsonb
      or o.payload->>'template_name' is distinct from 'consent_request' then
      return jsonb_build_object('action','skip','code','WA_CONSENT_REQUIRED');
    end if;
  end if;
  if o.purpose='consent_request' and (o.kind<>'template' or o.payload->>'template_name' is distinct from 'consent_request') then
    return jsonb_build_object('action','skip','code','WA_TEMPLATE_UNAVAILABLE');
  end if;
  required_feature:=case o.purpose when 'medication' then 'med_reminders' when 'queue' then 'walk_in_tokens' when 'doctor_summary' then 'doctor_summary' end;
  if required_feature is not null and not exists(select 1 from public.clinic_features where clinic_id=c.id and clinic_features.feature=required_feature and enabled) then
    return jsonb_build_object('action','skip','code','FEATURE_DISABLED');
  end if;
  lang:=coalesce(o.payload->>'language','en');
  if lang not in ('en','te','hi') then return jsonb_build_object('action','skip','code','CONFIG_INVALID'); end if;
  if lang<>'en' and not exists(select 1 from public.clinic_features where clinic_id=c.id and clinic_features.feature='lang_'||lang and enabled) then
    return jsonb_build_object('action','skip','code','FEATURE_DISABLED');
  end if;
  if o.kind='template' then
    template_key:=coalesce(o.payload->>'template_name','')||':'||lang;
    if c.settings->'approved_templates'->template_key is distinct from 'true'::jsonb
      or c.settings->'unavailable_templates'->template_key='true'::jsonb then
      return jsonb_build_object('action','skip','code','WA_TEMPLATE_UNAVAILABLE');
    end if;
  elsif not exists(select 1 from public.conversations where clinic_id=p.clinic_id and mobile_e164=p.mobile_e164
      and last_inbound_at<=p_now and last_inbound_at>p_now-interval '24 hours') then
    return jsonb_build_object('action','skip','code','WA_WINDOW_CLOSED');
  end if;
  if o.purpose in ('reminder','medication','doctor_summary','queue') and p_now-o.not_before>interval '30 minutes' then
    return jsonb_build_object('action','skip','code','JOB_STALE');
  end if;
  local_now:=p_now at time zone 'Asia/Kolkata';
  if o.purpose<>'staff_reply' and c.settings->'quiet_hours'->'enabled' is distinct from 'false'::jsonb then
    if coalesce(c.settings->'quiet_hours'->>'start','21:00')!~'^([01][0-9]|2[0-3]):[0-5][0-9]$'
      or coalesce(c.settings->'quiet_hours'->>'end','07:00')!~'^([01][0-9]|2[0-3]):[0-5][0-9]$' then
      return jsonb_build_object('action','skip','code','CONFIG_INVALID');
    end if;
    start_at:=coalesce(c.settings->'quiet_hours'->>'start','21:00')::time;
    end_at:=coalesce(c.settings->'quiet_hours'->>'end','07:00')::time;
    if start_at=end_at then return jsonb_build_object('action','skip','code','CONFIG_INVALID'); end if;
    if (start_at>end_at and (local_now::time>=start_at or local_now::time<end_at))
      or (start_at<end_at and local_now::time>=start_at and local_now::time<end_at) then
      next_at:=local_now::date+end_at;
      if start_at>end_at and local_now::time>=start_at then next_at:=next_at+interval '1 day'; end if;
      return jsonb_build_object('action','defer','code','QUIET_HOURS','not_before',next_at at time zone 'Asia/Kolkata');
    end if;
  end if;
  select count(*) into used from public.outbox x where x.clinic_id=c.id and x.id<>o.id and x.cap_date=local_now::date
    and (x.status in ('sent','uncertain') or (x.status='processing' and x.prepared_at is not null));
  if used>=c.daily_send_cap then
    perform private.delivery_alert(c.id,null,'SEND_CAP_REACHED','cap/'||c.id::text||'/'||local_now::date::text||'/100',p_now);
    return jsonb_build_object('action','defer','code','SEND_CAP_REACHED','not_before',(local_now::date+1)::timestamp at time zone 'Asia/Kolkata');
  end if;
  return jsonb_build_object('action','send','used',used,'cap',c.daily_send_cap);
end $$;

-- A private service-only operation boundary. Background workers have no end-user auth.uid().
-- Grants, not a user-provided role parameter, authorize this API; no staff/anon role can execute it.
create function private.delivery(p_action text,p_input jsonb,p_now timestamptz default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare t timestamptz:=coalesce(p_now,clock_timestamp()); o public.outbox; decision jsonb; patient uuid;
  worker uuid; fence uuid; recovering boolean; provider text; failure text; next_status text;
  receipt_status text; receipt_time timestamptz; receipt_clinic uuid; inserted uuid; accepted_time timestamptz;
begin
  if p_input is null or jsonb_typeof(p_input)<>'object' then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  if p_action='claim' then
    worker:=(p_input->>'worker_id')::uuid;
    if worker is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    select * into o from public.outbox where (status='queued' and not_before<=t)
      or (status='processing' and locked_at<=t-interval '5 minutes')
      order by not_before,id for update skip locked limit 1;
    if not found then return null; end if;
    recovering:=o.prepared_at is not null;
    update public.outbox set status='processing',locked_at=t,lock_owner=worker,lease_token=gen_random_uuid()
      where id=o.id returning * into o;
    return jsonb_build_object('id',o.id,'clinic_id',o.clinic_id,'worker_id',worker,'lease_token',o.lease_token,'recovering',recovering);
  end if;

  if p_action='receipt' then
    receipt_clinic:=(p_input->>'clinic_id')::uuid; provider:=p_input->>'wa_message_id';
    receipt_status:=p_input->>'status'; receipt_time:=(p_input->>'occurred_at')::timestamptz;
    if receipt_clinic is null or provider is null or length(provider) not between 1 and 200 or receipt_status is null
      or receipt_status not in ('sent','delivered','read','failed') or receipt_time is null or receipt_time>t+interval '5 minutes' then
      raise exception 'INPUT_INVALID' using errcode='22023';
    end if;
    if p_input->>'error_code' is not null and (p_input->>'error_code')!~'^[A-Za-z0-9_-]{1,64}$' then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    insert into public.delivery_receipts(clinic_id,wa_message_id,status,occurred_at,error_code)
      values(receipt_clinic,provider,receipt_status,receipt_time,left(p_input->>'error_code',100))
      on conflict(clinic_id,wa_message_id,status,occurred_at) do nothing returning id into inserted;
    select * into o from public.outbox where clinic_id=receipt_clinic and wa_message_id=provider for update;
    if not found then return jsonb_build_object('matched',false,'duplicate',inserted is null); end if;
    next_status:=private.delivery_apply_receipts(o.id,t);
    return jsonb_build_object('matched',true,'duplicate',inserted is null,'status',next_status);
  end if;

  if p_action not in ('prepare','mock_accept','lookup','complete','failure') or p_action is null then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  -- Match the consent operation's patient-before-outbox lock order.
  select patient_id into patient from public.outbox where id=(p_input->>'id')::uuid;
  perform 1 from public.patients where id=patient for update;
  select * into o from public.outbox where id=(p_input->>'id')::uuid for update;
  worker:=(p_input->>'worker_id')::uuid; fence:=(p_input->>'lease_token')::uuid;
  if o.id is null or worker is null or fence is null or o.status<>'processing' or o.lock_owner<>worker or o.lease_token<>fence
    or o.locked_at<=t-interval '5 minutes' then raise exception 'LEASE_LOST' using errcode='P0001'; end if;

  if p_action='lookup' then
    select wa_message_id into provider from public.mock_deliveries where outbox_id=o.id and clinic_id=o.clinic_id;
    return jsonb_build_object('state',case when provider is null then 'absent' else 'accepted' end,'wa_message_id',provider);
  end if;
  if p_action in ('prepare','mock_accept') then
    if p_action='prepare' and o.prepared_at is not null then return jsonb_build_object('action','reconcile'); end if;
    if p_action='mock_accept' then
      if o.prepared_at is null then raise exception 'NOT_PREPARED' using errcode='P0001'; end if;
      select wa_message_id into provider from public.mock_deliveries where outbox_id=o.id and clinic_id=o.clinic_id;
      if provider is not null then return jsonb_build_object('action','accepted','wa_message_id',provider); end if;
    end if;
    decision:=private.delivery_policy(o,t);
    if decision->>'action'='skip' then
      update public.outbox set status='skipped',last_error=decision->>'code',locked_at=null,lock_owner=null,lease_token=null,prepared_at=null,
        attempts=case when p_action='mock_accept' then greatest(attempts-1,0) else attempts end where id=o.id;
      if decision->>'code' in ('WA_TEMPLATE_UNAVAILABLE','WA_NOT_ON_WHATSAPP','CONFIG_INVALID') then
        perform private.delivery_alert(o.clinic_id,o.patient_id,decision->>'code','policy/'||o.id::text||'/'||(decision->>'code'),t);
      end if;
      return decision;
    elsif decision->>'action'='defer' then
      update public.outbox set status='queued',not_before=(decision->>'not_before')::timestamptz,last_error=decision->>'code',locked_at=null,lock_owner=null,lease_token=null,prepared_at=null,
        attempts=case when p_action='mock_accept' then greatest(attempts-1,0) else attempts end where id=o.id;
      return decision;
    end if;
    if p_action='prepare' then
      update public.outbox set attempts=attempts+1,prepared_at=t,cap_date=(t at time zone 'Asia/Kolkata')::date,last_error=null where id=o.id returning * into o;
      if (decision->>'used')::integer+1>=ceil((decision->>'cap')::numeric*0.8) then
        perform private.delivery_alert(o.clinic_id,null,'SEND_CAP_80','cap/'||o.clinic_id::text||'/'||o.cap_date::text||'/80',t);
      end if;
      if (decision->>'used')::integer+1>=(decision->>'cap')::integer then
        perform private.delivery_alert(o.clinic_id,null,'SEND_CAP_REACHED','cap/'||o.clinic_id::text||'/'||o.cap_date::text||'/100',t);
      end if;
      return jsonb_build_object('action','send','id',o.id,'clinic_id',o.clinic_id,'patient_id',o.patient_id,'kind',o.kind,'purpose',o.purpose,'payload',o.payload,'attempt',o.attempts,'idempotency_key',o.idempotency_key);
    end if;
    provider:='mock.'||o.id::text;
    update public.outbox set cap_date=(t at time zone 'Asia/Kolkata')::date where id=o.id;
    if o.cap_date is distinct from (t at time zone 'Asia/Kolkata')::date then
      if (decision->>'used')::integer+1>=ceil((decision->>'cap')::numeric*0.8) then
        perform private.delivery_alert(o.clinic_id,null,'SEND_CAP_80','cap/'||o.clinic_id::text||'/'||(t at time zone 'Asia/Kolkata')::date::text||'/80',t);
      end if;
      if (decision->>'used')::integer+1>=(decision->>'cap')::integer then
        perform private.delivery_alert(o.clinic_id,null,'SEND_CAP_REACHED','cap/'||o.clinic_id::text||'/'||(t at time zone 'Asia/Kolkata')::date::text||'/100',t);
      end if;
    end if;
    insert into public.mock_deliveries(outbox_id,clinic_id,wa_message_id,payload,accepted_at) values(o.id,o.clinic_id,provider,o.payload,t);
    return jsonb_build_object('action','accepted','wa_message_id',provider);
  end if;

  if p_action='complete' then
    provider:=p_input->>'wa_message_id';
    if o.prepared_at is null or provider is null or length(provider) not between 1 and 200 then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    -- This development worker accepts only durable mock-provider evidence. No live sender is enabled.
    select accepted_at into accepted_time from public.mock_deliveries where outbox_id=o.id and clinic_id=o.clinic_id and wa_message_id=provider;
    if not found then
      raise exception 'ACCEPTANCE_UNVERIFIED' using errcode='P0001';
    end if;
    insert into public.message_log(clinic_id,patient_id,outbox_id,wa_message_id,type,template_name,created_at)
      values(o.clinic_id,o.patient_id,o.id,provider,o.kind,o.payload->>'template_name',accepted_time);
    update public.outbox set status='sent',wa_message_id=provider,provider_status='accepted',locked_at=null,lock_owner=null,lease_token=null where id=o.id;
    insert into public.events(clinic_id,patient_id,type,occurred_at,meta) values(o.clinic_id,o.patient_id,'message.accepted',accepted_time,jsonb_build_object('outbox_id',o.id,'provider','mock'));
    -- Apply any receipt that arrived before acceptance was committed.
    if exists(select 1 from public.delivery_receipts where clinic_id=o.clinic_id and wa_message_id=provider) then
      perform private.delivery_apply_receipts(o.id,t);
    end if;
    return jsonb_build_object('action','sent','wa_message_id',provider);
  end if;

  failure:=p_input->>'code';
  if o.prepared_at is null then raise exception 'NOT_PREPARED' using errcode='P0001'; end if;
  if failure is null or failure not in ('WA_SEND_FAILED','WA_NOT_ON_WHATSAPP','WA_TEMPLATE_UNAVAILABLE','WA_ACCEPTANCE_UNKNOWN','MOCK_ABSENT') then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  if failure='WA_NOT_ON_WHATSAPP' then update public.patients set whatsapp_status='not_on_whatsapp' where id=o.patient_id and clinic_id=o.clinic_id; end if;
  if failure='WA_TEMPLATE_UNAVAILABLE' then
    update public.clinics set settings=jsonb_set(settings,'{unavailable_templates}',coalesce(settings->'unavailable_templates','{}'::jsonb)||jsonb_build_object((o.payload->>'template_name')||':'||coalesce(o.payload->>'language','en'),true)) where id=o.clinic_id;
  end if;
  if failure='WA_ACCEPTANCE_UNKNOWN' then next_status:='uncertain';
  elsif failure in ('WA_SEND_FAILED','MOCK_ABSENT') and o.attempts<4 then next_status:='queued';
  else next_status:='failed'; end if;
  update public.outbox set status=next_status,last_error=failure,
    not_before=case when next_status='queued' then t+case when o.attempts<=1 then interval '1 minute' when o.attempts=2 then interval '5 minutes' else interval '15 minutes' end else not_before end,
    locked_at=null,lock_owner=null,lease_token=null,prepared_at=case when next_status='uncertain' then prepared_at else null end
    where id=o.id;
  if next_status in ('failed','uncertain') then perform private.delivery_alert(o.clinic_id,o.patient_id,failure,'failure/'||o.id::text||'/'||failure,t); end if;
  return jsonb_build_object('action',next_status,'code',failure);
end $$;

create function public.tabiyo_delivery(p_action text,p_input jsonb,p_now timestamptz default null) returns jsonb
language sql security invoker set search_path='' as $$ select private.delivery(p_action,p_input,p_now) $$;
revoke all on function private.delivery_alert(uuid,uuid,text,text,timestamptz),private.delivery_apply_receipts(uuid,timestamptz),private.delivery_policy(public.outbox,timestamptz),private.delivery(text,jsonb,timestamptz),public.tabiyo_delivery(text,jsonb,timestamptz) from public,anon,authenticated,service_role;
grant usage on schema private to service_role;
grant execute on function private.delivery(text,jsonb,timestamptz),public.tabiyo_delivery(text,jsonb,timestamptz) to service_role;

commit;
