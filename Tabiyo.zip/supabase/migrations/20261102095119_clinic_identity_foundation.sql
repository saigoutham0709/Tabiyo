begin;

create table public.clinics (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) between 1 and 200),
  address text not null default '',
  timezone text not null default 'Asia/Kolkata' check (timezone = 'Asia/Kolkata'),
  default_language text not null default 'en' check (default_language in ('en','te','hi')),
  whatsapp_phone_number_id text unique,
  plan text not null default 'pilot',
  daily_send_cap integer not null default 1000 check (daily_send_cap > 0),
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.staff_users (
  id uuid primary key references auth.users(id) on delete restrict,
  clinic_id uuid not null references public.clinics(id) on delete restrict,
  name text not null check (length(trim(name)) between 1 and 200),
  role text not null check (role in ('admin','doctor','front_desk')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (id, clinic_id)
);
create index staff_users_clinic_idx on public.staff_users(clinic_id);

create table public.doctors (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete restrict,
  staff_user_id uuid,
  name text not null check (length(trim(name)) between 1 and 200),
  specialty text not null default '',
  slot_minutes integer not null default 30 check (slot_minutes between 5 and 180),
  active boolean not null default true,
  unique (id, clinic_id),
  foreign key (staff_user_id, clinic_id) references public.staff_users(id, clinic_id) on delete restrict
);
create index doctors_clinic_idx on public.doctors(clinic_id);

create table public.patients (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete restrict,
  mobile_e164 text not null check (mobile_e164 ~ '^\+91[6-9][0-9]{9}$'),
  name text not null check (length(trim(name)) between 1 and 200),
  date_of_birth date,
  gender text check (gender in ('female','male','other','undisclosed')),
  language text not null default 'en' check (language in ('en','te','hi')),
  whatsapp_status text not null default 'unknown' check (whatsapp_status in ('unknown','ok','not_on_whatsapp','blocked')),
  opted_out boolean not null default false,
  merged_into uuid,
  created_at timestamptz not null default now(),
  unique (id, clinic_id),
  check (merged_into is null or merged_into <> id),
  foreign key (merged_into, clinic_id) references public.patients(id, clinic_id) on delete restrict
);
-- Deliberately not unique: family members share a mobile but retain separate identities.
create index patients_clinic_mobile_idx on public.patients(clinic_id, mobile_e164);

create table public.consents (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete restrict,
  patient_id uuid not null,
  version text not null check (length(trim(version)) between 1 and 100),
  status text not null check (status in ('granted','revoked')),
  channel text not null check (channel in ('phone','whatsapp','paper','dashboard')),
  created_by uuid,
  created_at timestamptz not null default now(),
  foreign key (patient_id, clinic_id) references public.patients(id, clinic_id) on delete restrict,
  foreign key (created_by, clinic_id) references public.staff_users(id, clinic_id) on delete restrict
);
create index consents_patient_idx on public.consents(clinic_id, patient_id, created_at);

alter table public.clinics enable row level security;
alter table public.staff_users enable row level security;
alter table public.doctors enable row level security;
alter table public.patients enable row level security;
alter table public.consents enable row level security;

-- Avoid recursive membership policies: staff can only read their own active membership.
-- Staff onboarding/role changes require a separately authorized server operation, not self-service SQL.
create policy staff_read_self on public.staff_users for select to authenticated
  using (id = (select auth.uid()) and active);

create policy clinics_read_member on public.clinics for select to authenticated
  using (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = clinics.id));

create policy doctors_read_member on public.doctors for select to authenticated
  using (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = doctors.clinic_id));

create policy patients_read_member on public.patients for select to authenticated
  using (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = patients.clinic_id));
create policy patients_insert_member on public.patients for insert to authenticated
  with check (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = patients.clinic_id));
create policy patients_update_member on public.patients for update to authenticated
  using (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = patients.clinic_id))
  with check (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = patients.clinic_id));

create policy consents_read_member on public.consents for select to authenticated
  using (exists (select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = consents.clinic_id));
create policy consents_insert_member on public.consents for insert to authenticated
  with check (created_by = (select auth.uid()) and exists (
    select 1 from public.staff_users s where s.id = (select auth.uid()) and s.active and s.clinic_id = consents.clinic_id
  ));

-- Explicit grants are required independently of RLS, including on projects with changed defaults.
revoke all on public.clinics, public.staff_users, public.doctors, public.patients, public.consents from anon, authenticated, service_role;
grant select on public.clinics, public.staff_users, public.doctors, public.patients, public.consents to authenticated;
grant insert, update on public.patients to authenticated;
grant insert on public.consents to authenticated;
grant select, insert, update, delete on public.clinics, public.staff_users, public.doctors, public.patients to service_role;
-- Consent is append-only for both user-scoped and application service-role clients.
grant select, insert on public.consents to service_role;

commit;
