begin;
create function private.patient_get(p_id uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; p public.patients;
begin
  s:=private.require_staff();
  select * into p from public.patients where id=p_id and clinic_id=s.clinic_id;
  if not found then raise exception 'PATIENT_NOT_FOUND' using errcode='P0001'; end if;
  insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'patient.read','patients',p.id);
  return to_jsonb(p);
end $$;
revoke all on function private.patient_get(uuid) from public,anon,authenticated,service_role;
grant execute on function private.patient_get(uuid) to authenticated;
create function public.tabiyo_patient_get(p_id uuid) returns jsonb
language sql security invoker set search_path='' as $$ select private.patient_get(p_id) $$;
revoke all on function public.tabiyo_patient_get(uuid) from public,anon,authenticated,service_role;
grant execute on function public.tabiyo_patient_get(uuid) to authenticated;
alter table public.staff_alerts add column resolved_by uuid;
alter table public.staff_alerts add column resolution_code text check(resolution_code in ('investigated','patient_contacted','configuration_fixed','no_action_required','delivery_reconciled'));
alter table public.staff_alerts add foreign key(resolved_by,clinic_id) references public.staff_users(id,clinic_id);
create index alerts_clinic_status_time on public.staff_alerts(clinic_id,status,created_at desc,id);

-- Contains only operation IDs and results, never cached patient bodies or provider payloads.
create table public.staff_operation_requests (
  clinic_id uuid not null references public.clinics(id),
  request_id uuid not null,
  actor_id uuid not null,
  action text not null,
  fingerprint text not null,
  response jsonb not null,
  created_at timestamptz not null default now(),
  primary key(clinic_id,request_id),
  foreign key(actor_id,clinic_id) references public.staff_users(id,clinic_id)
);
alter table public.staff_operation_requests enable row level security;
revoke all on public.staff_operation_requests from public,anon,authenticated,service_role;
grant select on public.staff_operation_requests to service_role;

create function private.staff_operations(p_action text,p_input jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
declare s public.staff_users; a public.staff_alerts; o public.outbox; proof public.mock_deliveries;
  cached public.staff_operation_requests; request uuid; fingerprint text; result jsonb; items jsonb:='[]';
  r record; row_limit integer; selected_status text; mobile text; worker uuid; fence uuid; resolution text;
begin
  s:=private.require_staff();
  if p_action is null or p_action not in ('alerts','resolve_alert','uncertain','reconcile_mock','close_without_resend')
    or p_input is null or jsonb_typeof(p_input)<>'object' then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
  -- Doctor-specific clinical ownership is not inferred from operational alert IDs.
  if s.role not in ('admin','front_desk') or (p_action in ('uncertain','reconcile_mock','close_without_resend') and s.role<>'admin') then
    raise exception 'OPERATION_FORBIDDEN' using errcode='42501';
  end if;
  if p_action in ('alerts','uncertain') then
    if p_input-array['limit','status']<>'{}'::jsonb then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    row_limit:=coalesce((p_input->>'limit')::integer,50);
    if row_limit not between 1 and 100 then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    if p_action='alerts' then
      selected_status:=coalesce(p_input->>'status','open');
      if selected_status not in ('open','resolved') then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
      for a in select * from public.staff_alerts where clinic_id=s.clinic_id and status=selected_status order by created_at desc,id limit row_limit loop
        items:=items||jsonb_build_array(jsonb_build_object('id',a.id,'clinic_id',a.clinic_id,'patient_id',a.patient_id,
          'code',a.code,'status',a.status,'created_at',a.created_at,'resolved_at',a.resolved_at,'resolved_by',a.resolved_by,'resolution_code',a.resolution_code));
        insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'alert.read','staff_alerts',a.id);
      end loop;
      return jsonb_build_object('alerts',items);
    end if;
    if p_input?'status' then raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    for o in select * from public.outbox where clinic_id=s.clinic_id and status='uncertain' order by created_at,id limit row_limit loop
      items:=items||jsonb_build_array(jsonb_build_object('id',o.id,'clinic_id',o.clinic_id,'patient_id',o.patient_id,'purpose',o.purpose,
        'attempts',o.attempts,'created_at',o.created_at,'has_mock_evidence',exists(select 1 from public.mock_deliveries where outbox_id=o.id)));
      insert into public.audit_log(clinic_id,user_id,action,table_name,record_id) values(s.clinic_id,s.id,'delivery.uncertain_read','outbox',o.id);
    end loop;
    return jsonb_build_object('deliveries',items);
  end if;
  if p_input-array['id','request_id','resolution_code']<>'{}'::jsonb or p_input->>'id' is null or p_input->>'request_id' is null then
    raise exception 'INPUT_INVALID' using errcode='22023';
  end if;
  request:=(p_input->>'request_id')::uuid;
  fingerprint:=md5(p_action||':'||p_input::text);
  perform pg_advisory_xact_lock(hashtextextended('staff-operation/'||s.clinic_id::text||'/'||request::text,0));
  select * into cached from public.staff_operation_requests where clinic_id=s.clinic_id and request_id=request;
  if found then
    if cached.actor_id<>s.id or cached.fingerprint<>fingerprint then raise exception 'IDEMPOTENCY_CONFLICT' using errcode='P0001'; end if;
    return cached.response||jsonb_build_object('replayed',true);
  end if;
  resolution:=p_input->>'resolution_code';
  if p_action='resolve_alert' then
    if resolution is null or resolution not in ('investigated','patient_contacted','configuration_fixed','no_action_required') then
      raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    select * into a from public.staff_alerts where id=(p_input->>'id')::uuid and clinic_id=s.clinic_id for update;
    if not found then raise exception 'ALERT_NOT_FOUND' using errcode='P0001'; end if;
    if a.status='resolved' then raise exception 'ALERT_ALREADY_RESOLVED' using errcode='P0001'; end if;
    if exists(select 1 from public.outbox x where x.clinic_id=s.clinic_id and x.status='uncertain'
      and a.dedup_key='failure/'||x.id::text||'/WA_ACCEPTANCE_UNKNOWN') then
      raise exception 'DELIVERY_REVIEW_REQUIRED' using errcode='P0001'; end if;
    update public.staff_alerts set status='resolved',resolved_by=s.id,resolution_code=resolution where id=a.id;
    insert into public.events(clinic_id,patient_id,type,meta) values(s.clinic_id,a.patient_id,'staff.alert_resolved',jsonb_build_object('alert_id',a.id,'resolution_code',resolution));
    insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id,reason)
      values(s.clinic_id,s.id,'alert.resolved','staff_alerts',a.id,request,resolution);
    result:=jsonb_build_object('id',a.id,'clinic_id',s.clinic_id,'status','resolved','replayed',false);
  else
    if (p_action='reconcile_mock' and resolution is not null) or
       (p_action='close_without_resend' and (resolution is null or resolution not in ('patient_contacted','no_action_required'))) then
      raise exception 'INPUT_INVALID' using errcode='22023'; end if;
    select p.mobile_e164 into mobile from public.outbox x join public.patients p on p.id=x.patient_id and p.clinic_id=x.clinic_id
      where x.id=(p_input->>'id')::uuid and x.clinic_id=s.clinic_id;
    if not found then raise exception 'DELIVERY_NOT_FOUND' using errcode='P0001'; end if;
    perform pg_advisory_xact_lock(hashtextextended('contact/'||s.clinic_id::text||'/'||mobile,0));
    perform 1 from public.patients where clinic_id=s.clinic_id and id=(select patient_id from public.outbox where id=(p_input->>'id')::uuid) for update;
    select * into o from public.outbox where id=(p_input->>'id')::uuid and clinic_id=s.clinic_id for update;
    if o.status<>'uncertain' then raise exception 'DELIVERY_NOT_UNCERTAIN' using errcode='P0001'; end if;
    select * into proof from public.mock_deliveries where outbox_id=o.id and clinic_id=s.clinic_id;
    if p_action='reconcile_mock' and proof.outbox_id is not null then
      worker:=gen_random_uuid(); fence:=gen_random_uuid();
      update public.outbox set status='processing',lock_owner=worker,lease_token=fence,locked_at=clock_timestamp() where id=o.id;
      perform private.delivery('complete',jsonb_build_object('id',o.id,'worker_id',worker,'lease_token',fence,'wa_message_id',proof.wa_message_id));
      resolution:='accepted';
    elsif p_action='close_without_resend' then
      if proof.outbox_id is not null then raise exception 'ACCEPTANCE_EVIDENCE_EXISTS' using errcode='P0001'; end if;
      update public.outbox set status='failed',last_error='MANUAL_NO_RESEND',lock_owner=null,lease_token=null,locked_at=null where id=o.id;
      resolution:='closed_without_resend';
    else resolution:='held'; end if;
    select * into o from public.outbox where id=o.id;
    if resolution<>'held' then
      for a in select * from public.staff_alerts where clinic_id=s.clinic_id and status='open'
          and dedup_key='failure/'||o.id::text||'/WA_ACCEPTANCE_UNKNOWN' for update loop
        update public.staff_alerts set status='resolved',resolved_by=s.id,resolution_code='delivery_reconciled' where id=a.id;
        insert into public.events(clinic_id,patient_id,type,meta) values(s.clinic_id,a.patient_id,'staff.alert_resolved',jsonb_build_object('alert_id',a.id,'resolution_code','delivery_reconciled'));
      end loop;
    end if;
    insert into public.events(clinic_id,patient_id,type,meta) values(s.clinic_id,o.patient_id,'delivery.reviewed',jsonb_build_object('outbox_id',o.id,'resolution',resolution));
    insert into public.audit_log(clinic_id,user_id,action,table_name,record_id,request_id,reason)
      values(s.clinic_id,s.id,'delivery.reviewed','outbox',o.id,request,coalesce(p_input->>'resolution_code',resolution));
    result:=jsonb_build_object('id',o.id,'clinic_id',s.clinic_id,'status',o.status,'resolution',resolution,'replayed',false);
  end if;
  insert into public.staff_operation_requests(clinic_id,request_id,actor_id,action,fingerprint,response) values(s.clinic_id,request,s.id,p_action,fingerprint,result);
  return result;
end $$;
revoke all on function private.staff_operations(text,jsonb) from public,anon,authenticated,service_role;
grant execute on function private.staff_operations(text,jsonb) to authenticated;
create function public.tabiyo_staff_operations(p_action text,p_input jsonb default '{}') returns jsonb
language sql security invoker set search_path='' as $$ select private.staff_operations(p_action,p_input) $$;
revoke all on function public.tabiyo_staff_operations(text,jsonb) from public,anon,authenticated,service_role;
grant execute on function public.tabiyo_staff_operations(text,jsonb) to authenticated;
commit;
