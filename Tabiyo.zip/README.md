# Tabiyo

## Handbook development track

The original synthetic pilot remains at the repository root. The handbook application is being built in `apps/api`, `apps/dashboard`, `packages/shared` and `supabase`. The separate staff dashboard uses the new API; it is not connected to live WhatsApp.

The new backend includes audited patient services, atomic queue records, a mock delivery worker, signed local inbound processing, pg-boss scheduling and bounded technical retention. Staff operations, safe delivery reconciliation, dashboard sessions, appointment services and durable reminder creation are now implemented locally. See [staff workspace and appointments](docs/STAFF-WORKSPACE-AND-APPOINTMENTS.md), [patient API](docs/PATIENT-API.md), [mock worker](docs/DELIVERY-WORKER.md), [gateway](docs/INBOUND-GATEWAY.md) and [scheduler/retention](docs/SCHEDULER-RETENTION.md). Run `npm run demo:delivery`, `npm run demo:gateway` or `npm run demo:scheduler` for isolated synthetic demonstrations; zero physical messages are sent. Full handbook completion remains open. The server entry point does not start background workers, ingress or a live sender.

All development resources must be controlled by **admin@catalystintelligence.in**. Supabase and Meta setup are pending at the user's request. Do not connect a different account. See [execution plan](docs/DEVELOPMENT-EXECUTION.md), [current development status](docs/DEVELOPMENT-STATUS.md) and [resource registry](config/development-resources.json).

Admin schedule/leave controls and the default-off walk-in queue are implemented locally. See [availability and queue contracts](docs/AVAILABILITY-AND-QUEUE.md). Approved patient-facing wording/versions will be supplied by the user; no production notice text is seeded.

```sh
npx --yes pnpm@11.25.0 install --frozen-lockfile
npm test
npm run typecheck
npm run lint
npm run build
npm run build:dashboard
npm run test:dashboard:smoke
```

`npm test` includes the original pilot tests, Fastify API/auth tests and PostgreSQL schema/RLS tests using PGlite. These run with synthetic data and no cloud account. Embedded PostgreSQL tests do not replace Supabase Auth/Storage and staging acceptance. For the new API, `npm run dev:api` requires an intentionally configured, owner-verified Supabase development environment in ignored `.env.local`. No configuration enables a fake staff identity.

The sections below describe the earlier pilot baseline; consult the current status document for the new development track.

A private, persistent pilot for two connected experiences: a clinic staff website and a WhatsApp-style patient conversation simulator. Uses the Tabiyo pitch deck's forest, cream and saffron brand with scheduling design guidance from VoltAgent's awesome-design-md.

**This is a synthetic pilot, not a launched healthcare service.** No WhatsApp, SMS, voice, OCR, payment, EMR connector, or identity-verification provider is connected. Do not enter real patient data. The public webhook intentionally returns 503. India-only storage has not been verified. Production staff membership, assignment-based access, MFA and immutable audits are not implemented.

## What works

- Persisted account-isolated workspace; private hosted sign-in.
- Appointment booking, check-in, cancellation, no-show, atomic rescheduling and slot-conflict checks.
- Separate queues and delay updates for three sample doctors.
- Patient chat booking, self-service rescheduling/cancellation, clinic FAQs, queue status, opt-out, caregiver approval, protected-record handoff and staff requests.
- Typed medicine drafts → clinician review → patient confirmation → active plan; patient-reported taken/snoozed events and course-date enforcement.
- Staff inbox with conversation history, review tasks and resolution.
- Patient profiles, basic factual pre-visit summary, structured lab results and same-test/unit trends.
- Follow-up task journeys; explicit patient caregiver permission and revocation.
- Activity counts, data export, clinic settings and pilot action history.
- Validated commands, parameterized database queries, optimistic concurrency, request replay protection and account rate limits.

## Stack and development

React 19, TypeScript, Vinext/Vite, Cloudflare Worker and D1/Drizzle. Node 24 is used for the tests (built-in TypeScript stripping and SQLite). Sites controls hosting auth and publication; preserve the build integration and `.openai/hosting.json`.

```sh
node --test tests/*.test.mjs
node node_modules/typescript/bin/tsc --noEmit
npm run build
```

Use the Sites skill for dependency setup, approved preview lifecycle, builds and source synchronization. Migrations live in `drizzle/`; do not modify applied migrations.

## Code map

| File | Responsibility |
| --- | --- |
| `app/tabiyo.tsx`, `app/globals.css` | Staff UI and synthetic patient simulator |
| `lib/domain.ts` | Typed commands, business rules and patient conversation state machine |
| `lib/repository.ts` | Account ownership, persisted state, compare-and-swap and rate limits |
| `app/api/workspace/route.ts` | Authenticated, same-origin API boundary |
| `lib/whatsapp.ts` | Isolated HMAC, 24-hour/consent policy and official API sender primitives |
| `app/api/webhooks/whatsapp/route.ts` | Disabled live ingress; fails closed |
| `middleware.ts` | Baseline response security headers |
| `tests/` | 22 domain + 10 API/SQLite integration tests |
| `docs/PRODUCT_AND_LAUNCH.md` | Market evidence, feature statuses, production architecture and launch requirements |
| `DESIGN.md` | Tabiyo-specific visual tokens and interaction rules |

## Verification

32 tests passed and TypeScript and deployable build passed. API integration tests use the actual generated SQL in in-memory SQLite, with a mocked platform identity and D1 binding. These are not live Meta, D1-provider, browser, accessibility-audit or penetration tests. The available browser-control skill is absent; visual browser QA was not performed.

## Storage boundary

This pilot stores a bounded aggregate per signed-in owner with a versioned compare-and-swap write. That is sufficient for exploring the connected sample workflow, not hospital-scale operations. Limits: 500 sample patients and 3,000 appointments per workspace; 1,500 retained messages, 1,000 audit entries, 200 replay keys. Migrate to normalized tenant-scoped production tables, proper retention and append-only audits before live use.
