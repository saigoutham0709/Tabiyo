// Synthetic, in-memory demonstration only. No credentials, cloud accounts or Meta calls.
import {fixture,ids} from '../supabase/tests/helpers.mjs';
import {createDeliveryStore,DeliveryStoreError} from '../apps/api/src/delivery/store.ts';
import {RecordingMockSender} from '../apps/api/src/delivery/mock-sender.ts';
import {DeliveryWorker} from '../apps/api/src/delivery/worker.ts';

const database=await fixture();
const simulatedNow='2026-11-02T04:30:00.000Z';
try{
  await database.db.query('update public.clinics set settings=$1::jsonb where id=$2',[JSON.stringify({approved_templates:{'demo_notice:en':true}}),ids.clinicA]);
  await database.db.query('insert into public.consents(clinic_id,patient_id,version,status,channel,created_by) values ($1,$2,$3,$4,$5,$6)',[ids.clinicA,ids.patientA,'synthetic-demo','granted','phone',ids.adminA]);
  const queued=(await database.db.query('insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key,not_before) values ($1,$2,$3,$4,$5::jsonb,$6,$7) returning id',[ids.clinicA,ids.patientA,'template','appointment',JSON.stringify({template_name:'demo_notice',language:'en'}),crypto.randomUUID(),simulatedNow])).rows[0];
  const store=createDeliveryStore(async(action,input)=>{
    try{return await database.asUser(null,async tx=>(await tx.query('select public.tabiyo_delivery($1,$2::jsonb,$3::timestamptz) as result',[action,JSON.stringify(input),simulatedNow])).rows[0].result,'service_role');}
    catch(error){throw new DeliveryStoreError(error.message);}
  });
  const worker=new DeliveryWorker(store,new RecordingMockSender(store));
  await worker.runOnce();
  const accepted=(await database.db.query('select provider_status,wa_message_id from public.outbox where id=$1',[queued.id])).rows[0];
  await store.receipt({clinic_id:ids.clinicA,wa_message_id:accepted.wa_message_id,status:'delivered',occurred_at:simulatedNow});
  const final=(await database.db.query('select status,provider_status from public.outbox where id=$1',[queued.id])).rows[0];
  console.log(JSON.stringify({mode:'synthetic mock',clock:'simulated',acceptanceStatus:accepted.provider_status,afterSimulatedReceipt:final.provider_status,queueState:final.status,physicalMessagesSent:0},null,2));
}finally{await database.db.close();}
