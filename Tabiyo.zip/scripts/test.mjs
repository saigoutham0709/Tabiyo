// Keep file isolation while ensuring V8's WASM memory flags reach the actual test process.
// Node's default process-isolated test runner in the pinned runtime drops those V8 exec arguments.
import {readdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {stripVTControlCharacters} from 'node:util';
const root=fileURLToPath(new URL('../',import.meta.url));
const groups={all:['tests','apps/api/tests','apps/dashboard/tests','supabase/tests'],
  foundation:['apps/api/tests','apps/dashboard/tests','supabase/tests'],api:['apps/api/tests'],dashboard:['apps/dashboard/tests']};
const group=process.argv[2]??'all';
if(!Object.hasOwn(groups,group))throw new Error('UNKNOWN_TEST_GROUP');
const files=groups[group].flatMap(directory=>readdirSync(path.join(root,directory)).filter(name=>name.endsWith('.test.mjs')).sort().map(name=>path.join(directory,name)));
let passed=0,failed=0;
for(const file of files){
  const result=spawnSync(process.execPath,['--wasm-num-compilation-tasks=1','--no-wasm-tier-up','--test-isolation=none',
    '--test','--test-reporter=spec',file],{cwd:root,windowsHide:true,encoding:'utf8',maxBuffer:4*1024*1024});
  process.stdout.write(result.stdout??'');process.stderr.write(result.stderr??'');
  const output=stripVTControlCharacters(result.stdout??'');
  const successes=output.match(/^ℹ pass (\d+)$/m),failures=output.match(/^ℹ fail (\d+)$/m);
  passed+=Number(successes?.[1]??0);failed+=Number(failures?.[1]??0);
  if(result.error||result.status!==0||!successes||!failures){
    console.error(`Verification failed in ${file}.`);process.exit(1);
  }
}
console.log(`Tabiyo verification: ${passed} passed, ${failed} failed across ${files.length} isolated files.`);
