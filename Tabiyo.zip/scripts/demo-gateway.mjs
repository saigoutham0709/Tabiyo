// Synthetic in-memory request/worker demo. No keys, tunnels, provider accounts or live messages.
import {createHmac} from 'node:crypto';
import {fixture,ids} from '../supabase/tests/helpers.mjs';
import {buildApp} from '../apps/api/src/app.ts';
import {createGatewayStore,GatewayStoreError} from '../apps/api/src/whatsapp/store.ts';
import {GatewayWorker} from '../apps/api/src/whatsapp/worker.ts';

const f=await fixture(),time='2026-11-02T04:30:00.000Z';
const secret='synthetic-gateway-demo-secret';
let app;
try{
  await f.db.query('update public.clinics set whatsapp_phone_number_id=$1 where id=$2',['111',ids.clinicA]);
  const store=createGatewayStore(async(action,input)=>{
    try{return await f.asUser(null,async tx=>(await tx.query('select public.tabiyo_gateway($1,$2::jsonb,$3::timestamptz) as result',[action,JSON.stringify(input),time])).rows[0].result,'service_role');}
    catch(error){throw new GatewayStoreError(error.message);}
  });
  app=buildApp({authenticate:async()=>{throw Error('No staff session used by gateway demo.');},webhook:{mode:'local-test',appSecret:secret,verifyToken:'synthetic-gateway-demo-token',gatewayId:'synthetic-demo',store}});
  const raw=JSON.stringify({object:'whatsapp_business_account',entry:[{id:'synthetic-business',changes:[{field:'messages',value:{metadata:{phone_number_id:'111'},messages:[{id:'wamid.synthetic.'+crypto.randomUUID(),from:'919000000001',timestamp:String(Date.parse(time)/1000),type:'text',text:{body:'STOP'}}]}}]}]});
  const response=await app.inject({method:'POST',url:'/webhooks/whatsapp',headers:{'content-type':'application/json','x-hub-signature-256':'sha256='+createHmac('sha256',secret).update(raw).digest('hex')},payload:raw});
  if(response.statusCode!==200)throw Error('Synthetic intake failed.');
  const queued=(await f.db.query('select status from public.webhook_raw')).rows[0].status;
  await new GatewayWorker(store).runOnce();
  const stopped=(await f.db.query('select channel_stopped from public.conversations')).rows[0].channel_stopped;
  console.log(JSON.stringify({mode:'synthetic local gateway',verifiedIntake:true,queueBeforeProcessing:queued,inboundRecords:(await f.db.query("select count(*)::integer as n from public.message_log where direction='in'")).rows[0].n,sharedPhoneStopped:stopped,physicalMessagesSent:0},null,2));
}finally{await app?.close();await f.db.close();}
