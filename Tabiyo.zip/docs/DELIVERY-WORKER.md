# Mock delivery worker: Phase 1B

This increment implements and verifies a durable **mock** delivery path. It makes no Meta requests and starts no daemon. Cloud setup is still pending under `admin@catalystintelligence.in`. No real patient data belongs in these fixtures.

## Run locally

```sh
npm test
npm run demo:delivery
```

The demo migrates an isolated in-memory PostgreSQL engine, seeds synthetic staff/patients and a synthetic template approval, queues a notification, runs one worker and supplies a simulated receipt. It reports mock acceptance and simulated delivery separately. `physicalMessagesSent` is always zero. It uses no keys, provider accounts, WhatsApp recipients or external message API.

Tests run one file at a time to bound PostgreSQL WebAssembly memory. Running the full database suite and demo concurrently exceeded local memory during development; the concurrency limit fixes test orchestration, not application concurrency. Multi-connection PostgreSQL locking verification remains an external-stack gate.

## Components

| Source | Responsibility |
| --- | --- |
| `apps/api/src/delivery/worker.ts` | One bounded claim/prepare/send-or-reconcile/settle cycle. Database errors preserve recovery state. |
| `apps/api/src/delivery/store.ts` | Validated RPC boundary and optional server-only Supabase adapter restricted to mock mode. No API route exposes worker controls. |
| `apps/api/src/delivery/mock-sender.ts` | Recording fake provider; injects timeout, 5xx, not-on-WhatsApp, rejected template and accepted-then-timeout scenarios. |
| `supabase/migrations/20261102110424_delivery_worker_and_receipts.sql` | Lease fencing, policy, reservations, immutable logs/receipts, mock evidence and durable alerts. |
| `apps/api/tests/delivery.test.mjs` | Policy, ACL, recovery, retries, cap, clock, receipt and privacy cases against actual migrated local PostgreSQL. |

Only a service role may invoke `tabiyo_delivery`. Public wrappers are invoker functions; privileged implementation stays in the unexposed private schema with an empty search path and revoked PUBLIC/anonymous/staff execution. Workers have no end-user `auth.uid()`; service-role execution grants are their identity boundary. No credentials were requested or configured. Normal staff cannot manufacture mock acceptance or mutate immutable delivery records.

## Delivery lifecycle

1. Claim the oldest eligible queued row, or reclaim an expired processing lease, using `FOR UPDATE SKIP LOCKED`. Claim creates a fresh fencing UUID and five-minute lease.
2. Prepare under patient/outbox locks; serialize cap reservation with a clinic lock. Apply policy at current database time and reserve one daily slot only when eligible. An authorized attempt increments `attempts`.
3. The mock provider rechecks policy and persists acceptance atomically. This blocks a same-patient consent revocation committed between prepare and mock acceptance.
4. Complete only when the durable mock ledger proves acceptance. Save one immutable `message_log` record and acceptance event. Retain the original provider acceptance time during crash recovery.
5. Apply actual simulated/provider receipts separately. There is no fabricated sent receipt on completion.

The legacy outbox `status='sent'` means the queue item was accepted by the configured mock provider. `provider_status='accepted'` remains distinct from a later `sent`, `delivered`, `read`, or `failed` receipt. The immutable message log records acceptance; the receipt ledger and derived outbox field represent subsequent progress. A saved/accepted row is never represented as delivered without a receipt.

A worker with an old/expired lease cannot settle work reclaimed by another worker. A crash before dispatch permits safe requeue only after the mock proves absence. A crash after acceptance recovers from durable evidence without another mock acceptance. Unknown acceptance becomes `uncertain` with an alert; the worker never blindly resends it. Do not generalize the mock's provable absence/idempotency to Meta's real API.

## Current policy

- Deny opted-out/blocked/merged/not-on-WhatsApp patients. The gateway increment adds explicit global phone suppression through `conversations.channel_stopped`; individual patient withdrawal remains patient-specific.
- Require current append-only consent history; its generated `recorded_order` provides deterministic ordering even when timestamps tie. Never infer consent from `opted_out:false` alone.
- An unconsented patient's `consent_request` may pass only when the server-controlled `allow_consent_request` setting is explicitly true, the exact purpose/kind/name matches and the language/template is approved. Default is off. Opt-out still wins. Final business/consent wording and permitted initiation rules remain a product/provider review gate.
- Default-off feature flags gate medication, queue, doctor summary and Telugu/Hindi messages.
- Templates must appear in `settings.approved_templates` as `<name>:<language>` keys with boolean true. Rejected templates are disabled in `unavailable_templates` and trigger alerts. These fixture approvals are not Meta approval evidence.
- Non-template text/buttons/lists/documents require a past inbound timestamp strictly inside 24 hours. Future timestamps and the exact 24-hour boundary fail closed.
- Default quiet hours are 21:00–07:00 IST. Clinic settings may specify other `HH:mm` intervals. Immediate staff replies are exempt from quiet hours, but not consent, window or caps. Invalid configuration blocks dispatch. Deferral consumes no send attempt.
- Daily caps count accepted, uncertain and prepared processing reservations for the IST send day. Threshold alerts at 80% and 100% are deduplicated. Reservations crossing midnight move to the actual mock acceptance day under the cap lock.
- Reminder/medication/queue/summary work more than 30 minutes overdue is skipped. Appointment validity and medication-course validity must be integrated when those domain modules exist.
- Every policy read of the patient record appends an audit entry. Neither message bodies nor raw error objects are printed to logs.

Definite mock rejection retries after 1, 5 and 15 minutes; the fourth authorized attempt fails and opens a staff alert. Timeouts require reconciliation first. Policy skips/deferments are not labeled successful sends. A known not-on-WhatsApp failure updates patient state; template failure stops reuse of that template. An approved generic fallback is not invented and remains pending agreed template contracts.

## Receipts, events and alerts

Receipts are immutable and deduplicated by clinic/message/status/provider time. They can arrive before worker completion and will be applied after acceptance. Receipt-derived events use unique receipt IDs, so replay and delayed matching cannot double-count progress. Read/delivered evidence cannot regress to sent/failed because of reordered callbacks. Conflicting callbacks remain preserved for inspection. Message IDs from one clinic cannot update another clinic's queue state.

`staff_alerts` stores deduplicated clinic-scoped operational alerts with codes and IDs. It does **not** send email/WhatsApp or constitute a monitored escalation channel. Staff alert UI, assignment/resolution and external notification remain pending. Error-code fields accept stable codes rather than arbitrary provider text.

The migration adds the handbook `message_log` plus `delivery_receipts`, `mock_deliveries`, and `staff_alerts` support tables. Total schema: 12 handbook domain tables and four support tables, all with RLS. Message log, receipts and mock acceptance evidence have no staff access and are insert-only through restricted worker operations; the service adapter cannot forge acceptance through a direct table insert. Their retention/deletion workflow still needs reviewed maintenance operations before production.

## Gates still open

- Local pg-boss scheduling and explicit mock composition are implemented in `SCHEDULER-RETENTION.md`. No deployed worker or live sender is enabled.
- Signed local-test intake, inbound dedup, shared STOP/START and raw cleanup are now implemented in `INBOUND-GATEWAY.md`. No deployed public/live ingress is enabled; the old pilot webhook remains disabled.
- No approved production template copy, generic fallback contract, provider credentials, number verification or actual receipts.
- No full-stack Supabase advisors/Auth/Storage, real multi-process locks, 10-clinic load or staging-phone acceptance. Current SQL behavior is verified in PGlite.
- The gateway/contact lock model is now locally implemented. Real multi-process shared-contact contention and provider in-flight races still require verification and provider reconciliation; a message already accepted cannot be unsent.
- Appointment changes, course end/Stop/Later semantics, doctor recipients and flag UI must be supplied by their domain modules before enabling those purposes live.
- Uncertain outcomes require a reviewed reconciliation/resolution workflow. Never manually reset uncertain rows merely to make a queue look empty.

Technical maintenance now expires eligible queue/mock payloads while retaining message history, late receipt events and active/uncertain evidence. See `SCHEDULER-RETENTION.md`; production policy review remains pending. Next increment: staff alert resolution/reconciliation, then full replies and OTP/dashboard migration. Owner account setup remains a separate pending gate.
