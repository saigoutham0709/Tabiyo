# Pilot verification

Date: 20 October 2026 (India).

- 22 domain tests: booking, conflict, patient overlap, valid dates, atomic reschedule, queue transitions, check-in date, terminal visit states, opt-out, caregiver approval, review gates, domain permissions, course expiry, dose idempotency, record protection, uncertain intent, emergency handoff heuristic, cancellation, WhatsApp send policy, HMAC, patient reschedule and cancellation.
- 10 API/SQLite integration tests: anonymous rejection, account isolation, same-origin writes, replay behavior, stale client conflict, concurrent database compare-and-swap, validation, content-type/body size, cache headers and persisted rate limiting.
- TypeScript no-emit check passed.
- Sites/Vinext production build passed.
- Build warning: current framework deprecates `middleware.ts` in favor of `proxy.ts`; current build includes middleware. This is not a failed check.
- Browser control unavailable; no browser screenshot, viewport interaction, end-to-end browser, screen-reader or keyboard audit was completed.
- No live Meta/SMS/voice/OCR, real-provider failover, provider-specific D1 integration or independent penetration test completed.

## Manual pilot walkthrough

1. Open the private app and sign in. All patients must be labeled synthetic.
2. New appointment → tomorrow → choose a doctor/slot → save. Verify in Appointments.
3. Patient experience → choose a patient → Book appointment → doctor/date/slot → Confirm booking. Verify one appointment in staff view.
4. Patient experience → Reschedule → new date/slot → confirm. Verify original changed only on final confirmation.
5. Appointments → today → check in. Live queue → selected doctor → call next. Verify current and previous statuses.
6. Medicine plans → add draft → review exact instructions → patient experience → Medicines → Confirm medicines → Taken. Verify summary count.
7. Patient record → request caregiver → patient experience → Approve caregiver → Revoke caregiver. Verify each status.
8. Patient experience → Reports. Verify staff task and no document release.
9. Patient experience → STOP. Verify paused consent, caregiver revoked and plans stopped. START must not silently restart stopped courses.
10. Try on mobile; verify readable typography, menus, dialog focus, keyboard action, error placement and horizontal table scrolling. This step is still pending.
