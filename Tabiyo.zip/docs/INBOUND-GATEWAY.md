# Signed inbound gateway — local Phase 1B

The Fastify gateway now has signed durable intake, a bounded processing worker, tenant routing, message deduplication, shared-contact consent commands and seven-day raw cleanup. It is **local-test wiring only**. The server entry point does not configure it, so normal startup returns 503 at `/webhooks/whatsapp`. The older synthetic pilot webhook remains disabled. No Meta account, tunnel, real recipient or credentials were connected.

All future resources must be controlled by `admin@catalystintelligence.in`. Cloud setup remains pending at the user's request.

## Reproduce

```sh
npm test
npm run demo:gateway
```

The demo signs a synthetic STOP payload, injects it into Fastify, checks that it was durably queued, runs one worker and verifies contact suppression. It uses an isolated in-memory PostgreSQL engine and fixed synthetic credentials. It prints aggregates only and sends zero physical messages. It starts no server or background monitor.

## HTTP boundary

- `GET /webhooks/whatsapp` answers the exact `hub.challenge` only for subscribe mode and a timing-safe matching verify token. Failure returns a generic 403; no token is echoed in errors.
- `POST /webhooks/whatsapp` retains bytes in an encapsulated Fastify content parser, with a 256 KiB limit. It checks `X-Hub-Signature-256` HMAC before UTF-8/JSON parsing. Changed bytes, malformed/missing signatures and invalid input fail without exposing submitted content.
- Invalid signatures return 401. A service-only hourly counter records no request body and marks an incident after more than ten failures in its bucket. This is durable monitoring metadata, not an external alert/page. If monitoring storage fails, ingress still rejects the request and emits only a static operational error code.
- A valid envelope is split by change/phone ID. The complete batch is saved in one database transaction. The route returns 200 only after durable storage; storage failure returns 503 and rolls back the batch. No conversation processing, patient mutation, provider call or LLM call occurs before acknowledgment.
- Recognized phone IDs route through the clinic table, never a caller-provided clinic ID. SQL checks the supplied group phone against its payload metadata. Missing/unknown phone metadata remains private quarantine. No quarantine row is assigned to a clinic merely because that phone becomes configured later.

Raw storage contains each change's original parsed value, including contacts/media fields, rather than copying other clinics' changes into every row. This is a tenant-scoped replay fragment, not the complete signed HTTP envelope. No signature/app secret/verify token is stored. Payload contents stay in private raw storage for the retention period; inbox text history beyond this raw window is a separate protected-record requirement.

## Durable processing and replay

`GatewayWorker.runOnce()` claims one queued or expired raw row with a five-minute lease and fresh fencing token. It processes the complete fragment transactionally. An expired worker cannot mutate a reclaimed job. Invalid/conflicting events fail with a durable clinic alert. Transient failures roll back message/consent effects, retry after one minute and stop with an alert after three attempts. The raw evidence remains available during retention.

Messages are logged once by provider message ID. Same-ID retries with identical content are harmless even when surrounding contact metadata changes or the raw payload is replayed. A changed message/clinic under the same provider ID is a visible conflict. `source_hash`, conversation and raw UUID linkages support review without storing a permanent plaintext body preview. Incoming logs use direction `in`, status `received`, and `inbound_unpriced`; no inbound cost estimate is invented.

Conversation `last_inbound_at` never moves backwards on delayed traffic. Multiple patients on a number remain unselected (`choose_patient`). Unknown senders start `new` onboarding without a fabricated name, patient record or consent grant. Unsupported media creates a handoff alert without downloading the media. Full menus, booking, identity challenges, unsupported-type replies, emergency replies and multilingual copy remain conversation-engine work.

Status-only fragments go through the existing immutable receipt path. Read/delivered/sent/failed progress is scoped by clinic, deduplicated and safe to receive before outbound completion. Processing an inbound status does not fabricate a patient message.

Explicit replay is service-only, audited and permitted only within retention for an already mapped, non-processing row whose phone still belongs to that clinic. Replay does not create a second message/consent transition. Unknown quarantine cannot be blindly replayed into a newly assigned tenant.

## Shared-phone STOP and START

Global phone suppression is now an explicit `conversations.channel_stopped` control. Patient-specific withdrawal remains patient-specific. The earlier mock-only inference that any family's patient flag implied a global phone STOP is replaced by this contact control.

STOP, Hindi/Telugu STOP variants, and matching interactive payload IDs:

1. Acquire the clinic/contact lock and append one source-linked revocation per current family member.
2. Set patient opt-outs and the contact stop flag, reset sensitive patient selection and remember only previously eligible consent for possible restoration.
3. Skip queued and prepared-but-unaccepted mock work and fence old workers. Already accepted evidence is retained and can still be completed: it cannot be unsent.
4. Preserve suppression for an unknown sender, so a patient created later on that phone cannot bypass the stop through a consent request.

START is not a blanket consent grant. It must be newer than STOP and the command watermark; tied/stale/replayed START cannot resume sends. Automatic restoration additionally requires configured `consent_notice_approved:true` and an unchanged matching `consent_version`. Only eligible consent captured before STOP can be restored. Other family members receive no new grant. A later individual staff revocation removes that patient from the restore list. A changed/unapproved notice requires the explicit consent flow instead.

START never revives skipped outbox rows or medication courses. A phone-wide START does not bypass each patient's latest consent check. Family selection is required again before a patient action. Unknown senders still need real registration, notice presentation and consent capture.

Gateway commands, staff patient mutations and mock dispatch boundaries use the same contact-before-patient advisory lock order. Multi-contact fragments acquire contact locks in deterministic order. These local transactions are tested; real multi-process PostgreSQL contention/load and real provider in-flight race handling remain acceptance gates. The live sender is still absent.

No STOP confirmation, consent notice or bot reply is sent by this increment. The approved response-copy/exception policies and conversation flow must exist before enabling real patient ingress. Clinical/emergency detection is not supplied by this protocol collector.

## Cleanup and operations

`store.cleanup()` deletes up to 500 raw rows older than seven days, skips active leases, and keeps message-ID/consent proof so later transport replay cannot repeat a mutation. Expired pending work raises a durable alert before deletion. Clinic deletions are audited; a global maintenance record stores only counts. Unknown quarantine is deleted without exposing its payload to a clinic. Signature-counter buckets older than seven days are removed.

Local pg-boss composition now schedules this cleanup and technical maintenance; see `SCHEDULER-RETENTION.md`. No persistent daemon is running. Security cleanup is bounded to 500 buckets per call. Production wiring/policy review, staff resolution UI and external notifications remain pending. `gateway_security`/`gateway_maintenance` are two service-only support tables; current total is 12 handbook domain tables plus six support tables, all with RLS.

New stable error codes include `WEBHOOK_DISABLED`, `WA_VERIFY_FAILED`, `WA_BAD_SIGNATURE`, `WEBHOOK_INVALID`, `WEBHOOK_UNAVAILABLE`, `WEBHOOK_EVENT_INVALID`, `WEBHOOK_MESSAGE_CONFLICT`, `WEBHOOK_PROCESS_FAILED`, `WEBHOOK_RETENTION_EXPIRED`, `REPLAY_FORBIDDEN` and `LEASE_LOST`. None includes a name, phone, body, secret or raw database error.

## Remaining release gates

- No deployed ingress, Meta verification round trip, live signature/callback sample or approved production number/template.
- No complete local Supabase container/advisors run, real multi-connection concurrency, measured webhook p95/acknowledgment target or ten-clinic load run. Current verification uses actual migrated PostgreSQL in PGlite plus Fastify injection.
- pg-boss recurring schedules pass local tests; no deployed cleanup daemon or monitored alert delivery.
- No complete language/consent onboarding, appointment state machine, emergency response, document identity flow, medication course handling or migrated staff inbox.
- Before a real connection, recheck official Meta payload/verification requirements and validate with test-number traffic under the verified owner account. The official Meta page was rate-limited during this increment; no live-provider conformance is claimed from local fixtures.

References: [Fastify parser encapsulation](https://fastify.dev/docs/latest/Reference/ContentTypeParser/), [Meta webhook setup](https://developers.facebook.com/docs/graph-api/webhooks/getting-started/). Implementation tests use the handbook's signed webhook and callback contract.
