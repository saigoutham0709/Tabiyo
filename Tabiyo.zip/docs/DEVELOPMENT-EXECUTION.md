# Tabiyo development execution

Owner requirement, recorded 2 November 2026: **admin@catalystintelligence.in**. User confirmed that Supabase and Meta Business are not set up and requested that cloud setup remain pending. Local coding and synthetic verification continue. This document governs execution alongside `HANDBOOK-COMPLETION-PLAN.md`; the handbook remains the feature authority.

## Account and resource rules

- Use this email as the controlling development account, business contact and recovery address wherever the provider supports it. Supabase organizations/projects, hosting, monitoring, vault and FAQ-provider resources must be controlled by this account. No personal or unrelated organization resources may be substituted.
- Keep the requested GitHub repository `Ritish017/Tabiyo`. Its existing ownership is not proof of the email on its controlling GitHub account. Verify that account email/access before remote development changes; do not transfer or delete the repository as an assumed fix.
- Meta business assets must be under the authorized Catalyst Intelligence business setup, with this business contact email. Use provider-required genuine administrators and business-owned system users. An email alone cannot replace Meta's required administrator identity, phone ownership or business verification.
- Record nonsecret organization/project/business/app IDs, region and ownership evidence in `config/development-resources.json` when verified. A configuration label is not provider verification.
- Do not share a common password with developers. Use named, least-privilege invitations, MFA and a business-controlled vault. Service tokens must belong to the verified project/business; never put credentials in this registry or source control.
- This email requirement applies to development-resource ownership. Clinic staff still sign in through phone OTP; patients do not need this email.
- No cloud resource has been created, no existing cloud project has been modified and no billable service has been enabled. Cloud setup remains pending at the user's request.

## Sequential phases

Advance after a phase's local gate passes. Track cloud and staging gates separately: code may continue locally, but a phase is not fully accepted until its integration evidence exists. Fix failing checks before expanding the same feature.

| Phase | Work | Completion gate | Current state |
| --- | --- | --- | --- |
| 0: Scope and ownership | Handbook audit, owner registry, architecture decisions, baseline checks and ticket ledger | Decisions/constraints recorded; baseline reproduced; cloud ownership explicitly pending | Plan/owner policy recorded; product ambiguities remain for their affected gates |
| 1A: Local platform | Fastify API, shared contracts, initial clinic/staff/doctor/patient/consent schema, RLS, seed, CI | Two synthetic clinics isolated; shared mobile accepted; inactive/missing membership denied; checks pass | Local increment verified; cloud/provider gates pending |
| 1B: Complete foundation | Remaining schema, OTP dashboard, clinical permissions, flags/events/audits, outbox, verified webhook, sender/receipts, pg-boss | Mock integration passes; then real test-number round trip and staging CI under verified owner | Active: staff operations and separate dashboard session/patient/alert/review code now locally verified; full onboarding/replies/permissions and provider gates remain |
| 2: Appointments | Availability/breaks/leaves, interval exclusion, transactional booking, Today/booking UI, WhatsApp state machine and family selector, walk-in queue | Concurrent booking has one winner; no past/out-of-hours booking; phone and WhatsApp UAT | Active: admin availability controls, affected-booking review and feature-gated walk-in queue now implemented locally; approved notices, patient chat, multi-process and full acceptance remain |
| 3: Reminders and records | Appointment jobs, caps/quiet hours, visits/slips, private storage, DOB lockout, signed links, inbox assignment/window, CSV/merge | Restart/duplicate/expiry tests, secure document and import tests; test-phone journeys | Reminder creation/invalidation implemented locally; records/storage/inbox/import/merge and full acceptance remain |
| 4: Adherence and FAQ | Doctor-only structured prescriptions, grouped dose jobs, Taken/Later/Stop, course completion/adherence, FAQ editor/LLM/guardrails | Three medicines produce one reminder; single snooze; flag/STOP works; safe FAQ and emergency UAT | Not started |
| 5: Clinic operations | Event-based reports/baseline/costs, onboarding/QR/staff/super-admin, full languages, monitoring, summaries, export/delete/retention/backups | Native-language review, audited onboarding/report correctness, alert and restore evidence | Not started |
| 6: Release acceptance | 20 UAT scripts, 26 error cases, 10-clinic mock load, performance/security/accessibility/poor-network checks, staff walkthrough, RC | All required evidence accepted; production number/templates/config ready; reviewed release and rollback | Not started |

The full ticket detail and acceptance criteria remain in `HANDBOOK-REQUIREMENTS.csv`. Phase 1A is a foundation increment, not completion of Sprint 1 or a new live application. The existing synthetic pilot stays available while the new backend is built. No new unrelated functionality is added to it.

## First local increment

1. Create workspace packages without moving or deleting the pilot.
2. Add Fastify `/health` and authenticated `/api/v1/me`. Validate the Supabase user remotely, then resolve active staff membership server-side. Ignore caller-supplied clinic/role/identity headers.
3. Add the first migration, tenant-safe foreign keys, append-only consent records and default-deny RLS. No user may grant their own staff membership or role.
4. Seed a fake clinic, two doctors and ten fake patients, including a shared-phone family. Use isolated second-clinic fixtures in tests.
5. Test migrations with actual PostgreSQL execution locally. Embedded PostgreSQL results are not Supabase Auth/Storage/provider acceptance.
6. Add CI for tests, type checks and lint. Resolve baseline lint errors rather than disabling project-wide checks.

## Cloud setup checklist — pending

When cloud setup resumes, use the owner email above and perform these steps in order:

1. Verify GitHub's controlling account email; Supabase login/organization ownership; MFA/recovery and vault access.
2. Create `tabiyo-dev`, `tabiyo-staging`, `tabiyo-prod` in Mumbai after reviewing provider plan/quoted cost. Do not silently substitute another region/project. Free-tier project limits may require a later plan decision; this plan does not assume three free hosted projects are available.
3. Apply reviewed migrations first to development. Run the full Supabase CLI/provider RLS and advisors checks, including Auth/session and private Storage behavior. Then promote the same migration set to staging with fake data.
4. Create the authorized Meta business/app/test number, register developer phones and configure the secured public webhook. Store tokens privately and verify asset ownership. No personal WhatsApp automation.
5. Create hosting, Sentry/uptime and FAQ provider resources under the same controlling email. Configure API/dashboard/worker environments and regional data boundaries.
6. Record actual resource IDs/ownership evidence, run test-phone/staging acceptance and only then mark the relevant cloud gates accepted.

No credentials are needed to run local tests. Use `.env.local` only for an intentionally connected development environment; it is git-ignored. No empty config enables a fake signed-in user in the new API.

## Scheduling and continuation

The handbook's 55 estimates total 109.5 developer-days. Its six two-week sprints are an initial envelope, not a validated promise for two part-time developers. Complete 1A, compare actual throughput, then set dates for 1B–6. Do not treat an agent turn as a two-week sprint.

For each increment record changed files, checks, remaining tickets and first incomplete gate in `DEVELOPMENT-STATUS.md`. Continue that gate before starting later features. Account-dependent work remains pending; useful local work can continue without claiming integration is complete. Deployment and external messaging require their concrete configuration and verified owner account.

Current technical references: [Supabase RLS](https://supabase.com/docs/guides/database/postgres/row-level-security), [trusted getUser validation](https://supabase.com/docs/reference/javascript/auth-getuser), [API keys](https://supabase.com/docs/guides/getting-started/api-keys), [Fastify testing](https://fastify.dev/docs/latest/Guides/Testing/). Provider settings and API changes must be rechecked when setup resumes.
