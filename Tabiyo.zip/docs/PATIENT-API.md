# Patient services: Phase 1B local contract

These routes belong to the new Fastify API. The root synthetic pilot UI is not migrated yet. Supabase and Meta cloud setup remain pending under `admin@catalystintelligence.in`.

## Routes

Every route requires `Authorization: Bearer <staff access token>`. Writes also require a UUID `Idempotency-Key` header. Caller-supplied clinic, actor, role, `opted_out`, or consent fields are rejected. Identity is verified by Supabase Auth; the database independently resolves the active staff membership for every operation.

| Method/path | Body/query | Result |
| --- | --- | --- |
| `GET /api/v1/patients?mobile=%2B919000000001` | E.164 mobile; no extra query fields | `{patients:[...]}` including every unmerged family member on that number in the caller's clinic. Each returned record is audited. |
| `POST /api/v1/patients` | Required `name`, `mobile_e164`; optional `date_of_birth`, `gender`, `language` | 201 `{patient,replayed:false}`; queues one consent-request record atomically. Same successful request replay returns 200 with the same patient and `replayed:true`. |
| `PATCH /api/v1/patients/:id` | One or more editable fields | `{patient,replayed}`. Mobile changes are blocked until a verified contact-change workflow exists. |
| `POST /api/v1/patients/:id/consents` | `version`, `status` (`granted`/`revoked`), `channel` (`phone`/`paper`/`dashboard`) | `{patient,consent,replayed}` with authenticated actor and tenant assigned by the server. |

Create example using synthetic data:

```json
{
  "name": "Synthetic Family Member",
  "mobile_e164": "+919000000001",
  "date_of_birth": "1991-02-03",
  "language": "te"
}
```

`language` supports `en`, `te`, `hi`. `gender` supports `female`, `male`, `other`, `undisclosed`, or null. DOB must be a valid calendar date no later than the clinic's current IST date. Names are trimmed. Mobile numbers are strict Indian E.164; bulk normalization belongs to the later CSV feature.

Do not interpret `opted_out:false` as evidence of granted consent. A newly created patient has no consent grant. The future sender must validate the consent history and all send policies independently.

## Atomicity and access boundaries

Patient creation commits five related writes together: patient, consent-request outbox row, event, audit and replay ledger. Any failure rolls back the whole transaction. No module sends to Meta directly. The queued payload contains a template name/language contract, not approved copy or a delivery receipt.

Consent revocation appends a new proof row, sets `opted_out`, and skips queued outbox rows for that patient in the same transaction. A new grant does not revive skipped sends. Medication schedule cancellation and in-flight sender races require the forthcoming worker/course services; they are not claimed here. Staff cannot label manual consent as an inbound WhatsApp event.

Replay keys are tenant-scoped and actor-bound. Reusing a successful key with a different operation/body/actor returns 409. Cached successful responses are immutable snapshots, not a live refresh of the patient's current consent status. Read the latest record before making a later care decision. Replay accesses are audited.

`api_requests` is a support table beyond the handbook's 21 domain tables. Its cached responses contain patient data. It requires explicit expiry and patient-deletion handling before production, alongside outbox/raw/audit retention. No indefinite retention claim is made.

Authenticated clients no longer have direct patient/consent table grants. Reads and mutations go through audited operations. To write mandatory audit/outbox records without letting clients forge them, implementations use narrowly scoped `SECURITY DEFINER` functions in the unexposed `private` schema. Every such operation checks `auth.uid()`, active membership and explicit clinic predicates; `search_path` is empty, SQL is parameterized, and PUBLIC/anonymous execution is revoked. Only `SECURITY INVOKER` wrappers are in the exposed public schema. Never regrant broad table access to fix a client error.

RLS remains on every table as defense in depth. The RLS fixture role in tests receives additional grants only inside the isolated test engine to exercise policies independently of production ACLs. No such role is created by migrations.

## New records

The second migration adds `clinic_features`, `events`, `audit_log`, `outbox`, `webhook_raw`, `conversations` and `api_requests`. Later worker/gateway migrations add delivery and maintenance records: current total is 12 handbook domain tables plus six support tables, all with RLS enabled.

Raw webhook payloads have no staff access. Unmapped numbers are quarantined with a null clinic; mapped rows must match a clinic/phone-ID foreign key. The new local gateway splits multi-number envelopes and implements seven-day cleanup and replay. It is not configured by the server entry point or connected to Meta; see `INBOUND-GATEWAY.md`.

`events.appointment_id` is reserved for the later appointments migration; its foreign key must be added with that table. Feature flags are default-off and readable within the clinic. The new mock worker enforces send flags and processing leases; no staff toggle, feature UI or live sender process is enabled. See `DELIVERY-WORKER.md` for its completed local scope and limits.

## Verification and remaining gates

Local integration tests exercise the actual migrations through Fastify, the real Supabase JS adapter and a mocked provider transport backed by PGlite. They cover shared phones, both clinics, inactive identities, invalid input, consent, replay and rollback. They are not hosted Supabase/Meta acceptance or proof of cross-process concurrency. Advisory request locks and unique ledger keys must also be tested on the complete PostgreSQL/Supabase stack when Docker/provider setup is available.

Mock sender, durable claims/recovery, send policy, receipts and signed local inbound/dedup/cleanup are tested. Shared-contact controls are described in `INBOUND-GATEWAY.md`. Next: pg-boss and remaining retention, full replies, then OTP/dashboard and patient-picker migration. Live messages remain disabled.

Implementation references: [Supabase function security](https://supabase.com/docs/guides/database/functions), [Supabase RPC client](https://supabase.com/docs/reference/javascript/rpc). Provider configuration and external acceptance remain separate from these local results.
