# Admin availability and walk-in queue

Local continuation: 4 November 2026. Migrations `20261104153332_doctor_availability_management.sql` and `20261104154416_walk_in_queue_controls.sql` build on the existing caller-JWT API, audited operations ledger, dashboard session gateway and mock delivery pipeline. Cloud setup and live sending remain disabled. The user will supply approved patient-facing wording and notice versions; this increment does not draft or approve those messages.

## Admin availability

`GET/PATCH /api/v1/doctors/:id/availability` is clinic-admin only. The dashboard's Doctor availability screen loads weekly hours, breaks and current/upcoming leave, then supports weekday upsert/closure and reason-coded leave addition/removal. Each write requires a request key and the last loaded `expected_revision`. Changed revisions reject stale saves with `AVAILABILITY_CHANGED` rather than silently overwriting another administrator.

Schedule intervals and breaks are validated by the API and database constraints. Leave is bounded, reason-coded and cannot start in the past. Duplicate leave periods are rejected. An idempotent replay returns the original outcome without repeating revisions/events. Clinic identity and actor come from active membership; body scope injection and non-admin access are denied.

Existing appointment rows are preserved. Changes produce a count of future active appointments that no longer fit the doctor’s hours, break, leave, holiday or active state. Up to 100 affected appointments can be reviewed, with audited patient/appointment reads. A count-only `DOCTOR_AVAILABILITY_REVIEW` alert links to the doctor through an ID-only context. Staff cannot resolve that alert while conflicting future bookings remain. Reschedule patients or restore valid availability, then resolve it.

Dispatch checks current availability again before mock acceptance. Invalidated confirmations/reminders are skipped without fabricating delivery. Known acceptance proof remains historical truth. Automatic patient change notices still require approved wording and a valid replacement appointment; this code does not promise a new time when none was selected.

## Walk-in queue

`queue_tokens` adds the sixteenth handbook domain table. Total public schema: **16 domain tables plus seven support tables**, all with RLS, across nine migrations. The queue is default-off behind `walk_in_tokens`.

| Endpoint | Behavior |
| --- | --- |
| `GET /api/v1/queue/status` | Caller’s clinic feature status, no patient data |
| `GET /api/v1/doctors/:id/queue` | Audited current-day token list; optional history date within the previous 31 days |
| `POST /api/v1/doctors/:id/queue` | Add, call-next, skip or complete, with a UUID request key |

All active staff can operate the queue; doctors are restricted to their linked schedule. Tokens use patient UUIDs, so family members sharing a phone remain distinct. Numbering is monotonic per doctor/IST day, with a 1,000-token daily limit. Unique indexes protect numbering, one currently called token per doctor/day, and one active token per patient/clinic/day. Completed/skipped tokens cannot be revived. Direct staff/service table mutations are denied.

Call-next requires both the currently displayed called-token ID (or null) and expected next-token ID. A stale view returns `QUEUE_CHANGED`. The operation completes only the current token, then calls the first waiting token. Separate completion ends a called token without calling another. Leave, holidays, inactive doctors, closed hours and breaks block calling while preserving the waiting list. Queue tokens track physical order separately from appointment/visit status; calling a token does not silently alter unrelated appointment rows.

The dashboard hides queue navigation and patient add-token controls when the flag is off. The API independently blocks queue reads/writes; dispatch independently rechecks the flag. A safe status route supports feature visibility. No flag-management authority is granted to clinic staff by this increment.

## Next-patient notice contract

Calling a token can queue a notice for the first patient still waiting, using one logical notice per called/next pair. Adding or skipping a token also reassesses that pair without duplicating an existing notice. `notice_state=queued` means durable outbox intake, not provider delivery. An already recorded notice is not automatically revived after suppression.

The notice requires the clinic’s explicit approved text/version for the recipient’s enabled language, current patient consent/contact eligibility and a valid inbound 24-hour window. Version and text must be nonblank strings; malformed objects and disabled recipient languages become review tasks instead of messages. Missing copy or eligibility creates a deduplicated `QUEUE_NOTICE_REVIEW` staff task. No generic template or translation is invented. Supplied text supports the controlled `{token_number}` placeholder. Approval is configured through `settings.approved_queue_notice[language]` with `approved`, `version`, and `text`; no production value is seeded.

At dispatch, the worker checks that the recipient is still first waiting behind the same called token on the same IST day. It also checks current wording approval/version/text, preferred language, doctor availability, flags, consent, STOP, window, cap and quiet/stale policies. Queue changes return `QUEUE_CHANGED`; withdrawn or changed copy returns `QUEUE_NOTICE_UNAPPROVED`. Accepted proof is never reset to retry merely because the queue moved.

## Locking and evidence limits

Queue changes serialize on a clinic/doctor/IST-day advisory lock. Admin availability changes use that lock before locking the doctor row. Queue notices acquire it before the delivery contact/patient/outbox boundary on prepare and mock acceptance. Known-acceptance completion/reconciliation does not require a queue lock. This avoids reversing the existing contact/patient lock order during historical reconciliation. No queue operation rewrites old outbox rows while acquiring patient foreign-key locks; stale notices are invalidated at dispatch.

Operations recheck the IST date after waiting for the lock, preventing a stale-day write after midnight. Request-key replay, doctor revision checks and call-next expectations provide separate duplicate/stale-write protection. Real multi-connection PostgreSQL contention and midnight-wait/load scenarios remain release acceptance gates; single-connection PGlite tests do not establish them.

Verification covers scoped admin controls, revision conflicts, affected-booking preservation and alert resolution guards; queue default-off behavior, shared-family identity, numbering/terminal states, stale call-next, doctor/clinic isolation, missing-copy handoff, notice dedup and queue/copy changes between preparation and mock acceptance. API integration uses the real Supabase JS adapter against the migrated local engine through a synthetic HTTP transport. Dashboard builds and HTTP smoke checks do not replace real OTP/browser/UAT.

Remaining: approved wording/versions, actual notification delivery, full Supabase/advisors/multi-process validation, patient conversation onboarding/booking, browser walkthrough and the later handbook phases. This increment does not complete the full application or the staging definition of done.
