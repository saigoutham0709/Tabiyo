# Tabiyo — product decisions and production launch plan

Research checked 20 October 2026 (India). Source of product scope and brand: Tabiyo_Pitch_Deck.pdf, 20 pages, supplied by the user. The deck explicitly stages rollout from front desk to adherence to intelligence. This implementation begins that rollout with a synthetic, connected pilot.

## 1. Product model

**Staff website:** clinic/hospital owner and admin manage branches, verified staff membership, schedules, access, integrations, consent and operations. Reception handles bookings, queue and handoffs. Doctors see assigned patients, review prescription instructions and read factual follow-up summaries. Diagnostic staff manage verified report ingestion and release.

**Patient channel:** the clinic's official WhatsApp number provides consent-based FAQs, appointments, queue updates, verified record access and care follow-up. The production patient journey must not require a new patient app. The phone-shaped conversation in this release is an authenticated staff test simulator, not a substitute for live WhatsApp.

One care workflow connects both sides. A booking or cancellation updates the same inventory. A message is never labeled delivered just because it was saved locally. A caregiver can never access a patient's information solely because someone entered a name at reception.

## 2. Alternatives in the market

Capabilities below are supported by public first-party documentation, not a paid hands-on evaluation. Lack of a cited feature is not proof a product lacks it. No vendor performance statistic is treated as an independently verified result.

| Alternative | Verified overlap | Tabiyo decision |
| --- | --- | --- |
| Practo Ray | Appointments, queue manager, patient records, billing and reminder communications; current product also describes post-consultation communication and rescheduling | Treat staff booking and records as baseline. Make post-visit continuity central and keep the clinic's existing relationships. |
| Eka Care / Eka EMR | EMR and WhatsApp prescriptions; interactive follow-up confirmations, cancellations and rescheduling visible in the doctor queue | Strong direct overlap. Differentiate with tested, low-friction care operations, consent and meaningful staff intervention. |
| WATI healthcare | WhatsApp team operations, automation, routing, history and CRM integration in its Rockethealth case study | Learn from shared history and handover. Avoid making patient-support operations dependent on an opaque bot. |
| Gallabox healthcare | Appointment confirmation/reminders, rescheduling/cancellation, shared inbox, aftercare and multilingual interaction | These are not novel by themselves. Use a coherent clinical approval chain and operational reliability rather than a feature-count pitch. |

Sources:

1. Practo Ray current overview: https://www.practo.com/providers/clinics/ray
2. Practo's navigation and queue documentation: https://help.practo.com/practo-ray/navigation/
3. Eka Care: https://www.eka.care/
4. Eka interactive follow-up documentation: https://info.eka.care/services/follow-ups-are-smarter-with-eka-care
5. WATI / Rockethealth case study: https://www.wati.io/page/case-studies/rockethealth/
6. Gallabox healthcare: https://gallabox.com/industry/healthcare/whatsapp

## 3. Reported friction → product response

Evidence is directional. Vendor case studies describe selected customers; public reviews are anecdotal, selection-biased and unverified by this project. They do not establish market-wide frequency or prove a product is unsafe.

| Observed issue | Evidence | Response in this pilot | Production work still required |
| --- | --- | --- | --- |
| Manual appointment reminders and context lost between staff | Rockethealth's WATI case study describes these prior operating problems | Persistent conversation history and staff care inbox | Named assignment, shift handoff, escalation SLA and reminder workers |
| Difficult human support and downtime complaints | Recent WATI Trustpilot reviewers report these problems | Explicit Talk to staff route, unresolved request list, no fake delivery labels | Provider health dashboard, alerting, retry/backoff, escalation paging and incident process |
| Cancellation, billing and pricing dissatisfaction | Some WATI Trustpilot reviewers report these issues | Self-service booking cancellation/reschedule, consent stop and immediate data export | Transparent subscription cancellation and Meta/SMS usage ledger; no platform billing built yet |
| Follow-ups missed and rescheduling requires effort | Eka's first-party follow-up explanation | Patient confirmation, self-service booking changes, review task journeys | Approved outbound templates and durable scheduling |
| Privacy confusion on family devices | Design risk inferred from the requested patient and caregiver model | Record requests fail closed; caregiver approval and revocation | Verified identities, delegated scopes, minors/guardian rules, number-change recovery |
| Prescription recognition can be wrong | Safety risk inferred from handwritten input in the deck | Manual entry and two-step clinician/patient gate | Secure OCR ingestion, confidence/provenance, medication reconciliation and clinician QA |
| Poor connectivity and tool switching | Practo documents offline access; the need is broader than a new product feature | A simple connected workspace and explicit error/retry behavior | Read-only/offline queue fallback and supervised reconciliation; never promise a slot while offline |

Public reviews: https://www.trustpilot.com/review/wati.io
Offline reference: https://help.practo.com/practo-ray/app/how-to-access-ray-offline/

## 4. Feature status against the pitch deck

“Working pilot” means actual mutations persisted server-side in the account's synthetic workspace, not external service delivery.

| Deck feature | Implemented now | Remaining live product work |
| --- | --- | --- |
| QR and 24/7 approved answers | Clinic FAQs and deterministic conversation menu | Onboard number; generate per-clinic click-to-chat QR after number verification; approved multilingual FAQ repository |
| Appointments | Staff and patient booking, conflict checks, self-service change/cancel | Doctor availability/leave/holidays, visit duration, calendar/EMR sync, reminder scheduler, deposits/refunds where required |
| Phone bookings | Reception booking channel, patient directory and consent fields | Versioned consent proof with staff/source/notice; actual confirmation delivery |
| Live queue | Check-in, per-doctor queue, current consultation, delay and estimates | Push updates, measured durations, emergency/priority overrides, audited reordering and reliable travel guidance |
| Previous records | Request and staff identity-verification task; no protected record release | OTP or stronger step-up, short-lived single-use links, private documents and scan pipeline |
| Prescription to reminders | Typed draft, review, patient confirmation and course gates | Secure files, OCR, reminders/outbox, prescription corrections and versioned approvals |
| Low-literacy reminders | Taken/snoozed records in simulator | Patient medicine-strip photos, grouped dose messages, actual snooze scheduling, accessibility field testing |
| Local language voice | Four sample language greetings and language preferences | ASR/TTS, language validation and clinician-reviewed translations; code-switching; actual voice ingestion |
| Family/caregiver | Pending request, explicit simulated patient approval, revocation | Verified caregiver identity/number, granular scopes, timezone, expiry, cross-account authorization |
| Care journeys | Follow-up task templates and completion tracking | Clinician-controlled eligibility, individualized schedules, reminder workers and escalations |
| Pre-visit summary | Factual counts, patient messages, plans/results per patient | Reporting interval, complete dose denominator, source-linked notes and clinician validation |
| Labs/trends | Structured numeric entries; chart groups same test and unit | Lab integrations, source documents, unit normalization and verified release workflow |
| Clinic dashboard | Counts from saved activity, channels, export | Delivery/latency metrics, follow-up cohorts, billing costs, doctor/branch access and validated outcome evaluation |

This is not an inpatient hospital information system. Admissions, beds, insurance/claims, pharmacy stock, full EMR, e-prescribing, emergency triage and telemedicine are outside this release. Integrate with existing systems through agreed contracts rather than silently expanding Tabiyo into every hospital function.

## 5. Security controls and honest limits

No application can be promised to be the “most secure.” Production needs a defined threat model, implementation evidence and independent verification. Use OWASP ASVS as an acceptance framework: https://owasp.org/projects/asvs

Implemented and tested:

- Hosted private access plus API sign-in checks.
- The server derives ownership from platform identity, never from a client-supplied tenant ID. Account A cannot read/write account B's pilot aggregate.
- Parameterized SQLite/D1 queries; Zod command validation; bounded commands and input payloads.
- Exact same-origin JSON writes, no sensitive API caching, baseline security headers and browser API restrictions.
- Atomic compare-and-swap prevents stale clients from overwriting state. Conflict retries require the user to refresh/reassess.
- Replay keys suppress duplicate mutations within a retained window; 120 requests/minute/account quota is persisted in the database.
- No secrets or access tokens in the browser. Disabled live webhook fails closed.
- Consent gates, caregiver revocation and review-before-activation. Expired/unconfirmed doses cannot be acknowledged as active.

Explicit limitations:

- Identity currently establishes a personal synthetic workspace owner. There is no live multi-staff clinic membership or doctor-assignment enforcement. Domain role permissions have tests but do not constitute completed production RBAC.
- API tests mock trusted platform identity. They do not test header spoofing defenses at the hosting edge. Edge trust boundaries must be reviewed before public deployment elsewhere.
- Aggregate JSON is not a production health-record store. No verified India residency or application-level envelope encryption; do not insert real patient data.
- Pilot audit history is mutable as part of state and capped at 1,000 entries; it is not an immutable compliance audit trail. Reads and exports are not independently audited.
- Baseline CSP permits inline scripts/styles for framework hydration; replace with tested nonce/hash policies where supported. No independent penetration test or full accessibility audit has been performed.
- The English emergency keyword heuristic is a staff-warning aid, not clinical triage. It cannot recognize all emergencies, languages or misspellings and must never be marketed as emergency coverage.
- No background job, provider callback, delivery receipt, template approval, SMS fallback, hardware-backed key rotation, backup/restore drill, regional failover or SLO monitoring is enabled.

Production threat-model checklist:

1. Tenant and branch isolation on every resource; server-enforced active memberships, assigned-patient restrictions, expiring invites, MFA/passkeys and audited break-glass access.
2. Workload identity and secret-manager access; KMS envelope encryption; TLS; encrypted backups with region and key controls; documented retention and key rotation.
3. Restricted document ingestion: MIME sniffing, size/type allowlist, malware scanning, quarantine, private buckets, expiring links, OTP attempt limits and no public object URLs.
4. Signed webhook validation against the raw body, phone-number-to-tenant mapping, deduplication by provider message ID, timestamp/replay policy, restricted provider egress and atomic outbox/inbox.
5. Log minimization and redaction; no prescriptions/phone numbers in analytics; immutable access/mutation/consent audit exported to separate controlled storage.
6. Staff offboarding, session revocation, data export, correction/erasure requests with lawful clinical retention and withdrawal semantics.
7. Secure SDLC: dependency/secret scans, SAST/DAST, negative authorization tests, WAF/rate limits, backup recovery, load/chaos tests, incident playbooks and independent penetration test before live PHI.

## 6. WhatsApp policy and privacy requirements

Official policy checked: https://business.whatsapp.com/policy (current page dated 23 September 2026).

The platform requires opt-in, respect for opt-outs, approved templates for business-initiated conversations and messages outside the 24-hour customer-service window, and a clear human escalation path. Its policy also places conditions on health-information/telemedicine usage where applicable regulations require stronger safeguards. These are reasons to provision the official service correctly, not to use personal-account automation.

The sender and HMAC helpers are isolated primitives, not an integrated working provider. Live ingress is deliberately disabled. Deploy a separately secured public production gateway; the owner-private pilot's authentication wall is incompatible with ordinary Meta inbound webhooks.

The deck explicitly asks for encrypted health data stored in India. That is a product requirement independent of broad assumptions about the DPDP Act. Choose production database, objects, logs, backups, OCR/voice inference and vendors accordingly; validate each data flow and contract. Do not infer data residency just from a region selector or an encryption claim.

Official legal source: MeitY's DPDP Rules 2025 page includes the notified rules, enforcement timeline and corrigendum:
https://www.meity.gov.in/documents/act-and-policies/digital-personal-data-protection-rules-2025-gDOxUjMtQWa?pageTitle=Digital-Personal-Data-Protection-Rules-2025

Check the actual phased enforcement timeline, data-fiduciary/processor responsibilities, notices and rights, children/guardian consent, retention and breach procedures for the clinic's situation with a qualified reviewer. This pilot is not a compliance certification. ABDM/FHIR/ABHA integration also requires its own implementation and approval path; none is claimed here.

## 7. Production architecture

Keep this presentation/UI layer reusable. Before live clinic use, migrate core records to a normalized India-region transactional service (for example PostgreSQL with enforced tenant access and database constraints), an India-region private object store, durable queue and scheduler, managed secrets/KMS, and separately restricted audit and telemetry systems. The exact vendor needs the user's hosting account and budget.

Suggested modules and resources:

- Clinic → branch → membership → role → doctor assignment.
- Patient → verified contact → identity challenges → versioned consent → caregiver grants.
- Doctor → availability → exception → slot inventory → appointment → check-in → queue event.
- Prescription → source document → reviewed line → patient approval → medicine schedule → dose occurrence → acknowledgment.
- Journey template version → clinician enrollment → scheduled task → completion/escalation.
- Report → source document → structured observation → unit → verification/release.
- Conversation → assigned staff → incoming event → outgoing event/outbox → provider status receipt.
- Immutable audit event, retention request, export request, incident and provider health.

Required concurrency constraints: unique active doctor/slot inventory; overlap exclusion for variable-duration visits; atomic rescheduling; unique dose occurrence; unique provider message ID; unique durable delivery key; explicit state-machine transition guards.

Durable delivery: transactionally write the business change and outbox event, then a worker claims the event with a lease. Recheck opt-in and caregiver scope at send time; select an approved template outside the allowed window. Track queued/attempted/accepted/delivered/read/failed separately. Bound retries with jitter and dead-letter queues. On timeout with ambiguous provider acceptance, reconcile before resending. Patient opt-out invalidates pending jobs. SMS fallback must have separate consent and operational ownership.

The server remains the authority. A language model can classify intent, translate approved text or draft a staff summary, but cannot grant access, invent availability, change a prescription or bypass consent. Use tool schemas, source provenance and explicit uncertainty/handoff thresholds. Evaluate on representative Telugu/Hindi/Urdu/English and mixed-language cases before enabling them.

## 8. Ordered path to a real clinic pilot

1. **Review this working sample:** complete staff and patient test scenarios; conduct browser/mobile/accessibility QA; validate workflows with a receptionist and doctor. Resolve observed issues.
2. **Provision the real environment:** clinic identity, branch and clinician schedules; confirmed India-hosting accounts, security settings, data-processing contracts, retention and operational contacts. Keep synthetic and live environments separate.
3. **Implement staff identity and production storage:** invitations, role/assignment authorization, MFA, normalized database and document security. Migrate the UI's API boundary; prove tenant and branch isolation with tests.
4. **Connect the clinic's official WhatsApp number:** WABA ownership, credentials via secret management, verified webhook, utility templates, opt-in/opt-out, receipts and small-number tests. Never paste credentials into chat or client configuration.
5. **Enable front desk only:** verified FAQs, staff/WhatsApp booking, reschedule/cancel, reminder job, queue updates, monitoring and staff handoffs. Run a real clinic acceptance test.
6. **Enable adherence:** typed prescriptions, reviewer permissions and patient confirmation, individual dose occurrences and grouped delivery. Add caregiver access only after identity and scope tests.
7. **Enable document/voice intelligence selectively:** OCR/ASR/TTS/lab integrations, human review and protected retrieval after security and clinical evaluation. Avoid automatic diagnosis.
8. **Release gate:** backup restore and outage drills, signed security review, measured pilot results, support roster and incident contacts. Document known limitations in staff training.

Inputs needed to complete live launch: clinic/legal owner and authorized staff; actual doctor schedules; India-hosting provider account and budget; clinic-controlled Meta Business/WABA number and approved templates; SMS and identity-verification provider choice; clinical reviewers and applicable privacy/retention policy. These cannot be fabricated by an agent.

## 9. Acceptance scenarios

- Patient books in WhatsApp; reception sees one confirmed slot; simultaneous booking gets an alternative rather than a duplicate.
- Patient changes a slot; original booking survives until the new slot commits. Cancellation requires confirmation.
- Reception checks in the patient; doctor calls next; token estimate updates without pretending to guarantee arrival time.
- Clinician enters and reviews a prescription; patient verifies instructions; reminders activate only after both gates and stop after course end or opt-out.
- A caregiver request grants nothing until separately verified patient approval, and queued caregiver updates cease on revocation.
- A record request from a shared or changed number cannot retrieve anything without secure step-up verification.
- A repeated webhook and retried delivery produce one domain mutation and one logical reminder.
- A provider outage is visible to staff and triggers a supported escalation path; saved != sent != delivered.
- Every real patient access/export has an independently retained audit record and the required region/retention controls.

## 10. Design provenance

User reference: https://github.com/voltagent/awesome-design-md
Selected guidance: https://github.com/VoltAgent/awesome-design-md/blob/main/design-md/cal/DESIGN.md

Used the neutral scheduling layout, component hierarchy, responsive principles and design-document format. The Tabiyo deck remains the authority for forest/cream/saffron, the serif identity and warm Indian-language voice. No competitor UI or proprietary asset was copied. See `DESIGN.md` for implementation tokens.
