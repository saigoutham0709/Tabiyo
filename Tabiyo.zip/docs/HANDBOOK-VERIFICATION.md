# Handbook review verification

Date: 2 November 2026. Source baseline: `75afe576f063280b3d9637a3be674cfd4889f549`. Local checkout: `C:\Users\kurma\Documents\Codex\Tabiyo-review`. Node `v24.11.1`, npm `11.6.2`, pnpm `11.25.0`. The repository was cloned from the authorized private GitHub repository; no application source was changed for this review.

## Executed checks

| Command | Result | Limits |
| --- | --- | --- |
| `npx --yes pnpm@11.25.0 install --frozen-lockfile` | Passed; 639 packages installed, lockfile supply-chain policy check passed | No dependency upgrade or lockfile change. This is not a full vulnerability/secret audit. |
| `node --test tests/*.test.mjs` | Passed: 32/32, zero failures | 22 domain tests plus 10 mocked API/SQLite integration tests; no live providers. |
| `node node_modules/typescript/bin/tsc --noEmit` | Passed, exit 0 | Static type check only. |
| `npm run build` | Passed, exit 0 | Portable Vinext build, not production deployment. Middleware deprecation warning and unknown page classification warning remain. API routes listed were `/api/workspace` and `/api/webhooks/whatsapp`. |
| `npm run lint -- --format json --output-file outputs/eslint-results.json` | Failed: four errors, five warnings | Existing source findings below. Review scope did not change application code to hide them. |
| `node docs/handbook-probes.mjs` | Passed all nine assertions of observed gaps | These assertions reproduce existing mismatches; passing does not mean the app meets the handbook. |

An initial test invocation ran before dependency installation finished and failed with `ERR_MODULE_NOT_FOUND` for `zod`. After installation completed, the full suite passed. The final result above is the usable baseline.

## Lint findings

| File | Line | Rule | Finding |
| --- | --- | --- | --- |
| `app/api/workspace/route.ts` | 9 | `prefer-const` | `state` is never reassigned. |
| `app/tabiyo.tsx` | 14 | `react-hooks/refs` | Ref access during render flagged. |
| `app/tabiyo.tsx` | 19 | `react-hooks/set-state-in-effect` | Synchronous state update in effect flagged. |
| `app/tabiyo.tsx` | 33 | `react-hooks/refs` | Ref access during render flagged. |

Five warnings are spread across `app/tabiyo.tsx` and `tests/domain.test.mjs`. Full machine-readable output is local in ignored `outputs/eslint-results.json`. Lint must pass before adding it as a required CI gate. Do not globally disable the rules as an acceptance shortcut.

## Focused behavioral evidence

The checked-in review script uses only synthetic data. It asserts current behavior and should be converted into inverse regression expectations when each gap is fixed.

| Probe | Observed behavior | Handbook gap |
| --- | --- | --- |
| P01 shared phone | Creating a second patient on `+919000000001` throws `This number already belongs to a patient. Use the existing record.` | T1.8/T2.8 and D4 require multiple patients per phone. |
| P02 Sunday | Seed says Mon–Sat; `slots()` offers 16 slots on Sunday 8 November 2026. | T2.1 requires real schedules/hours/leaves. |
| P03 opted-out emergency | `I cannot breathe` from synthetic patient p5 gets paused/START reply; no high-priority alert. | Emergency handling must precede ordinary state/consent dispatch. |
| P04 old inbox window | Staff reply accepted as `preview` after a last inbound 25 hours earlier. | T3.7/WA_WINDOW_CLOSED require blocking free text and offering a template. No actual external message was sent. |
| P05 admin prescription | `admin` can create a medicine draft. | Permission matrix allows prescription entry only to doctor. Production API currently gives every owner admin. |
| P06 stale reschedule | A persisted move-confirm session targeting yesterday commits a past appointment. | Session timeout and commit-time availability/date checks missing. |
| P07 ended course | Expired active plan remains `active` and is listed as Active by Medicines. | T4.4 requires auto-completion. Existing dose acknowledgment date guard still rejects an expired course. |
| P08 ingress | GET and POST handlers both return 503. | Intentional fail-closed pilot; no working handbook webhook. |
| P09 same-day past | With clock fixed at 20:00 IST on 2 November, a 14:00 same-day slot is accepted. | SLOT_INVALID requires rejecting bookings in the past. |

P06 injects a stale persisted session because current state has no timestamp/expiry machinery. P09 restores the real Date class after its isolated fake-clock check. These probes do not call Meta, use patient data or alter a database.

## Repository and handbook traceability

GitHub returned only `main`, at the audited SHA, with `protected:false`. The Actions runs collection returned zero runs. No tracked `.github` workflow exists. These checks do not prove that external CI, account settings or unpublished developer checkouts are absent.

The CSV preserves original handbook row wording and extracted-source line numbers, alongside status/evidence/remaining work/stage. All 55 ticket IDs occur exactly once. Ticket classification:

CSV integrity check passed: 361 comparison rows; 55 unique tickets; all 21 schema table names; 13 screens; 26 error scenarios; 20 UAT scripts; seven retention categories. Some additional rows describe workflow, constraints or scope rather than independently shippable features. These rows must not be used as a completion-percentage denominator. `git diff --check` passed; working-tree changes consist only of the five new review documents/scripts.

| Sprint | Partial | Missing | Divergent | Unverified | Total |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1 | 4 | 7 | 2 | 0 | 13 |
| 2 | 7 | 2 | 1 | 0 | 10 |
| 3 | 2 | 7 | 0 | 0 | 9 |
| 4 | 5 | 3 | 0 | 0 | 8 |
| 5 | 3 | 4 | 1 | 1 | 9 |
| 6 | 1 | 3 | 0 | 2 | 6 |
| Total | 22 | 26 | 4 | 3 | 55 |

- **Partial:** useful prototype code exists, but full handbook acceptance is incomplete.
- **Missing:** prescribed implementation is absent from inspected source.
- **Divergent:** existing design conflicts with a stated requirement.
- **Unverified:** completion requires external configuration, operational evidence or people not inspected in this review.

Zero tickets are accepted as Done under the full handbook definition of done. This is an evidence boundary, not a claim that zero useful development exists. Counts are not an implementation percentage.

No browser/mobile/accessibility evaluation, actual provider round trip, live hosted-D1 inspection, Supabase account inspection, staging UAT, monthly uptime measurement, independent security test or backup restore was performed. Those remain explicit completion gates. The review and plan are local documents; nothing was committed, pushed or published.
