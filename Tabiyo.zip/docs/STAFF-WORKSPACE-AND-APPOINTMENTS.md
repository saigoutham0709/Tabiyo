# Staff workspace, operational review and appointment services

This increment adds a separate Next.js dashboard in `apps/dashboard`, caller-JWT staff operations, and the first normalized appointment services. The original Vinext/D1 pilot remains independent and synthetic. The new dashboard contains no fake signed-in identity and no seeded staff credential. Cloud setup remains pending under `admin@catalystintelligence.in`; no provider resource, external notification, public ingress or live sender is enabled.

## Staff operations

Migration `20261103141940_staff_operations_and_delivery_review.sql` adds an RLS-protected `staff_operation_requests` ledger and controlled alert resolution fields. All new operations resolve membership through `private.require_staff()`. Their public wrappers use security invoker; privileged functions remain private with empty search paths and explicit grants.

| Endpoint | Access and behavior |
| --- | --- |
| `GET /api/v1/patients/:id` | Active clinic staff; audited patient lookup for operational follow-up |
| `GET /api/v1/alerts?status=open&limit=50` | Admin/front desk; bounded clinic-scoped metadata with audited reads |
| `POST /api/v1/alerts/:id/resolve` | Admin/front desk; UUID request key and controlled resolution code required |
| `GET /api/v1/deliveries/uncertain` | Admin only; bounded metadata, no raw payload or message body |
| `POST /api/v1/deliveries/:id/review` | Admin only; reconcile mock evidence or explicitly close without resending |

`reconcile_mock` completes an uncertain record only when durable mock acceptance exists. It preserves the original provider ID, acceptance timestamp and attempt count. It sends nothing. Missing proof returns `held` and leaves the delivery uncertain. `close_without_resend` requires `patient_contacted` or `no_action_required`, refuses known acceptance evidence, and records a failed/closed outcome instead of queueing another send. Ordinary alert resolution cannot hide an unresolved uncertain send. Related uncertainty alerts resolve only after accepted reconciliation or explicit closure.

Operation request keys are scoped to clinic and actor and reject changed inputs. Replay does not duplicate audit, acceptance or alert events. The ledger contains operation IDs/results rather than patient bodies and is retained pending a reviewed deletion policy. Doctors do not receive broad operational access; doctor-specific alert ownership remains a later permission increment. These database alerts are still not an external monitored notification channel.

## Dashboard session boundary

Run `npm run dev:dashboard` after configuring a working local stack or an owner-verified environment. Required server settings are `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `TABIYO_API_ORIGIN` and `TABIYO_DASHBOARD_ORIGIN`. Missing configuration returns a static 503 and does not contact an OTP provider. Phone OTP uses `shouldCreateUser: false`; successful OTP must also pass the API membership check before a dashboard session opens.

The browser receives an opaque HttpOnly/SameSite=Strict cookie, with Secure on HTTPS. Access and refresh tokens stay in process memory. The server enforces 30-minute idle expiry, refreshes only active sessions, and invalidates local custody on sign-out even if remote revocation fails. Same-origin writes, bounded request bodies, limited OTP attempts, redirect refusal and an API route allowlist protect the proxy boundary. Raw incoming-request logging is disabled. Patient search and availability requests put identifiers in browser request bodies rather than query strings.

The local store is deliberately process-local: restart signs staff out. It is not yet a multi-instance session store, and it does not impose a new idle policy on independently obtained direct API JWTs. Distributed rate limiting/session custody, full hosted refresh/logout behavior and direct-API idle enforcement remain release gates. No browser tokens or patient form bodies are written to local/session storage; only a random pending-create request key is retained to protect retries. Resetting that key requires an explicit record-check confirmation. Unsaved sensitive form drafts are cleared at session loss; reviewed authenticated form restoration remains open.

The dashboard supports patient family selection, patient create/edit, explicit manual consent decisions, patient details from operational alerts, alert resolution, admin delivery review, day view, booking, reschedule and state actions. Mobile layouts, labels, focus outlines, status announcements, offline notices and reduced-motion CSS are included. Production browser UAT, keyboard speed measurements and a clinic walkthrough are not established by a build or HTTP smoke test.

## Appointment persistence

Migration `20261103144127_appointment_services_and_availability.sql` adds `doctor_schedules`, `doctor_leaves` and `appointments`. Public schema total becomes 15 handbook tables plus seven support tables, all with RLS. The local PostgreSQL fixture registers the real `btree_gist` extension for interval exclusion tests.

- Times are stored in UTC; weekly hours, breaks, leave dates, clinic holidays and day view use Asia/Kolkata. Availability uses configured slot lengths, excludes past instants, and bounds new bookings to 90 days.
- Both doctor overlap and patient overlap use database exclusion constraints for booked/checked-in intervals. Shared-phone family members remain separate patient identities. Adjacent intervals are allowed.
- Caller-JWT booking, reschedule and state transitions are transactional, clinic scoped and idempotent. Doctors can operate only on their own linked schedule. Reschedule preserves the original when a replacement conflicts. A conflict returns HTTP 409 plus up to three validated same-day alternatives.
- Booking/reschedule atomically writes a confirmation/change outbox record and future 24-hour/two-hour reminder records. Offsets already in the past are omitted. pg-boss's minute delivery backstop processes due outbox rows; no in-memory reminder timer is required.
- Reschedule/cancel skips stale queued appointment work. Dispatch rechecks appointment identity, start time, cancellation/state, doctor activity, leave and clinic holiday. Contact locks coordinate staff changes with mock acceptance. Accepted historical evidence is preserved.
- Cancellation creates a staff notice task rather than inventing an unapproved cancellation template. Automatic patient cancellation/leave notices remain pending approved copy and the conversation flow.
- Read and write APIs emit clinic-scoped patient/appointment audits and domain events. No external provider receipt is fabricated.

New endpoints: `GET /api/v1/doctors`, `GET /api/v1/doctors/:id/slots`, `GET /api/v1/appointments?date=`, `POST /api/v1/appointments`, `PATCH /api/v1/appointments/:id`. Writes require `Idempotency-Key`. Patch actions are reschedule/cancel/check_in/complete/no_show. Future-day check-in, premature no-show, completion without check-in and resurrection of terminal appointments are rejected.

## Remaining gates

Stage 1 still needs complete consent/language/reply onboarding, approved copy, local scheduler wake integration, the full permission/session contract, complete Supabase validation and actual provider evidence. Admin schedule/leave controls, affected-booking review and the feature-gated walk-in queue were subsequently implemented; see `AVAILABILITY-AND-QUEUE.md`. Stage 2 still needs approved change/queue notices, the patient WhatsApp booking/reschedule/cancel state machine, cross-day alternatives, real concurrent PostgreSQL verification and browser/test-phone UAT. The reminders are an implementation increment into Stage 3, not completion of that stage.

Slips/private storage/DOB retrieval, inbox, import/merge, prescriptions/adherence, FAQ/guardrails, clinic onboarding/feature management, reports, export/delete, backups/monitoring and full release acceptance remain open in the main handbook plan. None is represented as completed by the new dashboard shell.

Verification commands: `npm test`, `npm run lint`, `npm run typecheck`, `npm run build`, `npm run build:dashboard`, `npm run test:dashboard:smoke`. The smoke script starts an ephemeral loopback-only Next server with empty provider settings, verifies security headers and disabled authentication, and shuts it down. This is HTTP verification, not browser UAT. CI now includes both builds and this smoke check; no remote CI run is claimed before pushing.

References: [Supabase functions](https://supabase.com/docs/guides/database/functions), [RLS](https://supabase.com/docs/guides/database/postgres/row-level-security), [OTP sign-in](https://supabase.com/docs/reference/javascript/auth-signinwithotp), [OTP verification](https://supabase.com/docs/reference/javascript/auth-verifyotp).
