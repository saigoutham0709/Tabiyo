# Tabiyo development status

Updated: 2 November 2026. Working checkout: `C:\Users\kurma\Documents\Codex\Tabiyo-review`. Git baseline: `75afe576f063280b3d9637a3be674cfd4889f549`. Changes are local and uncommitted.

## Required ownership

All development resources must be controlled by **admin@catalystintelligence.in**. The user confirmed Supabase and Meta Business are not set up and requested that cloud setup stay pending. No provider account was substituted, no cloud resource was created, and no external WhatsApp message was sent. GitHub account email/resource ownership remains unverified; nothing has been pushed.

Registry: `config/development-resources.json`. Execution and account setup checklist: `DEVELOPMENT-EXECUTION.md`. Full feature plan: `HANDBOOK-COMPLETION-PLAN.md`.

## Delivered local increment — Phase 1A

- Workspace packages `@tabiyo/api` and `@tabiyo/shared`; the root synthetic pilot remains in place.
- Node/Fastify `/health` liveness route and `/api/v1/me` staff-context route.
- Supabase Auth `getUser(token)` verification; active staff membership and clinic resolved with the caller's token. No trusted caller-provided role/clinic or platform-header fallback. Unknown/anonymous users, missing/inactive membership and inconsistent clinic data are denied.
- Stable API error codes; no-store responses; authorization/cookie redaction; no automatic URL/body request logging. Auth HTTP calls have timeout signals. This does not complete all handbook logging/error requirements.
- CLI-created migration `supabase/migrations/20261102095119_clinic_identity_foundation.sql` for `clinics`, `staff_users`, `doctors`, `patients`, `consents`.
- RLS on all five new tables; anonymous access denied; user reads and patient writes scoped by active clinic membership. Staff membership/role mutation is not granted to authenticated clients.
- Nonunique clinic/mobile index for family records; tenant-safe doctor/staff, patient-merge and consent foreign keys. Consent rows are append-only for both authenticated and service-role application clients.
- Synthetic seed: one clinic, two doctors, ten fake patients, including two family members on one phone. No credential, fake login or pre-granted patient consent is seeded.
- Supabase CLI local config with explicit table exposure grants, anonymous auth disabled and self-signup disabled. Hosted configuration is not created or verified.
- GitHub Actions definition for locked install, lint, types, tests and pilot build. Deployment is deliberately absent while cloud ownership/setup is pending. No remote workflow run is claimed.
- Baseline lint fixes: stable mutation/refresh callbacks, mount-fetch cancellation, effect-based close callback synchronization, removal of unused imports and render-time IIFEs around event handlers. No lint rule was disabled. Generated `outputs/` is excluded from source linting.

The new SQL/backend are not connected to the root pilot UI. Its existing D1 aggregate, shared-phone restriction, simulated delivery and other audit findings remain until their migration tickets are completed. Do not represent a schema test as a fixed production screen or a complete handbook ticket.

## Delivered local increment — Phase 1B patient and delivery records

- Added CLI-created migration `20261102100856_patient_services_and_delivery_records.sql`: six more handbook tables (`clinic_features`, `events`, `audit_log`, `outbox`, `webhook_raw`, `conversations`) plus the durable `api_requests` replay support table. Total: 11 handbook domain tables plus one support table, all with RLS.
- Added authenticated patient mobile search, create, edit and versioned consent APIs. Every read result is audited. Creating a patient atomically queues a consent-request record, event, audit and actor-bound replay response. No message is sent.
- Added database-side input/tenant checks, request advisory locking and replay uniqueness. Reusing a key across actors/operations/bodies is rejected; keys in different clinics are independent.
- Consent revocation appends proof, updates opt-out state and skips queued messages. Subsequent grants do not revive skipped rows. Staff cannot impersonate inbound WhatsApp consent. Changing a mobile number is blocked until verified contact-change handling exists.
- Restricted direct authenticated patient/consent table access. Narrow private privileged operations enforce mandatory audit/outbox writes; all require current active membership and pinned search paths. Public RPC wrappers remain invoker functions.
- Added safe unmapped-webhook quarantine schema, tenant-safe phone routing foreign key, default-off feature records and restricted internal-table access. These are data foundations, not an enabled gateway or worker.
- Added end-to-end local API/adapter/PostgreSQL tests, failure-trigger rollback tests, read-audit failure tests and ACL/privileged-function checks. No dependency changes were needed for this increment.

Contract and security rationale: `PATIENT-API.md`. Implemented error responses: `runbook.md`.

## Delivered local increment — Phase 1B mock delivery worker

- Added migration `20261102110424_delivery_worker_and_receipts.sql`, service-only worker RPC and a bounded `DeliveryWorker.runOnce()` implementation. No daemon, scheduler or live provider starts automatically.
- Added expiring claims with fencing tokens, stale-lease recovery, durable mock acceptance and reconciliation. Accepted evidence survives worker restart; unknown acceptance stops automatic retries and opens an alert.
- Enforced current consent/opt-out/shared-phone suppression, controlled default-off consent-request exception, feature/language flags, approved templates, 24-hour windows, configurable IST quiet hours and daily cap reservations. Every policy read is audited.
- Added definite-rejection retries at 1/5/15 minutes, terminal failure alerts, not-on-WhatsApp state and rejected-template suppression. Added 80%/100% cap alerts and 30-minute stale scheduled-job handling. Generic approved template fallback remains a business-contract gate.
- Added immutable outbound `message_log`, immutable/deduplicated `delivery_receipts`, durable `mock_deliveries` and clinic-scoped `staff_alerts`. Provider acceptance is distinct from sent/delivered/read callbacks; early/out-of-order receipts are reconciled without duplicate event counts. Alerts are database records, not external notifications.
- Added deterministic consent append ordering and preserved actual mock acceptance timestamps and IST cap day across recovery/midnight.
- Added `npm run demo:delivery`, an in-memory synthetic demonstration with simulated receipt and zero physical messages. Restricted test-file concurrency after parallel PostgreSQL WebAssembly fixtures and the demo exhausted local memory; the complete suite then passed without removing checks.

Schema total is now 12 handbook domain tables plus four support tables, all with RLS. Design, operational limits and remaining live gates: `DELIVERY-WORKER.md`.

## Delivered local increment — Phase 1B signed inbound gateway

- Added migration `20261102130121_signed_gateway_and_contact_controls.sql`, raw-byte HMAC/verification routes, atomic scoped intake and a bounded gateway worker. Configuration is explicit local-test wiring only; the server entry point and legacy pilot ingress remain disabled.
- Added phone-ID-to-clinic routing, multi-number payload isolation, private quarantine, durable queued acknowledgment, global message-ID dedup and conflict detection. Replays cannot repeat a consent transition. Incoming logs remain private and have no permanent plaintext body preview.
- Added shared-contact STOP/START with append-only source-linked proof, stale-command guards, approved matching-notice requirements, no blanket family consent grants and no revival of skipped work. Unknown-number STOP protects later-created patient records. Individual staff withdrawal remains individual, while global STOP suppresses the whole contact.
- Coordinated contact locks across gateway commands, staff writes and mock dispatch. Prepared-but-unaccepted work is fenced on STOP; already accepted evidence remains truthful and can be completed.
- Added inbound receipt routing, unsupported-media handoff, raw replay, lease recovery, transactional processing retries and bounded seven-day cleanup. Cleanup alerts for expired pending work and preserves dedup proof. No recurring job runs yet.
- Added private hourly signature-abuse counters and cleanup metadata. These records and staff alerts are not external/monitored notification delivery.
- Added `npm run demo:gateway`: synthetic signed intake, queued processing and shared-phone suppression with zero physical messages.

Current schema is 12 handbook domain tables plus six support tables, all with RLS. Protocol, consent safety and remaining gates: `INBOUND-GATEWAY.md`.

## Delivered local increment — Phase 1B scheduler and technical retention

- Integrated pg-boss 12.38.0 with persistent minute schedules for delivery/intake, daily IST cleanup, empty control payloads, bounded drains, sanitized retries and graceful shutdown. Explicit mock composition starts no daemon or connection on import.
- Added migration `20261102162200_bounded_retention_jobs.sql`: bounded maintenance for terminal outbox/mock payloads, replay-response redaction, orphan receipts, message previews, resolved alerts, security counters and maintenance metadata. Active/uncertain work, immutable delivery history and request-key tombstones remain protected.
- Preserved late receipt matching/events after queue payload expiry, including monotonic delivery evidence and suppression of replayed historical failure alerts. Expired cached responses return safe HTTP 409 `REQUEST_REPLAY_EXPIRED` before or after redaction.
- Added `npm run demo:scheduler`: actual pg-boss workers operate on migrated synthetic SQL stores, accept one mock delivery, process STOP and run maintenance. Zero physical messages; workers and database close on completion.
- Added serialized low-memory WebAssembly test settings after the local machine exhausted memory during optimized PostgreSQL compilation. No assertions were removed.

Current public schema remains 12 handbook domain tables plus six support tables, all with RLS. pg-boss owns a separate jobs schema in local tests. Contracts and limits: `SCHEDULER-RETENTION.md`. Default server wiring, cloud setup and live messaging remain disabled.

## Delivered local continuation — 3 November: staff workspace and appointment services

- Added CLI-created migration `20261103141940_staff_operations_and_delivery_review.sql`, audited single-patient lookup, clinic-scoped alert listing/resolution and admin-only uncertain-delivery review. Known mock acceptance completes without resending; absent evidence stays held. Explicit reason-required closure never fabricates acceptance or requeues a send. Request keys prevent duplicate operational mutations.
- Added a separate Next.js workspace in `apps/dashboard`: phone OTP integration with staff membership validation, server-held tokens, opaque HttpOnly cookies, 30-minute server-side idle expiry, active-only refresh, same-origin proxy controls and disabled configuration handling. UI includes family patient selection, create/edit/consent, operational patient lookup, alerts and delivery review. Direct API JWT inactivity, distributed custody and real OTP remain acceptance gates.
- Added CLI-created migration `20261103144127_appointment_services_and_availability.sql`: weekly schedules, leave, UTC appointment intervals with IST availability/day view, real doctor/patient exclusion constraints, atomic scoped booking/reschedule, controlled status transitions and up to three same-day alternatives. Doctor operations are limited to the linked doctor's own schedule.
- Connected booking, appointment day view, reschedule, check-in/completion/no-show/cancel to the dashboard. Added atomic future 24-hour/two-hour reminder outbox records, skipped stale queued work, and appointment validation at dispatch. Cancellation raises a staff notice task pending approved patient-facing copy.
- Added actual built-dashboard HTTP smoke verification with empty provider settings and ephemeral loopback startup/shutdown. CI source now includes the new dashboard build and smoke check; remote CI has not been run.
- Diagnosed the pinned Node runner dropping V8 flags in its child processes. `scripts/test.mjs` now launches each file in a separate process with its memory flags retained, preserving all assertions and isolation. A complete 224-test run passes after this fix.

Current public schema: **15 handbook domain tables plus seven support tables**, all with RLS. Seven migrations are applied in the local PostgreSQL fixture, including real `btree_gist`. Detailed contracts and remaining gaps: `STAFF-WORKSPACE-AND-APPOINTMENTS.md`.

The user requested completion of all phases. That objective remains open: this continuation is implementation progress, not completion of the full handbook. No real OTP, Meta traffic, hosted deployment, external notification or clinical-record storage has been verified. Approved patient-facing consent/reply wording has been requested; cloud setup remains pending by user instruction.

## Delivered local continuation — 4 November: availability management and walk-in queue

- Added CLI-created migration `20261104153332_doctor_availability_management.sql`: clinic-admin schedule/break/leave APIs and dashboard, request-key replay, revision checks, audited affected-appointment review, ID-only alert context and a guard against resolving availability alerts while conflicting bookings remain.
- Added CLI-created migration `20261104154416_walk_in_queue_controls.sql`: RLS-protected `queue_tokens`, scoped default-off APIs/dashboard, per-day numbering, doctor-own scope, one called token per doctor, one active token per patient, stale-view call-next checks and terminal-state protection.
- Added next-patient notice intake only when approved wording, consent/contact eligibility and the 24-hour window exist. Missing copy/eligibility becomes a staff task. Queue order, approval/text/version, availability and existing delivery policies are checked again before mock acceptance. No live notice or unapproved fallback is sent.
- Coordinated queue/configuration/dispatch advisory locks, refreshed server time after lock waits and rejected writes crossing an IST day boundary. Real multi-process and midnight-wait acceptance still require the full PostgreSQL stack.
- The user confirmed they will provide approved patient-facing wording and notice versions. That content remains pending; no draft copy or approval is inferred from elapsed time.

Current public schema: **16 handbook domain tables plus seven support tables**, all with RLS. Nine migrations run in local fixtures. Contracts and limits: `AVAILABILITY-AND-QUEUE.md`. The root pilot, resource-owner restriction and pending cloud/live gate remain unchanged.

## Verification

| Check | Result |
| --- | --- |
| `npm test` | 250 passed: 32 original pilot, 105 API/Auth/patient/operations/appointment/availability/queue/delivery/gateway/scheduler, 14 dashboard boundary, 99 PostgreSQL schema/RLS/service/retention |
| `npm run demo:delivery` | Pass: mock accepted, simulated receipt delivered, zero physical messages |
| `npm run demo:gateway` | Pass: synthetic signature verified, queued before processing, shared phone stopped, zero physical messages |
| `npm run demo:scheduler` | Pass: actual pg-boss, mock acceptance, inbound STOP, three schedules and technical retention; zero physical messages |
| `npm run lint` | Pass; zero errors and zero warnings |
| `npm run typecheck` | Pass |
| `npm run build` | Pass for preserved Vinext pilot |
| `npm run build:dashboard` | Pass for separate Next.js staff dashboard |
| `npm run test:dashboard:smoke` | Pass: built app/security headers, absent configuration returns 503; zero physical messages |
| `git diff --check` | Pass |

API tests use Fastify injection. Patient, staff operation and appointment integration tests connect the actual Supabase JS adapter to a mocked HTTP transport backed by the migrated PostgreSQL test engine. Gateway tests sign real bytes and exercise the route/queue/worker against actual SQL. The startup test proves missing Supabase configuration exits instead of enabling a fake identity. Worker tests invoke service-only RPCs against the durable mock ledger. Scheduler tests use real pg-boss with clock-driven cron, retries and instance restart. Dashboard gateway tests verify token custody, membership, idle expiry, proxy allowlisting, OTP limits and error redaction. PostgreSQL tests execute all nine migrations and seed in PGlite with isolated Supabase-style Auth roles, an `auth.uid()` fixture and `btree_gist`. They prove local policy/transaction behavior, not hosted Supabase Auth/Storage/edge behavior or multi-process locking. Test-only RLS probe roles receive extra grants solely inside the isolated engine to exercise policies independently of production ACLs.

Docker's Linux engine was unavailable: `open //./pipe/dockerDesktopLinuxEngine: The system cannot find the file specified.` Therefore no complete local Supabase container stack, Supabase advisors, hosted RLS validation, phone OTP, real Meta round trip or staging/browser UAT has been completed. Existing build notices about `middleware.ts` deprecation and Vinext route classification remain. Node's experimental SQLite notice belongs to the original pilot integration tests.

## Ticket progress against the original audit

| Ticket | New evidence | Still required |
| --- | --- | --- |
| T1.1 | Workspace scaffold; local checks; CI file | Dashboard workspace migration, actual GitHub CI/staging deployment and reviewed PR evidence |
| T1.2 | Sixteen handbook tables plus seven support tables; CLI config; synthetic seed | Remaining five domain tables, full local Supabase validation and three verified Mumbai projects |
| T1.3 | RLS/ACL and private-operation tests; cross-clinic/membership/write denial | Remaining tables, storage, provider integration and multi-connection verification |
| T1.4 | Verified-session membership API, separate OTP dashboard code, opaque session custody and local idle tests | Real OTP, full permission/session matrix, direct-API inactivity and staff/super-admin management |
| T1.8 | Family patient APIs and dashboard, audited direct lookup and atomic consent-request queue | Verified mobile-change workflow, full browser UAT and actual permitted delivery |
| T1.5/T1.7 | Local signed durable intake, incoming logging/dedup and receipt routing | Actual Meta challenge/phone traffic, deployed public endpoint and staging evidence |
| T1.9 | Versioned consent, source-linked shared STOP/guarded START and dispatch fencing | Complete language/notice/reply onboarding, real concurrent/provider verification and approved copy |
| T1.10 | Durable mock worker, pg-boss scheduling/recovery, fenced claims, send policy, retries, reconciliation and receipts | Deployed worker, actual provider/fallback contracts, multi-process verification and live acceptance |
| T1.11 | Durable scoped intake/quarantine, replay and bounded scheduled seven-day cleanup | Production wiring, retention approval/advisors and live replay evidence |
| T5.9 | Bounded technical retention, queue expiry, one-year body redaction and preserved replay/delivery proof | Final periods, clinical/storage deletion, events/audit archiving, backups and staging evidence |
| T1.12 | Default-off flags, clinic-scoped reads and mock send enforcement | Authorized super-admin toggles and UI/API/job enforcement |
| T1.13 | Atomic patient/consent events and deduplicated delivery events | Booking/reminder events and later event-based reports |
| T2.1–T2.4 | Admin schedule/leave controls and affected-booking review; availability/exclusions, appointment APIs/dashboard, scoped transitions and audited reschedule | Approved change notifications, cross-day alternatives, full concurrent PostgreSQL and browser/test-phone acceptance |
| T2.10 | Default-off scoped queue API/dashboard; token ordering/transition constraints; guarded next-patient notice intake and stale-notice fencing | Approved wording, real patient notification, multi-process/load and browser/test-phone acceptance |
| T3.1 | Atomic future 24-hour/two-hour reminder records, stale invalidation and appointment policy at dispatch | Full-stack timing/load tests, immediate wake wiring and actual permitted patient receipts |

The historical audit and CSV remain snapshots of the earlier baseline. None of these tickets has met the full staging/reviewer definition of done yet.

## First incomplete gate and next increment

**Local foundation, staff operations, dashboard boundary and first appointment/reminder services pass automated checks. Full Stage 1 and Stage 2 acceptance remain incomplete.** Continue the existing full-handbook objective:

1. Complete consent/language/reply onboarding and patient WhatsApp booking/reschedule/cancel; wire committed intake/writes to scheduler wake. The user will provide approved wording/versions. Keep live sending disabled.
2. Complete change-notification contracts, cross-day booking alternatives and actual schedule/queue/notice acceptance. Add real PostgreSQL multi-connection tests when the local stack is available.
3. Complete dashboard permission/session behavior, safe authenticated draft restoration, browser/keyboard/mobile UAT and verified contact changes. Preserve the old synthetic pilot independently.
4. Build remaining Stage 3 records/storage/DOB/inbox/import/merge; Stage 4 medication/adherence/FAQ/guardrails; Stage 5 clinic operations/reports/full languages/export/delete/backups/monitoring; then Stage 6 release acceptance. Full details remain in `HANDBOOK-COMPLETION-PLAN.md`.
5. Resume Supabase/Meta setup and hosted/staging evidence only when the user explicitly resumes that gate under the required owner. No release or complete-stage claim may substitute local fixture evidence for provider/UAT/reviewer proof.

These local tasks do not need cloud setup. The provider gate remains pending until the user resumes setup under the required email. Then verify owner/account IDs, run full Supabase stack/advisors and actual test-number/staging acceptance. No automatic background continuation is running.

## Reproduce

```sh
npx --yes pnpm@11.25.0 install --frozen-lockfile
npm test
npm run demo:delivery
npm run demo:gateway
npm run demo:scheduler
npm run lint
npm run typecheck
npm run build
npm run build:dashboard
npm run test:dashboard:smoke
```

Use Node 24.11.1 or the compatible pinned CI runtime. Start the new API only with an intentionally configured owner-verified dev project or a working local Supabase stack: `npm run dev:api`. Keys belong in ignored `.env.local`/the verified business vault, never in chat or the resource registry.
