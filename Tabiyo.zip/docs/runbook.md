# Tabiyo API runbook — current local foundation

Resource owner: `admin@catalystintelligence.in`. Cloud setup is pending. This runbook covers implemented API errors; all handbook provider/job/document/FAQ incidents remain to be implemented and exercised before release.

| Code | Meaning and response |
| --- | --- |
| `AUTH_REQUIRED` (401) | Missing/invalid/anonymous session. Sign in again. Never trust identity headers or edit a JWT to regain access. |
| `AUTH_UNAVAILABLE` (503) | Auth verification service unavailable. Retry after recovery; inspect redacted provider status without printing tokens. |
| `STAFF_FORBIDDEN` (403) | No active clinic membership, revoked access or mismatched membership data. Authorized onboarding/admin checks the membership; do not self-grant roles or disable RLS. |
| `INPUT_INVALID` (400/413/415/422) | Invalid JSON/content type/body size or schema fields. Fix the request. No patient mutation should have committed. Error responses intentionally omit submitted values. |
| `PATIENT_NOT_FOUND` (404) | Record missing, merged, or outside caller clinic. Do not disclose another tenant's existence. Verify patient selection in the current clinic. |
| `IDEMPOTENCY_CONFLICT` (409) | Key was already used for another actor/body/operation. Retry the original unchanged request with its original key to recover its result. A genuinely new action needs a new UUID. |
| `CONTACT_CHANGE_REQUIRES_VERIFICATION` (409) | Mobile edit blocked pending verified contact-change handling. Keep the original contact/consent intact; do not edit database rows to bypass the block. |
| `SERVICE_UNAVAILABLE` / `DB_UNAVAILABLE` (503) | Patient service not configured, migration/RPC missing, response invalid, or database operation failed. Verify reviewed migrations and intended project configuration. Never connect a different cloud account as a workaround. |
| `NOT_FOUND` (404) | No API route at this path. Check method/path. Responses do not echo sensitive URL content. |
| `INTERNAL_ERROR` (500) | Unexpected failure. Use request ID and controlled logs. Never log full error objects, request bodies, names, phones, keys or tokens. |

For an ambiguous patient write failure, replay the same UUID and body after connectivity recovers. The database either rolled back or committed a durable response; do not create another patient merely because the HTTP result was lost. Queued outbox rows are not provider-accepted/delivered. Only a mock sender exists; no live manual sender is enabled.

Patient reads fail if their required audit insertion fails. Restore audit storage/permissions and retry; do not remove the audit operation to make a read work.

Consent revocation skips queued rows. A later grant does not restart those rows. The mock checks consent again atomically at acceptance. Real provider in-flight/shared-contact races remain a live gate. No live worker is running.

## Mock worker incidents

- `WA_SEND_FAILED`: a definite fake rejection retries at 1, 5 and 15 minutes, then fails on attempt four. Inspect the durable alert. Do not bypass the worker's attempt/cap controls.
- `WA_ACCEPTANCE_UNKNOWN`: work is `uncertain` and must not be automatically resent. Mock reconciliation can prove acceptance/absence. Real-provider reconciliation and reviewed operator resolution remain pending; do not reset rows by hand to hide uncertainty.
- `LEASE_LOST`: another worker reclaimed the expired five-minute lease. Stop work under the old fence. Recovery uses the new token and durable evidence.
- `WA_OPTED_OUT` / `WA_CONSENT_REQUIRED` / `FEATURE_DISABLED` / `WA_WINDOW_CLOSED`: inspect current consent/phone scope, feature settings and inbound window. Never edit a token or mark consent granted merely to release a send.
- `QUIET_HOURS` / `SEND_CAP_REACHED`: deferred work remains queued. Threshold alerts are deduplicated. Wait for the policy-approved time; no cap bypass.
- `WA_TEMPLATE_UNAVAILABLE`: template is unapproved or rejected. Its reuse is stopped; approved generic fallback copy has not been invented. Resolve the actual provider/template contract before enabling it.
- `WA_NOT_ON_WHATSAPP`: patient state is flagged and future dispatch stops. Verify contact through the clinic's authorized process.
- `JOB_STALE`: scheduled work is over 30 minutes late. It is skipped and recorded rather than misleadingly sent after relevance has expired.
- `WA_DELIVERY_FAILED`: a real/simulated failed receipt is retained and raises an internal alert. Accepted is not delivered. Out-of-order receipts never erase stronger read/delivered evidence.

`staff_alerts` is a durable internal record only. No external escalation, staff resolution screen or monitored notification channel is connected. Use `DELIVERY-WORKER.md` for current mock boundaries and the pending operational gates.

When provider setup resumes, verify account ownership and resource IDs first. Run Supabase advisors, Auth/Storage integration, multi-connection locking, restore and staging tests before approving live data or messaging.

## Local gateway incidents

- `WEBHOOK_DISABLED` (503): default server state. Local-test construction is available to fixtures; no environment flag or live connection has been configured. Do not expose the pilot route as a workaround.
- `WA_VERIFY_FAILED` (403): verification mode/token mismatch. Confirm the intended account and privately configured token. Never print a verify token or query URL to diagnose it.
- `WA_BAD_SIGNATURE` (401): byte-level HMAC check failed. Do not parse or replay this request as trusted inbound data. Hourly counters contain no bodies; `alert=true` is only an internal incident flag after the threshold.
- `WEBHOOK_INVALID` (400): signed input has invalid UTF-8/envelope shape. Errors omit the input. Unsupported content types or oversized bodies may produce 415/413 before processing.
- `WEBHOOK_UNAVAILABLE` (503): atomic durable intake failed; no acknowledgment of receipt was issued. After database recovery, let Meta retry or use the original authorized test fixture. Never fabricate a successful acknowledgment.
- `WEBHOOK_EVENT_INVALID` / `WEBHOOK_MESSAGE_CONFLICT`: a stored fragment is failed and alerted. Inspect private raw evidence within retention under authorized access. Never remap a provider message ID to a different clinic or edit payloads to hide the conflict.
- `WEBHOOK_PROCESS_FAILED`: transaction rolled back and retries after one minute, up to three attempts. Investigate static error code/request or raw UUID; no full payload or SQL error in logs. No partial consent transition should survive.
- `REPLAY_FORBIDDEN`: row is quarantined, unmapped, actively processing, expired, or no longer belongs to the same route. Do not assign historical unknown payloads to a newly created clinic. Replay is a private, audited operation.
- `WEBHOOK_RETENTION_EXPIRED`: pending work aged beyond raw retention. A durable alert is created before deletion. Investigate scheduler/backlog health; source message/consent dedup records remain. Cleanup is bounded and skips active leases.

Shared phone STOP is a global contact control; an individual staff withdrawal is patient-specific. START requires freshness and a configured matching approved notice before restoring prior eligible consent. It grants nothing to an untouched family member, revives no skipped messages and restarts no medication course. No automatic confirmation reply is implemented in this gateway increment.

Local pg-boss integration and bounded technical retention are implemented; no daemon or external alert channel is enabled. Run `npm run demo:scheduler` for the isolated synthetic demonstration. Continue staff alert resolution/reconciliation and full consent/reply onboarding before live verification. See `INBOUND-GATEWAY.md` and `SCHEDULER-RETENTION.md`.

`REQUEST_REPLAY_EXPIRED` (409): the 90-day cached response window ended. Search existing patient records and reconcile the original operation. Never automatically generate a fresh create key. The retained request tombstone prevents a duplicate write.

Scheduler failures expose `SCHEDULER_START_FAILED`, `SCHEDULER_HANDLER_FAILED` or `SCHEDULER_ERROR`. Inspect queue state and static codes through authorized local tooling; never print job/provider/raw error objects. Control retries do not resolve uncertain delivery. Cleanup preserves open alerts and active/uncertain evidence; large backlogs need repeated bounded calls, with counts checked after each run.
