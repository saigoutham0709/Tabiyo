# Tabiyo handbook alignment audit

Review date: 2 November 2026. Repository: https://github.com/Ritish017/Tabiyo. Baseline: `main`, commit `75afe576f063280b3d9637a3be674cfd4889f549` (21 October 2026).

Authority: the supplied **Tabiyo: Development Handbook**, dated 24 October 2026. The extracted attachment contains all 16 named sections, 55 sprint tickets, 21 proposed tables, 26 error scenarios and 20 UAT scripts. The earlier pitch-deck plan in `docs/PRODUCT_AND_LAUNCH.md` describes the existing pilot; it does not supersede this newer handbook.

## Verdict

The full source for the current synthetic pilot is present on the inspected branch. The handbook application is not complete, and the current architecture differs materially from its settled decisions. No missing private branch was found: GitHub returned only `main`. This does not establish that unpushed developer code or separately hosted services do not exist.

The repository is a useful workflow prototype: appointment mutations, a staff dashboard, an authenticated patient-chat simulator, queue actions, medicine review and patient confirmation, and account-scoped persistence. It is explicitly labeled synthetic. It is not the handbook's clinic-ready MVP.

Do not equate the 32 pilot tests with handbook acceptance. They cover selected aggregate-state rules and a mocked hosting identity/SQLite boundary. They do not establish Supabase RLS, clinic RBAC, live WhatsApp delivery, durable jobs, document access, full language support, or staging UAT. No handbook ticket is marked complete in this audit because its full acceptance and definition of done have not been evidenced.

Companion files:

- `HANDBOOK-REQUIREMENTS.csv`: requirement-level inventory, including every ticket and cross-cutting requirement.
- `HANDBOOK-COMPLETION-PLAN.md`: ordered implementation stages, dependencies and completion gates.
- `HANDBOOK-VERIFICATION.md`: current commands, results and behavioral probes.

## Evidence map

| Reference | Inspected source | What it establishes |
| --- | --- | --- |
| E1 | `package.json`, `vite.config.ts`, `.openai/hosting.json` | Vinext/Vite, Cloudflare Worker/D1, React/TypeScript/Tailwind; no Fastify, Supabase, pg-boss, Sentry or PDF dependency. |
| E2 | `db/schema.ts:2`, `drizzle/*.sql`, `lib/repository.ts:3` | Two SQLite tables: `workspaces` and `rate_limits`. Domain data is an owner-scoped JSON aggregate with optimistic concurrency. No normalized clinic schema or SQL RLS. |
| E3 | `app/api/workspace/route.ts:9`, `app/chatgpt-auth.ts:22` | Hosting-supplied identity headers; API supplies the `admin` role for every authenticated workspace owner. No Supabase OTP or staff membership lookup. |
| E4 | `lib/domain.ts:36`, `lib/domain.ts:78` | Domain permission helper exists, but admin has `*`; patient creation rejects a reused phone number. |
| E5 | `lib/domain.ts:41`, `lib/domain.ts:45`, `lib/domain.ts:75` | Fixed half-hour slots, date-range checks, conflict checks and atomic aggregate-state rescheduling. No hours/break/leave model, appointment intervals or same-day elapsed-time check. |
| E6 | `lib/domain.ts:47`, `lib/domain.ts:72` | Persisted simulator conversation stages, consent boolean, STOP/START, generic handoff and English emergency heuristic. No actual inbound gateway, DOB, language onboarding or session timestamps. |
| E7 | `lib/whatsapp.ts:2`, `app/api/webhooks/whatsapp/route.ts:2` | Isolated HMAC/window/send helpers. Both live webhook handlers always return 503. Helpers are not wired into a sender worker. |
| E8 | `lib/domain.ts:80`, `lib/domain.ts:83`, `app/tabiyo.tsx:58` | Typed medicine drafts, clinician/patient gates, course-date checks and patient-reported dose records. No scheduled dose delivery or grouped occurrences. |
| E9 | `app/tabiyo.tsx:17`, `app/tabiyo.tsx:44`, `app/tabiyo.tsx:57` | Staff screens, local patient selector, conversation history, requests, profile and settings; no staff assignment, window timer or clinical read filtering. |
| E10 | `app/tabiyo.tsx:26`, `app/tabiyo.tsx:49`, `lib/domain.ts:42` | Client JSON export, aggregate-derived Insights, capped mutable action history. No events-based pilot reporting or access/export auditing. |
| E11 | `tests/domain.test.mjs`, `tests/api.test.mjs`, `docs/QA.md` | 22 domain and 10 mocked API/SQLite tests. No browser, Supabase, provider, load or full UAT suites. |
| E12 | `.gitignore`, `.env.example`, `middleware.ts` | Ignored environment files, placeholder integration names and baseline response headers. No complete handbook environment contract or production security proof. |
| E13 | GitHub branch and Actions collection reads | Only `main`, `protected:false`; zero Actions workflow runs returned. No tracked `.github` workflows. External CI/deployment configuration not inspected. |

## Stack, architecture and scope

| Handbook requirement | Current implementation | Required disposition |
| --- | --- | --- |
| TypeScript; Next.js App Router and Tailwind | TypeScript/React/App Router-style source and Tailwind, executed through Vinext/Vite | Preserve visual design and reusable components; move staff app to handbook Next.js runtime. |
| One Node Fastify or NestJS API | Next-style routes inside a Cloudflare Worker | Add `apps/api` with Fastify and the `/api/v1` contract. Dashboard accesses business data through API. |
| Supabase Postgres/auth/storage in Mumbai | D1 JSON aggregate; hosting-managed account auth; no document store | Replace production persistence and identity. Preserve synthetic pilot separately during migration. |
| pg-boss jobs in Postgres | No job worker | Implement scheduling, retries, cleanup and recovery as first-class modules. |
| One outbox for every outbound message | `emit()` appends `preview`/`held` messages; isolated raw send helper | Build transactional outbox and one policy-enforcing sender. Never turn simulator emits into direct provider calls. |
| Clinic isolation, per-clinic flags and events | Account ownership; no `clinic_id`, flags or events | Implement all three foundations before feature migration. |
| UTC instants, IST display | Appointment date/time strings in IST; action timestamps are ISO instants | Store `starts_at`/`ends_at` as UTC instants and test IST boundary cases. |
| One number per clinic, routed by provider phone ID | No number-to-clinic mapping | Persist unique routing and reject unknown mappings before domain handling. |
| Private slips, PDF generation, FAQ LLM, Sentry | None integrated | Implement in the appropriate stages below. |
| GitHub Actions and staging deployment | No tracked CI; zero Actions runs observed | Add checks and fake-data staging deployment workflow. Verify external account setup separately. |

Extra prototype features include caregiver approval, care journeys, structured labs/trends, pre-visit summaries and Urdu sample greetings. Preserve their source, but keep them outside the handbook critical path. Payments, telemedicine, ABHA, multi-branch hospitals and free-form Telugu/Hindi AI remain excluded. Do not add OCR, voice, EMR, SMS or billing providers merely because the earlier deck plan mentions them.

## Prioritized findings

These are observed implementation gaps, not claims of a demonstrated breach in the managed hosting platform.

1. **P0 — Production foundation diverges.** E1–E3. Owner isolation is not clinic membership/RLS. Only two aggregate tables exist instead of the 21 domain tables. India residency, backups and storage controls are unverified. All authenticated owners receive admin authority. A standalone deployment must not trust the identity headers without the platform's verified trust boundary.
2. **P0 — No live messaging safety pipeline.** E7. Ingress is intentionally disabled; no raw webhook storage, provider deduplication, outbox, receipt processing, quiet hours, send caps or jobs exist. Keep ingress disabled until the complete gateway and sender controls pass tests.
3. **P1 — Shared-family identity conflicts directly with D4.** E4. A second patient on an existing phone receives 409. State has no DOB or duplicate-merge lineage. Rebuild identity around patient ID; index but never uniquely constrain phone.
4. **P1 — Slot validity is incomplete.** E5. Slots are hard-coded, including Sundays despite seeded Mon–Sat clinic hours. Same-day elapsed slots can be booked. No leave, break, configurable duration or database interval exclusion exists. Aggregate CAS prevents some races but does not meet the required normalized transaction/exclusion proof.
5. **P1 — Emergency handling does not take precedence.** E6. Nonconsented patients return before emergency detection. The reply lacks the required 108 and clinic number. Only selected English phrases are recognized; staff alerts are internal records, not monitored delivery.
6. **P1 — Staff replies bypass the 24-hour check.** E6–E7. `reply` calls `emit()` without checking last inbound; `canSend()` is unused by the application flow. This currently produces previews, not external sends. A production sender must enforce policy independently of UI.
7. **P1 — Sensitive read permissions are absent.** E3/E9. GET returns the full workspace including all plans, messages and reports. Domain write restrictions cannot provide front-desk clinical read restrictions or doctor-own-patient reporting. Admin prescription entry also conflicts with the handbook matrix.
8. **P1 — Conversations cannot expire correctly.** E6. Sessions have no timestamps or lockout state. Booking can be started for one date and confirmed after that date becomes invalid; chat rescheduling does not revalidate date range at final confirmation. Restart and timeout tests are required.
9. **P1 — Slips are not implemented.** E6/E9. Record requests safely create a verification task but no visits/slips, PDF upload, signed links, DOB check, three-attempt lock or staff lockout alert exists.
10. **P1 — Medication prototype does not schedule medication reminders.** E8. Snooze only records a state; no 30-minute resend, grouping, occurrence jobs or end-date completion worker exists. Date guards reject expired acknowledgments, but expired plans remain `active` in state.
11. **P1 — Audits/reports cannot support the pilot.** E10. Action history is mutable and capped at 1,000. Reads/exports are not independently logged. Insights uses current arrays, not durable events, baseline comparisons or delivery/cost receipts.
12. **P2 — Recovery and operational checks missing.** E9/E11–E13. No offline banner/reconnect flow, durable form recovery on auth expiry, full translations, Sentry, uptime checker, backup drill, retention jobs, runbook, load evidence or staging UAT sign-offs.

## Handbook sections: coverage and disposition

| Section | Audit result |
| --- | --- |
| Start here | Reusable portions of staff booking and patient simulator; none of the external patient delivery journeys is complete. MVP exclusions retained. Dev A/Dev B/Sai are proposed ownership roles, not evidence of configured team access. |
| Tech stack/environment | Material divergence as above. Local/staging/prod Mumbai projects, Meta test recipients, Sentry and shared vault require external verification. Current `.env.example` lacks Supabase, LLM, Sentry and signed-link settings. |
| Week 0 | Repo and sample persistence exist. No evidence of the three Supabase projects, two local Meta round trips, shared vault, team working agreement or reviewed T1.5/T1.2 PRs. Use this as a new environment gate. |
| Architecture/repository | Existing compact pilot is not prescribed monorepo. Preserve it while building `apps/api`, `apps/dashboard`, `packages/shared`, `packages/templates`, `supabase/migrations` and `docs/runbook.md`. |
| Database | All 21 normalized handbook tables are missing as SQL tables. Some entities exist inside JSON. No clinic FKs/RLS, append-only controls, interval exclusion, shared-phone index, private buckets or signed URLs. CSV lists each table separately. |
| WhatsApp | HMAC/window helpers are reusable primitives only. All gateway rules, five message payload types, seven templates in three languages, receipts, normalization/failure mapping and quiet hours still need integrated evidence. |
| API/conversations | None of the handbook `/api/v1` endpoints or `/health` exists at its specified path. Some equivalent pilot commands exist. `/api/webhooks/whatsapp` differs from `/webhooks/whatsapp` and returns 503. State coverage is partial; CSV lists every endpoint and state. |
| Roles/screens | All four production roles require server membership enforcement. Several screens are reusable; login, staff management, super admin, formal adherence and complete reports are absent. CSV lists all 16 permission rows and 13 screens. |
| Sprint backlog | All 55 tickets individually mapped in CSV with evidence and closing work. Partial implementation never means accepted on staging. |
| Errors | All 26 scenarios individually mapped in CSV. `DomainError` has HTTP status/message but no stable handbook error code. No centralized translated error catalog or external-call timeout/retry policy. |
| Security | Zod command validation, owner-scoped parameterized SQL, ignored env files and headers are useful. All-table RLS, authenticated clinic roles, private documents, audit reads, 30-minute inactivity and telemetry redaction are missing/unverified. No claim of legal certification is made. |
| Performance/retention | No measured handbook target. App's count caps are not retention. All eight performance measures and seven retention rows need evidence. |
| Testing | Pilot unit/API suite exists, using Node's test runner. No Vitest coverage report, pgTAP/per-table RLS tests, Playwright, real test-number UAT or mock-sender load simulation. Twenty UAT scripts remain unaccepted. |
| Workflow/definition of done | No CI workflow or observed Actions run. Branch protection absent on observed main. Reviews, staging demos, weekly cadence and ticket-by-ticket acceptance records are not established by source presence. |
| Decision log | D1/D3/D4/D7/D8/D9 differ or lack implementation. D2 has an unused direct-API primitive. D5 uses deterministic menus/FAQ-like clinic fields; no FAQ LLM. D6 lacks flags. Any deviation from settled decisions needs a recorded product-owner decision. |
| Business dependencies/questions | No supplied evidence of approved wording, clinic samples, pilot prescription format, verified production number, approved templates or walkthrough availability. These do not block local/mock/test-number development. They gate specific copy/clinical/production milestones. |

## Resolve handbook ambiguities before coding the affected behavior

1. Opening says five sprints/about ten weeks; backlog says six sprints/twelve weeks and release candidate week 13. Plan against six build/hardening stages after a short alignment gate; dates are forecasts, not commitments.
2. Header says every table carries `clinic_id`, but several displayed table column lists omit it, notably `webhook_raw`. Use explicit tenant fields on domain tables. Decide how unroutable raw payloads are stored briefly without creating cross-clinic exposure.
3. `message_log` is described as insert-only for app code while status callbacks must update delivery state. Keep immutable message/receipt events and derive status, or define a narrow audited worker-only transition path. Do not grant broad update permission.
4. Architecture says workers go through API, while pg-boss jobs run inside the central backend. Prefer shared server-only application services within that service; confirm whether literal worker HTTP calls are intended.
5. Consent must precede ordinary sends, but consent-request messages and STOP confirmations require controlled exceptions. Define a small allowed-kind policy; never use a blanket consent bypass.
6. Medication Stop appears both as stopping a course and stopping reminders. Decide scope for grouped medicines and retain distinct global STOP. Record response semantics and clinician visibility.
7. Resolve front-desk prescription access through an explicit default-deny clinic setting. Add a separate super-admin identity model and reason-required audit semantics.
8. Retention periods are proposed and need Sai's decision. Resolve archival/deletion versus append-only guarantees and patient deletion versus retained clinical records.
9. Seven listed templates do not include the approved generic fallback, token-next message or doctor summary. Decide approved template contracts and language variants before implementing outside-window sends.
10. Preserve extra clinician/patient medicine review gates unless a documented product decision changes them. They are useful safeguards beyond the handbook's entry flow.

## Completion boundary

This review changes documentation only. It does not migrate data, enable messaging, configure paid accounts, alter hosting, publish the application, or certify production readiness. Detailed staged work is in `HANDBOOK-COMPLETION-PLAN.md`. Live clinic use remains gated on the handbook's tested workflows and operational evidence.
