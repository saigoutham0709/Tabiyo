# Tabiyo completion plan against the development handbook

Baseline: `75afe576f063280b3d9637a3be674cfd4889f549`. Review: 2 November 2026. Scope: the 24 October handbook MVP, including all 55 tickets and the cross-cutting gates in `HANDBOOK-REQUIREMENTS.csv`.

Execution update: development-resource ownership is restricted to **admin@catalystintelligence.in**. Cloud setup remains pending by user request. Follow `DEVELOPMENT-EXECUTION.md` for the sequential phase gates and `DEVELOPMENT-STATUS.md` for current verified work. The audit/CSV remain the historical baseline; they do not automatically mark later code complete.

## Approach and ownership

Continue in https://github.com/Ritish017/Tabiyo. Preserve the synthetic pilot as a reference and reuse its visual design, components, tested booking transition rules and clinician/patient review gates. Replace production persistence, auth and messaging boundaries in small ticket-linked changes. Do not rewrite every screen before building the backend foundation.

Target structure:

```text
apps/api/src/{whatsapp,conversation,appointments,patients,documents,prescriptions,faq,jobs,common}
apps/dashboard/                 # Next.js App Router, Tailwind
packages/shared/                # types and Zod contracts
packages/templates/             # approved names and en/te/hi strings
supabase/migrations/            # normalized schema, constraints and RLS
supabase/seed.sql               # demo clinic, 2 doctors, 10 fake patients
docs/runbook.md
```

Use the handbook roles: Dev A owns API/gateway/jobs/conversation/FAQ/monitoring; Dev B owns schema/RLS/dashboard/documents/reports; Sai owns product decisions, approved language, clinic coordination and the business track. Actual assignees are not assumed. The other developer reviews each PR. This plan assigns work; it does not dispatch workers or contact anyone.

Use six approximately two-week stages after a 2–3 working-day alignment gate. This is an initial planning envelope for two developers, subject to capacity and actual throughput. The handbook's 55 ticket estimates sum to 109.5 developer-days; two part-time developers' available capacity must be checked against that total. Do not promise a fixed delivery date. Re-estimate after Stage 1. Build locally and against the Meta test number; production verification is a final go-live dependency. If needed, the handbook allows medication reminders to follow initial pilot start, but the full application remains incomplete until Stage 4 passes.

## Stage 0 — Lock the baseline and acceptance contract

Duration: 2–3 working days. Depends on: this audit. Owner: both developers; Sai decides product ambiguities.

Deliverables:

- Confirm handbook is scope authority; record the ten ambiguities in the audit with decisions/owners. Keep excluded features out of the MVP.
- Establish the monorepo migration plan and an explicit synthetic-pilot boundary. Keep existing D1 demo data synthetic; no real-record migration is assumed.
- Reproduce baseline tests, lint/type/build checks; resolve existing failures before relying on them as CI gates.
- Define trusted auth boundary, clinic/super-admin membership model, database schema, events, error codes and outbound policy contracts.
- Create a ticket evidence ledger using the CSV. Each ticket needs implementation reference, automated check, staging demo, reviewer and unresolved risks.
- Assign environment setup from Week 0: dev/staging/prod Mumbai projects, test app/recipients, vault and alert destinations. Verify account configuration through the authorized accounts when available.

Exit gate: reviewed architecture/decision record; every handbook requirement has an owner/stage; reproducible baseline and clear recorded blockers. No business verification is required to start the code foundation.

## Stage 1 — Secure platform and first real test-number message

Handbook: T1.1–T1.13. Owners: Dev A and Dev B as specified in handbook.

Build sequence:

1. Add Fastify service, Next.js dashboard workspace and shared Zod/error/template packages. Preserve existing hosting files until their replacement path is tested; do not republish the pilot as a side effect.
2. Add all normalized tables and tenant relationships, active staff membership and role resolution. Use Supabase Mumbai and private buckets. Seed exactly the required demo data; implement `merged_into` and nonunique shared-phone indexing from the start.
3. Implement Supabase phone OTP, protected dashboard, default-deny server permissions and 30-minute inactivity. Add RLS and isolation tests per table, plus service-role tenant checks and storage-path tests.
4. Implement patient create/search/edit and append-only versioned consent. Add clinic flags and immutable event/audit emission contracts.
5. Build raw-body HMAC webhook verification, phone-ID routing, durable intake, raw retention and deduplication. Acknowledge after durable storage/enqueue, before heavy work, within the handbook target.
6. Implement mock and real sender adapters behind one transactional outbox. Worker claims/reclaims jobs, rechecks consent, exceptions, flags, quiet hours, daily cap, window/template policy and retries. Record provider acceptance separately from delivery/read receipts.
7. Implement all five send types and receipt transitions. Add timeout/error mapping, idempotency tests, signature abuse alert threshold, cleanup and `/health`. Wire CI and staging-on-main deployment with fake data.

Exit gate:

- Clinic A staff cannot access clinic B through API, direct user-scoped SQL or storage; every table has a test.
- Production API derives role/clinic from authenticated membership; front desk cannot read protected clinical fields by default.
- Same mobile returns two distinct patients; consent history persists; global STOP prevents subsequent ordinary sends.
- One real incoming message on the test number yields one durable inbound event and one permitted reply. All send types and receipts have recorded test-phone evidence.
- Duplicate intake/outbox execution produces one business mutation and one logical delivery. Crash-after-send ambiguity has an explicit reconciliation/review policy; do not claim end-to-end exactly-once delivery without proof.
- CI lint/type/test checks pass and a staging deployment is recorded. No live health data.

## Stage 2 — Complete appointments and WhatsApp booking

Handbook: T2.1–T2.10. Depends on Stage 1 auth/schema/outbox/events.

Build doctor schedule/break/leave/slot duration models. Store UTC intervals, display IST and add database exclusion constraints. Revalidate availability and current time at final booking/reschedule commit. Return next three available alternatives on conflict. Apply the same services to dashboard and conversation actions.

Migrate Today/New appointment screens and patient search/picker. Implement allowed status transitions, audit/events and leave-change notifications. Add durable conversation states, 30-minute timeout/recovery, global en/te/hi commands, emergency precedence and shared-family selection. Implement patient upcoming appointments, explicit reschedule/cancel confirmation and confirmation outbox transactions.

Complete feature-flagged walk-in queue with add/call/skip and next-patient notification. Its optional sprint timing is not permission to mark the full MVP complete without it.

Exit gate: concurrent DB requests yield exactly one booking; hours/breaks/leaves/past instants are rejected; atomic reschedule preserves the original on failure; family selection prevents cross-patient disclosure; phone and actual test-number booking appear in the same clinic dashboard. Measure phone booking under 30 seconds and verify mobile/desktop shortcuts. All state transitions emit the expected audit/events once.

## Stage 3 — Reminders, secure slips, profiles and staff inbox

Handbook: T3.1–T3.9. Depends on Stage 2 appointment services and Stage 1 storage/outbox.

Implement durable 24-hour/2-hour reminder jobs, reschedule cancellation and stale-job policy. Recheck patient/appointment/flags at execution. Apply quiet hours and 80%/100% cap alerts. Generate or upload validated PDF/JPG/PNG slips, max 10 MB; store privately under clinic/patient paths. Add visits, slip-ready messages, DOB step-up, three-failure one-hour lockout, alerts, five-minute signed URLs and authenticated access audits.

Complete inbox list/open/assign/resolve, patient context, last-inbound timer and blocked-outside-window replies with approved template alternative. Complete patient profile, mobile search, CSV normalization/error reporting, duplicate review and transactional merge preserving clinical/consent/message history.

Exit gate: reminders queued within one minute, stale and cancelled jobs behave correctly after restart; expired links fail; wrong DOB locks for one hour; no cross-clinic/family document access; staff reply after 24 hours is blocked at API and sender. Import 500 rows with error report and prove merge history retention. Real test-phone slip journey passes.

## Stage 4 — Medication reminders and grounded FAQ

Handbook: T4.1–T4.8. Depends on patient/visit/outbox/jobs/flags/roles.

Migrate doctor-only prescription entry into structured medicine/dose/timing/food/duration fields and normalized schedules. Retain explicit clinician review and patient confirmation. Build deterministic occurrence groups: three morning medicines create one patient message. Add signed callback IDs, authorized Taken/Later/Stop transitions, one 30-minute Later retry, end-date auto-completion, duplicate-response handling and per-medicine adherence denominator.

Build admin FAQ CRUD and a strict clinic-only LLM adapter behind `ai_faq`. Send only current clinic FAQ plus question. Enforce timeout at eight seconds, unknown-answer handoff, fixed medical-advice refusal and emergency response with 108/clinic phone and prompt staff alert. Emergency checks must run before ordinary consent/state dispatch. Define and test carefully bounded response exceptions.

Exit gate: grouped dose UAT and Stop/Later/end-date/replay cases pass; disabling `med_reminders` hides screens and cancels/blocks sends; doctor/admin views reflect taken/missed/stopped correctly. FAQ adversarial/out-of-scope/timeout/medical/emergency fixtures pass; no patient data from another context reaches the model. Real test-number journeys pass in each approved language.

## Stage 5 — Clinic operations, languages and reliability

Handbook: T5.1–T5.9. Depends on stable events and domain models.

Build no-show/baseline, reminder, confirmation and cost reports exclusively from events, with doctor-own-patient restrictions, date filters and CSV export. Add clinic onboarding, hours/holidays/doctors/FAQ/QR, staff invite/deactivate and audited reason-required super-admin feature management. Implement complete English/Telugu/Hindi menus, commands, errors and template contracts; native speakers review operational language.

Add Sentry redaction, uptime monitoring and staffed alert paths; prove a forced incident reaches the team within five minutes. Implement patient-specific export/delete, lifecycle/retention jobs and a documented backup restore to a fresh Mumbai project. Build doctor-summary schedules behind its flag. Complete runbook for all error codes and known provider failures.

Exit gate: report numbers match a fixed event fixture; new clinic needs no SQL access; every translated bot string is reviewed; patient export/delete is authorized and audited; retention removes/archives only eligible data and logs decisions. Restore meets four hours. Summary and cap alerts have delivery evidence. Region, backup, secrets and environment settings are verified, not inferred from source.

## Stage 6 — Full acceptance, hardening and release candidate

Handbook: T6.1–T6.6. Depends on all prior gates; both developers and Sai.

- Run all 20 UAT scripts on staging using actual phones/test number. Record date, tester, pass/fail and evidence; include native Telugu/Hindi speakers.
- Exercise all 26 error scenarios and stable translated error codes. Verify retries at 1/5/15 minutes and failure escalation, template fallback, leave notifications, lockouts, offline recovery and auth-form restoration.
- Run mock-sender load for 10 clinics × 50 patients/day × 7 simulated days. Record expected vs actual mutations/jobs/messages, duplicates, dead letters, p95 response times and restart recovery.
- Measure all eight performance/SLO targets, distinguishing a short load test from monthly uptime evidence. Document a monitoring window for 99.5% uptime.
- Complete security review, per-table RLS, sensitive read audits, storage isolation, dependency/secret review, staff deactivation and incident/restore drills. Fix blockers before the tag.
- Pilot front desk books 20 fake patients without help. Verify mobile, keyboard, accessibility, session expiry and poor-network behavior.
- Produce reviewed `v0.1.0` release candidate, reproducible deployment, environment-only number switch, rollback instructions and on-call contacts. Production deploys from a reviewed tag.

Exit gate: all CSV requirements have passing acceptance evidence or an explicit product-approved scope change. No silent acceptance waivers. If medication is deferred for an initial clinic pilot, release notes must say so; the full handbook app is still unfinished.

Production gate: authorized clinic onboarding, final consent/template language, approved utility templates, clinic-controlled verified number and retention decisions are ready. Keep these distinct from test-number development completion.

## First concrete development batch

Start Stage 0 and the first part of Stage 1, not more prototype features.

1. Create an architecture/ambiguity decision record and add monorepo scaffolding without deleting the current pilot.
2. Add the first Supabase migration for clinics/staff/doctors/patients/consents, shared-family identity and tenant-safe foreign keys; add local seed.
3. Add Fastify `/health` and authenticated `/api/v1/me` with default-deny role resolution.
4. Prove clinic isolation and shared-number behavior through database/API tests; wire checks into CI.

Finish line: reproducible local fake-data stack, two clinic identities demonstrably isolated, shared-phone patients accepted, checks green. Then continue the remaining foundation tickets. Do not enable the old webhook or connect real patients to the D1 prototype.
