# Local scheduler and technical retention

This increment uses pg-boss 12.38.0 with explicit lifecycle control. `createMockScheduler()` composes the existing SQL gateway and delivery workers with `RecordingMockSender`. Importing the module starts nothing. The API entry point does not start this scheduler, open webhook ingress, connect a queue database, or enable a live sender. Cloud setup remains pending under `admin@catalystintelligence.in`.

## Execution contract

- Queues: `tabiyo.delivery.tick`, `tabiyo.gateway.tick`, `tabiyo.cleanup.tick`. Payloads must be empty objects. Patient details, provider payloads and secrets remain outside the job tables.
- Delivery and gateway fallback schedules run every minute. Cleanup runs daily at 03:15 Asia/Kolkata. Schedules persist in PostgreSQL. Startup wakes delivery and gateway immediately; `wake(kind)` supports explicit wake after a committed write/intake.
- Queue policy `stately` coalesces queued work and limits active control jobs. Each process registers one worker per queue. Each drain starts at most 25 operations, stopping between operations after 20 seconds. Limits can be reduced or raised to 100 operations/30 seconds. This is a cooperative budget, not cancellation of an active SQL transaction.
- Control-job failures retry three times with 30-second exponential backoff. Jobs expire after 120 seconds of activity; unstarted control jobs have a one-day retention window; completed job records have a seven-day deletion setting. SQL leases and durable acceptance evidence remain authoritative if a control job expires or restarts.
- Domain retries remain separate: the outbox controls its send attempts, and raw intake controls its processing attempts. A queue retry does not reset either ledger or turn an uncertain send into a retryable send.
- Shutdown stops new drain iterations and asks pg-boss to wait for active work, with a 30-second timeout. A process crash still requires SQL lease recovery. No permanent runner is installed by this change.
- Handler exceptions are replaced with `SCHEDULER_HANDLER_FAILED` before pg-boss persists them. The optional observer receives only static codes and queue kinds. External alert delivery and backlog monitoring remain pending.

Minute polling alone cannot establish the handbook's sub-three-second bot response target. Production must wire immediate wake after committed intake, verify fallback behavior, and measure end-to-end latency. The local demo explicitly invokes wake; the default API remains disconnected.

## Retention contract

Migration `20261102162200_bounded_retention_jobs.sql` adds service-only maintenance operations. Each category processes at most 500 rows per call with `FOR UPDATE SKIP LOCKED`. Scheduled cleanup calls raw cleanup and then technical retention. Their transactions are independent and safe to repeat if the second operation fails.

| Data | Local maintenance rule | Evidence preserved |
| --- | --- | --- |
| Raw webhook payloads | Delete after seven days, excluding active leases | Incoming message IDs, consent proof, clinic audit, expired-pending alert |
| Terminal outbox payloads | Delete sent/failed/skipped rows after 90 days without activity | Immutable message history and historical outbox UUID |
| Active/uncertain outbox | Keep regardless of age | Lease/reconciliation and mock acceptance proof |
| Mock acceptance payloads | Delete only alongside an eligible terminal outbox row | Accepted message history |
| API replay responses | Redact after 90 days | Request key, hash, actor, operation and patient UUID prevent duplicate creation |
| Unmatched receipts | Delete after 90 days only without message, outbox or mock acceptance evidence | All matched receipt history |
| Message body previews | Clear after one year | Message metadata, IDs, consent links and receipt events |
| Resolved staff alerts | Delete 90 days after recorded resolution | Audit and event history; open and legacy undated alerts remain |
| Signature counters | Delete after seven days | Count-only maintenance evidence |
| Maintenance metadata | Delete after 90 days | Current count-only execution record |

The outbox age starts from last activity, conservatively initialized at migration time for existing rows. Recent processing of an old row resets its window. This intentionally preserves more history than deleting solely by creation time. Message history retains the outbox UUID without a foreign key to the expiring queue row. Late receipts still match immutable message history, create deduplicated events, preserve read/delivered precedence and avoid reopening an expired alert for an already-recorded failure.

Expired API responses return HTTP 409 `REQUEST_REPLAY_EXPIRED`, even before scheduled redaction. Search patient records before making a new create request. Never automatically replace an expired request key. Tombstones are retained pending a reviewed patient-deletion policy.

Seven-day raw, 90-day outbox and one-year body rules follow the handbook's proposed periods. Replay, orphan receipt, alert and maintenance periods are local engineering defaults requiring operational review. Clinical files, consent proof, three-year events/audit archiving, backup deletion and hosted storage lifecycle remain pending final policy approval and provider setup. Full T5.9 acceptance is not claimed.

## Verification and limits

Run `npm test`, `npm run demo:scheduler`, `npm run lint`, `npm run typecheck` and `npm run build`. The scheduler demo uses actual pg-boss and migrated PGlite stores to accept one synthetic mock delivery, process STOP and execute maintenance. It sends zero physical messages and closes its workers and database before exiting.

Tests exercise real pg-boss worker execution, persisted schedules, clock-driven cron, retry recovery, restart between library instances, cooperative drain limits and graceful shutdown. PostgreSQL tests verify maintenance grants, boundaries, replay tombstones, historical callbacks, alert behavior and bounded batches. Test scripts serialize database fixtures and limit WebAssembly compilation to avoid local memory exhaustion; SQL checks remain enabled.

PGlite uses a single connection. This does not prove full Supabase behavior, real multi-process contention, process/disk recovery, provider delivery, measured latency or staging acceptance. No account setup, deployment, listener or live messaging is enabled.

Official references: [pg-boss database backends](https://pgboss.io/database-backends), [scheduling](https://pgboss.io/api/scheduling), [workers](https://pgboss.io/api/workers).
