/** Fail closed until an India-hosted production gateway and tenant/number mapping are provisioned. */
export async function GET(){return Response.json({error:'WhatsApp is not connected in this private pilot.'},{status:503});}
export async function POST(){return Response.json({error:'WhatsApp is not connected in this private pilot.'},{status:503});}
