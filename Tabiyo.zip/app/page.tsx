import Tabiyo from './tabiyo';
export default function Page(){return <Tabiyo/>;}
