import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Tabiyo · Care, every day',description:'A calmer clinic. Care that continues on WhatsApp.',icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body>{children}</body></html>;}
