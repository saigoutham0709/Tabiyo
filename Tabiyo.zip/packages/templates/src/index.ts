export type SupportedLanguage = 'en' | 'te' | 'hi';

export type TemplateName =
  | 'consent_request'
  | 'appointment_confirmed'
  | 'appointment_reminder'
  | 'appointment_changed'
  | 'visit_slip_ready'
  | 'medication_reminder'
  | 'follow_up_due';

export type GlobalCommand = 'menu' | 'stop' | 'start' | 'help';

export interface TemplateButton {
  id: string;
  title: string;
}

export interface TemplateDefinition {
  name: TemplateName;
  language: SupportedLanguage;
  body: string;
  buttons: TemplateButton[];
}

export const TEMPLATES: Record<TemplateName, Record<SupportedLanguage, TemplateDefinition>> = {
  consent_request: {
    en: {
      name: 'consent_request',
      language: 'en',
      body: 'Namaste from {{clinic_name}}. We would like to send you appointment confirmations, reminders, prescription guidance, and visit slips on WhatsApp. Please tap Agree below to receive these care updates.',
      buttons: [
        { id: 'consent:agree', title: 'Agree' },
        { id: 'consent:not_now', title: 'Not now' },
      ],
    },
    te: {
      name: 'consent_request',
      language: 'te',
      body: '{{clinic_name}} నుండి నమస్తే. మేము మీకు వాట్సాప్‌లో అపాయింట్‌మెంట్ వివరాలు, రిమైండర్‌లు, ప్రిస్క్రిప్షన్ సూచనలు మరియు విజిట్ స్లిప్పులను పంపాలనుకుంటున్నాము. ఈ అప్‌డేట్‌లను అందుకోవడానికి దయచేసి క్రింద ఉన్న సమ్మతి పై నొక్కండి.',
      buttons: [
        { id: 'consent:agree', title: 'సమ్మతి' },
        { id: 'consent:not_now', title: 'ఇప్పుడు కాదు' },
      ],
    },
    hi: {
      name: 'consent_request',
      language: 'hi',
      body: '{{clinic_name}} की ओर से नमस्ते। हम आपको व्हाट्सएप पर अपॉइंटमेंट की जानकारी, रिमाइंडर, दवा के निर्देश और विजिट स्लिप भेजना चाहते हैं। ये अपडेट प्राप्त करने के लिए कृपया नीचे सहमत पर टैप करें।',
      buttons: [
        { id: 'consent:agree', title: 'सहमत' },
        { id: 'consent:not_now', title: 'अभी नहीं' },
      ],
    },
  },
  appointment_confirmed: {
    en: {
      name: 'appointment_confirmed',
      language: 'en',
      body: 'Hello {{patient_name}}, your appointment with {{doctor_name}} at {{clinic_name}} is confirmed for {{date}} at {{time}}.\n\nReply Reschedule to change or Cancel to cancel.',
      buttons: [
        { id: 'appointment:reschedule', title: 'Reschedule' },
        { id: 'appointment:cancel', title: 'Cancel' },
      ],
    },
    te: {
      name: 'appointment_confirmed',
      language: 'te',
      body: 'నమస్తే {{patient_name}}, {{clinic_name}}లో {{doctor_name}} గారితో మీ అపాయింట్‌మెంట్ {{date}}న {{time}}కి నిర్ధారించబడింది.\n\nసమయం మార్చడానికి రీషెడ్యూల్ లేదా రద్దు చేయడానికి రద్దు చేయి అని తెలియజేయండి.',
      buttons: [
        { id: 'appointment:reschedule', title: 'రీషెడ్యూల్' },
        { id: 'appointment:cancel', title: 'రద్దు చేయి' },
      ],
    },
    hi: {
      name: 'appointment_confirmed',
      language: 'hi',
      body: 'नमस्ते {{patient_name}}, {{clinic_name}} में {{doctor_name}} के साथ आपका अपॉइंटमेंट {{date}} को {{time}} बजे कन्फर्म हो गया है।\n\nबदलने के लिए पुनर्निर्धारित या रद्द करने के लिए रद्द करें रिप्लाई करें।',
      buttons: [
        { id: 'appointment:reschedule', title: 'पुनर्निर्धारित' },
        { id: 'appointment:cancel', title: 'रद्द करें' },
      ],
    },
  },
  appointment_reminder: {
    en: {
      name: 'appointment_reminder',
      language: 'en',
      body: 'Reminder: Hello {{patient_name}}, you have an upcoming appointment with {{doctor_name}} on {{date}} at {{time}}. Please let us know if you are coming.',
      buttons: [
        { id: 'appointment:confirm', title: 'Confirm' },
        { id: 'appointment:reschedule', title: 'Reschedule' },
      ],
    },
    te: {
      name: 'appointment_reminder',
      language: 'te',
      body: 'రిమైండర్: నమస్తే {{patient_name}}, మీకు {{date}}న {{time}}కి {{doctor_name}} గారితో అపాయింట్‌మెంట్ ఉంది. మీరు వస్తున్నట్లు నిర్ధారించండి లేదా సమయం మార్చండి.',
      buttons: [
        { id: 'appointment:confirm', title: 'నిర్ధారించు' },
        { id: 'appointment:reschedule', title: 'రీషెడ్యూల్' },
      ],
    },
    hi: {
      name: 'appointment_reminder',
      language: 'hi',
      body: 'रिमाइंडर: नमस्ते {{patient_name}}, आपका {{date}} को {{time}} बजे {{doctor_name}} के साथ अपॉइंटमेंट है। कृपया आने की पुष्टि करें या समय बदलें।',
      buttons: [
        { id: 'appointment:confirm', title: 'कन्फर्म करें' },
        { id: 'appointment:reschedule', title: 'पुनर्निर्धारित' },
      ],
    },
  },
  appointment_changed: {
    en: {
      name: 'appointment_changed',
      language: 'en',
      body: 'Hello {{patient_name}}, your appointment with {{doctor_name}} has been updated to {{new_date}} at {{new_time}}.',
      buttons: [],
    },
    te: {
      name: 'appointment_changed',
      language: 'te',
      body: 'నమస్తే {{patient_name}}, {{doctor_name}} గారితో మీ అపాయింట్‌మెంట్ {{new_date}}న {{new_time}}కి మార్చబడింది.',
      buttons: [],
    },
    hi: {
      name: 'appointment_changed',
      language: 'hi',
      body: 'नमस्ते {{patient_name}}, {{doctor_name}} के साथ आपका अपॉइंटमेंट {{new_date}} को {{new_time}} बजे अपडेट कर दिया गया है।',
      buttons: [],
    },
  },
  visit_slip_ready: {
    en: {
      name: 'visit_slip_ready',
      language: 'en',
      body: 'Hello {{patient_name}}, your visit slip for {{date}} is ready. Tap Get slip below to securely view or download your slip.',
      buttons: [
        { id: 'slip:get', title: 'Get slip' },
      ],
    },
    te: {
      name: 'visit_slip_ready',
      language: 'te',
      body: 'నమస్తే {{patient_name}}, {{date}} నాటి మీ విజిట్ స్లిప్ సిద్ధంగా ఉంది. మీ స్లిప్‌ను సురక్షితంగా చూడటానికి క్రింద ఉన్న స్లిప్ పొందండి పై నొక్కండి.',
      buttons: [
        { id: 'slip:get', title: 'స్లిప్ పొందండి' },
      ],
    },
    hi: {
      name: 'visit_slip_ready',
      language: 'hi',
      body: 'नमस्ते {{patient_name}}, {{date}} की आपकी विजिट स्लिप तैयार है। सुरक्षित रूप से देखने या डाउनलोड करने के लिए नीचे स्लिप प्राप्त करें पर टैप करें।',
      buttons: [
        { id: 'slip:get', title: 'स्लिप प्राप्त करें' },
      ],
    },
  },
  medication_reminder: {
    en: {
      name: 'medication_reminder',
      language: 'en',
      body: 'Hi {{patient_name}}, it is time for your {{time_of_day}} medications:\n{{medicine_list}}\n\nPlease select an action below:',
      buttons: [
        { id: 'dose:taken', title: 'Taken' },
        { id: 'dose:later', title: 'Remind later' },
        { id: 'dose:stop', title: 'Stop' },
      ],
    },
    te: {
      name: 'medication_reminder',
      language: 'te',
      body: 'నమస్తే {{patient_name}}, మీ {{time_of_day}} మందులు తీసుకునే సమయం అయింది:\n{{medicine_list}}\n\nదయచేసి క్రింది ఎంపికలలో ఒకదాన్ని ఎంచుకోండి:',
      buttons: [
        { id: 'dose:taken', title: 'తీసుకున్నాను' },
        { id: 'dose:later', title: 'తర్వాత గుర్తుచేయి' },
        { id: 'dose:stop', title: 'ఆపు' },
      ],
    },
    hi: {
      name: 'medication_reminder',
      language: 'hi',
      body: 'नमस्ते {{patient_name}}, आपकी {{time_of_day}} की दवाओं का समय हो गया है:\n{{medicine_list}}\n\nकृपया नीचे दिए गए विकल्पों में से चुनें:',
      buttons: [
        { id: 'dose:taken', title: 'ले ली' },
        { id: 'dose:later', title: 'बाद में याद दिलाएं' },
        { id: 'dose:stop', title: 'रोकें' },
      ],
    },
  },
  follow_up_due: {
    en: {
      name: 'follow_up_due',
      language: 'en',
      body: 'Hello {{patient_name}}, your follow-up visit with {{doctor_name}} is due on {{date}}. Tap Book now to schedule your appointment.',
      buttons: [
        { id: 'follow_up:book', title: 'Book now' },
      ],
    },
    te: {
      name: 'follow_up_due',
      language: 'te',
      body: 'నమస్తే {{patient_name}}, {{doctor_name}} గారితో మీ ఫాలో-అప్ చెకప్ {{date}}న జరగాల్సి ఉంది. అపాయింట్‌మెంట్ బుక్ చేయడానికి ఇప్పుడే బుక్ చేయండి పై నొక్కండి.',
      buttons: [
        { id: 'follow_up:book', title: 'ఇప్పుడే బుక్ చేయండి' },
      ],
    },
    hi: {
      name: 'follow_up_due',
      language: 'hi',
      body: 'नमस्ते {{patient_name}}, {{doctor_name}} के साथ आपका फॉलो-अप चेकअप {{date}} को होना है। अपॉइंटमेंट बुक करने के लिए अभी बुक करें पर टैप करें।',
      buttons: [
        { id: 'follow_up:book', title: 'अभी बुक करें' },
      ],
    },
  },
};

export const GLOBAL_COMMANDS: Record<GlobalCommand, Record<SupportedLanguage, string[]>> = {
  menu: {
    en: ['menu', 'home', 'main menu'],
    te: ['మెనూ', 'మెను', 'హోమ్'],
    hi: ['मेनू', 'मेन्यू', 'होम'],
  },
  stop: {
    en: ['stop', 'unsubscribe', 'opt out', 'cancel updates'],
    te: ['ఆపు', 'వద్దు', 'ఆపివేయి'],
    hi: ['बंद', 'रोकें', 'समाप्त'],
  },
  start: {
    en: ['start', 'restart', 'unstop', 'subscribe'],
    te: ['ప్రారంభించు', 'మొదలుపెట్టు', 'ప్రారంభం'],
    hi: ['शुरू', 'आरंभ', 'प्रारंभ'],
  },
  help: {
    en: ['help', 'human', 'support', 'staff', 'talk to staff', 'talk to clinic', 'agent'],
    te: ['సహాయం', 'సిబ్బంది', 'సహాయకుడు', 'మద్దతు'],
    hi: ['मदद', 'सहायता', 'स्टाफ', 'सपोर्ट', 'बात करें'],
  },
};

export const EMERGENCY_PATTERNS = [
  /chest pain/i,
  /cannot breathe/i,
  /can'?t breathe/i,
  /difficulty breathing/i,
  /shortness of breath/i,
  /severe bleeding/i,
  /bleeding heavily/i,
  /unconscious/i,
  /collapsed/i,
  /fainted/i,
  /suicid/i,
  /heart attack/i,
  /stroke/i,
  /seizure/i,
  /fits/i,
  /emergency/i,
  /poison/i,
  /choking/i,
  // Telugu
  /గుండె నొప్పి/i,
  /రక్తస్రావం/i,
  /స్పృహ తప్పింది/i,
  /శ్వాస ఆడటం లేదు/i,
  /అత్యవసరం/i,
  /ఆత్మహత్య/i,
  // Hindi
  /सीने में दर्द/i,
  /खून बह रहा/i,
  /बेहोश/i,
  /सांस नहीं आ रही/i,
  /सांस लेने में तकलीफ/i,
  /आपातकालीन/i,
  /आत्महत्या/i,
  /दिल का दौरा/i,
];

export const MEDICAL_ADVICE_PATTERNS = [
  /symptom/i,
  /diagnos/i,
  /fever/i,
  /headache/i,
  /stomach pain/i,
  /abdominal pain/i,
  /vomit/i,
  /nausea/i,
  /diarrhea/i,
  /loose motion/i,
  /cough/i,
  /cold/i,
  /flu/i,
  /rash/i,
  /dizz/i,
  /dosage/i,
  /can i take (\d+)/i,
  /double dose/i,
  /change dose/i,
  /increase dose/i,
  /decrease dose/i,
  /missed dose/i,
  /prescribe/i,
  /which tablet/i,
  /which medicine/i,
  /what tablet/i,
  /what medicine should i/i,
  // Telugu
  /జ్వరం/i,
  /తలనెప్పి/i,
  /తల నొప్పి/i,
  /కడుపు నొప్పి/i,
  /వాంతులు/i,
  /దగ్గు/i,
  /రొంప/i,
  /మోతాదు/i,
  /మందు మార్చ/i,
  // Hindi
  /बुखार/i,
  /सिरदर्द/i,
  /सिर दर्द/i,
  /पेट दर्द/i,
  /उल्टी/i,
  /दस्त/i,
  /खांसी/i,
  /जुकाम/i,
  /खुराक/i,
  /दवा बदल/i,
  /दवा की मात्रा/i,
];

export const EMERGENCY_MESSAGES: Record<SupportedLanguage, string> = {
  en: 'EMERGENCY: Do not wait for a chat reply. Call local emergency services (108) immediately or visit the nearest hospital emergency room. Clinic phone: {{clinic_phone}}.',
  te: 'అత్యవసర పరిస్థితి: దయచేసి చాట్ ప్రత్యుత్తరం కోసం వేచి ఉండకండి. వెంటనే స్థానిక అత్యవసర సేవలకు (108) కాల్ చేయండి లేదా సమీపంలోని ఆసుపత్రి అత్యవసర విభాగానికి వెళ్లండి. క్లినిక్ ఫోన్: {{clinic_phone}}.',
  hi: 'आपातकालीन सूचना: कृपया चैट उत्तर की प्रतीक्षा न करें। तुरंत स्थानीय आपातकालीन सेवाओं (108) पर कॉल करें या नजदीकी अस्पताल के आपातकालीन कक्ष में जाएं। क्लिनिक फोन: {{clinic_phone}}.',
};

export const MEDICAL_REFUSAL_MESSAGES: Record<SupportedLanguage, string> = {
  en: 'I cannot provide medical advice, diagnosis, or adjust medication doses. Please consult a qualified doctor for any medical symptoms or dosage changes.\n\nWould you like to book an appointment with our doctor?',
  te: 'నేను వైద్య సలహాలు, రోగ నిర్ధారణ లేదా మందుల మోతాదులను మార్చలేను. ఏవైనా లక్షణాలు లేదా మందుల మార్పుల కోసం దయచేసి వైద్యుడిని సంప్రదించండి.\n\nమీరు మా వైద్యుడితో అపాయింట్‌మెంట్ బుక్ చేసుకోవాలనుకుంటున్నారా?',
  hi: 'मैं चिकित्सीय सलाह, निदान या दवा की खुराक में बदलाव नहीं दे सकता। किसी भी लक्षण या दवा की खुराक में बदलाव के लिए कृपया योग्य डॉक्टर से परामर्श लें।\n\nक्या आप हमारे डॉक्टर के साथ अपॉइंटमेंट बुक करना चाहते हैं?',
};

export const MENU_MESSAGES: Record<SupportedLanguage, { text: string; options: { id: string; label: string }[] }> = {
  en: {
    text: 'Main Menu:\n1. Book appointment\n2. My appointments\n3. Get visit slip\n4. Clinic info\n5. Talk to clinic staff',
    options: [
      { id: 'menu:book', label: '1. Book appointment' },
      { id: 'menu:appointments', label: '2. My appointments' },
      { id: 'menu:slip', label: '3. Get visit slip' },
      { id: 'menu:clinic_info', label: '4. Clinic info' },
      { id: 'menu:handoff', label: '5. Talk to clinic' },
    ],
  },
  te: {
    text: 'ప్రధాన మెనూ:\n1. అపాయింట్‌మెంట్ బుక్ చేయండి\n2. నా అపాయింట్‌మెంట్‌లు\n3. విజిట్ స్లిప్ పొందండి\n4. క్లినిక్ వివరాలు\n5. క్లినిక్ సిబ్బందితో మాట్లాడండి',
    options: [
      { id: 'menu:book', label: '1. అపాయింట్‌మెంట్ బుక్ చేయండి' },
      { id: 'menu:appointments', label: '2. నా అపాయింట్‌మెంట్‌లు' },
      { id: 'menu:slip', label: '3. విజిట్ స్లిప్ పొందండి' },
      { id: 'menu:clinic_info', label: '4. క్లినిక్ వివరాలు' },
      { id: 'menu:handoff', label: '5. క్లినిక్ సిబ్బందితో మాట్లాడండి' },
    ],
  },
  hi: {
    text: 'मुख्य मेनू:\n1. अपॉइंटमेंट बुक करें\n2. मेरे अपॉइंटमेंट\n3. विजिट स्लिप प्राप्त करें\n4. क्लिनिक की जानकारी\n5. क्लिनिक स्टाफ से बात करें',
    options: [
      { id: 'menu:book', label: '1. अपॉइंटमेंट बुक करें' },
      { id: 'menu:appointments', label: '2. मेरे अपॉइंटमेंट' },
      { id: 'menu:slip', label: '3. विजिट स्लिप प्राप्त करें' },
      { id: 'menu:clinic_info', label: '4. क्लिनिक जानकारी' },
      { id: 'menu:handoff', label: '5. क्लिनिक स्टाफ से बात करें' },
    ],
  },
};

export const LANGUAGE_CHOICE_MESSAGE =
  'Please select your preferred language / దయచేసి మీ భాషను ఎంచుకోండి / कृपया अपनी भाषा चुनें:\n1. English\n2. తెలుగు (Telugu)\n3. हिन्दी (Hindi)';

export const DOB_PROMPT_MESSAGES: Record<SupportedLanguage, string> = {
  en: 'For your security, please enter your Date of Birth to verify your identity (Format: YYYY-MM-DD):',
  te: 'మీ భద్రత కోసం, దయచేసి మీ పుట్టిన తేదీని నమోదు చేయండి (ఫార్మాట్: YYYY-MM-DD):',
  hi: 'आपकी सुरक्षा के लिए, कृपया अपनी पहचान सत्यापित करने हेतु अपनी जन्म तिथि दर्ज करें (प्रारूप: YYYY-MM-DD):',
};

export const DOB_FAILED_MESSAGES: Record<SupportedLanguage, string> = {
  en: 'Date of birth did not match. Please try again (Attempt {{attempt}} of 3). Format: YYYY-MM-DD.',
  te: 'పుట్టిన తేదీ సరిపోలలేదు. దయచేసి మళ్ళీ ప్రయత్నించండి (ప్రయత్నం {{attempt}}/3). ఫార్మాట్: YYYY-MM-DD.',
  hi: 'जन्म तिथि मेल नहीं खाई। कृपया पुनः प्रयास करें (प्रयास {{attempt}}/3)। प्रारूप: YYYY-MM-DD.',
};

export const DOB_LOCKED_MESSAGES: Record<SupportedLanguage, string> = {
  en: 'Too many incorrect attempts. For security reasons, visit slip access is locked for 1 hour. Clinic staff have been alerted to assist you.',
  te: 'చాలా తప్పు ప్రయత్నాలు జరిగాయి. భద్రతా కారణాల దృష్ట్యా, విజిట్ స్లిప్ సదుపాయం 1 గంట పాటు తాత్కాలికంగా నిలిపివేయబడింది. మీకు సహాయం చేయడానికి క్లినిక్ సిబ్బందికి సమాచారం అందించబడింది.',
  hi: 'अत्यधिक गलत प्रयास। सुरक्षा कारणों से, विजिट स्लिप पहुंच 1 घंटे के लिए लॉक कर दी गई है। आपकी सहायता के लिए क्लिनिक स्टाफ को सूचित कर दिया गया है।',
};

/** Render template body by replacing {{variable}} placeholders */
export function renderTemplate(
  name: TemplateName,
  language: SupportedLanguage,
  variables: Record<string, string | number> = {}
): string {
  const tpl = TEMPLATES[name]?.[language] ?? TEMPLATES[name]?.en;
  if (!tpl) throw new Error(`Unknown template: ${name}`);
  let text = tpl.body;
  for (const [key, value] of Object.entries(variables)) {
    text = text.replaceAll(new RegExp(`\\{\\{\\s*${key}\\s*\\}\\}`, 'g'), String(value));
  }
  return text;
}

/** Get template buttons for a template in a specific language */
export function getTemplateButtons(name: TemplateName, language: SupportedLanguage): TemplateButton[] {
  const tpl = TEMPLATES[name]?.[language] ?? TEMPLATES[name]?.en;
  return tpl?.buttons ?? [];
}

/** Check if input matches a global command in any supported language */
export function matchGlobalCommand(input: string): GlobalCommand | null {
  const normalized = input.trim().toLowerCase();
  for (const [cmd, langs] of Object.entries(GLOBAL_COMMANDS) as [GlobalCommand, Record<SupportedLanguage, string[]>][]) {
    for (const words of Object.values(langs)) {
      if (words.some(w => w.toLowerCase() === normalized)) {
        return cmd;
      }
    }
  }
  return null;
}

/** Check if an incoming message indicates a medical emergency */
export function isEmergencyMessage(text: string): boolean {
  return EMERGENCY_PATTERNS.some(pattern => pattern.test(text));
}

/** Check if an incoming message is seeking medical advice, diagnosis, or dosage change */
export function isMedicalAdviceQuery(text: string): boolean {
  return MEDICAL_ADVICE_PATTERNS.some(pattern => pattern.test(text));
}

/** Get emergency reply text with clinic phone */
export function getEmergencyReply(language: SupportedLanguage, clinicPhone: string = '+919000000000'): string {
  const msg = EMERGENCY_MESSAGES[language] ?? EMERGENCY_MESSAGES.en;
  return msg.replaceAll('{{clinic_phone}}', clinicPhone);
}

/** Get medical refusal reply text */
export function getMedicalRefusalReply(language: SupportedLanguage): string {
  return MEDICAL_REFUSAL_MESSAGES[language] ?? MEDICAL_REFUSAL_MESSAGES.en;
}
