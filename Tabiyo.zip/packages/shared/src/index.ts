import { z } from 'zod';

export const staffRoleSchema = z.enum(['admin', 'doctor', 'front_desk']);
export const staffSchema = z.object({
  id: z.string().uuid(),
  clinic_id: z.string().uuid(),
  name: z.string().min(1),
  role: staffRoleSchema,
  active: z.literal(true),
});
export const clinicSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1),
  timezone: z.literal('Asia/Kolkata'),
  default_language: z.enum(['en', 'te', 'hi']),
});
export type Staff = z.infer<typeof staffSchema>;
export type Clinic = z.infer<typeof clinicSchema>;
export type StaffContext = { staff: Staff; clinic: Clinic };

export const mobileSchema = z.string().regex(/^\+91[6-9]\d{9}$/);
const birthDateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(value => {
  const parsed = Date.parse(value);
  const clinicToday = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  return Number.isFinite(parsed) && new Date(parsed).toISOString().slice(0, 10) === value && value <= clinicToday;
}, 'Invalid date of birth');
export const patientCreateSchema = z.object({
  name: z.string().trim().min(1).max(200),
  mobile_e164: mobileSchema,
  date_of_birth: birthDateSchema.nullable().optional(),
  gender: z.enum(['female','male','other','undisclosed']).nullable().optional(),
  language: z.enum(['en','te','hi']).optional(),
}).strict();
export const patientUpdateSchema = patientCreateSchema.partial().refine(value => Object.keys(value).length > 0);
export const staffConsentSchema = z.object({
  version: z.string().trim().min(1).max(100),
  status: z.enum(['granted','revoked']),
  channel: z.enum(['phone','paper','dashboard']),
}).strict();
export const patientRecordSchema = patientCreateSchema.extend({
  id: z.string().uuid(), clinic_id: z.string().uuid(),
  date_of_birth: z.string().nullable(), gender: z.string().nullable(),
  language: z.enum(['en','te','hi']),
  whatsapp_status: z.enum(['unknown','ok','not_on_whatsapp','blocked']),
  opted_out: z.boolean(), merged_into: z.string().uuid().nullable(), created_at: z.string(),
});
export const patientWriteResultSchema = z.object({
  patient: patientRecordSchema,
  replayed: z.boolean(),
  consent: z.object({
    id: z.string().uuid(), clinic_id: z.string().uuid(), patient_id: z.string().uuid(),
    version: z.string(), status: z.enum(['granted','revoked']), channel: z.string(),
    created_by: z.string().uuid().nullable(), created_at: z.string(),
  }).optional(),
});
export type PatientWriteInput = z.infer<typeof patientCreateSchema> | z.infer<typeof patientUpdateSchema> | z.infer<typeof staffConsentSchema>;
export type PatientWriteResult = z.infer<typeof patientWriteResultSchema>;
export type PatientRecord = z.infer<typeof patientRecordSchema>;

export const alertResolutionSchema = z.enum(['investigated','patient_contacted','configuration_fixed','no_action_required']);
export const alertListQuerySchema = z.object({
  status: z.enum(['open','resolved']).default('open'),
  limit: z.coerce.number().int().min(1).max(100).default(50),
}).strict();
export const staffAlertSchema = z.object({
  id:z.string().uuid(),clinic_id:z.string().uuid(),patient_id:z.string().uuid().nullable(),
  code:z.string(),status:z.enum(['open','resolved']),created_at:z.string(),
  resolved_at:z.string().nullable(),resolved_by:z.string().uuid().nullable(),
  resolution_code:z.string().nullable(),
  context:z.object({doctor_id:z.string().uuid().optional(),appointment_id:z.string().uuid().optional(),outbox_id:z.string().uuid().optional()}).strict().optional(),
});
export const uncertainDeliverySchema = z.object({
  id:z.string().uuid(),clinic_id:z.string().uuid(),patient_id:z.string().uuid(),purpose:z.string(),
  attempts:z.number().int().nonnegative(),created_at:z.string(),has_mock_evidence:z.boolean(),
});
export const alertResolveResultSchema = z.object({
  id:z.string().uuid(),clinic_id:z.string().uuid(),status:z.literal('resolved'),replayed:z.boolean(),
});
export const deliveryReviewResultSchema = z.object({
  id:z.string().uuid(),clinic_id:z.string().uuid(),status:z.enum(['sent','failed','uncertain']),
  resolution:z.enum(['accepted','closed_without_resend','held']),replayed:z.boolean(),
});
export type StaffAlert = z.infer<typeof staffAlertSchema>;
export type UncertainDelivery = z.infer<typeof uncertainDeliverySchema>;
export type AlertResolution = z.infer<typeof alertResolutionSchema>;
export type AlertResolveResult = z.infer<typeof alertResolveResultSchema>;
export type DeliveryReviewResult = z.infer<typeof deliveryReviewResultSchema>;

export const calendarDateSchema=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(value=>{
  const parsed=Date.parse(value);return Number.isFinite(parsed)&&new Date(parsed).toISOString().slice(0,10)===value;
},'Invalid calendar date');
export const doctorRecordSchema=z.object({id:z.string().uuid(),clinic_id:z.string().uuid(),name:z.string(),specialty:z.string(),slot_minutes:z.number().int().positive()});
export const appointmentSlotSchema=z.object({starts_at:z.string().datetime({offset:true}),ends_at:z.string().datetime({offset:true})});
export const appointmentRecordSchema=appointmentSlotSchema.extend({
  id:z.string().uuid(),clinic_id:z.string().uuid(),patient_id:z.string().uuid(),doctor_id:z.string().uuid(),
  status:z.enum(['booked','checked_in','completed','no_show','cancelled']),source:z.enum(['phone','whatsapp','walk_in']),
  created_by:z.string().uuid().nullable(),created_at:z.string(),patient_name:z.string().optional(),
});
export const appointmentCreateSchema=z.object({
  patient_id:z.string().uuid(),doctor_id:z.string().uuid(),starts_at:z.string().datetime({offset:true}),source:z.enum(['phone','walk_in']).default('phone'),
}).strict();
export const appointmentUpdateSchema=z.discriminatedUnion('action',[
  z.object({action:z.literal('reschedule'),doctor_id:z.string().uuid().optional(),starts_at:z.string().datetime({offset:true})}).strict(),
  z.object({action:z.literal('cancel')}).strict(),
  z.object({action:z.literal('check_in')}).strict(),
  z.object({action:z.literal('complete')}).strict(),
  z.object({action:z.literal('no_show')}).strict(),
]);
export const appointmentWriteResultSchema=z.object({appointment:appointmentRecordSchema,replayed:z.boolean(),conflict:z.literal(false)});
export type AppointmentRecord=z.infer<typeof appointmentRecordSchema>;
export type AppointmentSlot=z.infer<typeof appointmentSlotSchema>;
export type DoctorRecord=z.infer<typeof doctorRecordSchema>;
export type AppointmentWriteResult=z.infer<typeof appointmentWriteResultSchema>;

const timeInputSchema=z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/);
const revisionSchema=z.number().int().min(0).max(2147483647);
export const doctorAvailabilitySchema=z.object({
  doctor_id:z.string().uuid(),clinic_id:z.string().uuid(),revision:revisionSchema,
  schedules:z.array(z.object({id:z.string().uuid(),weekday:z.number().int().min(0).max(6),start_time:z.string(),end_time:z.string(),break_start:z.string().nullable(),break_end:z.string().nullable()})),
  leaves:z.array(z.object({id:z.string().uuid(),date_from:calendarDateSchema,date_to:calendarDateSchema,reason:z.string()})),
  affected_appointments:z.array(appointmentRecordSchema).max(100),affected_count:z.number().int().nonnegative(),
});
export const doctorAvailabilityWriteSchema=z.discriminatedUnion('action',[
  z.object({action:z.literal('schedule'),expected_revision:revisionSchema,weekday:z.number().int().min(0).max(6),start_time:timeInputSchema,end_time:timeInputSchema,
    break_start:timeInputSchema.nullable().optional(),break_end:timeInputSchema.nullable().optional()}).strict(),
  z.object({action:z.literal('delete_schedule'),expected_revision:revisionSchema,weekday:z.number().int().min(0).max(6)}).strict(),
  z.object({action:z.literal('leave'),expected_revision:revisionSchema,date_from:calendarDateSchema,date_to:calendarDateSchema,reason:z.enum(['planned_leave','clinic_change','other'])}).strict(),
  z.object({action:z.literal('delete_leave'),expected_revision:revisionSchema,leave_id:z.string().uuid()}).strict(),
]);
export const doctorAvailabilityResultSchema=z.object({doctor_id:z.string().uuid(),clinic_id:z.string().uuid(),revision:revisionSchema,
  affected_count:z.number().int().nonnegative(),notice_alert_id:z.string().uuid().nullable(),replayed:z.boolean()});
export type DoctorAvailability=z.infer<typeof doctorAvailabilitySchema>;
export type DoctorAvailabilityWrite=z.infer<typeof doctorAvailabilityWriteSchema>;
export type DoctorAvailabilityResult=z.infer<typeof doctorAvailabilityResultSchema>;

export const queueTokenSchema=z.object({id:z.string().uuid(),clinic_id:z.string().uuid(),doctor_id:z.string().uuid(),patient_id:z.string().uuid(),date:calendarDateSchema,
  token_number:z.number().int().min(1).max(1000),status:z.enum(['waiting','called','done','skipped']),called_at:z.string().nullable(),finished_at:z.string().nullable(),
  created_by:z.string().uuid(),created_at:z.string(),patient_name:z.string().optional()});
export const queueStatusSchema=z.object({clinic_id:z.string().uuid(),enabled:z.boolean()});
export const queueReadSchema=z.object({clinic_id:z.string().uuid(),doctor_id:z.string().uuid(),date:calendarDateSchema,tokens:z.array(queueTokenSchema).max(1000)});
export const queueWriteSchema=z.discriminatedUnion('action',[
  z.object({action:z.literal('add'),patient_id:z.string().uuid()}).strict(),
  z.object({action:z.literal('call_next'),expected_called_id:z.string().uuid().nullable(),expected_next_id:z.string().uuid()}).strict(),
  z.object({action:z.literal('skip'),id:z.string().uuid()}).strict(),
  z.object({action:z.literal('complete'),id:z.string().uuid()}).strict(),
]);
export const queueResultSchema=z.object({clinic_id:z.string().uuid(),token:queueTokenSchema,notice_state:z.enum(['none','queued','existing','review_required']),replayed:z.boolean()});
export type QueueToken=z.infer<typeof queueTokenSchema>;
export type QueueRead=z.infer<typeof queueReadSchema>;
export type QueueWrite=z.infer<typeof queueWriteSchema>;
export type QueueResult=z.infer<typeof queueResultSchema>;
export type QueueStatus=z.infer<typeof queueStatusSchema>;

// --- Clinical Services & Prescriptions (T4.1 - T4.5) ---
export const foodRelationSchema = z.enum(['before_food', 'after_food', 'with_food', 'no_relation']);
export const medicationItemBaseSchema = z.object({
  medicine: z.string().trim().min(1).max(200),
  dose: z.string().trim().min(1).max(100),
  times: z.array(z.string().trim().min(1)).min(1).max(6),
  food_relation: foodRelationSchema,
  start_date: calendarDateSchema,
  end_date: calendarDateSchema,
});

export const medicationItemSchema = medicationItemBaseSchema.refine(data => data.end_date >= data.start_date, {
  message: 'end_date must be on or after start_date',
  path: ['end_date']
});

export const prescriptionCreateSchema = z.object({
  patient_id: z.string().uuid(),
  visit_id: z.string().uuid().optional(),
  items: z.array(medicationItemSchema).min(1).max(20),
}).strict();

export const medicationScheduleRecordSchema = medicationItemBaseSchema.extend({
  id: z.string().uuid(),
  clinic_id: z.string().uuid(),
  prescription_id: z.string().uuid(),
  patient_id: z.string().uuid(),
  status: z.enum(['active', 'stopped', 'completed']),
  created_at: z.string(),
});

export const prescriptionRecordSchema = z.object({
  id: z.string().uuid(),
  clinic_id: z.string().uuid(),
  visit_id: z.string().uuid().nullable(),
  patient_id: z.string().uuid(),
  created_by: z.string().uuid(),
  created_at: z.string(),
  items: z.array(medicationScheduleRecordSchema),
});

export const adherenceMetricSchema = z.object({
  medicine: z.string(),
  dose: z.string(),
  taken: z.number().int().nonnegative(),
  missed: z.number().int().nonnegative(),
  stopped: z.number().int().nonnegative(),
  total_due: z.number().int().nonnegative(),
  adherence_rate: z.number().min(0).max(100),
  status: z.enum(['active', 'stopped', 'completed']),
});

export const patientAdherenceSchema = z.object({
  patient_id: z.string().uuid(),
  clinic_id: z.string().uuid(),
  adherence: z.array(adherenceMetricSchema),
});

export type MedicationItem = z.infer<typeof medicationItemSchema>;
export type PrescriptionCreate = z.infer<typeof prescriptionCreateSchema>;
export type PrescriptionRecord = z.infer<typeof prescriptionRecordSchema>;
export type MedicationScheduleRecord = z.infer<typeof medicationScheduleRecordSchema>;
export type AdherenceMetric = z.infer<typeof adherenceMetricSchema>;
export type PatientAdherence = z.infer<typeof patientAdherenceSchema>;

// --- Visits & Documents (T3.3 - T3.6) ---
export const visitRecordSchema = z.object({
  id: z.string().uuid(),
  clinic_id: z.string().uuid(),
  appointment_id: z.string().uuid(),
  patient_id: z.string().uuid(),
  notes: z.string(),
  slip_file_path: z.string().nullable(),
  completed_at: z.string(),
  created_at: z.string(),
});

export const visitCreateSchema = z.object({
  appointment_id: z.string().uuid(),
  notes: z.string().max(2000).default(''),
  generate_slip: z.boolean().default(true),
}).strict();

export const visitSlipUrlSchema = z.object({
  visit_id: z.string().uuid(),
  download_url: z.string().url(),
  expires_at: z.string(),
});

export type VisitRecord = z.infer<typeof visitRecordSchema>;
export type VisitCreate = z.infer<typeof visitCreateSchema>;
export type VisitSlipUrl = z.infer<typeof visitSlipUrlSchema>;

// --- FAQs (T4.6, T4.7) ---
export const faqSchema = z.object({
  id: z.string().uuid(),
  clinic_id: z.string().uuid(),
  question: z.string().trim().min(2).max(500),
  answer: z.string().trim().min(2).max(2000),
  language: z.enum(['en', 'te', 'hi']),
  active: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const faqCreateSchema = z.object({
  question: z.string().trim().min(2).max(500),
  answer: z.string().trim().min(2).max(2000),
  language: z.enum(['en', 'te', 'hi']).default('en'),
  active: z.boolean().default(true),
}).strict();

export const faqUpdateSchema = faqCreateSchema.partial();
export type FAQRecord = z.infer<typeof faqSchema>;
export type FAQCreate = z.infer<typeof faqCreateSchema>;

// --- Reports & Summary (T5.1) ---
export const reportSummarySchema = z.object({
  clinic_id: z.string().uuid(),
  from: calendarDateSchema,
  to: calendarDateSchema,
  appointments_booked: z.number().int().nonnegative(),
  appointments_attended: z.number().int().nonnegative(),
  no_shows: z.number().int().nonnegative(),
  no_show_rate: z.number().min(0).max(100),
  reminders_sent: z.number().int().nonnegative(),
  confirmations_received: z.number().int().nonnegative(),
  estimated_wa_cost_inr: z.number().nonnegative(),
});
export type ReportSummary = z.infer<typeof reportSummarySchema>;

// --- Patient CSV Import & Merge (T3.9) ---
export const patientImportRowSchema = z.object({
  name: z.string().trim().min(1).max(200),
  mobile_e164: mobileSchema,
  date_of_birth: calendarDateSchema.optional().nullable(),
  gender: z.enum(['female', 'male', 'other', 'undisclosed']).optional().nullable(),
  language: z.enum(['en', 'te', 'hi']).optional().default('en'),
});

export const patientMergeSchema = z.object({
  source_patient_id: z.string().uuid(),
  target_patient_id: z.string().uuid(),
  reason: z.string().trim().min(1).max(500),
}).strict();

export type PatientImportRow = z.infer<typeof patientImportRowSchema>;
export type PatientMerge = z.infer<typeof patientMergeSchema>;

export class ApiError extends Error {
  code: string;
  status: number;
  details?: Record<string,unknown>;

  constructor(code: string, status: number, message: string, details?: Record<string,unknown>) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}
