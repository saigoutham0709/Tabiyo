// Real pg-boss plus synthetic local SQL stores. No listener, credentials, network or physical messages.
import assert from 'node:assert/strict';
import {PgBoss,fromPglite} from 'pg-boss';
import {fixture,ids} from '../../../supabase/tests/helpers.mjs';
import {createDeliveryStore} from '../src/delivery/store.ts';
import {createGatewayStore} from '../src/whatsapp/store.ts';
import {createMockScheduler} from '../src/jobs/mock-runtime.ts';

const f=await fixture(),time='2026-11-02T04:30:00Z';
const boss=new PgBoss({backend:'pglite',db:fromPglite(f.db),schema:'tabiyo_jobs'});
const rpc=async(name,action,input)=>(await f.asUser(null,async tx=>(await tx.query(`select public.${name}($1,$2::jsonb,$3::timestamptz) result`,[action,JSON.stringify(input),time])).rows[0].result,'service_role'));
const deliveryStore=createDeliveryStore((action,input)=>rpc('tabiyo_delivery',action,input));
const gatewayStore=createGatewayStore((action,input)=>rpc('tabiyo_gateway',action,input));
const scheduler=createMockScheduler({boss,deliveryStore,gatewayStore,
  retention:()=>f.asUser(null,tx=>tx.query('select public.tabiyo_retention()'),'service_role')});
async function waitFor(sql) {
  const deadline=Date.now()+15_000;
  while(Date.now()<deadline){if((await f.db.query(sql)).rows[0].ready)return;await new Promise(resolve=>setTimeout(resolve,25));}
  throw new Error('SYNTHETIC_SCHEDULER_DEMO_TIMEOUT');
}
try {
  await f.db.query('update public.clinics set whatsapp_phone_number_id=$1,settings=$2 where id=$3',
    ['111',{approved_templates:{'notice:en':true}},ids.clinicA]);
  await f.db.query("insert into public.consents(clinic_id,patient_id,version,status,channel) values($1,$2,'synthetic-v1','granted','phone')",[ids.clinicA,ids.patientA]);
  await f.db.query(`insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key,not_before)
    values($1,$2,'template','appointment','{"template_name":"notice","language":"en"}','synthetic-scheduler',$3)`,[ids.clinicA,ids.patientA,time]);
  await scheduler.start();
  await waitFor("select exists(select 1 from public.outbox where status='sent') ready");
  await gatewayStore.intake([{phone_number_id:'111',payload:{metadata:{phone_number_id:'111'},messages:[{
    id:'wamid.synthetic.scheduler.stop',from:'919000000001',timestamp:String(Date.parse(time)/1000),type:'text',text:{body:'STOP'},
  }]}}]);
  await scheduler.wake('gateway');
  await waitFor('select exists(select 1 from public.conversations where channel_stopped) ready');
  await scheduler.wake('cleanup');
  await waitFor("select exists(select 1 from public.gateway_maintenance where action='technical.retention') ready");
  assert.equal((await f.db.query('select count(*)::integer n from public.mock_deliveries')).rows[0].n,1);
  console.log(JSON.stringify({mode:'synthetic pg-boss scheduler',mockAccepted:1,inboundStopProcessed:true,
    recurringSchedules:(await boss.getSchedules()).length,retentionExecuted:true,physicalMessagesSent:0},null,2));
} finally {await scheduler.stop();await boss.stop();await f.db.close();}
