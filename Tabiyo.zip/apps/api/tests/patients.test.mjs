import test,{before,after} from 'node:test';
import assert from 'node:assert/strict';
import {buildApp} from '../src/app.ts';
import {createAuthenticator} from '../src/auth.ts';
import {createPatientService} from '../src/patients.ts';
import {fixture,ids} from '../../../supabase/tests/helpers.mjs';
let f,app;
const users={staffA:ids.adminA,staffB:ids.adminB,front:ids.frontA,inactive:ids.inactive};
before(async()=>{
  f=await fixture();
  const providerFetch=async(input,init)=>{
    const url=new URL(typeof input==='string'?input:input.url??input.toString());
    const token=new Headers(init?.headers).get('authorization')?.replace('Bearer ','');
    const user=users[token];
    if(!user)return Response.json({msg:'invalid JWT',code:'bad_jwt'},{status:401});
    if(url.pathname==='/auth/v1/user')return Response.json({id:user,is_anonymous:false,user_metadata:{role:'admin',clinic_id:ids.clinicB}});
    if(url.pathname==='/rest/v1/staff_users'){
      assert.equal(url.searchParams.get('id'),'eq.'+user);
      return Response.json((await f.asUser(user,tx=>tx.query('select id,clinic_id,name,role,active from public.staff_users where id=$1 and active',[user]))).rows);
    }
    if(url.pathname==='/rest/v1/clinics')return Response.json((await f.asUser(user,tx=>tx.query('select id,name,timezone,default_language from public.clinics where id=$1',[url.searchParams.get('id')?.slice(3)]))).rows);
    try{
      const body=JSON.parse(init.body);
      if(url.pathname==='/rest/v1/rpc/tabiyo_patient_get')return Response.json(await f.asUser(user,async tx=>(await tx.query('select public.tabiyo_patient_get($1) result',[body.p_id])).rows[0].result));
      if(url.pathname==='/rest/v1/rpc/tabiyo_patient_search')return Response.json(await f.search(user,body.p_mobile));
      if(url.pathname==='/rest/v1/rpc/tabiyo_patient_write')return Response.json(await f.write(user,body.p_operation,body.p_input,body.p_request_id,body.p_patient_id));
    }catch(error){return Response.json({code:error.code??'XX000',message:error.message},{status:400});}
    throw Error('Unexpected mocked provider URL');
  };
  const config={url:'https://fixture.example.test',publishableKey:'fixture-public-key',fetch:providerFetch};
  app=buildApp({authenticate:createAuthenticator(config),patients:createPatientService(config)});
});
after(async()=>{await app?.close();await f?.db.close();});
const input={name:'Synthetic API Patient',mobile_e164:'+919000000001',language:'te'};
const headers=(token='staffA',key=crypto.randomUUID())=>({authorization:'Bearer '+token,'idempotency-key':key});

test('patient API searches shared phone through authenticated adapter, SQL and audited response',async()=>{
  const response=await app.inject({url:'/api/v1/patients?mobile='+encodeURIComponent(input.mobile_e164),headers:headers()});
  assert.equal(response.statusCode,200);assert.equal(response.json().patients.length,2);assert(response.json().patients.every(p=>p.clinic_id===ids.clinicA));
  const audit=(await f.db.query("select * from public.audit_log where action='patient.read'")).rows;assert.equal(audit.length,2);
  assert.equal(response.headers['cache-control'],'no-store');
});
test('patient API create and replay return one patient and one queued consent request',async()=>{
  const key=crypto.randomUUID();const request={method:'POST',url:'/api/v1/patients',headers:headers('front',key),payload:input};
  const first=await app.inject(request),second=await app.inject(request);
  assert.equal(first.statusCode,201);assert.equal(second.statusCode,200);assert.equal(first.json().patient.id,second.json().patient.id);assert(second.json().replayed);
  assert.equal((await f.db.query('select * from public.outbox where patient_id=$1',[first.json().patient.id])).rows.length,1);
  const conflict=await app.inject({...request,payload:{...input,name:'Other API Patient'}});assert.equal(conflict.statusCode,409);assert.equal(conflict.json().error.code,'IDEMPOTENCY_CONFLICT');
});
test('single-record lookup supports clinic operations and audits reads without crossing clinics',async()=>{
  const own=await app.inject({url:'/api/v1/patients/'+ids.patientA,headers:headers()});assert.equal(own.statusCode,200);assert.equal(own.json().patient.id,ids.patientA);
  const other=await app.inject({url:'/api/v1/patients/'+ids.patientB,headers:headers()});assert.equal(other.statusCode,404);
  assert.ok((await f.db.query("select count(*)::integer n from public.audit_log where action='patient.read'")).rows[0].n>0);
});
test('patient API edits and consent withdrawal use the same scoped transaction boundary',async()=>{
  const create=await app.inject({method:'POST',url:'/api/v1/patients',headers:headers(),payload:{...input,name:'Consent API Fixture'}});
  const id=create.json().patient.id;
  const update=await app.inject({method:'PATCH',url:'/api/v1/patients/'+id,headers:headers('front'),payload:{name:'Edited Synthetic Patient'}});
  assert.equal(update.statusCode,200);assert.equal(update.json().patient.name,'Edited Synthetic Patient');
  const revoke=await app.inject({method:'POST',url:'/api/v1/patients/'+id+'/consents',headers:headers('front'),payload:{status:'revoked',version:'fixture-v1',channel:'phone'}});
  assert.equal(revoke.statusCode,200);assert(revoke.json().patient.opted_out);assert.equal(revoke.json().consent.created_by,ids.frontA);
  assert.equal((await f.db.query('select status from public.outbox where patient_id=$1',[id])).rows[0].status,'skipped');
});

test('expired API replay returns a safe conflict and never creates another patient',async()=>{
  const key=crypto.randomUUID(),request={method:'POST',url:'/api/v1/patients',headers:headers('front',key),payload:input};
  const first=await app.inject(request);assert.equal(first.statusCode,201);
  await f.db.query("update public.api_requests set created_at=clock_timestamp()-interval '91 days' where request_id=$1",[key]);
  const replay=await app.inject(request);
  assert.equal(replay.statusCode,409);assert.equal(replay.json().error.code,'REQUEST_REPLAY_EXPIRED');
  assert.ok(!replay.body.includes(input.name));
});
test('patient API rejects caller clinic, consent impersonation, malformed dates and missing replay keys',async()=>{
  for(const payload of [{...input,clinic_id:ids.clinicB},{...input,consent:true},{...input,date_of_birth:'2026-02-30'}]){
    const response=await app.inject({method:'POST',url:'/api/v1/patients',headers:headers(),payload});assert.equal(response.statusCode,422);assert(!response.body.includes(input.name));
  }
  const noKey=await app.inject({method:'POST',url:'/api/v1/patients',headers:{authorization:'Bearer staffA'},payload:input});assert.equal(noKey.statusCode,422);
  const fakeConsent=await app.inject({method:'POST',url:'/api/v1/patients/'+ids.patientA+'/consents',headers:headers(),payload:{status:'granted',version:'v1',channel:'whatsapp'}});assert.equal(fakeConsent.statusCode,422);
  const invalidQuery=await app.inject({url:'/api/v1/patients?mobile='+encodeURIComponent(input.mobile_e164)+'&clinic_id='+ids.clinicB,headers:headers()});assert.equal(invalidQuery.statusCode,422);
});
test('another clinic cannot edit or consent a patient; inactive and invalid sessions are denied',async()=>{
  const cross=await app.inject({method:'PATCH',url:'/api/v1/patients/'+ids.patientA,headers:headers('staffB'),payload:{name:'Cross Clinic Attempt'}});
  assert.equal(cross.statusCode,404);assert.equal(cross.json().error.code,'PATIENT_NOT_FOUND');
  const crossConsent=await app.inject({method:'POST',url:'/api/v1/patients/'+ids.patientA+'/consents',headers:headers('staffB'),payload:{version:'v1',status:'granted',channel:'phone'}});assert.equal(crossConsent.statusCode,404);
  for(const [token,status] of [['inactive',403],['invalid',401]])assert.equal((await app.inject({url:'/api/v1/patients?mobile='+encodeURIComponent(input.mobile_e164),headers:headers(token)})).statusCode,status);
});
test('mobile changes are blocked; provider/database error details never leak',async()=>{
  const response=await app.inject({method:'PATCH',url:'/api/v1/patients/'+ids.patientA,headers:headers(),payload:{mobile_e164:'+919000000099'}});
  assert.equal(response.statusCode,409);assert.equal(response.json().error.code,'CONTACT_CHANGE_REQUIRES_VERIFICATION');assert(!response.body.includes('+919000000099'));
});
test('malformed JSON and oversized payload return client errors without echoing content',async()=>{
  const bad=await app.inject({method:'POST',url:'/api/v1/patients',headers:{...headers(),'content-type':'application/json'},payload:'{"private"'});assert.equal(bad.statusCode,400);assert(!bad.body.includes('private'));
  const large=await app.inject({method:'POST',url:'/api/v1/patients',headers:headers(),payload:{...input,name:'x'.repeat(18000)}});assert.equal(large.statusCode,413);
});
test('unknown route errors never echo sensitive URL content',async()=>{
  const response=await app.inject({url:'/unavailable/'+input.mobile_e164,headers:headers()});
  assert.equal(response.statusCode,404);assert(!response.body.includes(input.mobile_e164));assert.equal(response.json().error.code,'NOT_FOUND');
});
