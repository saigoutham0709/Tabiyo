import test from 'node:test';
import assert from 'node:assert/strict';
import { buildApp } from '../src/app.ts';
import { createAuthenticator } from '../src/auth.ts';
import { ApiError } from '../../../packages/shared/src/index.ts';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const userId='10000000-0000-4000-8000-000000000001';
const clinicId='20000000-0000-4000-8000-000000000001';
const context={staff:{id:userId,clinic_id:clinicId,name:'Synthetic Staff',role:'front_desk',active:true},clinic:{id:clinicId,name:'Synthetic Clinic',timezone:'Asia/Kolkata',default_language:'en'}};
function appFor(t, authenticate=async()=>context) { const app=buildApp({authenticate});t.after(()=>app.close());return app; }

test('health is liveness only and returns no configuration or patient data',async t=>{
  const response=await appFor(t).inject({url:'/health'});
  assert.equal(response.statusCode,200);assert.equal(response.json().scope,'liveness');assert.equal(response.headers['cache-control'],'no-store');
});
test('identity headers and caller clinic/role do not authenticate a request',async t=>{
  let calls=0;const app=appFor(t,async()=>{calls++;return context;});
  const response=await app.inject({url:'/api/v1/me?clinic_id=attacker&role=admin',headers:{'oai-authenticated-user-id':userId,'x-clinic-id':clinicId,'x-role':'admin'}});
  assert.equal(response.statusCode,401);assert.equal(calls,0);
});
test('me uses server membership, ignoring caller clinic and role',async t=>{
  const app=appFor(t,async token=>{assert.equal(token,'test-token');return context;});
  const response=await app.inject({url:'/api/v1/me?clinic_id=other&role=admin',headers:{authorization:'Bearer test-token','x-role':'admin'}});
  assert.equal(response.statusCode,200);assert.equal(response.json().staff.role,'front_desk');assert.equal(response.json().clinic.id,clinicId);
});
test('inactive and inconsistent clinic contexts are denied',async t=>{
  for(const bad of [{...context,staff:{...context.staff,active:false}},{...context,clinic:{...context.clinic,id:'20000000-0000-4000-8000-000000000002'}}]){
    const response=await appFor(t,async()=>bad).inject({url:'/api/v1/me',headers:{authorization:'Bearer test'}});assert.equal(response.statusCode,403);
  }
});
test('unknown auth errors do not leak tokens or implementation details',async t=>{
  const response=await appFor(t,async()=>{throw Error('private token/password detail');}).inject({url:'/api/v1/me',headers:{authorization:'Bearer test'}});
  assert.equal(response.statusCode,500);assert(!response.body.includes('password'));assert.equal(response.json().error.code,'INTERNAL_ERROR');
});
test('typed membership rejection has stable code',async t=>{
  const response=await appFor(t,async()=>{throw new ApiError('STAFF_FORBIDDEN',403,'Active clinic membership is required.');}).inject({url:'/api/v1/me',headers:{authorization:'Bearer test'}});
  assert.equal(response.statusCode,403);assert.equal(response.json().error.code,'STAFF_FORBIDDEN');
});
function authFixture({member=context.staff,user={id:userId,is_anonymous:false,user_metadata:{role:'admin',clinic_id:'attacker'}}}={}){
  const calls=[];
  const fetcher=async(input,init)=>{
    const url=new URL(typeof input==='string'?input:input.url??input.toString());calls.push({url,headers:new Headers(init?.headers)});
    if(url.pathname==='/auth/v1/user')return Response.json(user);
    if(url.pathname==='/rest/v1/staff_users')return Response.json(member?[member]:[]);
    if(url.pathname==='/rest/v1/clinics')return Response.json([context.clinic]);
    throw Error('Unexpected provider URL');
  };
  return {authenticate:createAuthenticator({url:'https://project.example.test',publishableKey:'test-publishable-key',fetch:fetcher}),calls};
}
test('Supabase adapter validates user and queries active membership with caller token',async()=>{
  const {authenticate,calls}=authFixture();const result=await authenticate('fixture-jwt');assert.equal(result.staff.role,'front_desk');
  assert.equal(calls[0].url.pathname,'/auth/v1/user');assert(calls.every(call=>call.headers.get('authorization')==='Bearer fixture-jwt'));
  assert.equal(calls[1].url.searchParams.get('id'),'eq.'+userId);assert.equal(calls[1].url.searchParams.get('active'),'eq.true');assert.equal(calls[2].url.searchParams.get('id'),'eq.'+clinicId);
});
test('Supabase adapter denies nonmembers, inactive members and anonymous identities',async()=>{
  for(const fixture of [{member:null},{member:{...context.staff,active:false}},{user:{id:userId,is_anonymous:true}}]){
    await assert.rejects(authFixture(fixture).authenticate('fixture-jwt'),error=>error instanceof ApiError&&[401,403].includes(error.status));
  }
});
test('Supabase adapter rejects invalid JWT without consulting memberships',async()=>{
  let calls=0;const authenticate=createAuthenticator({url:'https://project.example.test',publishableKey:'test-key',fetch:async()=>{calls++;return Response.json({msg:'invalid JWT',code:'bad_jwt'},{status:401});}});
  await assert.rejects(authenticate('invalid'),error=>error.code==='AUTH_REQUIRED');assert.equal(calls,1);
});
test('server refuses startup without Supabase configuration; no mock identity fallback',()=>{
  const result=spawnSync(process.execPath,[fileURLToPath(new URL('../src/server.ts',import.meta.url))],{
    encoding:'utf8',timeout:10_000,env:{PATH:process.env.PATH,SystemRoot:process.env.SystemRoot??''},
  });
  assert.equal(result.status,1);assert.match(result.stderr,/Missing or invalid API settings/);
  assert.match(result.stderr,/SUPABASE_URL/);assert.match(result.stderr,/SUPABASE_PUBLISHABLE_KEY/);
});
