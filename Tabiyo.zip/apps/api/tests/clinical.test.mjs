import test, { before, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { fixture, ids } from '../../../supabase/tests/helpers.mjs';
import { buildApp } from '../src/app.ts';
import { createAuthenticator } from '../src/auth.ts';
import { createClinicalService } from '../src/clinical.ts';

let f, app;
const doctorUser = '10000000-0000-4000-8000-000000000008';
const users = {
  front: ids.frontA,
  admin: ids.adminA,
  doctor: doctorUser,
  other: ids.adminB,
};

const headers = (token = 'front', key = crypto.randomUUID()) => ({
  authorization: 'Bearer ' + token,
  'idempotency-key': key,
});

before(async () => {
  f = await fixture();

  // Provision doctor user for clinicA
  await f.db.query('insert into auth.users(id) values ($1)', [doctorUser]);
  await f.db.query(
    'insert into public.staff_users(id, clinic_id, name, role, active) values ($1, $2, $3, $4, $5)',
    [doctorUser, ids.clinicA, 'Demo Doctor Staff', 'doctor', true]
  );

  const providerFetch = async (input, init) => {
    const url = new URL(typeof input === 'string' ? input : input.url ?? input.toString());
    const token = new Headers(init?.headers).get('authorization')?.replace('Bearer ', '');
    const user = users[token];
    if (!user) return Response.json({ msg: 'invalid JWT' }, { status: 401 });
    if (url.pathname === '/auth/v1/user') return Response.json({ id: user, is_anonymous: false });
    if (url.pathname === '/rest/v1/staff_users') {
      return Response.json(
        (await f.asUser(user, tx => tx.query('select id,clinic_id,name,role,active from public.staff_users where id=$1 and active', [user]))).rows
      );
    }
    if (url.pathname === '/rest/v1/clinics') {
      return Response.json(
        (await f.asUser(user, tx => tx.query('select id,name,timezone,default_language from public.clinics where id=$1', [url.searchParams.get('id')?.slice(3)]))).rows
      );
    }
    const body = JSON.parse(init.body);
    try {
      if (url.pathname === '/rest/v1/rpc/tabiyo_clinical') {
        return Response.json(
          await f.asUser(user, async tx => (
            await tx.query('select public.tabiyo_clinical($1, $2::jsonb, $3) result', [
              body.p_action,
              JSON.stringify(body.p_input),
              body.p_request_id,
            ])
          ).rows[0].result)
        );
      }
    } catch (error) {
      return Response.json({ code: error.code ?? 'XX000', message: error.message }, { status: 400 });
    }
    throw Error('Unexpected mocked provider URL: ' + url.pathname);
  };

  const config = { url: 'https://fixture.example.test', publishableKey: 'synthetic-publishable', fetch: providerFetch };
  app = buildApp({
    authenticate: createAuthenticator(config),
    clinical: createClinicalService(config),
  });
});

after(async () => {
  await app?.close();
  await f?.db.close();
});

beforeEach(async () => {
  await f.db.exec('truncate public.prescriptions, public.medication_schedules, public.dose_events, public.visits, public.faqs, public.dob_lockouts, public.events, public.audit_log cascade;');
});

test('Doctor creates prescription with schedules; Front Desk cannot create prescriptions (role check)', async () => {
  const prescriptionPayload = {
    patient_id: ids.patientA,
    items: [
      {
        medicine: 'Amoxicillin 500mg',
        dose: '1 capsule',
        times: ['08:00', '20:00'],
        food_relation: 'after_food',
        start_date: '2026-11-10',
        end_date: '2026-11-17',
      },
      {
        medicine: 'Paracetamol 650mg',
        dose: '1 tablet',
        times: ['14:00'],
        food_relation: 'with_food',
        start_date: '2026-11-10',
        end_date: '2026-11-12',
      },
    ],
  };

  // Front Desk attempts to create prescription -> 403 OPERATION_FORBIDDEN
  const frontDeskRes = await app.inject({
    method: 'POST',
    url: '/api/v1/prescriptions',
    headers: headers('front'),
    payload: prescriptionPayload,
  });
  assert.equal(frontDeskRes.statusCode, 403);
  assert.equal(frontDeskRes.json().error.code, 'OPERATION_FORBIDDEN');

  // Doctor creates prescription -> 201 Created
  const doctorRes = await app.inject({
    method: 'POST',
    url: '/api/v1/prescriptions',
    headers: headers('doctor'),
    payload: prescriptionPayload,
  });
  assert.equal(doctorRes.statusCode, 201);
  const data = doctorRes.json();
  assert.ok(data.prescription.id);
  assert.equal(data.prescription.patient_id, ids.patientA);
  assert.equal(data.prescription.clinic_id, ids.clinicA);
  assert.equal(data.prescription.items.length, 2);
  assert.equal(data.prescription.items[0].medicine, 'Amoxicillin 500mg');
  assert.equal(data.prescription.items[1].medicine, 'Paracetamol 650mg');

  // Verify rows in database
  const rxRows = (await f.db.query('select * from public.prescriptions where id = $1', [data.prescription.id])).rows;
  assert.equal(rxRows.length, 1);
  const msRows = (await f.db.query('select * from public.medication_schedules where prescription_id = $1 order by medicine', [data.prescription.id])).rows;
  assert.equal(msRows.length, 2);

  // Verify prescription_created event emitted
  const events = (await f.db.query("select * from public.events where clinic_id = $1 and type = 'prescription_created'", [ids.clinicA])).rows;
  assert.equal(events.length, 1);
  assert.equal(events[0].patient_id, ids.patientA);

  // Verify audit log
  const audit = (await f.db.query("select * from public.audit_log where clinic_id = $1 and action = 'prescription.create'", [ids.clinicA])).rows;
  assert.equal(audit.length, 1);
});

test('Adherence calculates accurately for taken and missed doses', async () => {
  const rxRes = await app.inject({
    method: 'POST',
    url: '/api/v1/prescriptions',
    headers: headers('doctor'),
    payload: {
      patient_id: ids.patientA,
      items: [
        {
          medicine: 'Metformin 500mg',
          dose: '1 tablet',
          times: ['08:00', '20:00'],
          food_relation: 'after_food',
          start_date: '2026-11-10',
          end_date: '2026-11-15',
        },
      ],
    },
  });
  assert.equal(rxRes.statusCode, 201);
  const schedId = rxRes.json().prescription.items[0].id;

  // Insert dose_events: 3 taken, 1 missed (none), 1 stopped
  // Total due = 3 + 1 + 1 = 5, Taken = 3 -> 3/5 = 60%
  await f.db.query(`
    insert into public.dose_events(clinic_id, schedule_group_key, patient_id, due_at, response)
    values
      ($1, $2, $3, now() - interval '4 hours', 'taken'),
      ($1, $2, $3, now() - interval '3 hours', 'taken'),
      ($1, $2, $3, now() - interval '2 hours', 'taken'),
      ($1, $2, $3, now() - interval '1 hour', 'none'),
      ($1, $2, $3, now(), 'stopped')
  `, [ids.clinicA, schedId, ids.patientA]);

  const adherenceRes = await app.inject({
    method: 'GET',
    url: `/api/v1/patients/${ids.patientA}/adherence`,
    headers: headers('front'),
  });
  assert.equal(adherenceRes.statusCode, 200);
  const adherenceData = adherenceRes.json();
  assert.equal(adherenceData.patient_id, ids.patientA);
  assert.equal(adherenceData.clinic_id, ids.clinicA);
  const metric = adherenceData.adherence.find(m => m.medicine === 'Metformin 500mg');
  assert.ok(metric);
  assert.equal(metric.taken, 3);
  assert.equal(metric.missed, 1);
  assert.equal(metric.stopped, 1);
  assert.equal(metric.total_due, 5);
  assert.equal(metric.adherence_rate, 60);
});

test('Visit slip URL generation works and has 5-minute TTL', async () => {
  const aptId = crypto.randomUUID();
  const doctor = '30000000-0000-4000-8000-000000000001';
  await f.db.query(`
    insert into public.appointments(id, clinic_id, patient_id, doctor_id, starts_at, ends_at, status, source)
    values ($1, $2, $3, $4, now() - interval '30 minutes', now(), 'completed', 'phone')
  `, [aptId, ids.clinicA, ids.patientA, doctor]);

  const beforeTime = Date.now();
  const slipRes = await app.inject({
    method: 'POST',
    url: `/api/v1/visits/${aptId}/slip`,
    headers: headers('front'),
    payload: { notes: 'Routine checkup completed. Prescribed rest.' },
  });
  assert.equal(slipRes.statusCode, 200);
  const slipData = slipRes.json();
  assert.ok(slipData.visit_id);
  assert.ok(slipData.download_url);
  assert.ok(slipData.download_url.startsWith('https://storage.tabiyo.internal/'));

  // 5-minute (300s) TTL validation
  const expiresAtMs = new Date(slipData.expires_at).getTime();
  const diffSec = Math.round((expiresAtMs - beforeTime) / 1000);
  assert.ok(diffSec >= 298 && diffSec <= 305, `Expected ~300s TTL, got ${diffSec}s`);

  // Verify slip_generated event
  const events = (await f.db.query("select * from public.events where clinic_id = $1 and type = 'slip_generated'", [ids.clinicA])).rows;
  assert.equal(events.length, 1);

  // GET slip-url works
  const getRes = await app.inject({
    url: `/api/v1/visits/${slipData.visit_id}/slip-url`,
    headers: headers('front'),
  });
  assert.equal(getRes.statusCode, 200);
  assert.ok(getRes.json().download_url);
});

test('FAQ CRUD works for admin and rejects non-admin', async () => {
  const faqData = {
    question: 'What are the clinic timings?',
    answer: 'We are open Monday to Saturday from 9 AM to 6 PM.',
    language: 'en',
    active: true,
  };

  // Front desk cannot PUT /api/v1/faqs -> 403
  const frontRes = await app.inject({
    method: 'PUT',
    url: '/api/v1/faqs',
    headers: headers('front'),
    payload: faqData,
  });
  assert.equal(frontRes.statusCode, 403);
  assert.equal(frontRes.json().error.code, 'OPERATION_FORBIDDEN');

  // Admin can PUT /api/v1/faqs -> 200
  const adminRes = await app.inject({
    method: 'PUT',
    url: '/api/v1/faqs',
    headers: headers('admin'),
    payload: faqData,
  });
  assert.equal(adminRes.statusCode, 200);
  assert.ok(adminRes.json().faqs.length >= 1);
  const createdFaq = adminRes.json().faqs.find(f => f.question === faqData.question);
  assert.ok(createdFaq);
  assert.equal(createdFaq.answer, faqData.answer);

  // Front desk can GET /api/v1/faqs -> 200
  const listRes = await app.inject({
    url: '/api/v1/faqs',
    headers: headers('front'),
  });
  assert.equal(listRes.statusCode, 200);
  assert.ok(listRes.json().faqs.some(f => f.question === faqData.question));
});

test('Reports summary aggregates correctly from events rows', async () => {
  const today = new Date().toISOString().slice(0, 10);
  // Insert synthetic events for today:
  // 5 booked, 3 attended, 1 no-show, 4 reminders, 2 confirmations
  // No-show rate = 1 / (3 + 1) = 25%
  await f.db.query(`
    insert into public.events(clinic_id, type, occurred_at, meta)
    values
      ($1, 'appointment.booked', now(), '{"cost_inr": 0}'),
      ($1, 'appointment.booked', now(), '{"cost_inr": 0}'),
      ($1, 'appointment.booked', now(), '{"cost_inr": 0}'),
      ($1, 'appointment.booked', now(), '{"cost_inr": 0}'),
      ($1, 'appointment.booked', now(), '{"cost_inr": 0}'),
      ($1, 'appointment.completed', now(), '{}'),
      ($1, 'appointment.completed', now(), '{}'),
      ($1, 'appointment.completed', now(), '{}'),
      ($1, 'appointment.no_show', now(), '{}'),
      ($1, 'reminder.sent', now(), '{"cost_inr": 0.75}'),
      ($1, 'reminder.sent', now(), '{"cost_inr": 0.75}'),
      ($1, 'reminder.sent', now(), '{"cost_inr": 0.75}'),
      ($1, 'reminder.sent', now(), '{"cost_inr": 0.75}'),
      ($1, 'confirmation.received', now(), '{}'),
      ($1, 'confirmation.received', now(), '{}')
  `, [ids.clinicA]);

  const res = await app.inject({
    url: `/api/v1/reports/summary?from=${today}&to=${today}`,
    headers: headers('admin'),
  });
  assert.equal(res.statusCode, 200);
  const rep = res.json();
  assert.equal(rep.clinic_id, ids.clinicA);
  assert.equal(rep.appointments_booked, 5);
  assert.equal(rep.appointments_attended, 3);
  assert.equal(rep.no_shows, 1);
  assert.equal(rep.no_show_rate, 25);
  assert.equal(rep.reminders_sent, 4);
  assert.equal(rep.confirmations_received, 2);
  assert.equal(rep.estimated_wa_cost_inr, 3.0);
});

test('CSV import detects duplicates and normalizes E.164', async () => {
  const csv = `name,mobile,date_of_birth,gender,language
Duplicate Person,9000000001,1985-05-15,female,en
Brand New Person,9876543210,1992-10-20,male,te`;

  const res = await app.inject({
    method: 'POST',
    url: '/api/v1/patients/import',
    headers: headers('front'),
    payload: { csv },
  });
  assert.equal(res.statusCode, 200);
  const result = res.json();
  assert.equal(result.duplicates, 1);
  assert.equal(result.imported, 1);
  assert.equal(result.patients.length, 1);
  assert.equal(result.patients[0].name, 'Brand New Person');
  assert.equal(result.patients[0].mobile_e164, '+919876543210');

  // Verify in database
  const dbRows = (await f.db.query("select * from public.patients where clinic_id = $1 and mobile_e164 = '+919876543210'", [ids.clinicA])).rows;
  assert.equal(dbRows.length, 1);
});

test('Patient merge updates merged_into and logs audit', async () => {
  const createRes = await f.db.query(`
    insert into public.patients(id, clinic_id, name, mobile_e164)
    values ($1, $2, 'Duplicate Target', '+919111122222')
    returning id
  `, [crypto.randomUUID(), ids.clinicA]);
  const sourceId = createRes.rows[0].id;

  const aptId = crypto.randomUUID();
  await f.db.query(`
    insert into public.appointments(id, clinic_id, patient_id, doctor_id, starts_at, ends_at, status, source)
    values ($1, $2, $3, '30000000-0000-4000-8000-000000000001', now() + interval '1 day', now() + interval '1 day 30 minutes', 'booked', 'phone')
  `, [aptId, ids.clinicA, sourceId]);

  // Front desk cannot merge -> 403
  const frontRes = await app.inject({
    method: 'POST',
    url: '/api/v1/patients/merge',
    headers: headers('front'),
    payload: {
      source_patient_id: sourceId,
      target_patient_id: ids.patientA,
      reason: 'Duplicate phone record found during intake',
    },
  });
  assert.equal(frontRes.statusCode, 403);

  // Admin merges source into target
  const adminRes = await app.inject({
    method: 'POST',
    url: '/api/v1/patients/merge',
    headers: headers('admin'),
    payload: {
      source_patient_id: sourceId,
      target_patient_id: ids.patientA,
      reason: 'Duplicate phone record found during intake',
    },
  });
  assert.equal(adminRes.statusCode, 200);
  assert.equal(adminRes.json().success, true);

  // Check source patient in DB: merged_into === ids.patientA
  const sourceRows = (await f.db.query('select * from public.patients where id = $1', [sourceId])).rows;
  assert.equal(sourceRows[0].merged_into, ids.patientA);

  // Check appointment re-pointed to target
  const aptRows = (await f.db.query('select * from public.appointments where id = $1', [aptId])).rows;
  assert.equal(aptRows[0].patient_id, ids.patientA);

  // Verify audit log
  const audit = (await f.db.query("select * from public.audit_log where clinic_id = $1 and action = 'patient.merge' and record_id = $2", [ids.clinicA, sourceId])).rows;
  assert.equal(audit.length, 1);
  assert.equal(audit[0].reason, 'Duplicate phone record found during intake');
});
