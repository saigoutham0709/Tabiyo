import test,{before,beforeEach,after} from 'node:test';
import assert from 'node:assert/strict';
import {fixture,ids} from '../../../supabase/tests/helpers.mjs';
import {buildApp} from '../src/app.ts';
import {createAuthenticator} from '../src/auth.ts';
import {createAppointmentService} from '../src/appointments.ts';
import {createAvailabilityService} from '../src/availability.ts';
import {createQueueService} from '../src/queue.ts';
let f,app,day;
const doctor='30000000-0000-4000-8000-000000000001',family='40000000-0000-4000-8000-000000000002';
const users={front:ids.frontA,admin:ids.adminA,other:ids.adminB};
const headers=(token='front',key=crypto.randomUUID())=>({authorization:'Bearer '+token,'idempotency-key':key});
before(async()=>{
  f=await fixture();day=(await f.db.query("select ((clock_timestamp() at time zone 'Asia/Kolkata')::date+1)::text as booking_date")).rows[0].booking_date;
  const providerFetch=async(input,init)=>{
    const url=new URL(typeof input==='string'?input:input.url??input.toString()),token=new Headers(init?.headers).get('authorization')?.replace('Bearer ',''),user=users[token];
    if(!user)return Response.json({msg:'invalid JWT'},{status:401});
    if(url.pathname==='/auth/v1/user')return Response.json({id:user,is_anonymous:false});
    if(url.pathname==='/rest/v1/staff_users')return Response.json((await f.asUser(user,tx=>tx.query('select id,clinic_id,name,role,active from public.staff_users where id=$1 and active',[user]))).rows);
    if(url.pathname==='/rest/v1/clinics')return Response.json((await f.asUser(user,tx=>tx.query('select id,name,timezone,default_language from public.clinics where id=$1',[url.searchParams.get('id')?.slice(3)]))).rows);
    const body=JSON.parse(init.body);
    try{
      if(url.pathname==='/rest/v1/rpc/tabiyo_queue')return Response.json(await f.asUser(user,async tx=>(await tx.query('select public.tabiyo_queue($1,$2::jsonb,$3) result',[body.p_action,JSON.stringify(body.p_input),body.p_request_id])).rows[0].result));
      if(url.pathname==='/rest/v1/rpc/tabiyo_doctor_management')return Response.json(await f.asUser(user,async tx=>(await tx.query('select public.tabiyo_doctor_management($1,$2::jsonb,$3) result',[body.p_action,JSON.stringify(body.p_input),body.p_request_id])).rows[0].result));
      if(url.pathname==='/rest/v1/rpc/tabiyo_appointment_read')return Response.json(await f.asUser(user,async tx=>(await tx.query('select public.tabiyo_appointment_read($1,$2::jsonb) result',[body.p_action,JSON.stringify(body.p_input)])).rows[0].result));
      if(url.pathname==='/rest/v1/rpc/tabiyo_appointment_write')return Response.json(await f.asUser(user,async tx=>(await tx.query('select public.tabiyo_appointment_write($1,$2::jsonb,$3) result',[body.p_action,JSON.stringify(body.p_input),body.p_request_id])).rows[0].result));
    }catch(error){return Response.json({code:error.code??'XX000',message:error.message},{status:400});}
    throw Error('Unexpected mocked provider URL');
  };
  const config={url:'https://fixture.example.test',publishableKey:'synthetic-publishable',fetch:providerFetch};
  app=buildApp({authenticate:createAuthenticator(config),appointments:createAppointmentService(config),availability:createAvailabilityService(config),queue:createQueueService(config)});
});
after(async()=>{await app?.close();await f?.db.close();});
beforeEach(async()=>{
  await f.db.exec("update public.doctors set schedule_revision=0; truncate public.queue_tokens; delete from public.clinic_features where feature='walk_in_tokens';");
  await f.db.exec('truncate public.staff_operation_requests,public.api_requests,public.consents,public.message_log,public.mock_deliveries,public.delivery_receipts,public.staff_alerts,public.events,public.audit_log,public.outbox,public.appointments,public.doctor_schedules,public.doctor_leaves cascade;');
  await f.db.query("insert into public.doctor_schedules(clinic_id,doctor_id,weekday,start_time,end_time) select $1,$2,w,'09:00','17:00' from generate_series(0,6) w",[ids.clinicA,doctor]);
});
const request=(options={})=>({method:'POST',url:'/api/v1/appointments',headers:headers(),payload:{patient_id:ids.patientA,doctor_id:doctor,starts_at:day+'T04:30:00.000Z',source:'phone',...options}});
test('staff can load doctors, availability, book, replay and see the same appointment in day view',async()=>{
  const doctors=await app.inject({url:'/api/v1/doctors',headers:headers()});assert.equal(doctors.statusCode,200);assert.equal(doctors.json().doctors.length,2);
  const slots=await app.inject({url:`/api/v1/doctors/${doctor}/slots?date=${day}`,headers:headers()});assert.equal(slots.statusCode,200);assert.ok(slots.json().slots.length>0);
  const input=request(),a=await app.inject(input),b=await app.inject(input);assert.equal(a.statusCode,201);assert.equal(b.statusCode,200);assert.equal(b.json().replayed,true);
  const result=await app.inject({url:'/api/v1/appointments?date='+day,headers:headers()});assert.equal(result.statusCode,200);assert.equal(result.json().appointments.length,1);assert.equal(result.json().appointments[0].id,a.json().appointment.id);
});
test('booking conflict returns HTTP 409 and three validated alternatives',async()=>{
  await app.inject(request());const conflict=await app.inject(request({patient_id:family}));
  assert.equal(conflict.statusCode,409);assert.equal(conflict.json().error.code,'SLOT_UNAVAILABLE');assert.equal(conflict.json().error.details.alternatives.length,3);
});
test('reschedule and cancellation use one clinic-scoped audited transaction boundary',async()=>{
  const created=await app.inject(request()),id=created.json().appointment.id;
  const moved=await app.inject({method:'PATCH',url:`/api/v1/appointments/${id}`,headers:headers(),payload:{action:'reschedule',starts_at:day+'T05:00:00.000Z'}});
  assert.equal(moved.statusCode,200);assert.equal(moved.json().appointment.id,id);
  const cancelled=await app.inject({method:'PATCH',url:`/api/v1/appointments/${id}`,headers:headers(),payload:{action:'cancel'}});assert.equal(cancelled.statusCode,200);assert.equal(cancelled.json().appointment.status,'cancelled');
});
test('foreign clinic, forged source, invented status and malformed calendar date are rejected',async()=>{
  assert.equal((await app.inject({...request(),headers:headers('other')})).statusCode,404);
  assert.equal((await app.inject(request({clinic_id:ids.clinicB}))).statusCode,422);
  assert.equal((await app.inject(request({source:'whatsapp'}))).statusCode,422);
  assert.equal((await app.inject({url:'/api/v1/appointments?date=2026-02-30',headers:headers()})).statusCode,422);
  const created=await app.inject(request()),id=created.json().appointment.id;
  assert.equal((await app.inject({method:'PATCH',url:`/api/v1/appointments/${id}`,headers:headers(),payload:{action:'booked'}})).statusCode,422);
  assert.equal((await app.inject({method:'PATCH',url:`/api/v1/appointments/${id}`,headers:headers('other'),payload:{action:'cancel'}})).statusCode,404);
});
test('admin availability API preserves revision checks and rejects other roles and clinics',async()=>{
  const url=`/api/v1/doctors/${doctor}/availability`;
  assert.equal((await app.inject({url,headers:headers()})).statusCode,403);
  assert.equal((await app.inject({url,headers:headers('other')})).statusCode,404);
  const loaded=await app.inject({url,headers:headers('admin')});assert.equal(loaded.statusCode,200);assert.equal(loaded.json().revision,0);
  const update={method:'PATCH',url,headers:headers('admin'),payload:{action:'schedule',expected_revision:0,weekday:1,start_time:'10:00',end_time:'16:00'}};
  const saved=await app.inject(update);assert.equal(saved.statusCode,200);assert.equal(saved.json().revision,1);
  assert.equal((await app.inject(update)).json().replayed,true);
  assert.equal((await app.inject({...update,headers:headers('admin')})).statusCode,409);
  assert.equal((await app.inject({...update,payload:{...update.payload,clinic_id:ids.clinicB}})).statusCode,422);
});
test('queue API is default-off, then supports scoped idempotent add and call-next',async()=>{
  const url=`/api/v1/doctors/${doctor}/queue`;
  assert.equal((await app.inject({url:'/api/v1/queue/status',headers:headers()})).json().enabled,false);
  assert.equal((await app.inject({url,headers:headers()})).statusCode,409);
  await f.db.query("insert into public.clinic_features(clinic_id,feature,enabled) values($1,'walk_in_tokens',true)",[ids.clinicA]);
  await f.db.exec("update public.doctor_schedules set start_time='00:00',end_time='24:00'");
  const input={method:'POST',url,headers:headers(),payload:{action:'add',patient_id:ids.patientA}};
  const first=await app.inject(input),again=await app.inject(input);assert.equal(first.statusCode,200);assert.equal(again.json().replayed,true);
  await app.inject({...input,headers:headers(),payload:{action:'add',patient_id:family}});
  const call=await app.inject({method:'POST',url,headers:headers(),payload:{action:'call_next',expected_called_id:null,expected_next_id:first.json().token.id}});
  assert.equal(call.statusCode,200);assert.equal(call.json().token.status,'called');assert.equal(call.json().notice_state,'review_required');
  const rows=await app.inject({url,headers:headers()});assert.equal(rows.json().tokens.length,2);
});
test('queue API rejects invalid transitions, missing expectations and injected scope',async()=>{
  await f.db.query("insert into public.clinic_features(clinic_id,feature,enabled) values($1,'walk_in_tokens',true)",[ids.clinicA]);
  const url=`/api/v1/doctors/${doctor}/queue`;
  for(const payload of [{action:'call_next',expected_next_id:crypto.randomUUID()},{action:'add',patient_id:ids.patientA,clinic_id:ids.clinicB},{action:'done',id:crypto.randomUUID()}])
    assert.equal((await app.inject({method:'POST',url,headers:headers(),payload})).statusCode,422);
  assert.equal((await app.inject({method:'POST',url,headers:headers(),payload:{action:'add',patient_id:ids.patientB}})).statusCode,404);
});
