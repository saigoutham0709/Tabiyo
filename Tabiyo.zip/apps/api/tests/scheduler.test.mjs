import test, {before, after} from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {PGlite} from '@electric-sql/pglite';
import {PgBoss, fromPglite, TestClock} from 'pg-boss';
import {Scheduler, queues} from '../src/jobs/scheduler.ts';

let db;
const idle = {runOnce: async () => ({action: 'idle'})};
const createBoss = () => new PgBoss({backend: 'pglite', db: fromPglite(db), schema: 'tabiyo_jobs'});
before(() => { db = new PGlite(); });
after(() => db.close());
async function until(read, predicate, description) {
  const deadline = Date.now() + 12_000;
  while (Date.now() < deadline) {
    const value = await read();
    if (predicate(value)) return value;
    await new Promise(resolve => setTimeout(resolve, 25));
  }
  assert.fail(`Timed out: ${description}`);
}
async function setup(options = {}, reset = true) {
  const boss = createBoss();
  await boss.start();
  if (reset) await boss.deleteAllJobs();
  const scheduler = new Scheduler({boss, mode: 'mock', delivery: idle, gateway: idle, cleanup: async () => {}, ...options});
  await scheduler.start();
  return {boss, scheduler};
}

test('real pg-boss starts once, persists three IST schedules, and stops without closing the database', async () => {
  const {boss, scheduler} = await setup();
  try {
    await Promise.all([scheduler.start(), scheduler.start()]);
    const schedules = (await boss.getSchedules()).filter(row => Object.values(queues).includes(row.name));
    assert.equal(schedules.length, 3);
    assert.ok(schedules.every(row => row.timezone === 'Asia/Kolkata'));
    assert.equal(schedules.find(row => row.name === queues.cleanup).cron, '15 3 * * *');
    const queue = await boss.getQueue(queues.delivery);
    assert.equal(queue.policy, 'stately');
    assert.equal(queue.retryLimit, 3);
    assert.equal(queue.expireInSeconds, 120);
    await until(() => boss.findJobs(queues.delivery), rows => rows.some(row => row.state === 'completed'), 'startup wake');
  } finally { await Promise.all([scheduler.stop(), scheduler.stop()]); }
  assert.equal((await db.query('select 1 as n')).rows[0].n, 1);
  await assert.rejects(() => scheduler.wake('gateway'), /SCHEDULER_NOT_RUNNING/);
});

test('bounded drains stop at item limit and use empty control payloads', async () => {
  let calls = 0;
  const {boss, scheduler} = await setup({maxItems: 3, delivery: {runOnce: async () => {calls++; return {action: 'sent'};}}});
  try {
    await until(() => boss.findJobs(queues.delivery), rows => rows.some(row => row.state === 'completed'), 'bounded delivery');
    assert.equal(calls, 3);
    assert.ok((await boss.findJobs(queues.delivery)).every(row => JSON.stringify(row.data) === '{}'));
  } finally { await scheduler.stop(); }
});

test('cleanup wake invokes existing bounded retention operation', async () => {
  let cleanups = 0;
  const {scheduler} = await setup({cleanup: async () => { cleanups++; }});
  try {
    await scheduler.wake('cleanup');
    await until(async () => cleanups, count => count === 1, 'cleanup');
  } finally { await scheduler.stop(); }
});

test('handler errors retry through pg-boss without persisting sensitive error text', async () => {
  const reports = [];
  let fail = true;
  const {boss, scheduler} = await setup({report: (...args) => reports.push(args),
    gateway: {runOnce: async () => {if (fail) throw new Error('patient-secret +919999999999'); return {action: 'idle'};}}});
  try {
    const rows = await until(() => boss.findJobs(queues.gateway), rows => rows.some(row => row.state === 'retry'), 'queue retry');
    const job = rows.find(row => row.state === 'retry');
    assert.ok(!JSON.stringify(job).includes('patient-secret'));
    assert.ok(JSON.stringify(job.output).includes('SCHEDULER_HANDLER_FAILED'));
    assert.deepEqual(reports[0], ['SCHEDULER_HANDLER_FAILED', 'gateway']);
    fail = false;
    // Move the real persisted retry deadline forward; avoid a 30-second wall-clock sleep.
    await boss.update(queues.gateway, {}, {id: job.id, startAfter: new Date()});
    await until(() => boss.findJobs(queues.gateway), rows => rows.some(row => row.id === job.id && row.state === 'completed'), 'retry recovery');
  } finally { await scheduler.stop(); }
});

test('queued jobs and schedules survive a pg-boss instance restart', async () => {
  const first = createBoss();
  await first.start();
  await first.deleteAllJobs();
  const id = await first.send(queues.gateway, {});
  await first.stop();
  let calls = 0;
  const {boss, scheduler} = await setup({gateway: {runOnce: async () => {calls++; return {action: 'idle'};}}}, false);
  try {
    await until(() => boss.findJobs(queues.gateway), rows => rows.some(row => row.id === id && row.state === 'completed'), 'restart recovery');
    assert.ok(calls >= 1);
    assert.equal((await boss.getSchedules()).length, 3);
  } finally { await scheduler.stop(); }
});

test('shutdown waits for an active operation and stops the next drain iteration', async () => {
  let release, entered;
  const inside = new Promise(resolve => {entered = resolve;});
  const blocked = new Promise(resolve => {release = resolve;});
  let calls = 0;
  const {scheduler} = await setup({gateway: {runOnce: async () => {calls++; entered(); await blocked; return {action: 'processed'};}}});
  await inside;
  let stopped = false;
  const stopping = scheduler.stop().then(() => {stopped = true;});
  await new Promise(resolve => setTimeout(resolve, 50));
  assert.equal(stopped, false);
  release();
  await stopping;
  assert.equal(calls, 1);
});

test('rejects live modes and invalid drain limits', () => {
  const dependencies = {boss: createBoss(), mode: 'mock', delivery: idle, gateway: idle, cleanup: async () => {}};
  assert.throws(() => new Scheduler({...dependencies, mode: 'live'}), /SCHEDULER_MOCK_ONLY/);
  for (const maxItems of [0, 101, 1.5]) assert.throws(() => new Scheduler({...dependencies, maxItems}), /INVALID_LIMITS/);
  for (const maxRunMs of [0, 30_001]) assert.throws(() => new Scheduler({...dependencies, maxRunMs}), /INVALID_LIMITS/);
});

test('real cron engine enqueues recurring work under a controlled clock', async () => {
  const clock = new TestClock('2026-11-02T04:30:00Z');
  const boss = new PgBoss({backend:'pglite',db:fromPglite(db),schema:'tabiyo_clock_jobs',clock});
  await boss.start();
  await boss.deleteAllJobs();
  let calls = 0;
  const scheduler = new Scheduler({boss,mode:'mock',delivery:idle,cleanup:async()=>{},
    gateway:{runOnce:async()=>{calls++;return {action:'idle'};}}});
  try {
    await scheduler.start();
    await clock.tick(2000);
    await until(async()=>calls,n=>n>=1,'initial clock-driven worker');
    await clock.tick(120_000);
    await clock.tick(5000);
    await until(async()=>calls,n=>n>=2,'recurring cron worker');
  } finally {await scheduler.stop();}
});

test('unexpected job payloads fail closed and observer errors cannot change outcomes', async () => {
  let cleanups = 0;
  const {boss,scheduler} = await setup({cleanup:async()=>{cleanups++;},report:()=>{throw new Error('observer-secret');}});
  try {
    const id = await boss.send(queues.cleanup,{unexpected:true});
    await until(()=>boss.findJobs(queues.cleanup),rows=>rows.some(row=>row.id===id&&row.state==='retry'),'invalid control payload');
    assert.equal(cleanups,0);
    boss.emit('error',new Error('private transport failure'));
  } finally {await scheduler.stop();}
});

test('partial startup unwinds resources and returns a static error even if shutdown fails', async () => {
  const boss = new EventEmitter();
  let stops = 0;
  boss.start = async () => {};
  boss.createQueue = async () => {throw new Error('private-database-error');};
  boss.stop = async () => {stops++;throw new Error('private-shutdown-error');};
  const scheduler = new Scheduler({boss,mode:'mock',delivery:idle,gateway:idle,cleanup:async()=>{}});
  await assert.rejects(scheduler.start(), {message:'SCHEDULER_START_FAILED'});
  assert.equal(stops,1);
  assert.equal(boss.listenerCount('error'),0);
  await scheduler.stop();
});

test('elapsed drain budget prevents starting another operation without abandoning in-flight work', async () => {
  let calls = 0;
  const {boss,scheduler} = await setup({maxRunMs:1,delivery:{runOnce:async()=>{
    calls++;await new Promise(resolve=>setTimeout(resolve,10));return {action:'sent'};
  }}});
  try {
    await until(()=>boss.findJobs(queues.delivery),rows=>rows.some(row=>row.state==='completed'),'elapsed drain bound');
    assert.equal(calls,1);
  } finally {await scheduler.stop();}
});
