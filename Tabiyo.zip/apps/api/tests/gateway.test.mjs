import test,{before,beforeEach,after} from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {fixture,ids} from '../../../supabase/tests/helpers.mjs';
import {buildApp} from '../src/app.ts';
import {createGatewayStore,GatewayStoreError} from '../src/whatsapp/store.ts';
import {GatewayWorker} from '../src/whatsapp/worker.ts';
import {splitWebhook} from '../src/whatsapp/gateway.ts';
import {createDeliveryStore,DeliveryStoreError} from '../src/delivery/store.ts';

const secret='synthetic-gateway-app-secret',token='synthetic-gateway-verify-token';
const base='2026-11-02T04:30:00.000Z',phone='919000000001';
let f,app,store,instant;
const now=()=>new Date(instant).toISOString();
const advance=minutes=>{instant+=minutes*60000;};
const context={staff:{id:ids.adminA,clinic_id:ids.clinicA,name:'Synthetic Staff',role:'admin',active:true},clinic:{id:ids.clinicA,name:'Synthetic Clinic',timezone:'Asia/Kolkata',default_language:'en'}};
const message=(body='Hi',extra={})=>({id:'wamid.fixture.'+crypto.randomUUID(),from:phone,timestamp:String(Math.floor(instant/1000)),type:'text',text:{body},...extra});
const packet=(messages,number='111',extra={})=>({object:'whatsapp_business_account',entry:[{id:'fixture-business',changes:[{field:'messages',value:{metadata:{phone_number_id:number},messages,...extra}}]}]});
const config=()=>({mode:'local-test',appSecret:secret,verifyToken:token,gatewayId:'synthetic-local',store});
const signature=raw=>'sha256='+createHmac('sha256',secret).update(raw).digest('hex');
const post=(body,headers={})=>{const raw=typeof body==='string'?body:JSON.stringify(body);return app.inject({method:'POST',url:'/webhooks/whatsapp',headers:{'content-type':'application/json','x-hub-signature-256':signature(raw),...headers},payload:raw});};
const worker=()=>new GatewayWorker(store);
const count=async table=>(await f.db.query('select count(*)::integer as n from public.'+table)).rows[0].n;
const conversation=async(number=phone)=>(await f.db.query('select * from public.conversations where clinic_id=$1 and mobile_e164=$2',[ids.clinicA,'+'+number])).rows[0];
before(async()=>{f=await fixture();});
beforeEach(async()=>{
  await app?.close();instant=Date.parse(base);
  await f.db.exec('truncate public.gateway_maintenance,public.gateway_security,public.webhook_raw,public.api_requests,public.consents,public.message_log,public.delivery_receipts,public.mock_deliveries,public.staff_alerts,public.outbox,public.events,public.audit_log,public.conversations;');
  await f.db.exec("delete from public.patients where id::text not like '40000000-0000-4000-8000-%'; update public.patients set opted_out=false,whatsapp_status='unknown'; update public.clinics set settings='{}';");
  await f.db.query('update public.clinics set whatsapp_phone_number_id=$1 where id=$2',['111',ids.clinicA]);
  await f.db.query('update public.clinics set whatsapp_phone_number_id=$1 where id=$2',['222',ids.clinicB]);
  store=createGatewayStore(async(action,input)=>{
    try{return await f.asUser(null,async tx=>(await tx.query('select public.tabiyo_gateway($1,$2::jsonb,$3::timestamptz) as result',[action,JSON.stringify(input),now()])).rows[0].result,'service_role');}
    catch(error){throw new GatewayStoreError(error.message);}
  });
  app=buildApp({authenticate:async()=>context,webhook:config()});
});
after(async()=>{await app?.close();await f?.db.close();});
async function grant(patient=ids.patientA,version='fixture-v1'){
  await f.db.query('insert into public.consents(clinic_id,patient_id,version,status,channel,created_by) values ($1,$2,$3,$4,$5,$6)',[ids.clinicA,patient,version,'granted','phone',ids.adminA]);
}
async function approveNotice(version='fixture-v1'){
  await f.db.query('update public.clinics set settings=settings||$1::jsonb where id=$2',[JSON.stringify({consent_version:version,consent_notice_approved:true}),ids.clinicA]);
}
async function deliverInbound(m){assert.equal((await post(packet([m]))).statusCode,200);return worker().runOnce();}
function deliveryStore(){return createDeliveryStore(async(action,input)=>{
  try{return await f.asUser(null,async tx=>(await tx.query('select public.tabiyo_delivery($1,$2::jsonb,$3::timestamptz) as result',[action,JSON.stringify(input),now()])).rows[0].result,'service_role');}
  catch(error){throw new DeliveryStoreError(error.message);}
});}
async function enqueue(patient=ids.patientA){return (await f.db.query('insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key,not_before) values ($1,$2,$3,$4,$5,$6,$7) returning id',[ids.clinicA,patient,'template','appointment',JSON.stringify({template_name:'notice',language:'en'}),crypto.randomUUID(),now()])).rows[0].id;}

test('gateway is disabled by default and verification challenge requires exact token',async t=>{
  const disabled=buildApp({authenticate:async()=>context});t.after(()=>disabled.close());
  assert.equal((await disabled.inject({url:'/webhooks/whatsapp'})).statusCode,503);
  assert.equal((await disabled.inject({method:'POST',url:'/webhooks/whatsapp',payload:{}})).statusCode,503);
  const query=new URLSearchParams({'hub.mode':'subscribe','hub.verify_token':token,'hub.challenge':'123456'});
  const accepted=await app.inject({url:'/webhooks/whatsapp?'+query});assert.equal(accepted.statusCode,200);assert.equal(accepted.body,'123456');assert.match(accepted.headers['content-type'],/text\/plain/);
  query.set('hub.verify_token','wrong');const bad=await app.inject({url:'/webhooks/whatsapp?'+query});assert.equal(bad.statusCode,403);assert(!bad.body.includes(token));
});
test('raw-byte HMAC rejects missing, malformed, changed and whitespace-normalized bodies',async()=>{
  const raw=JSON.stringify(packet([message('नमस्ते')]));
  for(const bad of ['', 'sha256=bad',signature(raw+' '),'sha256='+'0'.repeat(64)])assert.equal((await post(raw,{'x-hub-signature-256':bad})).statusCode,401);
  assert.equal(await count('webhook_raw'),0);assert.equal((await post(raw)).statusCode,200);
});
test('valid intake acknowledges durable storage without processing patient content synchronously',async()=>{
  const response=await post(packet([message()]));assert.equal(response.statusCode,200);assert.deepEqual(response.json(),{received:true});
  assert.equal(await count('webhook_raw'),1);assert.equal(await count('message_log'),0);assert.equal(await count('conversations'),0);
  assert.equal((await f.db.query('select status from public.webhook_raw')).rows[0].status,'queued');
  assert.equal((await worker().runOnce()).action,'processed');assert.equal(await count('message_log'),1);
});
test('storage failure returns 503 and rolls back all groups in a multi-clinic request',async()=>{
  await f.db.exec("create function private.test_raw_failure() returns trigger language plpgsql as $$ begin if new.phone_number_id='222' then raise exception 'private fixture detail'; end if; return new; end $$; create trigger test_raw_failure before insert on public.webhook_raw for each row execute function private.test_raw_failure();");
  const body=packet([message()]);body.entry[0].changes.push(packet([message()],'222').entry[0].changes[0]);
  try{const response=await post(body);assert.equal(response.statusCode,503);assert(!response.body.includes('private fixture'));assert.equal(await count('webhook_raw'),0);}finally{await f.db.exec('drop trigger test_raw_failure on public.webhook_raw; drop function private.test_raw_failure();');}
});
test('multi-number envelopes are split, routed by authoritative phone ID and processed in isolation',async()=>{
  const a=message('Hi A'),b=message('Hi B');const body=packet([a]);body.entry[0].changes.push(packet([b],'222').entry[0].changes[0]);
  await post(body);const rows=(await f.db.query('select * from public.webhook_raw')).rows;assert.equal(rows.length,2);
  for(const row of rows){assert.equal(row.payload.metadata.phone_number_id,row.phone_number_id);assert.equal(row.clinic_id,row.phone_number_id==='111'?ids.clinicA:ids.clinicB);assert.equal(row.payload.messages.length,1);}
  await worker().runOnce();await worker().runOnce();
  assert.equal((await f.db.query('select clinic_id from public.message_log where wa_message_id=$1',[a.id])).rows[0].clinic_id,ids.clinicA);
  assert.equal((await f.db.query('select clinic_id from public.message_log where wa_message_id=$1',[b.id])).rows[0].clinic_id,ids.clinicB);
});
test('unmapped and missing phone metadata stay quarantined and cannot be blindly replayed',async()=>{
  await post(packet([message()],'999'));const noMetadata=packet([message()]);delete noMetadata.entry[0].changes[0].value.metadata;await post(noMetadata);
  const rows=(await f.db.query('select * from public.webhook_raw')).rows;assert.equal(rows.length,2);assert(rows.every(row=>row.clinic_id===null&&row.status==='quarantined'));
  assert.equal((await worker().runOnce()).action,'idle');await assert.rejects(store.replay(rows[0].id),error=>error.code==='REPLAY_FORBIDDEN');
});
test('database intake rejects a caller-supplied phone that disagrees with payload metadata',async()=>{
  await assert.rejects(store.intake([{phone_number_id:'111',payload:packet([message()],'222').entry[0].changes[0].value}]));
  assert.equal(await count('webhook_raw'),0);
});
test('exact envelopes and changed envelope metadata cannot duplicate a message or consent transition',async()=>{
  await grant();const stop=message('STOP'),body=packet([stop]);await post(body);await post(body);assert.equal(await count('webhook_raw'),1);
  await worker().runOnce();const proofs=await count('consents');assert.equal(await count('message_log'),1);
  await post(packet([stop],'111',{contacts:[{profile:{name:'Synthetic renamed contact'}}]}));await worker().runOnce();
  assert.equal(await count('consents'),proofs);assert.equal(await count('message_log'),1);assert.equal((await f.db.query("select * from public.events where type='message.received'")).rows.length,1);
});
test('same provider message ID with changed content or clinic is a permanent, alerted conflict',async()=>{
  const m=message('Hi');await deliverInbound(m);await post(packet([{...m,text:{body:'Changed'}}]));assert.equal((await worker().runOnce()).code,'WEBHOOK_MESSAGE_CONFLICT');
  await post(packet([m],'222'));assert.equal((await worker().runOnce()).code,'WEBHOOK_MESSAGE_CONFLICT');assert.equal(await count('message_log'),1);assert.equal(await count('staff_alerts'),2);
});
test('inbound family identity remains unselected; old messages never move the inbound window backwards',async()=>{
  await deliverInbound(message());let c=await conversation();assert.equal(c.patient_id,null);assert.equal(c.state,'choose_patient');
  await deliverInbound(message('Old',{timestamp:String(Math.floor(instant/1000)-3600)}));c=await conversation();assert.equal(new Date(c.last_inbound_at).toISOString(),base);
  assert((await f.db.query('select patient_id from public.message_log')).rows.every(row=>row.patient_id===null));
});
test('unknown senders start language onboarding without creating or granting a patient',async()=>{
  const initial=await count('patients');await deliverInbound(message('Hi',{from:'919000000099'}));
  assert.equal((await conversation('919000000099')).state,'new');assert.equal(await count('patients'),initial);assert.equal(await count('consents'),0);
});
test('STOP revokes all family records, cancels queued/unaccepted work, and records source proof',async()=>{
  await grant();await grant('40000000-0000-4000-8000-000000000002');const id=await enqueue();
  const m=message('STOP');await deliverInbound(m);assert((await conversation()).channel_stopped);
  const family=(await f.db.query('select opted_out from public.patients where clinic_id=$1 and mobile_e164=$2',[ids.clinicA,'+'+phone])).rows;assert(family.every(row=>row.opted_out));
  assert.equal((await f.db.query('select status from public.outbox where id=$1',[id])).rows[0].status,'skipped');
  assert.equal((await f.db.query('select * from public.consents where source_message_id=$1',[m.id])).rows.length,2);
  assert.equal((await f.db.query('select opted_out from public.patients where id=$1',[ids.patientB])).rows[0].opted_out,false);
});
test('approved START restores only prior eligible consent; untouched family members get no grant',async()=>{
  await grant();await approveNotice();await deliverInbound(message('STOP'));advance(1);const start=message('START');await deliverInbound(start);
  const c=await conversation();assert.equal(c.channel_stopped,false);assert.equal(c.state,'choose_patient');
  assert.equal((await f.db.query('select opted_out from public.patients where id=$1',[ids.patientA])).rows[0].opted_out,false);
  const restored=(await f.db.query("select * from public.consents where source_message_id=$1 and status='granted'",[start.id])).rows;assert.equal(restored.length,1);assert.equal(restored[0].patient_id,ids.patientA);
  await f.db.query('update public.clinics set settings=settings||$1::jsonb where id=$2',[JSON.stringify({approved_templates:{'notice:en':true}}),ids.clinicA]);
  const id=await enqueue();const sends=deliveryStore();const claim=await sends.claim(crypto.randomUUID());assert.equal(claim.id,id);assert.equal((await sends.prepare(claim)).action,'send');
});
test('START without approved matching notice does not grant consent or replay later after configuration changes',async()=>{
  await grant();await deliverInbound(message('STOP'));advance(1);const blocked=message('START');await deliverInbound(blocked);
  assert((await conversation()).channel_stopped);await approveNotice();await deliverInbound({...message('START'),timestamp:blocked.timestamp});
  assert((await conversation()).channel_stopped);advance(1);await deliverInbound(message('START'));assert.equal((await conversation()).channel_stopped,false);
  await deliverInbound(message('STOP'));advance(1);await approveNotice('new-unseen-version');await deliverInbound(message('START'));
  assert.equal((await f.db.query('select opted_out from public.patients where id=$1',[ids.patientA])).rows[0].opted_out,true);
});
test('stale or tied START cannot override STOP; an individual later revocation is not resurrected',async()=>{
  await grant();await approveNotice();const stop=message('STOP');await deliverInbound(stop);await deliverInbound(message('START',{timestamp:stop.timestamp}));assert((await conversation()).channel_stopped);
  await f.write(ids.adminA,'consent',{status:'revoked',version:'fixture-v1',channel:'phone'},crypto.randomUUID(),ids.patientA);
  advance(1);const start=message('START');await deliverInbound(start);assert.equal((await f.db.query('select opted_out from public.patients where id=$1',[ids.patientA])).rows[0].opted_out,true);
  assert.equal((await f.db.query("select * from public.consents where source_message_id=$1 and status='granted'",[start.id])).rows.length,0);
});
test('an unknown number STOP blocks a patient created later, including consent-request sends',async()=>{
  const unknown='919000000099';await deliverInbound(message('STOP',{from:unknown}));
  const created=await f.write(ids.adminA,'create',{name:'New Synthetic Patient',mobile_e164:'+'+unknown,language:'en'});
  await f.db.query('update public.clinics set settings=$1::jsonb where id=$2',[JSON.stringify({allow_consent_request:true,approved_templates:{'consent_request:en':true}}),ids.clinicA]);
  await f.db.query('update public.outbox set not_before=$1 where patient_id=$2',[now(),created.patient.id]);
  const sends=deliveryStore();const claim=await sends.claim(crypto.randomUUID());assert.equal((await sends.prepare(claim)).code,'WA_OPTED_OUT');
});
test('STOP fences prepared but unaccepted work; accepted evidence can still be recorded after STOP',async()=>{
  await grant();await f.db.query('update public.clinics set settings=$1::jsonb where id=$2',[JSON.stringify({approved_templates:{'notice:en':true}}),ids.clinicA]);
  await enqueue();const sends=deliveryStore();const unaccepted=await sends.claim(crypto.randomUUID());await sends.prepare(unaccepted);
  await deliverInbound(message('STOP'));await assert.rejects(sends.mockAccept(unaccepted),error=>error.code==='LEASE_LOST');assert.equal(await count('mock_deliveries'),0);
  advance(1);await approveNotice();await deliverInbound(message('START'));await enqueue();const accepted=await sends.claim(crypto.randomUUID());await sends.prepare(accepted);const evidence=await sends.mockAccept(accepted);
  advance(1);await deliverInbound(message('STOP'));assert.equal((await sends.complete(accepted,evidence.wa_message_id)).action,'sent');assert.equal(await count('mock_deliveries'),1);
});
test('Hindi/Telugu text and interactive STOP IDs use the same suppression path',async()=>{
  await deliverInbound(message('बंद'));assert((await conversation()).channel_stopped);
  await deliverInbound(message('ఆపు'));assert((await conversation()).channel_stopped);
  await deliverInbound(message('',{type:'interactive',interactive:{type:'button_reply',button_reply:{id:'STOP',title:'Translated caption'}}}));assert((await conversation()).channel_stopped);
});
test('unsupported media is safely logged and handed off without downloading a file',async()=>{
  await deliverInbound(message('',{type:'audio',audio:{id:'synthetic-media-id'}}));assert.equal((await conversation()).handoff,true);
  assert.equal((await f.db.query("select * from public.staff_alerts where code='CONV_UNSUPPORTED_TYPE'")).rows.length,1);
  const log=(await f.db.query('select * from public.message_log')).rows[0];assert.equal(log.type,'audio');assert.equal(log.body_preview,null);
});
test('receipt-only signed callbacks reach the immutable delivery path without creating patient messages',async()=>{
  await grant();await f.db.query('update public.clinics set settings=$1::jsonb where id=$2',[JSON.stringify({approved_templates:{'notice:en':true}}),ids.clinicA]);
  await enqueue();const sends=deliveryStore();const claim=await sends.claim(crypto.randomUUID());await sends.prepare(claim);const accepted=await sends.mockAccept(claim);await sends.complete(claim,accepted.wa_message_id);
  const body=packet([],'111',{statuses:[{id:accepted.wa_message_id,status:'read',timestamp:String(Math.floor(instant/1000))}]});await post(body);assert.equal((await worker().runOnce()).action,'processed');
  assert.equal((await f.db.query('select provider_status from public.outbox')).rows[0].provider_status,'read');assert.equal((await f.db.query("select * from public.message_log where direction='in'")).rows.length,0);
});
test('invalid later message rolls back earlier STOP effects and fails visibly',async()=>{
  await grant();await post(packet([message('STOP'),message('bad',{timestamp:'invalid'})]));
  assert.equal((await worker().runOnce()).action,'failed');assert.equal(await count('message_log'),0);assert.equal(await count('conversations'),0);assert.equal((await f.db.query('select opted_out from public.patients where id=$1',[ids.patientA])).rows[0].opted_out,false);assert.equal(await count('staff_alerts'),1);
});
test('transient processing failure retries durably without partial mutation',async()=>{
  await f.db.exec("create function private.test_inbound_failure() returns trigger language plpgsql as $$ begin if new.direction='in' then raise exception 'fixture temporary failure'; end if; return new; end $$; create trigger test_inbound_failure before insert on public.message_log for each row execute function private.test_inbound_failure();");
  try{await post(packet([message('STOP')]));assert.equal((await worker().runOnce()).action,'queued');assert.equal(await count('message_log'),0);assert.equal(await count('conversations'),0);}finally{await f.db.exec('drop trigger test_inbound_failure on public.message_log; drop function private.test_inbound_failure();');}
  advance(1);assert.equal((await worker().runOnce()).action,'processed');assert.equal(await count('message_log'),1);
});
test('stale worker lease cannot process work reclaimed after restart',async()=>{
  await post(packet([message()]));const old=await store.claim(crypto.randomUUID());assert.equal(await store.claim(crypto.randomUUID()),null);advance(6);const fresh=await store.claim(crypto.randomUUID());
  await assert.rejects(store.process(old),error=>error.code==='LEASE_LOST');assert.equal((await store.process(fresh)).action,'processed');assert.equal(await count('message_log'),1);
});
test('authorized replay is audited and cannot repeat consent mutations',async()=>{
  await grant();await deliverInbound(message('STOP'));const proofs=await count('consents');const raw=(await f.db.query('select id from public.webhook_raw')).rows[0];
  await store.replay(raw.id);await worker().runOnce();assert.equal(await count('consents'),proofs);assert.equal(await count('message_log'),1);
  assert.equal((await f.db.query("select * from public.audit_log where action='webhook.replay'")).rows.length,1);
});
test('seven-day cleanup deletes raw data, keeps dedup proof and alerts for expired pending work',async()=>{
  const m=message('STOP');await deliverInbound(m);await post(packet([message()]));await post(packet([message()],'999'));
  advance(8*24*60);assert.equal((await store.cleanup()).deleted,3);assert.equal(await count('webhook_raw'),0);assert.equal(await count('message_log'),1);assert.equal(await count('gateway_maintenance'),1);
  assert.equal((await f.db.query("select * from public.staff_alerts where code='WEBHOOK_RETENTION_EXPIRED'")).rows.length,1);
  await post(packet([m]));await worker().runOnce();assert.equal(await count('message_log'),1);
});
test('signature failures cross the alert threshold without retaining request bodies',async()=>{
  for(let i=0;i<11;i++)assert.equal((await post(packet([message()]),{'x-hub-signature-256':'sha256='+'0'.repeat(64)})).statusCode,401);
  const security=(await f.db.query('select * from public.gateway_security')).rows[0];assert.equal(security.failures,11);assert.equal(security.alert,true);assert.equal(await count('webhook_raw'),0);
});
test('signature-monitor failure still rejects invalid input without leaking backend details',async t=>{
  const unavailable=buildApp({authenticate:async()=>context,webhook:{...config(),store:{...store,badSignature:async()=>{throw Error('private credential detail');}}}});t.after(()=>unavailable.close());
  const response=await unavailable.inject({method:'POST',url:'/webhooks/whatsapp',headers:{'content-type':'application/json','x-hub-signature-256':'sha256='+'0'.repeat(64)},payload:JSON.stringify(packet([message()]))});
  assert.equal(response.statusCode,401);assert(!response.body.includes('private credential'));assert.equal(await count('webhook_raw'),0);
});
test('malformed signed envelopes, invalid UTF-8 and oversized payloads are rejected without echoing content',async()=>{
  for(const body of ['{"private":',JSON.stringify({object:'other',entry:[]})]){const response=await post(body);assert.equal(response.statusCode,400);assert(!response.body.includes('private'));}
  const bytes=Buffer.from([0xff,0xfe]);const badUtf=await app.inject({method:'POST',url:'/webhooks/whatsapp',headers:{'content-type':'application/json','x-hub-signature-256':signature(bytes)},payload:bytes});assert.equal(badUtf.statusCode,400);
  const large=await post(packet([message('x'.repeat(260*1024))]));assert.equal(large.statusCode,413);assert.equal(await count('webhook_raw'),0);
});
test('staff and anonymous clients cannot execute gateway or inspect global security/maintenance data',async()=>{
  for(const role of ['authenticated','anon']){
    await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('select public.tabiyo_gateway($1,$2::jsonb)',['cleanup','{}']),role),/permission denied/);
    for(const table of ['gateway_security','gateway_maintenance'])await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('select * from public.'+table),role),/permission denied/);
  }
  await assert.rejects(f.asUser(null,tx=>tx.query('delete from public.webhook_raw'),'service_role'),/permission denied/);
});
test('cleanup preserves an active lease even if the raw payload is beyond seven days',async()=>{
  await post(packet([message()]));await store.claim(crypto.randomUUID());
  await f.db.query("update public.webhook_raw set received_at=$1",[new Date(instant-8*86400000).toISOString()]);
  assert.equal((await store.cleanup()).deleted,0);assert.equal(await count('webhook_raw'),1);
});
test('splitting retains each change value without copying other clinics into a group',()=>{
  const body=packet([message()]);body.entry[0].changes.push(packet([message()],'222').entry[0].changes[0]);const groups=splitWebhook(Buffer.from(JSON.stringify(body)));
  assert.equal(groups.length,2);assert.equal(groups[0].phone_number_id,'111');assert.equal(groups[1].phone_number_id,'222');assert.equal(groups[0].payload.messages.length,1);
});
