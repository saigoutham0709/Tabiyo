import test, { before, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { fixture, ids } from '../../../supabase/tests/helpers.mjs';
import { ConversationEngine } from '../src/conversation/engine.ts';
import { DoseScheduler } from '../src/jobs/dose-scheduler.ts';
import { askFaqAssistant } from '../src/faq/assistant.ts';
import {
  renderTemplate,
  matchGlobalCommand,
  isEmergencyMessage,
  isMedicalAdviceQuery,
} from '@tabiyo/templates';

let f;
const baseInstant = '2026-11-08T04:30:00.000Z'; // 10:00 AM IST
let currentInstant;
const now = () => new Date(currentInstant).toISOString();
const advanceMinutes = (mins) => {
  currentInstant += mins * 60 * 1000;
};

const doctor1 = '30000000-0000-4000-8000-000000000001'; // Demo Doctor One
const doctor2 = '30000000-0000-4000-8000-000000000002'; // Demo Doctor Two
const patient1 = ids.patientA; // Demo Patient 1 (+919000000001, DOB: 1990-01-02)
const patient2 = '40000000-0000-4000-8000-000000000002'; // Demo Patient 2 (+919000000001, DOB: 1990-01-03)
const singlePatientMobile = '+919000000003'; // Demo Patient 3 (+919000000003, single family member)

before(async () => {
  f = await fixture();
});

after(async () => {
  await f?.db.close();
});

beforeEach(async () => {
  currentInstant = Date.parse(baseInstant);
  // Truncate runtime tables
  await f.db.exec(`
    truncate public.staff_operation_requests, public.api_requests, public.consents,
             public.message_log, public.mock_deliveries, public.delivery_receipts,
             public.staff_alerts, public.events, public.audit_log, public.outbox,
             public.appointments, public.doctor_schedules, public.doctor_leaves,
             public.conversations, public.dob_lockouts, public.visits,
             public.prescriptions, public.medication_schedules, public.dose_events,
             public.faqs cascade;
  `);

  // Seed doctor schedules: Monday-Sunday 9 AM - 5 PM, 1 PM - 2 PM break
  await f.db.query(`
    insert into public.doctor_schedules (clinic_id, doctor_id, weekday, start_time, end_time, break_start, break_end)
    select $1, d.id, w, '09:00', '17:00', '13:00', '14:00'
    from public.doctors d
    cross join generate_series(0, 6) w
    where d.clinic_id = $1
    on conflict do nothing
  `, [ids.clinicA]);

  // Reset patient states
  await f.db.query(`update public.patients set opted_out = false where clinic_id = $1`, [ids.clinicA]);
  await f.db.query(`update public.clinics set settings = '{"phone": "+919876543210"}'::jsonb where id = $1`, [ids.clinicA]);
});

test('multi-lingual templates render expected text and buttons in en, te, hi', () => {
  // 1. Consent request
  const enConsent = renderTemplate('consent_request', 'en', { clinic_name: 'Sunrise Clinic' });
  assert.match(enConsent, /Sunrise Clinic/);
  assert.match(enConsent, /Agree/);

  const teConsent = renderTemplate('consent_request', 'te', { clinic_name: 'సూర్యోదయ క్లినిక్' });
  assert.match(teConsent, /సూర్యోదయ క్లినిక్/);
  assert.match(teConsent, /సమ్మతి/);

  const hiConsent = renderTemplate('consent_request', 'hi', { clinic_name: 'सूर्योदय क्लिनिक' });
  assert.match(hiConsent, /सूर्योदय क्लिनिक/);
  assert.match(hiConsent, /सहमत/);

  // 2. Appointment confirmed
  const enConfirmed = renderTemplate('appointment_confirmed', 'en', {
    patient_name: 'Lakshmi',
    doctor_name: 'Dr. Rao',
    clinic_name: 'Sunrise Clinic',
    date: '2026-11-10',
    time: '10:00 AM',
  });
  assert.match(enConfirmed, /Lakshmi/);
  assert.match(enConfirmed, /Dr\. Rao/);
  assert.match(enConfirmed, /Reschedule/);

  // 3. Medication reminder
  const enMed = renderTemplate('medication_reminder', 'en', {
    patient_name: 'Lakshmi',
    time_of_day: 'morning',
    medicine_list: '• Metformin 500mg',
  });
  assert.match(enMed, /morning/);
  assert.match(enMed, /Metformin/);

  // Global commands recognition
  assert.equal(matchGlobalCommand('menu'), 'menu');
  assert.equal(matchGlobalCommand('మెనూ'), 'menu');
  assert.equal(matchGlobalCommand('मेनू'), 'menu');
  assert.equal(matchGlobalCommand('stop'), 'stop');
  assert.equal(matchGlobalCommand('ఆపు'), 'stop');
  assert.equal(matchGlobalCommand('बंद'), 'stop');
  assert.equal(matchGlobalCommand('start'), 'start');
  assert.equal(matchGlobalCommand('help'), 'help');
  assert.equal(matchGlobalCommand('సహాయం'), 'help');
});

test('emergency 108 heuristic takes precedence over state/consent and raises staff alert', async () => {
  const engine = new ConversationEngine({ db: f.db, now });

  // Unregistered or unconsented phone with emergency message
  const emergencyInputs = [
    'I have severe chest pain and cannot breathe',
    'Emergency! The patient is unconscious and bleeding heavily',
    'తీవ్రమైన గుండె నొప్పి వస్తోంది, శ్వాస ఆడటం లేదు', // Telugu
    'मरीज बेहोश है और खून बह रहा है, आपातकालीन', // Hindi
  ];

  for (const text of emergencyInputs) {
    assert.equal(isEmergencyMessage(text), true);
    const result = await engine.handleMessage({
      clinicId: ids.clinicA,
      mobileE164: '+919888877777',
      text,
    });

    assert.equal(result.state, 'emergency');
    assert.match(result.reply, /108/);
    assert.match(result.reply, /\+919876543210/); // Clinic phone
    assert.equal(result.alertRaised, true);
    assert.equal(result.alertCode, 'AI_EMERGENCY');
  }

  // Verify alert persisted in staff_alerts
  const alerts = (await f.db.query("select * from public.staff_alerts where code = 'AI_EMERGENCY'")).rows;
  assert.ok(alerts.length >= 1);
  assert.equal(alerts[0].clinic_id, ids.clinicA);

  // Verify emergency event emitted
  const events = (await f.db.query("select * from public.events where type = 'emergency.alert'")).rows;
  assert.ok(events.length >= 1);
});

test('medical advice refusal guardrail strictly blocks symptoms and dosage changes', async () => {
  const engine = new ConversationEngine({ db: f.db, now });

  const medicalQueries = [
    'I have high fever and severe headache, what medicine should I take?',
    'Can I increase my dosage to 2 tablets daily?',
    'నాకు తీవ్రమైన జ్వరం మరియు దగ్గు ఉంది, ఏ మందు వాడాలి?',
    'मुझे सिरदर्द और बुखार है, क्या मैं दवा बदल सकता हूँ?',
  ];

  for (const text of medicalQueries) {
    assert.equal(isMedicalAdviceQuery(text), true);
    const result = await engine.handleMessage({
      clinicId: ids.clinicA,
      mobileE164: '+919000000003',
      text,
    });

    assert.equal(result.state, 'medical_refusal');
    assert.match(result.reply, /cannot provide medical advice|వైద్య సలహాలు|चिकित्सीय सलाह/);
    assert.match(result.reply, /consult a|doctor|వైద్యుడిని|डॉक्टर/);
  }
});

test('shared phone family member picker allows selecting among family members', async () => {
  const engine = new ConversationEngine({ db: f.db, now });
  const sharedMobile = '+919000000001'; // Belongs to Patient 1 and Patient 2

  // 1. Initial contact: user chooses language
  let res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: sharedMobile,
    text: '1', // English
  });

  // Multiple patients exist on this number -> enters choose_patient
  assert.equal(res.state, 'choose_patient');
  assert.match(res.reply, /Multiple family members share this number/);
  assert.match(res.reply, /1\. Demo Patient 1/);
  assert.match(res.reply, /2\. Demo Patient 2/);

  // 2. Select patient 2
  res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: sharedMobile,
    text: '2',
  });

  // Patient 2 needs consent -> enters awaiting_consent
  assert.equal(res.state, 'awaiting_consent');
  assert.match(res.reply, /Agree/);

  // Check conversation has patient_id set to Patient 2
  const conv = (await f.db.query("select * from public.conversations where mobile_e164 = $1", [sharedMobile])).rows[0];
  assert.equal(conv.patient_id, patient2);

  // 3. Grant consent
  res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: sharedMobile,
    text: '1', // Agree
  });

  assert.equal(res.state, 'menu');
  assert.match(res.reply, /Main Menu/);

  // Verify consent recorded
  const consent = (await f.db.query("select * from public.consents where patient_id = $1", [patient2])).rows[0];
  assert.equal(consent.status, 'granted');
});

test('full conversational booking flow from language -> menu -> doctor -> date -> slot -> confirmed', async () => {
  const engine = new ConversationEngine({ db: f.db, now });

  // 1. New message on single-patient number
  let res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: singlePatientMobile,
    text: 'Hi',
  });
  assert.equal(res.state, 'new');
  assert.match(res.reply, /English/);

  // 2. Choose English
  res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: singlePatientMobile,
    text: '1',
  });
  assert.equal(res.state, 'awaiting_consent');
  assert.match(res.reply, /Agree/);

  // 3. Agree to consent
  res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: singlePatientMobile,
    text: '1',
  });
  assert.equal(res.state, 'menu');
  assert.match(res.reply, /1\. Book appointment/);

  // 4. Select Book Appointment
  res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: singlePatientMobile,
    text: '1',
  });
  assert.equal(res.state, 'booking');
  assert.match(res.reply, /Demo Doctor One/);
  assert.match(res.reply, /Demo Doctor Two/);

  // 5. Select Doctor 1
  res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: singlePatientMobile,
    text: '1',
  });
  assert.equal(res.state, 'booking');
  assert.match(res.reply, /Please choose a date/);

  // 6. Select Date (Option 1)
  res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: singlePatientMobile,
    text: '1',
  });
  assert.equal(res.state, 'booking');
  assert.match(res.reply, /Available times/);

  // 7. Select Slot (Option 1)
  res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: singlePatientMobile,
    text: '1',
  });
  assert.equal(res.state, 'booking');
  assert.match(res.reply, /Please confirm your booking/);

  // 8. Confirm Booking
  res = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: singlePatientMobile,
    text: '1',
  });
  assert.equal(res.state, 'menu');
  assert.match(res.reply, /confirmed/i);

  // Verify appointment created in database
  const appts = (await f.db.query("select * from public.appointments where source = 'whatsapp'")).rows;
  assert.equal(appts.length, 1);
  assert.equal(appts[0].status, 'booked');
  assert.equal(appts[0].doctor_id, doctor1);

  // Verify outbox entry
  const outbox = (await f.db.query("select * from public.outbox where purpose = 'appointment'")).rows;
  assert.equal(outbox.length, 1);
  assert.equal(outbox[0].payload.template_name, 'appointment_confirmed');

  // Verify event emitted
  const events = (await f.db.query("select * from public.events where type = 'appointment.booked'")).rows;
  assert.equal(events.length, 1);
});

test('30-minute session expiration resets in-progress booking flow cleanly', async () => {
  const engine = new ConversationEngine({ db: f.db, now, sessionTimeoutMinutes: 30 });

  // Fast forward user to booking step
  await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: singlePatientMobile, text: '1' }); // en
  await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: singlePatientMobile, text: '1' }); // agree
  await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: singlePatientMobile, text: '1' }); // book
  const inProgress = await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: singlePatientMobile, text: '1' }); // choose doctor
  assert.equal(inProgress.state, 'booking');

  // Advance time by 31 minutes
  advanceMinutes(31);

  // Send next message: session has expired, resets to menu
  const expiredRes = await engine.handleMessage({
    clinicId: ids.clinicA,
    mobileE164: singlePatientMobile,
    text: '1',
  });

  // Cleanly recovered to menu or restarted
  assert.ok(['menu', 'booking'].includes(expiredRes.state));
});

test('DOB check with 3-strike lockout and staff alert for visit slips', async () => {
  const engine = new ConversationEngine({ db: f.db, now });

  // Onboard Patient 1
  await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '1' }); // en
  await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '1' }); // select patient 1
  await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '1' }); // agree

  // Go to visit slip
  let res = await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '3' });
  assert.equal(res.state, 'slip_verify');
  assert.match(res.reply, /Date of Birth/);

  // Attempt 1: Wrong DOB
  res = await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '1985-05-20' });
  assert.equal(res.state, 'slip_verify');
  assert.match(res.reply, /Attempt 1 of 3/);

  // Attempt 2: Wrong DOB
  res = await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '1988-12-10' });
  assert.equal(res.state, 'slip_verify');
  assert.match(res.reply, /Attempt 2 of 3/);

  // Attempt 3: Wrong DOB -> triggers 1-hour lockout and staff alert
  res = await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '1995-02-14' });
  assert.equal(res.state, 'menu');
  assert.match(res.reply, /locked for 1 hour/);
  assert.equal(res.alertRaised, true);
  assert.equal(res.alertCode, 'ID_CHECK_LOCKED');

  // Verify staff alert
  const alerts = (await f.db.query("select * from public.staff_alerts where code = 'ID_CHECK_LOCKED'")).rows;
  assert.equal(alerts.length, 1);
  assert.equal(alerts[0].patient_id, patient1);

  // Attempt 4 while locked: access remains blocked
  res = await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '3' });
  assert.match(res.reply, /locked for 1 hour/);

  // Reset lockout and test successful verification with correct DOB (1990-01-02)
  await f.db.query("delete from public.dob_lockouts where patient_id = $1", [patient1]);

  // Insert a test visit with slip
  const appt = (await f.db.query(
    `insert into public.appointments (clinic_id, patient_id, doctor_id, starts_at, ends_at, source)
     values ($1, $2, $3, $4, $4::timestamptz + interval '30 minutes', 'phone') returning id`,
    [ids.clinicA, patient1, doctor1, now()]
  )).rows[0];

  await f.db.query(
    `insert into public.visits (clinic_id, appointment_id, patient_id, notes, slip_file_path)
     values ($1, $2, $3, 'Regular checkup', 'slips/sample.pdf')`,
    [ids.clinicA, appt.id, patient1]
  );

  // Start slip verify again
  await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '3' });

  // Provide correct DOB
  res = await engine.handleMessage({ clinicId: ids.clinicA, mobileE164: '+919000000001', text: '1990-01-02' });
  assert.equal(res.state, 'menu');
  assert.match(res.reply, /ready/i);
  assert.match(res.reply, /storage\.tabiyo\.internal/);

  // Verify audit log
  const audit = (await f.db.query("select * from public.audit_log where action = 'document.read'")).rows;
  assert.equal(audit.length, 1);
});

test('grounded FAQ assistant answers strictly from clinic FAQs or hands off', async () => {
  // Add active FAQ for clinic A
  await f.db.query(
    `insert into public.faqs (clinic_id, question, answer, language)
     values ($1, 'What are the clinic consultation hours?', 'We are open Monday to Saturday from 9 AM to 6 PM IST.', 'en')`,
    [ids.clinicA]
  );

  // 1. Relevant question matching FAQ
  const res1 = await askFaqAssistant({
    clinicId: ids.clinicA,
    query: 'What are the clinic consultation hours?',
    language: 'en',
    db: f.db,
  });
  assert.equal(res1.answered, true);
  assert.match(res1.answer, /9 AM to 6 PM/);
  assert.equal(res1.offerHandoff, false);

  // 2. Question outside clinic FAQ
  const res2 = await askFaqAssistant({
    clinicId: ids.clinicA,
    query: 'Do you offer dental implants and root canals?',
    language: 'en',
    db: f.db,
  });
  assert.equal(res2.answered, false);
  assert.match(res2.answer, /not sure/i);
  assert.equal(res2.offerHandoff, true);
});

test('grouped dose reminders with Taken, Later (30m delay, max 1 retry), and Stop actions', async () => {
  const scheduler = new DoseScheduler({ db: f.db, now });
  const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata' }).format(new Date(now()));

  // 1. Create prescription with 2 morning medicines for Patient 1
  const rx = (await f.db.query(
    `insert into public.prescriptions (clinic_id, patient_id, created_by)
     values ($1, $2, $3) returning id`,
    [ids.clinicA, patient1, ids.adminA]
  )).rows[0];

  await f.db.query(
    `insert into public.medication_schedules (clinic_id, prescription_id, patient_id, medicine, dose, times, food_relation, start_date, end_date)
     values
     ($1, $2, $3, 'Metformin 500mg', '1 tablet', array['morning'], 'after_food', $4, $4::date + 5),
     ($1, $2, $3, 'Telmisartan 40mg', '1 tablet', array['morning'], 'before_food', $4, $4::date + 5)`,
    [ids.clinicA, rx.id, patient1, today]
  );

  // 2. Process morning dose reminders
  const processResult = await scheduler.processDueReminders('morning');
  assert.equal(processResult.sent, 1); // 1 grouped message for both medicines!

  // Check outbox
  const outbox = (await f.db.query("select * from public.outbox where purpose = 'medication'")).rows;
  assert.equal(outbox.length, 1);
  assert.match(outbox[0].payload.text, /Metformin 500mg/);
  assert.match(outbox[0].payload.text, /Telmisartan 40mg/);

  // Check dose_events
  const doseEvents = (await f.db.query("select * from public.dose_events")).rows;
  assert.equal(doseEvents.length, 1);
  assert.equal(doseEvents[0].response, 'none');

  const groupKey = doseEvents[0].schedule_group_key;

  // 3. Test 'Taken' action
  const takenResult = await scheduler.handleDoseAction(ids.clinicA, patient1, 'taken', groupKey);
  assert.equal(takenResult.success, true);
  assert.equal(takenResult.action, 'taken');

  const takenEvent = (await f.db.query("select * from public.dose_events where schedule_group_key = $1", [groupKey])).rows[0];
  assert.equal(takenEvent.response, 'taken');
  assert.ok(takenEvent.responded_at);

  // 4. Test 'Remind later' action (30-minute delay)
  const laterResult = await scheduler.handleDoseAction(ids.clinicA, patient1, 'later', groupKey);
  assert.equal(laterResult.success, true);
  assert.equal(laterResult.action, 'later');

  const delayedOutbox = (await f.db.query("select * from public.outbox where idempotency_key like '%:retry1'")).rows;
  assert.equal(delayedOutbox.length, 1);
  const scheduledTime = new Date(delayedOutbox[0].not_before).getTime();
  const originalTime = new Date(now()).getTime();
  assert.equal(Math.round((scheduledTime - originalTime) / (60 * 1000)), 30); // 30 minutes later!

  // Test max 1 retry: trying 'later' again should hit limit
  const secondLater = await scheduler.handleDoseAction(ids.clinicA, patient1, 'later', groupKey);
  assert.equal(secondLater.action, 'later_limit_reached');

  // 5. Test 'Stop' action
  const stopResult = await scheduler.handleDoseAction(ids.clinicA, patient1, 'stop', groupKey);
  assert.equal(stopResult.success, true);
  assert.equal(stopResult.action, 'stop');

  // Medication schedule should be marked as stopped
  const stoppedSchedules = (await f.db.query("select status from public.medication_schedules where patient_id = $1", [patient1])).rows;
  assert.ok(stoppedSchedules.every(s => s.status === 'stopped'));

  // 6. Test schedule completion when end_date has passed
  await f.db.query(
    `insert into public.medication_schedules (clinic_id, prescription_id, patient_id, medicine, dose, times, food_relation, start_date, end_date, status)
     values ($1, $2, $3, 'Amoxicillin 500mg', '1 capsule', array['morning'], 'after_food', $4::date - 10, $4::date - 1, 'active')`,
    [ids.clinicA, rx.id, patient1, today]
  );

  const completedCount = await scheduler.completeExpiredSchedules();
  assert.ok(completedCount >= 1);

  const expiredSched = (await f.db.query("select status from public.medication_schedules where medicine = 'Amoxicillin 500mg'")).rows[0];
  assert.equal(expiredSched.status, 'completed');
});
