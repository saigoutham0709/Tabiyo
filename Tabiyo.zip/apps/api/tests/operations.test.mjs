import test,{before,beforeEach,after} from 'node:test';
import assert from 'node:assert/strict';
import {fixture,ids} from '../../../supabase/tests/helpers.mjs';
import {buildApp} from '../src/app.ts';
import {createAuthenticator} from '../src/auth.ts';
import {createOperationsService} from '../src/operations.ts';
let f,app,providerFault;
const users={admin:ids.adminA,front:ids.frontA,other:ids.adminB,inactive:ids.inactive};
const inputHeaders=(token='admin',key=crypto.randomUUID())=>({authorization:'Bearer '+token,'idempotency-key':key});
before(async()=>{
  f=await fixture();
  const providerFetch=async(input,init)=>{
    const url=new URL(typeof input==='string'?input:input.url??input.toString());
    const token=new Headers(init?.headers).get('authorization')?.replace('Bearer ','');
    const user=users[token];
    if(!user)return Response.json({msg:'invalid JWT',code:'bad_jwt'},{status:401});
    if(url.pathname==='/auth/v1/user')return Response.json({id:user,is_anonymous:false,user_metadata:{role:'admin',clinic_id:ids.clinicB}});
    if(url.pathname==='/rest/v1/staff_users')return Response.json((await f.asUser(user,tx=>tx.query('select id,clinic_id,name,role,active from public.staff_users where id=$1 and active',[user]))).rows);
    if(url.pathname==='/rest/v1/clinics')return Response.json((await f.asUser(user,tx=>tx.query('select id,name,timezone,default_language from public.clinics where id=$1',[url.searchParams.get('id')?.slice(3)]))).rows);
    if(url.pathname==='/rest/v1/rpc/tabiyo_staff_operations'){
      if(providerFault==='scope')return Response.json({alerts:[{id:crypto.randomUUID(),clinic_id:ids.clinicB,patient_id:null,code:'SYNTHETIC',status:'open',created_at:new Date().toISOString(),resolved_at:null,resolved_by:null,resolution_code:null}]});
      if(providerFault==='error')return Response.json({code:'XX000',message:'secret connection +919999999999'},{status:500});
      const {p_action,p_input}=JSON.parse(init.body);
      try{return Response.json(await f.asUser(user,async tx=>(await tx.query('select public.tabiyo_staff_operations($1,$2::jsonb) result',[p_action,JSON.stringify(p_input)])).rows[0].result));}
      catch(error){return Response.json({code:error.code??'XX000',message:error.message},{status:400});}
    }
    throw Error('Unexpected mocked provider URL');
  };
  const config={url:'https://fixture.example.test',publishableKey:'synthetic-publishable-key',fetch:providerFetch};
  app=buildApp({authenticate:createAuthenticator(config),operations:createOperationsService(config)});
});
after(async()=>{await app?.close();await f?.db.close();});
beforeEach(async()=>{providerFault=null;await f.db.exec('truncate public.staff_operation_requests,public.staff_alerts,public.events,public.audit_log,public.consents,public.message_log,public.mock_deliveries,public.outbox;');});
async function alert(clinic=ids.clinicA){return (await f.db.query("insert into public.staff_alerts(clinic_id,code,dedup_key) values($1,'SYNTHETIC',$2) returning id",[clinic,crypto.randomUUID()])).rows[0].id;}
async function uncertain(){return (await f.db.query("insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key,status) values($1,$2,'template','appointment','{}',$3,'uncertain') returning id",[ids.clinicA,ids.patientA,crypto.randomUUID()])).rows[0].id;}
test('authenticated alert lists remain caller-scoped through the Supabase adapter',async()=>{
  await alert();await alert(ids.clinicB);
  const response=await app.inject({url:'/api/v1/alerts',headers:inputHeaders('front')});
  assert.equal(response.statusCode,200);assert.equal(response.json().alerts.length,1);
  assert.equal(response.json().alerts[0].clinic_id,ids.clinicA);assert.equal(response.headers['cache-control'],'no-store');
});
test('resolution requires a request key and returns one audited idempotent outcome',async()=>{
  const id=await alert(),request={method:'POST',url:`/api/v1/alerts/${id}/resolve`,headers:inputHeaders('front'),payload:{resolution_code:'investigated'}};
  const first=await app.inject(request),replay=await app.inject(request);
  assert.equal(first.statusCode,200);assert.equal(replay.json().replayed,true);
  assert.equal((await f.db.query("select count(*)::integer n from public.events where type='staff.alert_resolved'")).rows[0].n,1);
});
test('foreign clinic IDs, inactive identities and missing auth are rejected',async()=>{
  const id=await alert(ids.clinicB);
  const response=await app.inject({method:'POST',url:`/api/v1/alerts/${id}/resolve`,headers:inputHeaders(),payload:{resolution_code:'investigated'}});
  assert.equal(response.statusCode,404);
  assert.equal((await app.inject({url:'/api/v1/alerts',headers:inputHeaders('inactive')})).statusCode,403);
  assert.equal((await app.inject({url:'/api/v1/alerts'})).statusCode,401);
});
test('only admin can list or review uncertain delivery; missing proof is held',async()=>{
  const id=await uncertain();
  assert.equal((await app.inject({url:'/api/v1/deliveries/uncertain',headers:inputHeaders('front')})).statusCode,403);
  const request={method:'POST',url:`/api/v1/deliveries/${id}/review`,headers:inputHeaders(),payload:{action:'reconcile_mock'}};
  const result=await app.inject(request);assert.equal(result.statusCode,200);assert.equal(result.json().resolution,'held');
  assert.equal((await app.inject({...request,headers:inputHeaders('front')})).statusCode,403);
});
test('closure records a controlled reason and never claims successful delivery',async()=>{
  const id=await uncertain();
  const response=await app.inject({method:'POST',url:`/api/v1/deliveries/${id}/review`,headers:inputHeaders(),payload:{action:'close_without_resend',resolution_code:'patient_contacted'}});
  assert.equal(response.statusCode,200);assert.equal(response.json().status,'failed');
  assert.equal((await f.db.query('select count(*)::integer n from public.message_log')).rows[0].n,0);
});
test('strict route validation rejects arbitrary reasons, scope injection and missing request keys',async()=>{
  const id=await alert();
  for(const payload of [{resolution_code:'free text patient secret'},{resolution_code:'investigated',clinic_id:ids.clinicB}]){
    assert.equal((await app.inject({method:'POST',url:`/api/v1/alerts/${id}/resolve`,headers:inputHeaders(),payload})).statusCode,422);
  }
  assert.equal((await app.inject({url:'/api/v1/alerts?limit=101',headers:inputHeaders()})).statusCode,422);
  assert.equal((await app.inject({url:'/api/v1/alerts?clinic_id='+ids.clinicB,headers:inputHeaders()})).statusCode,422);
  assert.equal((await app.inject({method:'POST',url:`/api/v1/alerts/${id}/resolve`,headers:{authorization:'Bearer admin'},payload:{resolution_code:'investigated'}})).statusCode,422);
});
test('provider scope mismatch and raw errors fail closed without disclosing internals',async()=>{
  providerFault='scope';let result=await app.inject({url:'/api/v1/alerts',headers:inputHeaders()});assert.equal(result.statusCode,503);
  providerFault='error';result=await app.inject({url:'/api/v1/alerts',headers:inputHeaders()});
  assert.equal(result.statusCode,503);assert.ok(!result.body.includes('secret'));assert.ok(!result.body.includes('+91'));
});
