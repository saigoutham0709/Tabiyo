import test,{before,beforeEach,after} from 'node:test';
import assert from 'node:assert/strict';
import {fixture,ids} from '../../../supabase/tests/helpers.mjs';
import {createDeliveryStore,DeliveryStoreError} from '../src/delivery/store.ts';
import {RecordingMockSender,SendFailure} from '../src/delivery/mock-sender.ts';
import {DeliveryWorker} from '../src/delivery/worker.ts';

let f,store,instant;
const base='2026-11-02T04:30:00.000Z'; // 10 AM IST.
const approved={'notice:en':true,'notice:te':true,'consent_request:en':true,'medication_reminder:en':true};
const now=()=>new Date(instant).toISOString();
const advance=minutes=>{instant+=minutes*60000;};
before(async()=>{f=await fixture();});after(()=>f?.db.close());
beforeEach(async()=>{
  instant=Date.parse(base);
  await f.db.exec('truncate public.message_log,public.delivery_receipts,public.mock_deliveries,public.staff_alerts,public.events,public.audit_log,public.api_requests,public.outbox,public.consents,public.conversations;');
  await f.db.exec("update public.patients set opted_out=false,whatsapp_status='unknown',merged_into=null; delete from public.clinic_features;");
  await f.db.query('update public.clinics set daily_send_cap=100,settings=$1::jsonb',[JSON.stringify({approved_templates:approved})]);
  store=createDeliveryStore(async(action,input)=>{
    try{return await f.asUser(null,async tx=>(await tx.query('select public.tabiyo_delivery($1,$2::jsonb,$3::timestamptz) as result',[action,JSON.stringify(input),now()])).rows[0].result,'service_role');}
    catch(error){throw new DeliveryStoreError(error.message);}
  });
});
async function consent(status='granted',patient=ids.patientA){
  await f.db.query('insert into public.consents(clinic_id,patient_id,version,status,channel,created_by) values ($1,$2,$3,$4,$5,$6)',[ids.clinicA,patient,'fixture-v1',status,'phone',ids.adminA]);
}
async function enqueue({kind='template',purpose='appointment',payload={template_name:'notice',language:'en'},notBefore=now(),clinic=ids.clinicA,patient=ids.patientA}={}){
  return (await f.db.query('insert into public.outbox(clinic_id,patient_id,kind,purpose,payload,idempotency_key,not_before) values ($1,$2,$3,$4,$5::jsonb,$6,$7) returning id',[clinic,patient,kind,purpose,JSON.stringify(payload),crypto.randomUUID(),notBefore])).rows[0].id;
}
const row=async id=>(await f.db.query('select * from public.outbox where id=$1',[id])).rows[0];
const count=async table=>(await f.db.query('select count(*)::integer as n from public.'+table)).rows[0].n;
const worker=behavior=>new DeliveryWorker(store,new RecordingMockSender(store,behavior));

test('mock acceptance is durable, recorded once, and never called delivered without receipts',async()=>{
  await consent();const id=await enqueue();const w=worker();assert.equal((await w.runOnce()).action,'sent');assert.equal((await w.runOnce()).action,'idle');
  assert.equal((await row(id)).status,'sent');assert.equal((await row(id)).provider_status,'accepted');
  assert.equal(await count('mock_deliveries'),1);assert.equal(await count('message_log'),1);
  assert.equal((await f.db.query("select * from public.audit_log where action='outbox.policy_check'")).rows.length,2);
  assert.equal((await f.db.query('select body_preview from public.message_log')).rows[0].body_preview,null);
});
test('unknown consent is blocked; consent-request exception is default off and requires approval',async()=>{
  const normal=await enqueue();assert.equal((await worker().runOnce()).code,'WA_CONSENT_REQUIRED');assert.equal((await row(normal)).attempts,0);
  await enqueue({purpose:'consent_request',payload:{template_name:'consent_request',language:'en'}});assert.equal((await worker().runOnce()).code,'WA_CONSENT_REQUIRED');
  await f.db.exec("update public.clinics set settings=settings||'{\"allow_consent_request\":true}'::jsonb;");
  await enqueue({purpose:'consent_request',payload:{template_name:'consent_request',language:'en'}});assert.equal((await worker().runOnce()).action,'sent');
  assert.equal(await count('mock_deliveries'),1);
});
test('opt-out and shared-phone suppression override even the consent-request exception',async()=>{
  await consent();await f.db.query('insert into public.conversations(clinic_id,mobile_e164,channel_stopped,state) values ($1,$2,true,$3)',[ids.clinicA,'+919000000001','closed']);
  await enqueue();assert.equal((await worker().runOnce()).code,'WA_OPTED_OUT');
  await f.db.exec("update public.clinics set settings=settings||'{\"allow_consent_request\":true}'::jsonb;");
  await enqueue({purpose:'consent_request',payload:{template_name:'consent_request',language:'en'}});assert.equal((await worker().runOnce()).code,'WA_OPTED_OUT');assert.equal(await count('mock_deliveries'),0);
});
test('consent order is deterministic even when timestamps are equal',async()=>{
  await consent('granted');await consent('revoked');await f.db.exec("update public.consents set created_at='2026-11-01T00:00:00Z';");
  await enqueue();assert.equal((await worker().runOnce()).code,'WA_CONSENT_REQUIRED');assert.equal(await count('mock_deliveries'),0);
});
test('quiet hours defer to 7 AM IST without consuming attempts',async()=>{
  await consent();instant=Date.parse('2026-11-02T16:00:00Z');const id=await enqueue();
  const result=await worker().runOnce();assert.equal(result.action,'defer');assert.equal(result.code,'QUIET_HOURS');
  const queued=await row(id);assert.equal(new Date(queued.not_before).toISOString(),'2026-11-03T01:30:00.000Z');assert.equal(queued.attempts,0);
  instant=Date.parse('2026-11-03T01:30:00Z');assert.equal((await worker().runOnce()).action,'sent');
});
test('clinic quiet hours support daytime ranges and fail closed on invalid configuration',async()=>{
  await consent();await f.db.exec("update public.clinics set settings=settings||'{\"quiet_hours\":{\"start\":\"09:00\",\"end\":\"17:00\"}}'::jsonb;");
  const id=await enqueue();assert.equal((await worker().runOnce()).action,'defer');assert.equal(new Date((await row(id)).not_before).toISOString(),'2026-11-02T11:30:00.000Z');
  await f.db.exec("update public.clinics set settings=settings||'{\"quiet_hours\":{\"start\":\"wrong\"}}'::jsonb;");
  await enqueue();assert.equal((await worker().runOnce()).code,'CONFIG_INVALID');
});
test('free text requires an inbound window strictly less than 24 hours; future timestamps fail',async()=>{
  await consent();await enqueue({kind:'text',purpose:'staff_reply',payload:{text:'Synthetic reply'}});assert.equal((await worker().runOnce()).code,'WA_WINDOW_CLOSED');
  await f.db.query('insert into public.conversations(clinic_id,mobile_e164,last_inbound_at) values ($1,$2,$3)',[ids.clinicA,'+919000000001',new Date(instant-24*3600000).toISOString()]);
  await enqueue({kind:'text',purpose:'staff_reply',payload:{text:'Synthetic reply'}});assert.equal((await worker().runOnce()).code,'WA_WINDOW_CLOSED');
  await f.db.query('update public.conversations set last_inbound_at=$1',[new Date(instant+60000).toISOString()]);
  await enqueue({kind:'text',purpose:'staff_reply',payload:{text:'Synthetic reply'}});assert.equal((await worker().runOnce()).code,'WA_WINDOW_CLOSED');
  await f.db.query('update public.conversations set last_inbound_at=$1',[new Date(instant-60000).toISOString()]);
  await enqueue({kind:'text',purpose:'staff_reply',payload:{text:'Synthetic reply'}});assert.equal((await worker().runOnce()).action,'sent');
});
test('feature flags and language switches are enforced before dispatch',async()=>{
  await consent();await enqueue({purpose:'medication',payload:{template_name:'medication_reminder',language:'en'}});assert.equal((await worker().runOnce()).code,'FEATURE_DISABLED');
  await f.db.query('insert into public.clinic_features(clinic_id,feature,enabled) values ($1,$2,true)',[ids.clinicA,'med_reminders']);
  await enqueue({purpose:'medication',payload:{template_name:'medication_reminder',language:'en'}});assert.equal((await worker().runOnce()).action,'sent');
  await enqueue({payload:{template_name:'notice',language:'te'}});assert.equal((await worker().runOnce()).code,'FEATURE_DISABLED');
  await f.db.query('insert into public.clinic_features(clinic_id,feature,enabled) values ($1,$2,true)',[ids.clinicA,'lang_te']);
  await enqueue({payload:{template_name:'notice',language:'te'}});assert.equal((await worker().runOnce()).action,'sent');
});
test('unapproved templates stop with a durable staff alert',async()=>{
  await consent();const id=await enqueue({payload:{template_name:'unapproved',language:'en'}});assert.equal((await worker().runOnce()).code,'WA_TEMPLATE_UNAVAILABLE');
  assert.equal((await row(id)).attempts,0);assert.equal(await count('staff_alerts'),1);assert.equal(await count('mock_deliveries'),0);
});
test('daily cap includes active reservations; 80 and 100 percent alerts are deduplicated',async()=>{
  await consent();await f.db.exec('update public.clinics set daily_send_cap=1;');await enqueue();await enqueue();
  const first=await store.claim(crypto.randomUUID());assert.equal((await store.prepare(first)).action,'send');
  const second=await store.claim(crypto.randomUUID());const blocked=await store.prepare(second);assert.equal(blocked.code,'SEND_CAP_REACHED');
  assert.equal(await count('staff_alerts'),2);assert.equal((await row(second.id)).attempts,0);
  const accepted=await store.mockAccept(first);await store.complete(first,accepted.wa_message_id);assert.equal(await count('staff_alerts'),2);
});
test('definite rejection retries after 1, 5 and 15 minutes, then fails with an alert',async()=>{
  await consent();const id=await enqueue();const w=worker(()=> 'server_error');
  for(const delay of [1,5,15]){assert.equal((await w.runOnce()).action,'queued');assert.equal(new Date((await row(id)).not_before).getTime(),instant+delay*60000);assert.equal((await w.runOnce()).action,'idle');advance(delay);}
  assert.equal((await w.runOnce()).action,'failed');assert.equal((await row(id)).attempts,4);assert.equal(await count('staff_alerts'),1);assert.equal(await count('mock_deliveries'),0);
});
test('not-on-WhatsApp status blocks future sends and template rejection disables that template',async()=>{
  await consent();await enqueue();assert.equal((await worker(()=> 'not_on_whatsapp').runOnce()).action,'failed');
  assert.equal((await f.db.query('select whatsapp_status from public.patients where id=$1',[ids.patientA])).rows[0].whatsapp_status,'not_on_whatsapp');
  await enqueue();assert.equal((await worker().runOnce()).code,'WA_NOT_ON_WHATSAPP');
  await f.db.exec("update public.patients set whatsapp_status='unknown';");await enqueue();assert.equal((await worker(()=> 'template_unavailable').runOnce()).action,'failed');
  await enqueue();assert.equal((await worker().runOnce()).code,'WA_TEMPLATE_UNAVAILABLE');
});
test('stale scheduled jobs are skipped after 30 minutes; current jobs remain eligible',async()=>{
  await consent();await enqueue({purpose:'reminder',notBefore:new Date(instant-31*60000).toISOString()});assert.equal((await worker().runOnce()).code,'JOB_STALE');
  await enqueue({purpose:'reminder',notBefore:new Date(instant-30*60000).toISOString()});assert.equal((await worker().runOnce()).action,'sent');
});
test('consent revoked after prepare is rechecked atomically at mock acceptance',async()=>{
  await consent();const id=await enqueue();const claim=await store.claim(crypto.randomUUID());await store.prepare(claim);
  await f.write(ids.adminA,'consent',{status:'revoked',version:'v2',channel:'phone'},crypto.randomUUID(),ids.patientA);
  const accepted=await store.mockAccept(claim);assert.equal(accepted.code,'WA_OPTED_OUT');assert.equal((await row(id)).status,'skipped');assert.equal(await count('mock_deliveries'),0);
  assert.equal((await row(id)).attempts,0);
});
test('expired claimed work can be reclaimed and old lease holders cannot finish it',async()=>{
  await consent();await enqueue();const old=await store.claim(crypto.randomUUID());assert.equal(await store.claim(crypto.randomUUID()),null);
  advance(6);const fresh=await store.claim(crypto.randomUUID());assert.equal(fresh.id,old.id);assert.notEqual(fresh.lease_token,old.lease_token);assert.equal(fresh.recovering,false);
  await assert.rejects(store.prepare(old),error=>error.code==='LEASE_LOST');assert.equal((await store.prepare(fresh)).action,'send');
});
test('restart after acceptance reconciles durable evidence without a second mock delivery',async()=>{
  await consent();const id=await enqueue();const claim=await store.claim(crypto.randomUUID());await store.prepare(claim);await store.mockAccept(claim);
  advance(6);assert.equal((await worker().runOnce()).action,'sent');assert.equal((await row(id)).status,'sent');assert.equal(await count('mock_deliveries'),1);assert.equal(await count('message_log'),1);
});
test('restart before dispatch proves mock absence and retries instead of inventing acceptance',async()=>{
  await consent();const id=await enqueue();const claim=await store.claim(crypto.randomUUID());await store.prepare(claim);advance(6);
  assert.equal((await worker().runOnce()).action,'queued');assert.equal(await count('message_log'),0);advance(1);assert.equal((await worker().runOnce()).action,'sent');assert.equal((await row(id)).attempts,2);
});
test('accepted-then-timeout reconciles; unresolved acceptance stops automatic sends',async()=>{
  await consent();await enqueue();assert.equal((await worker(()=> 'accepted_then_timeout').runOnce()).action,'sent');assert.equal(await count('mock_deliveries'),1);
  const id=await enqueue();const uncertain=new DeliveryWorker(store,{send:async()=>{throw new SendFailure('WA_ACCEPTANCE_UNKNOWN',true);},reconcile:async()=>({state:'unknown'})});
  assert.equal((await uncertain.runOnce()).action,'uncertain');assert.equal((await row(id)).status,'uncertain');assert.equal((await uncertain.runOnce()).action,'idle');
  assert.equal((await f.db.query("select * from public.staff_alerts where code='WA_ACCEPTANCE_UNKNOWN'")).rows.length,1);
});
test('duplicate/out-of-order receipts remain append-only and cannot regress read status',async()=>{
  await consent();const id=await enqueue();await worker().runOnce();const provider=(await row(id)).wa_message_id;
  const receipt={clinic_id:ids.clinicA,wa_message_id:provider,status:'read',occurred_at:now()};
  assert.equal((await store.receipt(receipt)).status,'read');assert.equal((await store.receipt(receipt)).duplicate,true);
  await store.receipt({...receipt,status:'sent'});await store.receipt({...receipt,status:'failed'});assert.equal((await row(id)).provider_status,'read');
  assert.equal(await count('delivery_receipts'),3);assert.equal((await f.db.query('select status from public.message_log')).rows[0].status,'accepted');
  await store.receipt({...receipt,clinic_id:ids.clinicB,status:'delivered'});assert.equal((await row(id)).provider_status,'read');
});
test('receipt before worker completion is retained and applied when acceptance commits',async()=>{
  await consent();const id=await enqueue();const claim=await store.claim(crypto.randomUUID());await store.prepare(claim);const accepted=await store.mockAccept(claim);
  const receipt=await store.receipt({clinic_id:ids.clinicA,wa_message_id:accepted.wa_message_id,status:'delivered',occurred_at:now()});assert.equal(receipt.matched,false);
  await store.complete(claim,accepted.wa_message_id);assert.equal((await row(id)).provider_status,'delivered');
  assert.equal((await f.db.query("select * from public.events where type='message.delivered'")).rows.length,1);
  await store.receipt({clinic_id:ids.clinicA,wa_message_id:accepted.wa_message_id,status:'delivered',occurred_at:now()});
  assert.equal((await f.db.query("select * from public.events where type='message.delivered'")).rows.length,1);
});
test('late completion preserves the original provider acceptance time',async()=>{
  await consent();await enqueue();const claim=await store.claim(crypto.randomUUID());await store.prepare(claim);const accepted=await store.mockAccept(claim);
  advance(6);await worker().runOnce();
  assert.equal(new Date((await f.db.query('select created_at from public.message_log where wa_message_id=$1',[accepted.wa_message_id])).rows[0].created_at).toISOString(),base);
});
test('unprepared or unverified completion cannot fabricate delivery',async()=>{
  await consent();await enqueue();const claim=await store.claim(crypto.randomUUID());
  await assert.rejects(store.complete(claim,'mock.fake'),error=>['INPUT_INVALID','ACCEPTANCE_UNVERIFIED'].includes(error.code));
  await store.prepare(claim);await assert.rejects(store.complete(claim,'mock.fake'),error=>error.code==='ACCEPTANCE_UNVERIFIED');assert.equal(await count('message_log'),0);
});
test('timeout before acceptance is proven absent and safely retried by the mock',async()=>{
  await consent();await enqueue();assert.equal((await worker(()=> 'timeout').runOnce()).action,'queued');assert.equal(await count('mock_deliveries'),0);
  advance(1);assert.equal((await worker().runOnce()).action,'sent');assert.equal(await count('mock_deliveries'),1);
});
test('acceptance crossing midnight moves its cap reservation to the actual IST send day',async()=>{
  await consent();instant=Date.parse('2026-11-02T18:29:00Z');
  await f.db.query('insert into public.conversations(clinic_id,mobile_e164,last_inbound_at) values ($1,$2,$3)',[ids.clinicA,'+919000000001',now()]);
  const id=await enqueue({kind:'text',purpose:'staff_reply',payload:{text:'Synthetic reply'}});
  const claim=await store.claim(crypto.randomUUID());await store.prepare(claim);advance(2);const accepted=await store.mockAccept(claim);await store.complete(claim,accepted.wa_message_id);
  assert.equal(new Date((await row(id)).cap_date).toISOString().slice(0,10),'2026-11-03');
});
test('receipt failure alerts are deduplicated and raw error text is rejected',async()=>{
  await consent();const id=await enqueue();await worker().runOnce();const provider=(await row(id)).wa_message_id;
  const receipt={clinic_id:ids.clinicA,wa_message_id:provider,status:'failed',occurred_at:now(),error_code:'131026'};
  await store.receipt(receipt);await store.receipt(receipt);assert.equal((await row(id)).provider_status,'failed');
  assert.equal((await f.db.query("select * from public.staff_alerts where code='WA_DELIVERY_FAILED'")).rows.length,1);
  await assert.rejects(store.receipt({...receipt,error_code:'Patient name and phone'}));
});
test('service-only tables have default-deny RLS even when a test probe is granted reads',async()=>{
  await f.db.exec('create role delivery_probe; grant authenticated to delivery_probe; grant select on public.message_log,public.delivery_receipts,public.mock_deliveries to delivery_probe;');
  try{
    for(const table of ['message_log','delivery_receipts','mock_deliveries']){
      const result=await f.db.transaction(async tx=>{await tx.exec('set local role delivery_probe');await tx.query("select set_config('request.jwt.claim.sub',$1,true)",[ids.adminA]);return tx.query('select * from public.'+table);});assert.equal(result.rows.length,0);
    }
  }finally{await f.db.exec('drop owned by delivery_probe; drop role delivery_probe;');}
});
test('staff cannot call service worker operations or inspect internal delivery ledgers',async()=>{
  await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('select public.tabiyo_delivery($1,$2::jsonb)',['claim',JSON.stringify({worker_id:crypto.randomUUID()})])),/permission denied/);
  for(const table of ['message_log','delivery_receipts','mock_deliveries'])await assert.rejects(f.asUser(ids.adminA,tx=>tx.query('select * from public.'+table)),/permission denied/);
  for(const table of ['message_log','delivery_receipts','mock_deliveries'])await assert.rejects(f.asUser(null,tx=>tx.query('delete from public.'+table),'service_role'),/permission denied/);
});
test('service clients cannot manufacture provider acceptance by inserting a mock ledger row',async()=>{
  await consent();const id=await enqueue();
  await assert.rejects(f.asUser(null,tx=>tx.query('insert into public.mock_deliveries(outbox_id,clinic_id,wa_message_id,payload,accepted_at) values ($1,$2,$3,$4,$5)',[id,ids.clinicA,'mock.forged','{}',now()]),'service_role'),/permission denied/);
});
test('a malformed provider adapter response cannot cross the claimed clinic boundary',async()=>{
  await consent();await enqueue();const claim=await store.claim(crypto.randomUUID());const prepared=await store.prepare(claim);
  const badStore=createDeliveryStore(async()=>({...prepared,clinic_id:ids.clinicB}));
  await assert.rejects(badStore.prepare(claim),error=>error.code==='DELIVERY_SCOPE_MISMATCH');assert.equal(await count('mock_deliveries'),0);
});
