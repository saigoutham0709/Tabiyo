import {z} from 'zod';
import type {FastifyInstance,FastifyRequest} from 'fastify';
import {ApiError,calendarDateSchema,queueWriteSchema,type StaffContext} from '@tabiyo/shared';
import type {QueueService} from './queue.ts';
export function registerQueue(app:FastifyInstance,config:{staffContext:(request:FastifyRequest)=>Promise<{token:string;context:StaffContext}>;service?:QueueService}){
  function service(){if(!config.service)throw new ApiError('SERVICE_UNAVAILABLE',503,'The walk-in queue is unavailable.');return config.service;}
  function scoped(actual:string,expected:string){if(actual!==expected)throw new ApiError('DB_UNAVAILABLE',503,'The walk-in queue is unavailable.');}
  app.get('/api/v1/queue/status',async request=>{
    const {token,context}=await config.staffContext(request);z.object({}).strict().parse(request.query);
    const result=await service().status(token);scoped(result.clinic_id,context.clinic.id);return result;
  });
  app.get('/api/v1/doctors/:id/queue',async request=>{
    const {token,context}=await config.staffContext(request),{id}=z.object({id:z.string().uuid()}).parse(request.params);
    const {date}=z.object({date:calendarDateSchema.optional()}).strict().parse(request.query);
    const result=await service().read(token,id,date);scoped(result.clinic_id,context.clinic.id);scoped(result.doctor_id,id);
    result.tokens.forEach(item=>{scoped(item.clinic_id,context.clinic.id);scoped(item.doctor_id,id);});return result;
  });
  app.post('/api/v1/doctors/:id/queue',async request=>{
    const {token,context}=await config.staffContext(request),{id}=z.object({id:z.string().uuid()}).parse(request.params);
    const key=z.string().uuid().parse(request.headers['idempotency-key']);const result=await service().write(token,id,queueWriteSchema.parse(request.body),key);
    scoped(result.clinic_id,context.clinic.id);scoped(result.token.clinic_id,context.clinic.id);scoped(result.token.doctor_id,id);return result;
  });
}
