import {z} from 'zod';
import {ApiError,doctorRecordSchema,appointmentSlotSchema,appointmentRecordSchema,appointmentWriteResultSchema,
  type DoctorRecord,type AppointmentRecord,type AppointmentSlot,type AppointmentWriteResult} from '@tabiyo/shared';
import {createUserClient,type AuthConfig} from './auth.ts';
export type AppointmentAction='create'|'reschedule'|'cancel'|'check_in'|'complete'|'no_show';
export type AppointmentService={
  doctors(token:string):Promise<DoctorRecord[]>;
  slots(token:string,doctorId:string,date:string,patientId?:string):Promise<AppointmentSlot[]>;
  day(token:string,date:string):Promise<AppointmentRecord[]>;
  write(token:string,action:AppointmentAction,input:Record<string,unknown>,requestId:string):Promise<AppointmentWriteResult>;
};
const failures:Record<string,[number,string]>={
  STAFF_FORBIDDEN:[403,'Active clinic membership is required.'],PATIENT_NOT_FOUND:[404,'Patient not found.'],DOCTOR_NOT_FOUND:[404,'Doctor not found.'],
  APPOINTMENT_NOT_FOUND:[404,'Appointment not found.'],APPOINTMENT_STATE_INVALID:[409,'This appointment cannot make that transition. Refresh its status.'],
  APPOINTMENT_TIME_INVALID:[422,'Choose a future appointment within the next 90 days.'],IDEMPOTENCY_CONFLICT:[409,'This request key was already used for another operation.'],
  INPUT_INVALID:[422,'Check the appointment details and try again.'],
};
export function createAppointmentService(config:AuthConfig):AppointmentService{
  async function call(token:string,rpc:string,args:Record<string,unknown>){
    const {data,error}=await createUserClient(config,token).rpc(rpc,args);
    if(error){
      if(Object.hasOwn(failures,error.message)){const [status,message]=failures[error.message];throw new ApiError(error.message,status,message);}
      if(error.code==='42501')throw new ApiError('STAFF_FORBIDDEN',403,'Active clinic membership is required.');
      if(['22023','22007','22008','22P02','23502','23514'].includes(error.code))throw new ApiError('INPUT_INVALID',422,'Check the appointment details and try again.');
      throw new ApiError('DB_UNAVAILABLE',503,'Appointments are unavailable.');
    }return data;
  }
  function parse<T>(schema:z.ZodType<T>,value:unknown):T{
    const parsed=schema.safeParse(value);if(!parsed.success)throw new ApiError('DB_UNAVAILABLE',503,'Appointments are unavailable.');return parsed.data;
  }
  return {
    async doctors(token){return parse(z.object({doctors:z.array(doctorRecordSchema)}),await call(token,'tabiyo_appointment_read',{p_action:'doctors',p_input:{}})).doctors;},
    async slots(token,doctorId,date,patientId){return parse(z.object({slots:z.array(appointmentSlotSchema)}),await call(token,'tabiyo_appointment_read',{p_action:'slots',p_input:{doctor_id:doctorId,date,...(patientId?{patient_id:patientId}:{})}})).slots;},
    async day(token,date){return parse(z.object({appointments:z.array(appointmentRecordSchema)}),await call(token,'tabiyo_appointment_read',{p_action:'day',p_input:{date}})).appointments;},
    async write(token,action,input,requestId){
      const data=await call(token,'tabiyo_appointment_write',{p_action:action,p_input:input,p_request_id:requestId});
      const conflict=z.object({conflict:z.literal(true),alternatives:z.array(appointmentSlotSchema).max(3)}).safeParse(data);
      if(conflict.success)throw new ApiError('SLOT_UNAVAILABLE',409,'That time is unavailable. Choose an alternative or refresh the slots.',{alternatives:conflict.data.alternatives});
      return parse(appointmentWriteResultSchema,data);
    },
  };
}
