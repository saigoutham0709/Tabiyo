import { z } from 'zod';
import type { FastifyInstance, FastifyRequest } from 'fastify';
import {
  ApiError,
  calendarDateSchema,
  prescriptionCreateSchema,
  patientMergeSchema,
  type StaffContext,
} from '@tabiyo/shared';
import type { ClinicalService } from './clinical.ts';

const faqItemSchema = z.object({
  id: z.string().uuid().optional(),
  question: z.string().trim().min(2).max(500),
  answer: z.string().trim().min(2).max(2000),
  language: z.enum(['en', 'te', 'hi']).default('en'),
  active: z.boolean().default(true),
}).strict();

const faqUpsertBodySchema = z.union([
  faqItemSchema,
  z.array(faqItemSchema),
  z.object({ faqs: z.array(faqItemSchema) }).strict(),
]);

export function registerClinical(app: FastifyInstance, config: {
  staffContext: (request: FastifyRequest) => Promise<{ token: string; context: StaffContext }>;
  service?: ClinicalService;
}) {
  function service() {
    if (!config.service) throw new ApiError('SERVICE_UNAVAILABLE', 503, 'Clinical services are unavailable.');
    return config.service;
  }

  function scoped(actual: string, expected: string) {
    if (actual !== expected) throw new ApiError('DB_UNAVAILABLE', 503, 'Clinical services are unavailable.');
  }

  // 1. Prescriptions (Doctor/Admin only)
  app.post('/api/v1/prescriptions', async (request, reply) => {
    const { token, context } = await config.staffContext(request);
    if (context.staff.role !== 'doctor' && context.staff.role !== 'admin') {
      throw new ApiError('OPERATION_FORBIDDEN', 403, 'Only doctors and clinic administrators can create prescriptions.');
    }
    const body = prescriptionCreateSchema.parse(request.body);
    const key = request.headers['idempotency-key']
      ? z.string().uuid().parse(request.headers['idempotency-key'])
      : undefined;

    const result = await service().createPrescription(token, body, key);
    scoped(result.prescription.clinic_id, context.clinic.id);
    return reply.status(201).send(result);
  });

  // 2. Patient Adherence
  app.get('/api/v1/patients/:id/adherence', async (request) => {
    const { token, context } = await config.staffContext(request);
    const { id } = z.object({ id: z.string().uuid() }).parse(request.params);
    const result = await service().getAdherence(token, id);
    scoped(result.clinic_id, context.clinic.id);
    return result;
  });

  // 3. Visit Slip creation
  app.post('/api/v1/visits/:id/slip', async (request, reply) => {
    const { token, context } = await config.staffContext(request);
    const { id } = z.object({ id: z.string().uuid() }).parse(request.params);
    const bodySchema = z.object({
      notes: z.string().max(2000).optional(),
      slip_file_path: z.string().optional(),
      generate_slip: z.boolean().optional(),
    }).strict().optional();
    const body = bodySchema.parse(request.body ?? {});

    const result = await service().createOrUpdateVisitSlip(token, id, body);
    return reply.status(200).send(result);
  });

  // Also support POST /api/v1/visits/slip (for dashboard components)
  app.post('/api/v1/visits/slip', async (request, reply) => {
    const { token, context } = await config.staffContext(request);
    const body = z.object({
      appointment_id: z.string().uuid().optional(),
      patient_id: z.string().uuid().optional(),
      notes: z.string().max(2000).optional(),
      slip_file_path: z.string().optional(),
    }).strict().parse(request.body ?? {});

    const targetId = body.appointment_id || body.patient_id;
    if (!targetId) {
      throw new ApiError('INPUT_INVALID', 422, 'appointment_id or patient_id is required.');
    }
    const result = await service().createOrUpdateVisitSlip(token, targetId, body);
    return reply.status(200).send(result);
  });

  // 4. Visit Slip URL Retrieval with optional DOB verification
  app.get('/api/v1/visits/:id/slip-url', async (request) => {
    const { token } = await config.staffContext(request);
    const { id } = z.object({ id: z.string().uuid() }).parse(request.params);
    const query = z.object({
      dob: calendarDateSchema.optional(),
    }).strict().parse(request.query);

    return service().getVisitSlipUrl(token, id, query.dob);
  });

  // 5. FAQs List
  app.get('/api/v1/faqs', async (request) => {
    const { token, context } = await config.staffContext(request);
    const query = z.object({
      active: z.union([z.boolean(), z.enum(['true', 'false', 'all'])]).optional(),
      language: z.enum(['en', 'te', 'hi']).optional(),
    }).strict().parse(request.query);

    const activeFilter = query.active === 'true' ? true : query.active === 'false' ? false : query.active === 'all' ? 'all' : query.active;
    const faqs = await service().listFaqs(token, {
      active: activeFilter,
      language: query.language,
    });
    return { faqs };
  });

  // 6. FAQs Upsert (Admin only)
  app.put('/api/v1/faqs', async (request) => {
    const { token, context } = await config.staffContext(request);
    if (context.staff.role !== 'admin') {
      throw new ApiError('OPERATION_FORBIDDEN', 403, 'Only clinic administrators can manage FAQs.');
    }
    const parsed = faqUpsertBodySchema.parse(request.body);
    const faqsToUpsert: z.infer<typeof faqItemSchema>[] = Array.isArray(parsed)
      ? parsed
      : 'faqs' in parsed
      ? parsed.faqs
      : [parsed];

    const faqs = await service().upsertFaqs(token, faqsToUpsert);
    return { faqs };
  });

  // 7. Reports Summary
  app.get('/api/v1/reports/summary', async (request) => {
    const { token, context } = await config.staffContext(request);
    const query = z.object({
      from: calendarDateSchema,
      to: calendarDateSchema,
    }).strict().parse(request.query);

    if (query.to < query.from) {
      throw new ApiError('INPUT_INVALID', 422, 'to date must be on or after from date.');
    }

    const summary = await service().getReportsSummary(token, query.from, query.to);
    scoped(summary.clinic_id, context.clinic.id);
    return summary;
  });

  // 8. Patient CSV Import
  app.post('/api/v1/patients/import', async (request) => {
    const { token, context } = await config.staffContext(request);
    const body = request.body;
    const result = await service().importPatients(token, body as any);
    return result;
  });

  // 9. Patient Merge (Admin only)
  app.post('/api/v1/patients/merge', async (request) => {
    const { token, context } = await config.staffContext(request);
    if (context.staff.role !== 'admin') {
      throw new ApiError('OPERATION_FORBIDDEN', 403, 'Only clinic administrators can merge patient records.');
    }
    const body = patientMergeSchema.parse(request.body);
    if (body.source_patient_id === body.target_patient_id) {
      throw new ApiError('INPUT_INVALID', 422, 'Source and target patients must be different.');
    }
    return service().mergePatients(token, body);
  });
}
