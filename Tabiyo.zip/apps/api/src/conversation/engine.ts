import {
  renderTemplate,
  getEmergencyReply,
  getMedicalRefusalReply,
  isEmergencyMessage,
  isMedicalAdviceQuery,
  matchGlobalCommand,
  MENU_MESSAGES,
  LANGUAGE_CHOICE_MESSAGE,
  DOB_PROMPT_MESSAGES,
  DOB_FAILED_MESSAGES,
  DOB_LOCKED_MESSAGES,
  type SupportedLanguage,
} from '@tabiyo/templates';
import { askFaqAssistant } from '../faq/assistant.ts';

export interface ConversationDb {
  query: (sql: string, params?: unknown[]) => Promise<{ rows: any[] }>;
}

export interface InboundMessage {
  clinicId: string;
  mobileE164: string;
  text?: string;
  buttonId?: string;
  listId?: string;
  timestamp?: string;
}

export interface EngineResult {
  conversationId?: string;
  patientId?: string;
  state: string;
  reply: string;
  alertRaised?: boolean;
  alertCode?: string;
  outboxId?: string;
}

export class ConversationEngine {
  private db: ConversationDb;
  private nowFn: () => string;
  private sessionTimeoutMinutes: number;

  constructor(options: {
    db: ConversationDb;
    now?: () => string;
    sessionTimeoutMinutes?: number;
  }) {
    this.db = options.db;
    this.nowFn = options.now ?? (() => new Date().toISOString());
    this.sessionTimeoutMinutes = options.sessionTimeoutMinutes ?? 30;
  }

  private now(): string {
    return this.nowFn();
  }

  /**
   * Process an incoming patient message
   */
  async handleMessage(input: InboundMessage): Promise<EngineResult> {
    const nowIso = this.now();
    const rawText = (input.text || input.buttonId || input.listId || '').trim();
    const clinicId = input.clinicId;
    const mobileE164 = input.mobileE164;

    // Load clinic
    const clinicRes = await this.db.query(
      `SELECT id, name, default_language, settings FROM public.clinics WHERE id = $1`,
      [clinicId]
    );
    const clinic = clinicRes.rows[0];
    const clinicPhone = clinic?.settings?.phone || '+919000000000';
    const defaultLanguage: SupportedLanguage = clinic?.default_language || 'en';

    // 1. EMERGENCY HEURISTIC: PRECEDES ALL STATE DISPATCH, CONSENT, AND OPT-OUT
    if (isEmergencyMessage(rawText)) {
      // Find patient if known
      const patRes = await this.db.query(
        `SELECT id, language FROM public.patients WHERE clinic_id = $1 AND mobile_e164 = $2 AND merged_into IS NULL LIMIT 1`,
        [clinicId, mobileE164]
      );
      const patient = patRes.rows[0];
      const lang: SupportedLanguage = patient?.language || defaultLanguage;

      const dedupKey = `emergency:${clinicId}:${mobileE164}:${nowIso.slice(0, 16)}`;
      await this.db.query(
        `INSERT INTO public.staff_alerts (clinic_id, patient_id, code, dedup_key, created_at, context)
         VALUES ($1, $2, 'AI_EMERGENCY', $3, $4, '{}'::jsonb)
         ON CONFLICT (dedup_key) DO NOTHING`,
        [
          clinicId,
          patient?.id || null,
          dedupKey,
          nowIso,
        ]
      );

      await this.db.query(
        `INSERT INTO public.events (clinic_id, patient_id, type, occurred_at, meta)
         VALUES ($1, $2, 'emergency.alert', $3, $4::jsonb)`,
        [
          clinicId,
          patient?.id || null,
          nowIso,
          JSON.stringify({ raw_text: rawText, code: 'AI_EMERGENCY' }),
        ]
      );

      const emergencyReply = getEmergencyReply(lang, clinicPhone);

      // Enqueue to outbox
      if (patient?.id) {
        await this.db.query(
          `INSERT INTO public.outbox (clinic_id, patient_id, kind, purpose, payload, idempotency_key, not_before, created_at)
           VALUES ($1, $2, 'text', 'staff_reply', $3::jsonb, $4, $5, $5)
           ON CONFLICT (idempotency_key) DO NOTHING`,
          [
            clinicId,
            patient.id,
            JSON.stringify({ text: emergencyReply }),
            `outbox:emergency:${dedupKey}`,
            nowIso,
          ]
        );
      }

      return {
        state: 'emergency',
        reply: emergencyReply,
        alertRaised: true,
        alertCode: 'AI_EMERGENCY',
      };
    }

    // 2. MEDICAL ADVICE REFUSAL GUARDRAIL
    if (isMedicalAdviceQuery(rawText)) {
      const patRes = await this.db.query(
        `SELECT id, language FROM public.patients WHERE clinic_id = $1 AND mobile_e164 = $2 AND merged_into IS NULL LIMIT 1`,
        [clinicId, mobileE164]
      );
      const patient = patRes.rows[0];
      const lang: SupportedLanguage = patient?.language || defaultLanguage;
      const refusalReply = getMedicalRefusalReply(lang);

      return {
        state: 'medical_refusal',
        reply: refusalReply,
      };
    }

    // Load or create conversation
    let convRes = await this.db.query(
      `SELECT * FROM public.conversations WHERE clinic_id = $1 AND mobile_e164 = $2`,
      [clinicId, mobileE164]
    );

    let conv = convRes.rows[0];
    if (!conv) {
      const insertRes = await this.db.query(
        `INSERT INTO public.conversations (clinic_id, mobile_e164, state, language, context, last_inbound_at)
         VALUES ($1, $2, 'new', $3, '{}'::jsonb, $4)
         RETURNING *`,
        [clinicId, mobileE164, defaultLanguage, nowIso]
      );
      conv = insertRes.rows[0];
    }

    const language: SupportedLanguage = (conv.language as SupportedLanguage) || defaultLanguage;
    let context = typeof conv.context === 'string' ? JSON.parse(conv.context) : (conv.context || {});

    // 3. 30-MINUTE SESSION EXPIRATION & RECOVERY
    if (conv.last_inbound_at) {
      const lastInbound = Date.parse(conv.last_inbound_at);
      const current = Date.parse(nowIso);
      const elapsedMinutes = (current - lastInbound) / (1000 * 60);

      if (elapsedMinutes > this.sessionTimeoutMinutes) {
        // Session expired: reset active multi-step flows to menu or appropriate recovery state
        if (['booking', 'slip_verify', 'slip_select'].includes(conv.state)) {
          conv.state = conv.patient_id ? 'menu' : 'new';
          context = {};
          await this.db.query(
            `UPDATE public.conversations
             SET state = $1, context = '{}'::jsonb, last_inbound_at = $2
             WHERE id = $3`,
            [conv.state, nowIso, conv.id]
          );
        }
      }
    }

    // Update last_inbound_at
    await this.db.query(
      `UPDATE public.conversations SET last_inbound_at = $1 WHERE id = $2`,
      [nowIso, conv.id]
    );

    // 4. GLOBAL COMMANDS (WORK FROM ANY STATE)
    const globalCmd = matchGlobalCommand(rawText);
    if (globalCmd === 'stop') {
      // Opt out
      await this.db.query(
        `UPDATE public.conversations
         SET state = 'closed', channel_stopped = true, stopped_at = $1, last_command_at = $1, patient_id = NULL
         WHERE id = $2`,
        [nowIso, conv.id]
      );

      // Opt out all patients on this mobile
      const patients = (await this.db.query(
        `SELECT id FROM public.patients WHERE clinic_id = $1 AND mobile_e164 = $2 AND merged_into IS NULL`,
        [clinicId, mobileE164]
      )).rows;

      for (const p of patients) {
        await this.db.query(`UPDATE public.patients SET opted_out = true WHERE id = $1`, [p.id]);
        await this.db.query(
          `INSERT INTO public.consents (clinic_id, patient_id, version, status, channel, created_at)
           VALUES ($1, $2, 'stop-command', 'revoked', 'whatsapp', $3)`,
          [clinicId, p.id, nowIso]
        );
        // Skip queued outbox work
        await this.db.query(
          `UPDATE public.outbox SET status = 'skipped', last_error = 'WA_OPTED_OUT'
           WHERE clinic_id = $1 AND patient_id = $2 AND status = 'queued'`,
          [clinicId, p.id]
        );
        await this.db.query(
          `INSERT INTO public.events (clinic_id, patient_id, type, occurred_at, meta)
           VALUES ($1, $2, 'consent.revoked', $3, '{"source": "whatsapp_stop"}'::jsonb)`,
          [clinicId, p.id, nowIso]
        );
      }

      const stopReply = language === 'te'
        ? 'వాట్సాప్ అప్‌డేట్‌లు నిలిపివేయబడ్డాయి. తిరిగి ప్రారంభించడానికి ఎప్పుడైనా START అని పంపండి.'
        : language === 'hi'
        ? 'व्हाट्सएप अपडेट बंद कर दिए गए हैं। पुनः शुरू करने के लिए कभी भी START भेजें।'
        : 'WhatsApp updates are paused. Reply START anytime to resume.';

      return { conversationId: conv.id, state: 'closed', reply: stopReply };
    }

    if (globalCmd === 'start') {
      await this.db.query(
        `UPDATE public.conversations
         SET channel_stopped = false, last_command_at = $1
         WHERE id = $2`,
        [nowIso, conv.id]
      );

      const patients = (await this.db.query(
        `SELECT id FROM public.patients WHERE clinic_id = $1 AND mobile_e164 = $2 AND merged_into IS NULL`,
        [clinicId, mobileE164]
      )).rows;

      if (patients.length > 1) {
        await this.updateConversation(conv.id, 'choose_patient', {});
        return this.renderChoosePatient(clinicId, mobileE164, language);
      } else if (patients.length === 1) {
        await this.updateConversation(conv.id, 'awaiting_consent', {}, patients[0].id);
        return this.renderConsentPrompt(clinic.name, language);
      } else {
        await this.updateConversation(conv.id, 'new', {});
        return { conversationId: conv.id, state: 'new', reply: LANGUAGE_CHOICE_MESSAGE };
      }
    }

    if (globalCmd === 'help') {
      await this.updateConversation(conv.id, 'handoff', { requested_help: true });
      const dedupKey = `handoff:${clinicId}:${mobileE164}:${nowIso.slice(0, 16)}`;
      await this.db.query(
        `INSERT INTO public.staff_alerts (clinic_id, patient_id, code, dedup_key, created_at, context)
         VALUES ($1, $2, 'CONV_HANDOFF', $3, $4, '{}'::jsonb)
         ON CONFLICT (dedup_key) DO NOTHING`,
        [
          clinicId,
          conv.patient_id,
          dedupKey,
          nowIso,
        ]
      );

      const helpReply = language === 'te'
        ? `క్లినిక్ సిబ్బందికి సమాచారం పంపబడింది. అత్యవసర లేదా శీఘ్ర సహాయం కోసం దయచేసి కాల్ చేయండి: ${clinicPhone}`
        : language === 'hi'
        ? `क्लिनिक स्टाफ को सूचित कर दिया गया है। त्वरित सहायता के लिए कृपया कॉल करें: ${clinicPhone}`
        : `A clinic staff member has been notified and will reach out to you. For immediate scheduling assistance, please call: ${clinicPhone}`;

      return { conversationId: conv.id, state: 'handoff', reply: helpReply, alertRaised: true, alertCode: 'CONV_HANDOFF' };
    }

    if (globalCmd === 'menu') {
      if (conv.state === 'new') {
        return { conversationId: conv.id, state: 'new', reply: LANGUAGE_CHOICE_MESSAGE };
      }
      if (conv.state === 'awaiting_consent') {
        return this.renderConsentPrompt(clinic.name, language);
      }
      if (conv.state === 'choose_patient') {
        return this.renderChoosePatient(clinicId, mobileE164, language);
      }
      await this.updateConversation(conv.id, 'menu', {});
      const menu = MENU_MESSAGES[language] ?? MENU_MESSAGES.en;
      return { conversationId: conv.id, state: 'menu', reply: menu.text };
    }

    if (conv.state === 'closed') {
      return {
        conversationId: conv.id,
        state: 'closed',
        reply: 'Updates are paused. Reply START to opt back in to WhatsApp updates.',
      };
    }

    // 5. STATE MACHINE DISPATCH
    switch (conv.state) {
      case 'new': {
        // Check for language choice
        let chosenLang: SupportedLanguage | null = null;
        if (/^(1|english)$/i.test(rawText)) chosenLang = 'en';
        else if (/^(2|telugu|తెలుగు)$/i.test(rawText)) chosenLang = 'te';
        else if (/^(3|hindi|हिन्दी|हिंदी)$/i.test(rawText)) chosenLang = 'hi';

        if (chosenLang) {
          await this.db.query(`UPDATE public.conversations SET language = $1 WHERE id = $2`, [chosenLang, conv.id]);

          // Check patients on this number
          const patRes = await this.db.query(
            `SELECT id, name, opted_out FROM public.patients WHERE clinic_id = $1 AND mobile_e164 = $2 AND merged_into IS NULL ORDER BY created_at`,
            [clinicId, mobileE164]
          );

          if (patRes.rows.length > 1) {
            await this.updateConversation(conv.id, 'choose_patient', {});
            return this.renderChoosePatient(clinicId, mobileE164, chosenLang);
          } else if (patRes.rows.length === 1) {
            const patient = patRes.rows[0];
            await this.db.query(`UPDATE public.conversations SET patient_id = $1 WHERE id = $2`, [patient.id, conv.id]);
            // Check consent
            const consentRes = await this.db.query(
              `SELECT status FROM public.consents WHERE clinic_id = $1 AND patient_id = $2 ORDER BY recorded_order DESC LIMIT 1`,
              [clinicId, patient.id]
            );
            if (consentRes.rows[0]?.status === 'granted' && !patient.opted_out) {
              await this.updateConversation(conv.id, 'menu', {});
              const menu = MENU_MESSAGES[chosenLang] ?? MENU_MESSAGES.en;
              return { conversationId: conv.id, state: 'menu', reply: menu.text };
            } else {
              await this.updateConversation(conv.id, 'awaiting_consent', {}, patient.id);
              return this.renderConsentPrompt(clinic.name, chosenLang);
            }
          } else {
            // No existing patient - create new unconsented record
            const newPat = (await this.db.query(
              `INSERT INTO public.patients (clinic_id, mobile_e164, name, language)
               VALUES ($1, $2, 'Patient', $3)
               RETURNING id`,
              [clinicId, mobileE164, chosenLang]
            )).rows[0];
            await this.updateConversation(conv.id, 'awaiting_consent', {}, newPat.id);
            return this.renderConsentPrompt(clinic.name, chosenLang);
          }
        }

        return { conversationId: conv.id, state: 'new', reply: LANGUAGE_CHOICE_MESSAGE };
      }

      case 'choose_patient': {
        const patRes = await this.db.query(
          `SELECT id, name, opted_out FROM public.patients WHERE clinic_id = $1 AND mobile_e164 = $2 AND merged_into IS NULL ORDER BY created_at`,
          [clinicId, mobileE164]
        );
        const patients = patRes.rows;

        // Check if user selected index (1, 2, ...) or name
        const index = parseInt(rawText, 10);
        let selectedPatient: any = null;
        if (!isNaN(index) && index >= 1 && index <= patients.length) {
          selectedPatient = patients[index - 1];
        } else {
          selectedPatient = patients.find(p => p.name.toLowerCase() === rawText.toLowerCase());
        }

        if (selectedPatient) {
          await this.db.query(
            `UPDATE public.conversations SET patient_id = $1 WHERE id = $2`,
            [selectedPatient.id, conv.id]
          );

          // Check consent
          const consentRes = await this.db.query(
            `SELECT status FROM public.consents WHERE clinic_id = $1 AND patient_id = $2 ORDER BY recorded_order DESC LIMIT 1`,
            [clinicId, selectedPatient.id]
          );

          if (consentRes.rows[0]?.status === 'granted' && !selectedPatient.opted_out) {
            await this.updateConversation(conv.id, 'menu', {});
            const menu = MENU_MESSAGES[language] ?? MENU_MESSAGES.en;
            return {
              conversationId: conv.id,
              patientId: selectedPatient.id,
              state: 'menu',
              reply: `${language === 'te' ? 'ఎంపిక చేయబడినది' : language === 'hi' ? 'चयनित' : 'Selected'}: ${selectedPatient.name}\n\n${menu.text}`,
            };
          } else {
            await this.updateConversation(conv.id, 'awaiting_consent', {}, selectedPatient.id);
            return this.renderConsentPrompt(clinic.name, language);
          }
        }

        return this.renderChoosePatient(clinicId, mobileE164, language);
      }

      case 'awaiting_consent': {
        const isAgree = /^(agree|1|yes|consent:agree|సమ్మతి|सहमत)$/i.test(rawText);
        const isNotNow = /^(not now|2|no|consent:not_now|ఇప్పుడు కాదు|अभी नहीं)$/i.test(rawText);

        if (isAgree && conv.patient_id) {
          await this.db.query(
            `INSERT INTO public.consents (clinic_id, patient_id, version, status, channel, created_at)
             VALUES ($1, $2, 'whatsapp-v1', 'granted', 'whatsapp', $3)`,
            [clinicId, conv.patient_id, nowIso]
          );
          await this.db.query(
            `UPDATE public.patients SET opted_out = false WHERE id = $1`,
            [conv.patient_id]
          );
          await this.db.query(
            `INSERT INTO public.events (clinic_id, patient_id, type, occurred_at, meta)
             VALUES ($1, $2, 'consent.granted', $3, '{"source": "whatsapp_opt_in"}'::jsonb)`,
            [clinicId, conv.patient_id, nowIso]
          );

          await this.updateConversation(conv.id, 'menu', {});
          const menu = MENU_MESSAGES[language] ?? MENU_MESSAGES.en;
          const welcome = language === 'te'
            ? 'ధన్యవాదాలు! మీ సమ్మతి నమోదు చేయబడింది.'
            : language === 'hi'
            ? 'धन्यवाद! आपकी सहमति दर्ज कर ली गई है।'
            : 'Thank you! Your consent has been recorded.';
          return {
            conversationId: conv.id,
            patientId: conv.patient_id,
            state: 'menu',
            reply: `${welcome}\n\n${menu.text}`,
          };
        }

        if (isNotNow && conv.patient_id) {
          await this.db.query(
            `INSERT INTO public.consents (clinic_id, patient_id, version, status, channel, created_at)
             VALUES ($1, $2, 'whatsapp-v1', 'revoked', 'whatsapp', $3)`,
            [clinicId, conv.patient_id, nowIso]
          );
          await this.updateConversation(conv.id, 'closed', {});
          return {
            conversationId: conv.id,
            state: 'closed',
            reply: 'Understood. We will not send updates on WhatsApp. Reply START anytime to opt in.',
          };
        }

        return this.renderConsentPrompt(clinic.name, language);
      }

      case 'menu': {
        const lower = rawText.toLowerCase();
        if (lower.startsWith('1') || lower.includes('book') || lower.includes('బుక్') || lower.includes('अपॉइंटमेंट')) {
          // Transition to booking: step doctor
          const docRes = await this.db.query(
            `SELECT id, name, specialty FROM public.doctors WHERE clinic_id = $1 AND active = true ORDER BY name`,
            [clinicId]
          );
          const doctors = docRes.rows;
          if (doctors.length === 0) {
            return {
              conversationId: conv.id,
              state: 'menu',
              reply: 'No doctors are currently available for booking. Please contact clinic staff.',
            };
          }

          await this.updateConversation(conv.id, 'booking', { step: 'doctor', doctors });
          const docList = doctors.map((d, i) => `${i + 1}. ${d.name} (${d.specialty})`).join('\n');
          const prompt = language === 'te'
            ? `దయచేసి వైద్యుడిని ఎంచుకోండి:\n${docList}`
            : language === 'hi'
            ? `कृपया डॉक्टर का चयन करें:\n${docList}`
            : `Please choose a doctor:\n${docList}`;

          return { conversationId: conv.id, state: 'booking', reply: prompt };
        }

        if (lower.startsWith('2') || lower.includes('my appointment') || lower.includes('నా అపాయింట్‌మెంట్‌లు') || lower.includes('मेरे अपॉइंटमेंट')) {
          await this.updateConversation(conv.id, 'my_appointments', {});
          return this.renderMyAppointments(clinicId, conv.patient_id, language);
        }

        if (lower.startsWith('3') || lower.includes('slip') || lower.includes('స్లిప్') || lower.includes('स्लिप')) {
          // Check if currently locked out
          const lockRes = await this.db.query(
            `SELECT failed_attempts, locked_until FROM public.dob_lockouts WHERE clinic_id = $1 AND patient_id = $2`,
            [clinicId, conv.patient_id]
          );
          const lockout = lockRes.rows[0];
          if (lockout?.locked_until && new Date(lockout.locked_until).getTime() > new Date(nowIso).getTime()) {
            const msg = DOB_LOCKED_MESSAGES[language] ?? DOB_LOCKED_MESSAGES.en;
            return { conversationId: conv.id, state: 'menu', reply: msg };
          }

          // Transition to slip_verify
          await this.updateConversation(conv.id, 'slip_verify', {});
          const prompt = DOB_PROMPT_MESSAGES[language] ?? DOB_PROMPT_MESSAGES.en;
          return { conversationId: conv.id, state: 'slip_verify', reply: prompt };
        }

        if (lower.startsWith('4') || lower.includes('info') || lower.includes('clinic') || lower.includes('వివరాలు') || lower.includes('जानकारी')) {
          const info = `${clinic.name}\n${clinic.settings?.address || 'Hyderabad, India'}\nHours: Mon-Sat, 9:00 AM - 6:00 PM IST\nPhone: ${clinicPhone}`;
          return { conversationId: conv.id, state: 'menu', reply: info };
        }

        if (lower.startsWith('5') || lower.includes('staff') || lower.includes('talk') || lower.includes('సిబ్బంది') || lower.includes('स्टाफ')) {
          await this.updateConversation(conv.id, 'handoff', { requested_staff: true });
          const dedupKey = `handoff:${clinicId}:${mobileE164}:${nowIso.slice(0, 16)}`;
          await this.db.query(
            `INSERT INTO public.staff_alerts (clinic_id, patient_id, code, dedup_key, created_at, context)
             VALUES ($1, $2, 'CONV_HANDOFF', $3, $4, '{}'::jsonb)
             ON CONFLICT (dedup_key) DO NOTHING`,
            [clinicId, conv.patient_id, dedupKey, nowIso]
          );
          const handoffReply = language === 'te'
            ? `క్లినిక్ సిబ్బందికి సమాచారం పంపబడింది. వారు మిమ్మల్ని త్వరలో సంప్రదిస్తారు. ఫోన్: ${clinicPhone}`
            : language === 'hi'
            ? `क्लिनिक स्टाफ को सूचित कर दिया गया है। वे जल्द ही आपसे संपर्क करेंगे। फोन: ${clinicPhone}`
            : `Clinic staff have been notified and will reach out to you shortly. Clinic phone: ${clinicPhone}`;

          return { conversationId: conv.id, state: 'handoff', reply: handoffReply, alertRaised: true, alertCode: 'CONV_HANDOFF' };
        }

        // Outside standard menu: query clinic FAQ
        const faqResult = await askFaqAssistant({
          clinicId,
          query: rawText,
          language,
          db: this.db,
        });

        if (faqResult.answered) {
          return { conversationId: conv.id, state: 'menu', reply: `${faqResult.answer}\n\n(Reply Menu to return to options)` };
        } else {
          return { conversationId: conv.id, state: 'menu', reply: `${faqResult.answer}\n\n(Reply Help to speak with clinic staff, or Menu for options)` };
        }
      }

      case 'booking': {
        const step = context.step || 'doctor';

        if (step === 'doctor') {
          const doctors = context.doctors || (await this.db.query(
            `SELECT id, name, specialty FROM public.doctors WHERE clinic_id = $1 AND active = true ORDER BY name`,
            [clinicId]
          )).rows;

          const index = parseInt(rawText, 10);
          let chosenDoc: any = null;
          if (!isNaN(index) && index >= 1 && index <= doctors.length) {
            chosenDoc = doctors[index - 1];
          } else {
            chosenDoc = doctors.find((d: any) => d.name.toLowerCase().includes(rawText.toLowerCase()));
          }

          if (!chosenDoc) {
            const docList = doctors.map((d: any, i: number) => `${i + 1}. ${d.name} (${d.specialty})`).join('\n');
            return {
              conversationId: conv.id,
              state: 'booking',
              reply: `Please select a valid doctor:\n${docList}`,
            };
          }

          context.doctor_id = chosenDoc.id;
          context.doctor_name = chosenDoc.name;
          context.step = 'date';

          // Show available dates (tomorrow and day after)
          const todayDate = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata' }).format(new Date(nowIso));
          const d1 = new Date(Date.parse(todayDate + 'T12:00:00Z') + 86400000).toISOString().slice(0, 10);
          const d2 = new Date(Date.parse(todayDate + 'T12:00:00Z') + 2 * 86400000).toISOString().slice(0, 10);

          context.available_dates = [d1, d2];
          await this.updateConversation(conv.id, 'booking', context);

          const datePrompt = language === 'te'
            ? `దయచేసి తేదీని ఎంచుకోండి:\n1. ${d1}\n2. ${d2}\n(లేదా YYYY-MM-DD ఫార్మాట్‌లో తేదీని నమోదు చేయండి)`
            : language === 'hi'
            ? `कृपया तारीख चुनें:\n1. ${d1}\n2. ${d2}\n(या YYYY-MM-DD प्रारूप में दर्ज करें)`
            : `Please choose a date:\n1. ${d1}\n2. ${d2}\n(Or enter YYYY-MM-DD)`;

          return { conversationId: conv.id, state: 'booking', reply: datePrompt };
        }

        if (step === 'date') {
          let chosenDate: string | null = null;
          if (rawText === '1' && context.available_dates?.[0]) chosenDate = context.available_dates[0];
          else if (rawText === '2' && context.available_dates?.[1]) chosenDate = context.available_dates[1];
          else if (/^\d{4}-\d{2}-\d{2}$/.test(rawText)) chosenDate = rawText;

          if (!chosenDate) {
            return {
              conversationId: conv.id,
              state: 'booking',
              reply: 'Please enter a valid date in YYYY-MM-DD format (or choose 1 or 2).',
            };
          }

          context.date = chosenDate;
          context.step = 'slot';

          // Fetch available slots from doctor schedules & existing appointments
          const slots = await this.getAvailableSlots(clinicId, context.doctor_id, chosenDate, conv.patient_id);
          if (slots.length === 0) {
            return {
              conversationId: conv.id,
              state: 'booking',
              reply: `No available slots on ${chosenDate}. Please choose another date or reply Menu.`,
            };
          }

          context.slots = slots;
          await this.updateConversation(conv.id, 'booking', context);

          const slotList = slots.slice(0, 6).map((s, i) => `${i + 1}. ${s.label}`).join('\n');
          const prompt = language === 'te'
            ? `లభించే సమయాలు:\n${slotList}\nసమయాన్ని ఎంచుకోవడానికి నంబర్‌ను పంపండి:`
            : language === 'hi'
            ? `उपलब्ध समय:\n${slotList}\nसमय चुनने के लिए नंबर भेजें:`
            : `Available times:\n${slotList}\nReply with the slot number:`;

          return { conversationId: conv.id, state: 'booking', reply: prompt };
        }

        if (step === 'slot') {
          const index = parseInt(rawText, 10);
          const slots: any[] = context.slots || [];
          let chosenSlot: any = null;

          if (!isNaN(index) && index >= 1 && index <= slots.length) {
            chosenSlot = slots[index - 1];
          } else {
            chosenSlot = slots.find(s => s.label.includes(rawText) || s.starts_at.includes(rawText));
          }

          if (!chosenSlot) {
            return {
              conversationId: conv.id,
              state: 'booking',
              reply: 'Please select a valid slot number.',
            };
          }

          context.starts_at = chosenSlot.starts_at;
          context.ends_at = chosenSlot.ends_at;
          context.slot_label = chosenSlot.label;
          context.step = 'confirm';
          await this.updateConversation(conv.id, 'booking', context);

          const summary = language === 'te'
            ? `దయచేసి నిర్ధారించండి:\nడాక్టర్: ${context.doctor_name}\nతేదీ: ${context.date}\nసమయం: ${context.slot_label}\n\nనిర్ధారించడానికి 1 పంపండి, రద్దు చేయడానికి 2 పంపండి.`
            : language === 'hi'
            ? `कृपया पुष्टि करें:\nडॉक्टर: ${context.doctor_name}\nतारीख: ${context.date}\nसमय: ${context.slot_label}\n\nपुष्टि करने के लिए 1 भेजें, रद्द करने के लिए 2 भेजें।`
            : `Please confirm your booking:\nDoctor: ${context.doctor_name}\nDate: ${context.date}\nTime: ${context.slot_label}\n\nReply 1 to Confirm, 2 to Cancel.`;

          return { conversationId: conv.id, state: 'booking', reply: summary };
        }

        if (step === 'confirm') {
          if (/^(1|confirm|yes|నిర్ధారించు|कन्फर्म)$/i.test(rawText)) {
            // Book the appointment
            const apptRes = await this.db.query(
              `INSERT INTO public.appointments (clinic_id, patient_id, doctor_id, starts_at, ends_at, source, status, created_at)
               VALUES ($1, $2, $3, $4, $5, 'whatsapp', 'booked', $6)
               RETURNING id, starts_at`,
              [clinicId, conv.patient_id, context.doctor_id, context.starts_at, context.ends_at, nowIso]
            );
            const appt = apptRes.rows[0];

            // Load patient name
            const pRes = await this.db.query(`SELECT name FROM public.patients WHERE id = $1`, [conv.patient_id]);
            const patientName = pRes.rows[0]?.name || 'Patient';

            // Insert confirmation outbox message
            const outboxId = crypto.randomUUID();
            await this.db.query(
              `INSERT INTO public.outbox (id, clinic_id, patient_id, kind, purpose, payload, idempotency_key, not_before, created_at)
               VALUES ($1, $2, $3, 'template', 'appointment', $4::jsonb, $5, $6, $6)
               ON CONFLICT (idempotency_key) DO NOTHING`,
              [
                outboxId,
                clinicId,
                conv.patient_id,
                JSON.stringify({
                  template_name: 'appointment_confirmed',
                  language,
                  patient_name: patientName,
                  doctor_name: context.doctor_name,
                  date: context.date,
                  time: context.slot_label,
                  clinic_name: clinic.name,
                }),
                `appointment/${appt.id}/${outboxId}`,
                nowIso,
              ]
            );

            // Emit event
            await this.db.query(
              `INSERT INTO public.events (clinic_id, patient_id, appointment_id, type, occurred_at, meta)
               VALUES ($1, $2, $3, 'appointment.booked', $4, '{"source": "whatsapp"}'::jsonb)`,
              [clinicId, conv.patient_id, appt.id, nowIso]
            );

            await this.updateConversation(conv.id, 'menu', {});

            const confirmedText = renderTemplate('appointment_confirmed', language, {
              patient_name: patientName,
              doctor_name: context.doctor_name,
              clinic_name: clinic.name,
              date: context.date,
              time: context.slot_label,
            });

            return {
              conversationId: conv.id,
              patientId: conv.patient_id,
              state: 'menu',
              reply: confirmedText,
              outboxId,
            };
          } else {
            // Cancel booking flow
            await this.updateConversation(conv.id, 'menu', {});
            return {
              conversationId: conv.id,
              state: 'menu',
              reply: 'Booking cancelled. Returning to main menu.',
            };
          }
        }

        return { conversationId: conv.id, state: 'booking', reply: 'Please follow the prompts.' };
      }

      case 'my_appointments': {
        const lower = rawText.toLowerCase();
        if (lower === 'menu' || lower === '3') {
          await this.updateConversation(conv.id, 'menu', {});
          const menu = MENU_MESSAGES[language] ?? MENU_MESSAGES.en;
          return { conversationId: conv.id, state: 'menu', reply: menu.text };
        }

        if (lower.startsWith('1') || lower.includes('reschedule') || lower.includes('రీషెడ్యూల్')) {
          // Reschedule: find upcoming appointment
          const apptRes = await this.db.query(
            `SELECT id, doctor_id, starts_at FROM public.appointments
             WHERE clinic_id = $1 AND patient_id = $2 AND status = 'booked'
             ORDER BY starts_at ASC LIMIT 1`,
            [clinicId, conv.patient_id]
          );
          const appt = apptRes.rows[0];
          if (!appt) {
            await this.updateConversation(conv.id, 'menu', {});
            return { conversationId: conv.id, state: 'menu', reply: 'No upcoming appointment found to reschedule.' };
          }

          context.reschedule_appointment_id = appt.id;
          context.doctor_id = appt.doctor_id;
          context.step = 'reschedule_confirm';
          await this.updateConversation(conv.id, 'my_appointments', context);

          return {
            conversationId: conv.id,
            state: 'my_appointments',
            reply: 'Reply Confirm to reschedule or Menu to keep it.',
          };
        }

        if (lower.startsWith('2') || lower.includes('cancel') || lower.includes('రద్దు')) {
          const apptRes = await this.db.query(
            `SELECT id, starts_at FROM public.appointments
             WHERE clinic_id = $1 AND patient_id = $2 AND status = 'booked'
             ORDER BY starts_at ASC LIMIT 1`,
            [clinicId, conv.patient_id]
          );
          const appt = apptRes.rows[0];
          if (!appt) {
            await this.updateConversation(conv.id, 'menu', {});
            return { conversationId: conv.id, state: 'menu', reply: 'No upcoming appointment found to cancel.' };
          }

          await this.db.query(`UPDATE public.appointments SET status = 'cancelled' WHERE id = $1`, [appt.id]);
          await this.db.query(
            `INSERT INTO public.events (clinic_id, patient_id, appointment_id, type, occurred_at, meta)
             VALUES ($1, $2, $3, 'appointment.cancelled', $4, '{"source": "whatsapp"}'::jsonb)`,
            [clinicId, conv.patient_id, appt.id, nowIso]
          );

          await this.updateConversation(conv.id, 'menu', {});
          return {
            conversationId: conv.id,
            state: 'menu',
            reply: 'Your appointment has been cancelled.',
          };
        }

        return this.renderMyAppointments(clinicId, conv.patient_id, language);
      }

      case 'slip_verify': {
        // Check lockout
        const lockRes = await this.db.query(
          `SELECT failed_attempts, locked_until FROM public.dob_lockouts WHERE clinic_id = $1 AND patient_id = $2`,
          [clinicId, conv.patient_id]
        );
        const lockout = lockRes.rows[0];

        if (lockout?.locked_until && new Date(lockout.locked_until).getTime() > new Date(nowIso).getTime()) {
          const msg = DOB_LOCKED_MESSAGES[language] ?? DOB_LOCKED_MESSAGES.en;
          await this.updateConversation(conv.id, 'menu', {});
          return { conversationId: conv.id, state: 'menu', reply: msg };
        }

        // Fetch patient DOB
        const patRes = await this.db.query(
          `SELECT date_of_birth, name FROM public.patients WHERE id = $1`,
          [conv.patient_id]
        );
        const rawDob = patRes.rows[0]?.date_of_birth;
        const patientDob = rawDob instanceof Date
          ? `${rawDob.getFullYear()}-${String(rawDob.getMonth() + 1).padStart(2, '0')}-${String(rawDob.getDate()).padStart(2, '0')}`
          : typeof rawDob === 'string'
          ? rawDob.slice(0, 10)
          : null;

        // Normalize inputs: match YYYY-MM-DD
        const inputDob = rawText.trim();
        const matches = Boolean(patientDob && inputDob === patientDob);

        if (matches) {
          // Reset lockout
          await this.db.query(
            `INSERT INTO public.dob_lockouts (clinic_id, patient_id, failed_attempts, locked_until, updated_at)
             VALUES ($1, $2, 0, NULL, $3)
             ON CONFLICT (clinic_id, patient_id)
             DO UPDATE SET failed_attempts = 0, locked_until = NULL, updated_at = $3`,
            [clinicId, conv.patient_id, nowIso]
          );

          // Proceed directly to slip delivery
          await this.updateConversation(conv.id, 'slip_select', {});
          return this.deliverSlip(clinicId, conv.patient_id, patRes.rows[0].name, language, conv.id);
        } else {
          // Failed attempt
          const currentAttempts = (lockout?.failed_attempts || 0) + 1;
          if (currentAttempts >= 3) {
            // 3-strike lockout for 1 hour
            const lockedUntil = new Date(Date.parse(nowIso) + 60 * 60 * 1000).toISOString();
            await this.db.query(
              `INSERT INTO public.dob_lockouts (clinic_id, patient_id, failed_attempts, locked_until, updated_at)
               VALUES ($1, $2, $3, $4, $5)
               ON CONFLICT (clinic_id, patient_id)
               DO UPDATE SET failed_attempts = $3, locked_until = $4, updated_at = $5`,
              [clinicId, conv.patient_id, currentAttempts, lockedUntil, nowIso]
            );

            // Raise staff alert
            const dedupKey = `id_lockout:${clinicId}:${conv.patient_id}:${nowIso.slice(0, 13)}`;
            await this.db.query(
              `INSERT INTO public.staff_alerts (clinic_id, patient_id, code, dedup_key, created_at, context)
               VALUES ($1, $2, 'ID_CHECK_LOCKED', $3, $4, '{}'::jsonb)
               ON CONFLICT (dedup_key) DO NOTHING`,
              [clinicId, conv.patient_id, dedupKey, nowIso]
            );

            await this.updateConversation(conv.id, 'menu', {});
            const lockedMsg = DOB_LOCKED_MESSAGES[language] ?? DOB_LOCKED_MESSAGES.en;
            return {
              conversationId: conv.id,
              patientId: conv.patient_id,
              state: 'menu',
              reply: lockedMsg,
              alertRaised: true,
              alertCode: 'ID_CHECK_LOCKED',
            };
          } else {
            await this.db.query(
              `INSERT INTO public.dob_lockouts (clinic_id, patient_id, failed_attempts, locked_until, updated_at)
               VALUES ($1, $2, $3, NULL, $4)
               ON CONFLICT (clinic_id, patient_id)
               DO UPDATE SET failed_attempts = $3, updated_at = $4`,
              [clinicId, conv.patient_id, currentAttempts, nowIso]
            );

            const failedTpl = DOB_FAILED_MESSAGES[language] ?? DOB_FAILED_MESSAGES.en;
            const reply = failedTpl.replace('{{attempt}}', String(currentAttempts));
            return {
              conversationId: conv.id,
              patientId: conv.patient_id,
              state: 'slip_verify',
              reply,
            };
          }
        }
      }

      case 'slip_select': {
        const patRes = await this.db.query(`SELECT name FROM public.patients WHERE id = $1`, [conv.patient_id]);
        return this.deliverSlip(clinicId, conv.patient_id, patRes.rows[0]?.name || 'Patient', language, conv.id);
      }

      case 'handoff': {
        return {
          conversationId: conv.id,
          state: 'handoff',
          reply: 'Your request is with clinic staff. They will reply shortly.',
        };
      }

      default: {
        await this.updateConversation(conv.id, 'menu', {});
        const menu = MENU_MESSAGES[language] ?? MENU_MESSAGES.en;
        return { conversationId: conv.id, state: 'menu', reply: menu.text };
      }
    }
  }

  private async updateConversation(id: string, state: string, context: Record<string, unknown>, patientId?: string) {
    if (patientId) {
      await this.db.query(
        `UPDATE public.conversations SET state = $1, context = $2::jsonb, patient_id = $3 WHERE id = $4`,
        [state, JSON.stringify(context), patientId, id]
      );
    } else {
      await this.db.query(
        `UPDATE public.conversations SET state = $1, context = $2::jsonb WHERE id = $3`,
        [state, JSON.stringify(context), id]
      );
    }
  }

  private async renderChoosePatient(clinicId: string, mobileE164: string, language: SupportedLanguage): Promise<EngineResult> {
    const patRes = await this.db.query(
      `SELECT id, name FROM public.patients WHERE clinic_id = $1 AND mobile_e164 = $2 AND merged_into IS NULL ORDER BY created_at`,
      [clinicId, mobileE164]
    );
    const list = patRes.rows.map((p, i) => `${i + 1}. ${p.name}`).join('\n');
    const reply = language === 'te'
      ? `ఈ నంబర్‌తో ఒకటి కంటే ఎక్కువ మంది రోగులు ఉన్నారు. దయచేసి ఎంచుకోండి:\n${list}`
      : language === 'hi'
      ? `इस नंबर से एक से अधिक मरीज़ पंजीकृत हैं। कृपया चयन करें:\n${list}`
      : `Multiple family members share this number. Please select a patient:\n${list}`;

    return { state: 'choose_patient', reply };
  }

  private renderConsentPrompt(clinicName: string, language: SupportedLanguage): EngineResult {
    const text = renderTemplate('consent_request', language, { clinic_name: clinicName });
    return { state: 'awaiting_consent', reply: text };
  }

  private async renderMyAppointments(clinicId: string, patientId: string, language: SupportedLanguage): Promise<EngineResult> {
    const appts = (await this.db.query(
      `SELECT a.id, a.starts_at, d.name as doctor_name
       FROM public.appointments a
       JOIN public.doctors d ON d.id = a.doctor_id
       WHERE a.clinic_id = $1 AND a.patient_id = $2 AND a.status = 'booked'
       ORDER BY a.starts_at ASC`,
      [clinicId, patientId]
    )).rows;

    if (appts.length === 0) {
      const emptyMsg = language === 'te'
        ? 'మీకు రాబోయే అపాయింట్‌మెంట్‌లు ఏవీ లేవు. కొత్తది బుక్ చేయడానికి మెనూ అని రిప్లై ఇవ్వండి.'
        : language === 'hi'
        ? 'आपके पास कोई आगामी अपॉइंटमेंट नहीं है। नया बुक करने के लिए मेनू रिप्लाई करें।'
        : 'You have no upcoming appointments. Reply Menu to book one.';
      return { state: 'my_appointments', reply: emptyMsg };
    }

    const apptList = appts.map((a, i) => {
      const dt = new Intl.DateTimeFormat('en-IN', {
        timeZone: 'Asia/Kolkata',
        dateStyle: 'medium',
        timeStyle: 'short',
      }).format(new Date(a.starts_at));
      return `${i + 1}. ${a.doctor_name} - ${dt}`;
    }).join('\n');

    const reply = language === 'te'
      ? `మీ అపాయింట్‌మెంట్‌లు:\n${apptList}\n\n1. రీషెడ్యూల్\n2. రద్దు చేయి\n3. ప్రధాన మెనూ`
      : language === 'hi'
      ? `आपके अपॉइंटमेंट:\n${apptList}\n\n1. पुनर्निर्धारित करें\n2. रद्द करें\n3. मुख्य मेनू`
      : `Your appointments:\n${apptList}\n\n1. Reschedule\n2. Cancel\n3. Main Menu`;

    return { state: 'my_appointments', reply };
  }

  private async deliverSlip(clinicId: string, patientId: string, patientName: string, language: SupportedLanguage, convId: string): Promise<EngineResult> {
    const nowIso = this.now();
    const visitRes = await this.db.query(
      `SELECT id, slip_file_path, completed_at FROM public.visits
       WHERE clinic_id = $1 AND patient_id = $2
       ORDER BY completed_at DESC LIMIT 1`,
      [clinicId, patientId]
    );

    const visit = visitRes.rows[0];
    if (!visit || !visit.slip_file_path) {
      // Slip not ready
      const dedupKey = `slip_not_ready:${clinicId}:${patientId}`;
      await this.db.query(
        `INSERT INTO public.staff_alerts (clinic_id, patient_id, code, dedup_key, created_at, context)
         VALUES ($1, $2, 'DOC_NOT_READY', $3, $4, '{}'::jsonb)
         ON CONFLICT (dedup_key) DO NOTHING`,
        [clinicId, patientId, dedupKey, nowIso]
      );

      await this.updateConversation(convId, 'menu', {});
      const reply = language === 'te'
        ? 'మీ విజిట్ స్లిప్ ఇంకా సిద్ధంగా లేదు. క్లినిక్ సిబ్బందికి తెలియజేయబడింది.'
        : language === 'hi'
        ? 'आपकी विजिट स्लिप अभी तैयार नहीं है। क्लिनिक स्टाफ को सूचित कर दिया गया है।'
        : 'Your visit slip is not ready yet. Clinic staff have been alerted.';

      return { state: 'menu', reply, alertRaised: true, alertCode: 'DOC_NOT_READY' };
    }

    // Generate 5-minute signed URL
    const expiresAt = new Date(Date.parse(nowIso) + 5 * 60 * 1000).toISOString();
    const signedUrl = `https://storage.tabiyo.internal/v1/slips/${visit.id}?token=sig-${visit.id}&expires=${encodeURIComponent(expiresAt)}`;

    // Audit document access
    await this.db.query(
      `INSERT INTO public.audit_log (clinic_id, action, table_name, record_id, created_at)
       VALUES ($1, 'document.read', 'visits', $2, $3)`,
      [clinicId, visit.id, nowIso]
    );

    const visitDate = visit.completed_at instanceof Date
      ? visit.completed_at.toISOString().slice(0, 10)
      : String(visit.completed_at || nowIso).slice(0, 10);

    // Enqueue outbox template
    await this.db.query(
      `INSERT INTO public.outbox (clinic_id, patient_id, kind, purpose, payload, idempotency_key, not_before, created_at)
       VALUES ($1, $2, 'template', 'slip', $3::jsonb, $4, $5, $5)
       ON CONFLICT (idempotency_key) DO NOTHING`,
      [
        clinicId,
        patientId,
        JSON.stringify({
          template_name: 'visit_slip_ready',
          language,
          patient_name: patientName,
          date: visitDate,
          url: signedUrl,
        }),
        `slip/${visit.id}/${nowIso}`,
        nowIso,
      ]
    );

    await this.updateConversation(convId, 'menu', {});
    const slipNotice = renderTemplate('visit_slip_ready', language, {
      patient_name: patientName,
      date: visitDate,
    });

    return {
      state: 'menu',
      reply: `${slipNotice}\n\nDownload link (valid for 5 minutes):\n${signedUrl}`,
    };
  }

  private async getAvailableSlots(clinicId: string, doctorId: string, date: string, patientId?: string) {
    // Generate slots from doctor schedules for that weekday
    const schedRes = await this.db.query(
      `SELECT start_time, end_time, break_start, break_end, weekday
       FROM public.doctor_schedules
       WHERE clinic_id = $1 AND doctor_id = $2
         AND weekday = extract(dow from $3::date)
       LIMIT 1`,
      [clinicId, doctorId, date]
    );

    const schedule = schedRes.rows[0];
    if (!schedule) return [];

    // Check doctor leaves
    const leaveRes = await this.db.query(
      `SELECT 1 FROM public.doctor_leaves
       WHERE clinic_id = $1 AND doctor_id = $2 AND $3::date BETWEEN date_from AND date_to`,
      [clinicId, doctorId, date]
    );
    if (leaveRes.rows.length > 0) return [];

    // Check clinic holidays
    const holidayRes = await this.db.query(
      `SELECT 1 FROM public.clinics
       WHERE id = $1 AND settings->'holidays' ? $2`,
      [clinicId, date]
    );
    if (holidayRes.rows.length > 0) return [];

    // Query booked appointments on this date
    const apptsRes = await this.db.query(
      `SELECT starts_at, ends_at FROM public.appointments
       WHERE clinic_id = $1 AND doctor_id = $2 AND status IN ('booked', 'checked_in')
         AND starts_at::date = $3::date`,
      [clinicId, doctorId, date]
    );
    const bookedTimes = new Set(apptsRes.rows.map(a => new Date(a.starts_at).toISOString()));

    // Generate 30-min intervals between start_time and end_time
    const [startH, startM] = schedule.start_time.split(':').map(Number);
    const [endH, endM] = schedule.end_time.split(':').map(Number);
    const slots: Array<{ label: string; starts_at: string; ends_at: string }> = [];

    let curMinutes = startH * 60 + startM;
    const endMinutes = endH * 60 + endM;

    const [breakStartH, breakStartM] = schedule.break_start ? schedule.break_start.split(':').map(Number) : [-1, -1];
    const [breakEndH, breakEndM] = schedule.break_end ? schedule.break_end.split(':').map(Number) : [-1, -1];
    const breakStart = breakStartH >= 0 ? breakStartH * 60 + breakStartM : -1;
    const breakEnd = breakEndH >= 0 ? breakEndH * 60 + breakEndM : -1;

    while (curMinutes + 30 <= endMinutes) {
      if (breakStart >= 0 && curMinutes >= breakStart && curMinutes < breakEnd) {
        curMinutes += 30;
        continue;
      }

      const h = Math.floor(curMinutes / 60);
      const m = curMinutes % 60;
      const hh = String(h).padStart(2, '0');
      const mm = String(m).padStart(2, '0');
      const timeStr = `${hh}:${mm}`;

      // Convert to UTC ISO timestamp
      // Assuming IST is UTC+5:30
      const istDate = new Date(`${date}T${timeStr}:00+05:30`);
      const istEnd = new Date(istDate.getTime() + 30 * 60 * 1000);
      const isoStart = istDate.toISOString();
      const isoEnd = istEnd.toISOString();

      if (!bookedTimes.has(isoStart)) {
        slots.push({
          label: timeStr,
          starts_at: isoStart,
          ends_at: isoEnd,
        });
      }

      curMinutes += 30;
    }

    return slots;
  }
}
