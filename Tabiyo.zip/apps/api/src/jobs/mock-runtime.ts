import type {PgBoss} from 'pg-boss';
import {DeliveryWorker} from '../delivery/worker.ts';
import {RecordingMockSender} from '../delivery/mock-sender.ts';
import type {DeliveryStore} from '../delivery/store.ts';
import {GatewayWorker} from '../whatsapp/worker.ts';
import type {GatewayStore} from '../whatsapp/store.ts';
import {Scheduler} from './scheduler.ts';

/** Explicit local composition; importing this module starts no worker or connection. */
export function createMockScheduler(config: {
  boss: PgBoss;
  deliveryStore: DeliveryStore;
  gatewayStore: GatewayStore;
  retention: () => Promise<unknown>;
}) {
  return new Scheduler({
    boss: config.boss,
    mode: 'mock',
    delivery: new DeliveryWorker(config.deliveryStore, new RecordingMockSender(config.deliveryStore)),
    gateway: new GatewayWorker(config.gatewayStore),
    cleanup: async () => {
      await config.gatewayStore.cleanup();
      await config.retention();
    },
  });
}
