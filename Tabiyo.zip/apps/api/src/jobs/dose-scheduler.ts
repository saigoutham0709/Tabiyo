import { renderTemplate, type SupportedLanguage } from '@tabiyo/templates';

export interface DoseSchedulerDb {
  query: (sql: string, params?: unknown[]) => Promise<{ rows: any[] }>;
}

export interface DoseSchedulerOptions {
  db: DoseSchedulerDb;
  boss?: any;
  now?: () => string; // ISO string
}

export interface GroupedDose {
  patient_id: string;
  clinic_id: string;
  patient_name: string;
  language: SupportedLanguage;
  opted_out: boolean;
  time_of_day: string;
  date: string;
  group_key: string;
  medicines: Array<{
    id: string;
    medicine: string;
    dose: string;
    food_relation: string;
    times: string[];
  }>;
}

export class DoseScheduler {
  private db: DoseSchedulerDb;
  private boss?: any;
  private nowFn: () => string;

  constructor(options: DoseSchedulerOptions) {
    this.db = options.db;
    this.boss = options.boss;
    this.nowFn = options.now ?? (() => new Date().toISOString());
  }

  private now(): string {
    return this.nowFn();
  }

  private todayDate(): string {
    const iso = this.now();
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date(iso));
  }

  /**
   * Auto-complete medication schedules whose end_date has passed
   */
  async completeExpiredSchedules(): Promise<number> {
    const today = this.todayDate();
    const result = await this.db.query(
      `UPDATE public.medication_schedules
       SET status = 'completed'
       WHERE status = 'active' AND end_date < $1
       RETURNING id`,
      [today]
    );
    return result.rows.length;
  }

  /**
   * Group active medicines for today by patient and dose time
   */
  async findDueDoses(timeSlot?: string, targetDate?: string): Promise<GroupedDose[]> {
    const date = targetDate ?? this.todayDate();

    // Query active medication schedules active for the target date
    const query = `
      SELECT ms.id, ms.clinic_id, ms.prescription_id, ms.patient_id, ms.medicine,
             ms.dose, ms.times, ms.food_relation, ms.start_date, ms.end_date,
             p.name as patient_name, p.language as patient_language, p.opted_out
      FROM public.medication_schedules ms
      JOIN public.patients p ON p.id = ms.patient_id
      WHERE ms.status = 'active'
        AND ms.start_date <= $1
        AND ms.end_date >= $1
        AND p.opted_out = false
        AND p.merged_into IS NULL
      ORDER BY ms.patient_id, ms.created_at
    `;
    const res = await this.db.query(query, [date]);
    const schedules = res.rows;

    const groupMap = new Map<string, GroupedDose>();

    for (const s of schedules) {
      const times: string[] = Array.isArray(s.times) ? s.times : [];
      for (const t of times) {
        const slot = t.trim().toLowerCase();
        if (timeSlot && slot !== timeSlot.toLowerCase()) {
          continue;
        }

        const groupKey = `dose:${s.patient_id}:${date}:${slot}`;
        if (!groupMap.has(groupKey)) {
          groupMap.set(groupKey, {
            patient_id: s.patient_id,
            clinic_id: s.clinic_id,
            patient_name: s.patient_name,
            language: (s.patient_language as SupportedLanguage) || 'en',
            opted_out: s.opted_out,
            time_of_day: slot,
            date,
            group_key: groupKey,
            medicines: [],
          });
        }

        groupMap.get(groupKey)!.medicines.push({
          id: s.id,
          medicine: s.medicine,
          dose: s.dose,
          food_relation: s.food_relation,
          times: s.times,
        });
      }
    }

    return Array.from(groupMap.values());
  }

  /**
   * Process and enqueue grouped dose reminders
   */
  async processDueReminders(timeSlot?: string, targetDate?: string): Promise<{ sent: number; skipped: number }> {
    await this.completeExpiredSchedules();

    const groups = await this.findDueDoses(timeSlot, targetDate);
    let sent = 0;
    let skipped = 0;
    const nowIso = this.now();

    for (const group of groups) {
      // Check if dose_event already created for this group
      const existing = await this.db.query(
        `SELECT id, response FROM public.dose_events WHERE clinic_id = $1 AND schedule_group_key = $2`,
        [group.clinic_id, group.group_key]
      );

      if (existing.rows.length > 0) {
        skipped++;
        continue;
      }

      // Format medicine list
      const medicineLines = group.medicines.map(m => {
        const relation = m.food_relation ? ` (${m.food_relation.replace('_', ' ')})` : '';
        return `• ${m.medicine} - ${m.dose}${relation}`;
      }).join('\n');

      // Record dose event
      await this.db.query(
        `INSERT INTO public.dose_events (clinic_id, schedule_group_key, patient_id, due_at, sent_at, response, created_at)
         VALUES ($1, $2, $3, $4, $4, 'none', $4)`,
        [group.clinic_id, group.group_key, group.patient_id, nowIso]
      );

      // Render reminder message
      const reminderText = renderTemplate('medication_reminder', group.language, {
        patient_name: group.patient_name,
        time_of_day: group.time_of_day,
        medicine_list: medicineLines,
      });

      // Insert into outbox
      const outboxPayload = {
        template_name: 'medication_reminder',
        language: group.language,
        patient_name: group.patient_name,
        time_of_day: group.time_of_day,
        medicine_list: medicineLines,
        text: reminderText,
        schedule_group_key: group.group_key,
        buttons: [
          { id: `dose:taken:${group.group_key}`, title: 'Taken' },
          { id: `dose:later:${group.group_key}`, title: 'Remind later' },
          { id: `dose:stop:${group.group_key}`, title: 'Stop' },
        ],
      };

      await this.db.query(
        `INSERT INTO public.outbox (clinic_id, patient_id, kind, purpose, payload, idempotency_key, not_before, created_at)
         VALUES ($1, $2, 'interactive', 'medication', $3::jsonb, $4, $5, $5)
         ON CONFLICT (idempotency_key) DO NOTHING`,
        [group.clinic_id, group.patient_id, JSON.stringify(outboxPayload), group.group_key, nowIso]
      );

      // Emit event
      await this.db.query(
        `INSERT INTO public.events (clinic_id, patient_id, type, occurred_at, meta)
         VALUES ($1, $2, 'dose.reminder_sent', $3, $4::jsonb)`,
        [group.clinic_id, group.patient_id, nowIso, JSON.stringify({
          schedule_group_key: group.group_key,
          medicines_count: group.medicines.length,
          time_of_day: group.time_of_day,
        })]
      );

      sent++;
    }

    return { sent, skipped };
  }

  /**
   * Handle patient interactive button responses: Taken, Remind later, Stop
   */
  async handleDoseAction(
    clinicId: string,
    patientId: string,
    action: 'taken' | 'later' | 'stop',
    groupKey?: string
  ): Promise<{ success: boolean; action: string; reply: string }> {
    const nowIso = this.now();

    // Find the relevant dose event
    let targetEvent: any = null;
    if (groupKey) {
      const res = await this.db.query(
        `SELECT * FROM public.dose_events
         WHERE clinic_id = $1 AND schedule_group_key = $2`,
        [clinicId, groupKey]
      );
      targetEvent = res.rows[0];
    }

    if (!targetEvent) {
      // Find latest pending or recent dose event for this patient
      const res = await this.db.query(
        `SELECT * FROM public.dose_events
         WHERE clinic_id = $1 AND patient_id = $2
         ORDER BY due_at DESC LIMIT 1`,
        [clinicId, patientId]
      );
      targetEvent = res.rows[0];
    }

    // Get patient language
    const patientRes = await this.db.query(
      `SELECT language FROM public.patients WHERE id = $1`,
      [patientId]
    );
    const language: SupportedLanguage = patientRes.rows[0]?.language || 'en';

    if (action === 'taken') {
      if (targetEvent) {
        await this.db.query(
          `UPDATE public.dose_events
           SET response = 'taken', responded_at = $1
           WHERE id = $2`,
          [nowIso, targetEvent.id]
        );
      }

      await this.db.query(
        `INSERT INTO public.events (clinic_id, patient_id, type, occurred_at, meta)
         VALUES ($1, $2, 'dose.taken', $3, $4::jsonb)`,
        [clinicId, patientId, nowIso, JSON.stringify({
          schedule_group_key: targetEvent?.schedule_group_key || groupKey,
        })]
      );

      const reply = language === 'te'
        ? 'ధన్యవాదాలు! మీ మోతాదు తీసుకున్నట్లు నమోదు చేయబడింది. మందులను క్రమం తప్పకుండా తీసుకోవడం మంచిది!'
        : language === 'hi'
        ? 'धन्यवाद! आपकी दवा ले ली गई के रूप में दर्ज कर ली गई है। नियमित रूप से दवा लेते रहें!'
        : 'Thank you! Your dose has been recorded as taken. Excellent adherence!';

      return { success: true, action: 'taken', reply };
    }

    if (action === 'later') {
      // Max 1 retry check: check if a retry was already scheduled for this groupKey
      const retryKey = `${targetEvent?.schedule_group_key || groupKey}:retry1`;
      const existingRetry = await this.db.query(
        `SELECT id FROM public.outbox WHERE clinic_id = $1 AND idempotency_key = $2`,
        [clinicId, retryKey]
      );

      if (existingRetry.rows.length > 0) {
        const reply = language === 'te'
          ? 'మీరు ఇప్పటికే ఈ రిమైండర్‌ను ఒకసారి రీషెడ్యూల్ చేశారు. దయచేసి వీలైనంత త్వరగా మందులు తీసుకోండి.'
          : language === 'hi'
          ? 'आप इस रिमाइंडर को पहले ही एक बार आगे बढ़ा चुके हैं। कृपया सुरक्षित होते ही दवा लें।'
          : 'You have already snoozed this reminder once. Please take your medication when convenient.';
        return { success: true, action: 'later_limit_reached', reply };
      }

      if (targetEvent) {
        await this.db.query(
          `UPDATE public.dose_events
           SET response = 'later', responded_at = $1
           WHERE id = $2`,
          [nowIso, targetEvent.id]
        );
      }

      // Schedule 30-minute follow up
      const futureDate = new Date(Date.parse(nowIso) + 30 * 60 * 1000).toISOString();

      await this.db.query(
        `INSERT INTO public.outbox (clinic_id, patient_id, kind, purpose, payload, idempotency_key, not_before, created_at)
         VALUES ($1, $2, 'interactive', 'medication', $3::jsonb, $4, $5, $6)
         ON CONFLICT (idempotency_key) DO NOTHING`,
        [
          clinicId,
          patientId,
          JSON.stringify({
            template_name: 'medication_reminder',
            language,
            schedule_group_key: targetEvent?.schedule_group_key || groupKey,
            is_retry: true,
            buttons: [
              { id: `dose:taken:${targetEvent?.schedule_group_key || groupKey}`, title: 'Taken' },
              { id: `dose:stop:${targetEvent?.schedule_group_key || groupKey}`, title: 'Stop' },
            ],
          }),
          retryKey,
          futureDate,
          nowIso,
        ]
      );

      await this.db.query(
        `INSERT INTO public.events (clinic_id, patient_id, type, occurred_at, meta)
         VALUES ($1, $2, 'dose.later', $3, $4::jsonb)`,
        [clinicId, patientId, nowIso, JSON.stringify({
          schedule_group_key: targetEvent?.schedule_group_key || groupKey,
          scheduled_for: futureDate,
        })]
      );

      const reply = language === 'te'
        ? 'సరే, మేము 30 నిమిషాల తర్వాత మళ్ళీ గుర్తు చేస్తాము.'
        : language === 'hi'
        ? 'ठीक है, हम आपको 30 मिनट बाद फिर से याद दिलाएंगे।'
        : 'Okay, we will remind you again in 30 minutes.';

      return { success: true, action: 'later', reply };
    }

    if (action === 'stop') {
      // Mark medication schedules as stopped
      await this.db.query(
        `UPDATE public.medication_schedules
         SET status = 'stopped'
         WHERE clinic_id = $1 AND patient_id = $2 AND status = 'active'`,
        [clinicId, patientId]
      );

      if (targetEvent) {
        await this.db.query(
          `UPDATE public.dose_events
           SET response = 'stopped', responded_at = $1
           WHERE id = $2`,
          [nowIso, targetEvent.id]
        );
      }

      await this.db.query(
        `INSERT INTO public.events (clinic_id, patient_id, type, occurred_at, meta)
         VALUES ($1, $2, 'dose.stopped', $3, $4::jsonb)`,
        [clinicId, patientId, nowIso, JSON.stringify({
          schedule_group_key: targetEvent?.schedule_group_key || groupKey,
        })]
      );

      const reply = language === 'te'
        ? 'మీ మందుల రిమైండర్ షెడ్యూల్ నిలిపివేయబడింది. మందులను ఆపే ముందు దయచేసి మీ వైద్యుడిని సంప్రదించండి.'
        : language === 'hi'
        ? 'आपका दवा रिमाइंडर शेड्यूल रोक दिया गया है। कोई भी दवा बंद करने से पहले कृपया अपने डॉक्टर से परामर्श अवश्य लें।'
        : 'Your medication reminder schedule has been stopped. Please consult your doctor before discontinuing any medication.';

      return { success: true, action: 'stop', reply };
    }

    return { success: false, action: 'unknown', reply: 'Invalid action.' };
  }

  /**
   * pg-boss runOnce worker execution
   */
  async runOnce(): Promise<{ action: string; count?: number }> {
    const expiredCount = await this.completeExpiredSchedules();
    const result = await this.processDueReminders();
    return {
      action: result.sent > 0 ? 'processed' : 'idle',
      count: result.sent,
    };
  }
}
