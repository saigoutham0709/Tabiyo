import type {PgBoss} from 'pg-boss';

export const queues = {
  delivery: 'tabiyo.delivery.tick',
  gateway: 'tabiyo.gateway.tick',
  cleanup: 'tabiyo.cleanup.tick',
} as const;
export type JobKind = keyof typeof queues;
type Runner = {runOnce(): Promise<{action: string}>};
type Dependencies = {
  boss: PgBoss;
  mode: 'mock';
  delivery: Runner;
  gateway: Runner;
  cleanup: () => Promise<unknown>;
  report?: (code: 'SCHEDULER_ERROR' | 'SCHEDULER_HANDLER_FAILED', kind?: JobKind) => void;
  maxItems?: number;
  maxRunMs?: number;
};

/** Control jobs contain no clinical data. SQL stores remain the source of work and lease ownership. */
export class Scheduler {
  private dependencies: Dependencies;
  private state: 'stopped' | 'starting' | 'running' | 'stopping' = 'stopped';
  private transition?: Promise<void>;
  private readonly onError = () => this.report('SCHEDULER_ERROR');

  constructor(dependencies: Dependencies) {
    if (dependencies.mode !== 'mock') throw new Error('SCHEDULER_MOCK_ONLY');
    const {maxItems = 25, maxRunMs = 20_000} = dependencies;
    if (!Number.isInteger(maxItems) || maxItems < 1 || maxItems > 100 ||
        !Number.isInteger(maxRunMs) || maxRunMs < 1 || maxRunMs > 30_000) {
      throw new Error('SCHEDULER_INVALID_LIMITS');
    }
    this.dependencies = {...dependencies, maxItems, maxRunMs};
  }

  private report(code: 'SCHEDULER_ERROR' | 'SCHEDULER_HANDLER_FAILED', kind?: JobKind) {
    // Observability must never change a job outcome or expose the underlying error.
    try { this.dependencies.report?.(code, kind); } catch { /* observer failure is isolated */ }
  }

  private async execute(kind: JobKind, data: unknown) {
    try {
      if (!data || typeof data !== 'object' || Array.isArray(data) || Object.keys(data).length) {
        throw new Error('INVALID_CONTROL_JOB');
      }
      if (kind === 'cleanup') {
        await this.dependencies.cleanup();
        return;
      }
      const runner = this.dependencies[kind];
      const deadline = performance.now() + this.dependencies.maxRunMs!;
      for (let count = 0; count < this.dependencies.maxItems! && performance.now() < deadline; count++) {
        if (this.state !== 'running' && this.state !== 'starting') break;
        const result = await runner.runOnce();
        if (result.action === 'idle') break;
      }
    } catch {
      this.report('SCHEDULER_HANDLER_FAILED', kind);
      // pg-boss persists thrown errors: never pass provider errors or patient data through.
      throw new Error('SCHEDULER_HANDLER_FAILED');
    }
  }

  async start(): Promise<void> {
    if (this.state === 'running') return;
    if (this.state === 'starting') return this.transition;
    if (this.state === 'stopping') throw new Error('SCHEDULER_STOPPING');
    this.state = 'starting';
    this.transition = this.startInternal();
    return this.transition;
  }

  private async startInternal() {
    const {boss} = this.dependencies;
    boss.on('error', this.onError);
    try {
      await boss.start();
      for (const kind of Object.keys(queues) as JobKind[]) {
        await boss.createQueue(queues[kind], {
          policy: 'stately', retryLimit: 3, retryDelay: 30, retryBackoff: true,
          expireInSeconds: 120, retentionSeconds: 86_400, deleteAfterSeconds: 604_800,
        });
        await boss.schedule(queues[kind], kind === 'cleanup' ? '15 3 * * *' : '* * * * *', {},
          {tz: 'Asia/Kolkata'});
      }
      for (const kind of Object.keys(queues) as JobKind[]) {
        await boss.work(queues[kind], {batchSize: 1, localConcurrency: 1, pollingIntervalSeconds: 1},
          async jobs => { await this.execute(kind, jobs[0].data); });
      }
      this.state = 'running';
      await this.wake('gateway');
      await this.wake('delivery');
    } catch {
      this.state = 'stopping';
      try { await boss.stop({graceful: true, timeout: 30_000}); }
      catch { this.report('SCHEDULER_ERROR'); }
      finally { boss.off('error', this.onError); this.state = 'stopped'; }
      throw new Error('SCHEDULER_START_FAILED');
    }
  }

  /** Wake after a committed intake/write. Minute cron remains a recovery backstop. */
  async wake(kind: JobKind) {
    if (this.state !== 'running') throw new Error('SCHEDULER_NOT_RUNNING');
    return this.dependencies.boss.send(queues[kind], {});
  }

  async stop(): Promise<void> {
    if (this.state === 'starting') {
      try { await this.transition; } catch { return; }
    }
    if (this.state === 'stopped') return;
    if (this.state === 'stopping') return this.transition;
    this.state = 'stopping';
    this.transition = this.stopInternal();
    return this.transition;
  }

  private async stopInternal() {
    const {boss} = this.dependencies;
    try { await boss.stop({graceful: true, timeout: 30_000}); }
    finally { boss.off('error', this.onError); this.state = 'stopped'; }
  }
}
