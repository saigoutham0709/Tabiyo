import { z } from 'zod';
import {
  ApiError,
  prescriptionRecordSchema,
  patientAdherenceSchema,
  visitSlipUrlSchema,
  faqSchema,
  reportSummarySchema,
  patientRecordSchema,
  type PrescriptionCreate,
  type PrescriptionRecord,
  type PatientAdherence,
  type VisitSlipUrl,
  type FAQRecord,
  type FAQCreate,
  type ReportSummary,
  type PatientImportRow,
  type PatientMerge,
  type PatientRecord,
} from '@tabiyo/shared';
import { createUserClient, type AuthConfig } from './auth.ts';

export type ClinicalService = {
  createPrescription(token: string, input: PrescriptionCreate, requestId?: string): Promise<{ prescription: PrescriptionRecord }>;
  getAdherence(token: string, patientId: string): Promise<PatientAdherence>;
  createOrUpdateVisitSlip(token: string, visitIdOrAppointmentId: string, input?: { notes?: string; slip_file_path?: string; generate_slip?: boolean }): Promise<VisitSlipUrl>;
  getVisitSlipUrl(token: string, visitIdOrAppointmentId: string, dob?: string): Promise<VisitSlipUrl>;
  listFaqs(token: string, options?: { active?: boolean | string; language?: string }): Promise<FAQRecord[]>;
  upsertFaqs(token: string, faqs: FAQCreate[] | FAQCreate): Promise<FAQRecord[]>;
  getReportsSummary(token: string, from: string, to: string): Promise<ReportSummary>;
  importPatients(token: string, body: { rows?: PatientImportRow[]; csv?: string } | PatientImportRow[] | string): Promise<{ imported: number; duplicates: number; errors: Array<{ row: number; error: string }>; patients: PatientRecord[] }>;
  mergePatients(token: string, input: PatientMerge): Promise<{ success: boolean; source_patient_id: string; target_patient_id: string; merged_at: string }>;
};

const failures: Record<string, [number, string]> = {
  STAFF_FORBIDDEN: [403, 'Active clinic membership is required.'],
  OPERATION_FORBIDDEN: [403, 'Your role cannot perform this operation.'],
  PATIENT_NOT_FOUND: [404, 'Patient not found.'],
  APPOINTMENT_NOT_FOUND: [404, 'Appointment not found.'],
  VISIT_NOT_FOUND: [404, 'Visit not found.'],
  FAQ_NOT_FOUND: [404, 'FAQ not found.'],
  DOB_VERIFICATION_FAILED: [401, 'Incorrect date of birth provided.'],
  ID_CHECK_LOCKED: [403, 'Date of birth verification is locked due to too many failed attempts. Contact staff.'],
  PATIENT_STATE_INVALID: [409, 'Patient record is already merged or invalid.'],
  IDEMPOTENCY_CONFLICT: [409, 'This request key was already used for another operation.'],
  INPUT_INVALID: [422, 'Check the request details and try again.'],
};

function normalizeIndianMobile(raw: string): string | null {
  const digits = raw.replace(/\D/g, '');
  if (digits.length === 10 && /^[6-9]/.test(digits)) {
    return `+91${digits}`;
  }
  if (digits.length === 12 && digits.startsWith('91') && /^[6-9]/.test(digits.slice(2))) {
    return `+${digits}`;
  }
  if (digits.length === 11 && digits.startsWith('0') && /^[6-9]/.test(digits.slice(1))) {
    return `+91${digits.slice(1)}`;
  }
  return null;
}

function parseCsv(csvText: string): PatientImportRow[] {
  const lines = csvText.trim().split(/\r?\n/);
  const rows: PatientImportRow[] = [];
  if (lines.length === 0) return rows;

  const headerLine = lines[0].toLowerCase();
  const hasHeader = headerLine.includes('name') || headerLine.includes('phone') || headerLine.includes('mobile');
  const startIdx = hasHeader ? 1 : 0;

  for (let i = startIdx; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const parts = line.split(',').map(s => s.trim().replace(/^["']|["']$/g, ''));
    if (parts.length >= 2 && parts[0] && parts[1]) {
      const normalizedPhone = normalizeIndianMobile(parts[1]) || (parts[1].startsWith('+') ? parts[1] : `+${parts[1]}`);
      const rawDob = parts[2]?.trim() || null;
      const rawGender = parts[3]?.trim().toLowerCase();
      const rawLang = parts[4]?.trim().toLowerCase();

      rows.push({
        name: parts[0],
        mobile_e164: normalizedPhone as any,
        date_of_birth: rawDob,
        gender: (['female', 'male', 'other', 'undisclosed'].includes(rawGender ?? '') ? rawGender : 'undisclosed') as any,
        language: (['en', 'te', 'hi'].includes(rawLang ?? '') ? rawLang : 'en') as any,
      });
    }
  }
  return rows;
}

function makeSignedSlipUrl(slipFilePath: string, visitId: string): { download_url: string; expires_at: string } {
  const ttlSeconds = 300; // 5-minute TTL
  const expiresAt = new Date(Date.now() + ttlSeconds * 1000).toISOString();
  const tokenPayload = `${visitId}:${expiresAt}`;
  const sig = Buffer.from(tokenPayload).toString('base64url');
  const downloadUrl = `https://storage.tabiyo.internal/${slipFilePath.replace(/^\/+/, '')}?expires=${encodeURIComponent(expiresAt)}&signature=${sig}`;
  return { download_url: downloadUrl, expires_at: expiresAt };
}

export function createClinicalService(config: AuthConfig): ClinicalService {
  async function call<T>(token: string, action: string, input: Record<string, unknown>, key?: string | null, schema?: z.ZodType<T>): Promise<T> {
    const { data, error } = await createUserClient(config, token).rpc('tabiyo_clinical', {
      p_action: action,
      p_input: input,
      p_request_id: key ?? null,
    });
    if (error) {
      if (Object.hasOwn(failures, error.message)) {
        const [status, message] = failures[error.message];
        throw new ApiError(error.message, status, message);
      }
      if (error.code === '42501') throw new ApiError('STAFF_FORBIDDEN', 403, 'Active clinic membership is required.');
      if (['22023', '22007', '22008', '22P02', '23502', '23514'].includes(error.code)) {
        throw new ApiError('INPUT_INVALID', 422, 'Check the request details and try again.');
      }
      throw new ApiError('DB_UNAVAILABLE', 503, 'Clinical operations are unavailable.');
    }
    if (!schema) return data as T;
    const result = schema.safeParse(data);
    if (!result.success) throw new ApiError('DB_UNAVAILABLE', 503, 'Clinical operations are unavailable.');
    return result.data;
  }

  return {
    async createPrescription(token, input, requestId) {
      const data = await call(
        token,
        'create_prescription',
        input as Record<string, unknown>,
        requestId,
        z.object({ prescription: prescriptionRecordSchema })
      );
      return data;
    },

    async getAdherence(token, patientId) {
      return call(token, 'get_adherence', { patient_id: patientId }, null, patientAdherenceSchema);
    },

    async createOrUpdateVisitSlip(token, visitIdOrAppointmentId, input) {
      const res = await call<any>(
        token,
        'save_visit_slip',
        { id: visitIdOrAppointmentId, ...input },
        null
      );
      const signed = makeSignedSlipUrl(res.slip_file_path, res.visit_id);
      return visitSlipUrlSchema.parse({
        visit_id: res.visit_id,
        download_url: signed.download_url,
        expires_at: signed.expires_at,
      });
    },

    async getVisitSlipUrl(token, visitIdOrAppointmentId, dob) {
      const res = await call<any>(
        token,
        'get_visit_slip',
        { id: visitIdOrAppointmentId, ...(dob ? { dob } : {}) },
        null
      );
      const signed = makeSignedSlipUrl(res.slip_file_path, res.visit_id);
      return visitSlipUrlSchema.parse({
        visit_id: res.visit_id,
        download_url: signed.download_url,
        expires_at: signed.expires_at,
      });
    },

    async listFaqs(token, options) {
      const res = await call(
        token,
        'list_faqs',
        (options ?? {}) as Record<string, unknown>,
        null,
        z.object({ clinic_id: z.string().uuid(), faqs: z.array(faqSchema) })
      );
      return res.faqs;
    },

    async upsertFaqs(token, faqs) {
      const arr = Array.isArray(faqs) ? faqs : [faqs];
      const res = await call(
        token,
        'upsert_faqs',
        { faqs: arr },
        null,
        z.object({ clinic_id: z.string().uuid(), faqs: z.array(faqSchema) })
      );
      return res.faqs;
    },

    async getReportsSummary(token, from, to) {
      return call(token, 'reports_summary', { from, to }, null, reportSummarySchema);
    },

    async importPatients(token, body) {
      let rawRows: PatientImportRow[] = [];
      if (typeof body === 'string') {
        rawRows = parseCsv(body);
      } else if (Array.isArray(body)) {
        rawRows = body;
      } else if (body.csv) {
        rawRows = parseCsv(body.csv);
      } else if (body.rows) {
        rawRows = body.rows;
      }

      const rows: PatientImportRow[] = [];
      const errors: Array<{ row: number; error: string }> = [];

      for (let i = 0; i < rawRows.length; i++) {
        const item = rawRows[i];
        let phone = String(item.mobile_e164 || '').trim();
        const normalized = normalizeIndianMobile(phone);
        if (normalized) {
          phone = normalized;
        } else if (!phone.startsWith('+91')) {
          errors.push({ row: i + 1, error: `Invalid Indian mobile number: ${item.mobile_e164}` });
          continue;
        }
        rows.push({
          ...item,
          mobile_e164: phone as any,
        });
      }

      const res = await call<{
        imported: number;
        duplicates: number;
        errors: any[];
        patients: PatientRecord[];
      }>(token, 'import_patients', { rows }, null);

      return {
        imported: res.imported,
        duplicates: res.duplicates,
        errors,
        patients: res.patients,
      };
    },

    async mergePatients(token, input) {
      return call(
        token,
        'merge_patients',
        input as Record<string, unknown>,
        null,
        z.object({
          success: z.boolean(),
          source_patient_id: z.string().uuid(),
          target_patient_id: z.string().uuid(),
          merged_at: z.string(),
        })
      );
    },
  };
}
