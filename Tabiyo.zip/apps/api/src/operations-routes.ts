import {z} from 'zod';
import type {FastifyInstance,FastifyRequest} from 'fastify';
import {ApiError,alertListQuerySchema,alertResolutionSchema,type StaffContext} from '@tabiyo/shared';
import type {OperationsService} from './operations.ts';

export function registerOperations(app:FastifyInstance,config:{
  staffContext:(request:FastifyRequest)=>Promise<{token:string;context:StaffContext}>;
  service?:OperationsService;
}) {
  const service=()=>{
    if(!config.service)throw new ApiError('SERVICE_UNAVAILABLE',503,'Staff operations are unavailable.');
    return config.service;
  };
  const assertScope=(clinic:string,expected:string)=>{
    if(clinic!==expected)throw new ApiError('DB_UNAVAILABLE',503,'Staff operations are unavailable.');
  };
  app.get('/api/v1/alerts',async request=>{
    const {token,context}=await config.staffContext(request);
    const {status,limit}=alertListQuerySchema.parse(request.query);
    const alerts=await service().alerts(token,status,limit);
    alerts.forEach(alert=>assertScope(alert.clinic_id,context.clinic.id));
    return {alerts};
  });
  app.get('/api/v1/deliveries/uncertain',async request=>{
    const {token,context}=await config.staffContext(request);
    const {limit}=z.object({limit:z.coerce.number().int().min(1).max(100).default(50)}).strict().parse(request.query);
    const deliveries=await service().uncertain(token,limit);
    deliveries.forEach(delivery=>assertScope(delivery.clinic_id,context.clinic.id));
    return {deliveries};
  });
  app.post('/api/v1/alerts/:id/resolve',async request=>{
    const {token,context}=await config.staffContext(request);
    const {id}=z.object({id:z.string().uuid()}).parse(request.params);
    const key=z.string().uuid().parse(request.headers['idempotency-key']);
    const {resolution_code}=z.object({resolution_code:alertResolutionSchema}).strict().parse(request.body);
    const result=await service().resolve(token,id,key,resolution_code);
    assertScope(result.clinic_id,context.clinic.id);
    if(result.id!==id)throw new ApiError('DB_UNAVAILABLE',503,'Staff operations are unavailable.');
    return result;
  });
  app.post('/api/v1/deliveries/:id/review',async request=>{
    const {token,context}=await config.staffContext(request);
    const {id}=z.object({id:z.string().uuid()}).parse(request.params);
    const key=z.string().uuid().parse(request.headers['idempotency-key']);
    const body=z.discriminatedUnion('action',[
      z.object({action:z.literal('reconcile_mock')}).strict(),
      z.object({action:z.literal('close_without_resend'),resolution_code:z.enum(['patient_contacted','no_action_required'])}).strict(),
    ]).parse(request.body);
    const result=await service().review(token,id,key,body.action,'resolution_code' in body?body.resolution_code:undefined);
    assertScope(result.clinic_id,context.clinic.id);
    if(result.id!==id)throw new ApiError('DB_UNAVAILABLE',503,'Staff operations are unavailable.');
    return result;
  });
}
