import { z } from 'zod';
import { buildApp } from './app.ts';
import { createAuthenticator } from './auth.ts';
import { createPatientService } from './patients.ts';
import { createOperationsService } from './operations.ts';
import { createAppointmentService } from './appointments.ts';
import { createAvailabilityService } from './availability.ts';
import { createQueueService } from './queue.ts';
import { createClinicalService } from './clinical.ts';

const configSchema = z.object({
  SUPABASE_URL: z.string().url().refine(value => {
    const url = new URL(value);
    return url.protocol === 'https:' || (url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname));
  }),
  SUPABASE_PUBLISHABLE_KEY: z.string().min(1),
  PORT: z.coerce.number().int().min(1).max(65535).default(3001),
  HOST: z.string().default('127.0.0.1'),
});
const parsed = configSchema.safeParse(process.env);
if (!parsed.success) {
  // Report names only, never input values or complete process.env.
  console.error('Missing or invalid API settings:', parsed.error.issues.map(issue => issue.path.join('.')).join(', '));
  process.exit(1);
}
const config = parsed.data;
const app = buildApp({
  authenticate: createAuthenticator({ url: config.SUPABASE_URL, publishableKey: config.SUPABASE_PUBLISHABLE_KEY }),
  patients: createPatientService({ url: config.SUPABASE_URL, publishableKey: config.SUPABASE_PUBLISHABLE_KEY }),
  operations: createOperationsService({ url: config.SUPABASE_URL, publishableKey: config.SUPABASE_PUBLISHABLE_KEY }),
  appointments: createAppointmentService({ url: config.SUPABASE_URL, publishableKey: config.SUPABASE_PUBLISHABLE_KEY }),
  availability: createAvailabilityService({url:config.SUPABASE_URL,publishableKey:config.SUPABASE_PUBLISHABLE_KEY}),
  queue:createQueueService({url:config.SUPABASE_URL,publishableKey:config.SUPABASE_PUBLISHABLE_KEY}),
  clinical: createClinicalService({url:config.SUPABASE_URL,publishableKey:config.SUPABASE_PUBLISHABLE_KEY}),
  logger: true,
});
for (const signal of ['SIGTERM', 'SIGINT'] as const) {
  process.once(signal, () => { void app.close(); });
}
try {
  await app.listen({ port: config.PORT, host: config.HOST });
} catch {
  console.error('API startup failed. Check the configured host and port.');
  process.exitCode = 1;
}
