import {z} from 'zod';
import type {FastifyInstance,FastifyRequest} from 'fastify';
import {ApiError,calendarDateSchema,appointmentCreateSchema,appointmentUpdateSchema,type StaffContext} from '@tabiyo/shared';
import type {AppointmentService} from './appointments.ts';
export function registerAppointments(app:FastifyInstance,config:{
  staffContext:(request:FastifyRequest)=>Promise<{token:string;context:StaffContext}>;service?:AppointmentService;
}){
  function service(){if(!config.service)throw new ApiError('SERVICE_UNAVAILABLE',503,'Appointments are unavailable.');return config.service;}
  function scoped(actual:string,expected:string){if(actual!==expected)throw new ApiError('DB_UNAVAILABLE',503,'Appointments are unavailable.');}
  app.get('/api/v1/doctors',async request=>{
    const {token,context}=await config.staffContext(request);z.object({}).strict().parse(request.query);
    const doctors=await service().doctors(token);doctors.forEach(doctor=>scoped(doctor.clinic_id,context.clinic.id));return {doctors};
  });
  app.get('/api/v1/doctors/:id/slots',async request=>{
    const {token}=await config.staffContext(request),{id}=z.object({id:z.string().uuid()}).parse(request.params);
    const query=z.object({date:calendarDateSchema,patient_id:z.string().uuid().optional()}).strict().parse(request.query);
    return {slots:await service().slots(token,id,query.date,query.patient_id)};
  });
  app.get('/api/v1/appointments',async request=>{
    const {token,context}=await config.staffContext(request),{date}=z.object({date:calendarDateSchema}).strict().parse(request.query);
    const appointments=await service().day(token,date);appointments.forEach(appointment=>scoped(appointment.clinic_id,context.clinic.id));return {appointments};
  });
  app.post('/api/v1/appointments',async(request,reply)=>{
    const {token,context}=await config.staffContext(request),input=appointmentCreateSchema.parse(request.body);
    const key=z.string().uuid().parse(request.headers['idempotency-key']);
    const result=await service().write(token,'create',input,key);scoped(result.appointment.clinic_id,context.clinic.id);
    if(result.appointment.patient_id!==input.patient_id)throw new ApiError('DB_UNAVAILABLE',503,'Appointments are unavailable.');
    return reply.status(result.replayed?200:201).send(result);
  });
  app.patch('/api/v1/appointments/:id',async request=>{
    const {token,context}=await config.staffContext(request),{id}=z.object({id:z.string().uuid()}).parse(request.params);
    const {action,...input}=appointmentUpdateSchema.parse(request.body),key=z.string().uuid().parse(request.headers['idempotency-key']);
    const result=await service().write(token,action,{id,...input},key);scoped(result.appointment.clinic_id,context.clinic.id);
    if(result.appointment.id!==id)throw new ApiError('DB_UNAVAILABLE',503,'Appointments are unavailable.');return result;
  });
}
