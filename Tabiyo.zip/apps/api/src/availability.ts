import {z} from 'zod';
import {ApiError,doctorAvailabilitySchema,doctorAvailabilityResultSchema,type DoctorAvailability,type DoctorAvailabilityWrite,type DoctorAvailabilityResult} from '@tabiyo/shared';
import {createUserClient,type AuthConfig} from './auth.ts';
export type AvailabilityService={read(token:string,id:string):Promise<DoctorAvailability>;
  write(token:string,id:string,input:DoctorAvailabilityWrite,key:string):Promise<DoctorAvailabilityResult>};
const failures:Record<string,[number,string]>={
  STAFF_FORBIDDEN:[403,'Active clinic membership is required.'],OPERATION_FORBIDDEN:[403,'Only clinic administrators can manage availability.'],
  DOCTOR_NOT_FOUND:[404,'Doctor not found.'],SCHEDULE_NOT_FOUND:[404,'Schedule not found.'],LEAVE_NOT_FOUND:[404,'Leave not found.'],
  AVAILABILITY_CHANGED:[409,'Availability changed. Reload it before saving.'],LEAVE_ALREADY_EXISTS:[409,'Leave already exists for these dates. Reload availability.'],
  IDEMPOTENCY_CONFLICT:[409,'This request key was already used for another operation.'],INPUT_INVALID:[422,'Check the schedule or leave details.'],
};
export function createAvailabilityService(config:AuthConfig):AvailabilityService{
  async function call<T>(token:string,action:string,input:Record<string,unknown>,key:string|null,schema:z.ZodType<T>):Promise<T>{
    const {data,error}=await createUserClient(config,token).rpc('tabiyo_doctor_management',{p_action:action,p_input:input,p_request_id:key});
    if(error){
      if(Object.hasOwn(failures,error.message)){const [status,message]=failures[error.message];throw new ApiError(error.message,status,message);}
      if(error.code==='42501')throw new ApiError('OPERATION_FORBIDDEN',403,'Only clinic administrators can manage availability.');
      if(['22023','22007','22008','22P02','23502','23514'].includes(error.code))throw new ApiError('INPUT_INVALID',422,'Check the schedule or leave details.');
      throw new ApiError('DB_UNAVAILABLE',503,'Doctor availability is unavailable.');
    }
    const result=schema.safeParse(data);if(!result.success)throw new ApiError('DB_UNAVAILABLE',503,'Doctor availability is unavailable.');return result.data;
  }
  return {read:(token,id)=>call(token,'read',{doctor_id:id},null,doctorAvailabilitySchema),
    write:(token,id,{action,...input},key)=>call(token,action,{doctor_id:id,...input},key,doctorAvailabilityResultSchema)};
}
