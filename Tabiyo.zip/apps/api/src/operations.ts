import {z} from 'zod';
import {ApiError,staffAlertSchema,uncertainDeliverySchema,alertResolveResultSchema,deliveryReviewResultSchema,
  type StaffAlert,type UncertainDelivery,type AlertResolution,type AlertResolveResult,type DeliveryReviewResult} from '@tabiyo/shared';
import {createUserClient,type AuthConfig} from './auth.ts';

export type OperationsService = {
  alerts(token:string,status:'open'|'resolved',limit:number):Promise<StaffAlert[]>;
  uncertain(token:string,limit:number):Promise<UncertainDelivery[]>;
  resolve(token:string,id:string,requestId:string,resolution:AlertResolution):Promise<AlertResolveResult>;
  review(token:string,id:string,requestId:string,action:'reconcile_mock'|'close_without_resend',resolution?:'patient_contacted'|'no_action_required'):Promise<DeliveryReviewResult>;
};
const failures:Record<string,[number,string]> = {
  STAFF_FORBIDDEN:[403,'Active clinic membership is required.'],
  OPERATION_FORBIDDEN:[403,'Your role cannot perform this operation.'],
  INPUT_INVALID:[422,'Check the request format and try again.'],
  ALERT_NOT_FOUND:[404,'Alert not found.'],
  DELIVERY_NOT_FOUND:[404,'Delivery not found.'],
  ALERT_ALREADY_RESOLVED:[409,'This alert has already been resolved.'],
  IDEMPOTENCY_CONFLICT:[409,'This request key was already used for another operation.'],
  DELIVERY_REVIEW_REQUIRED:[409,'An administrator must review this uncertain delivery first.'],
  AVAILABILITY_REVIEW_REQUIRED:[409,'Resolve the affected appointments before closing this availability alert.'],
  DELIVERY_NOT_UNCERTAIN:[409,'This delivery is no longer awaiting review.'],
  ACCEPTANCE_EVIDENCE_EXISTS:[409,'Acceptance evidence exists. Reconcile it before closing this delivery.'],
};
export function createOperationsService(config:AuthConfig):OperationsService {
  async function call<T>(token:string,action:string,input:Record<string,unknown>,schema:z.ZodType<T>):Promise<T> {
    const {data,error}=await createUserClient(config,token).rpc('tabiyo_staff_operations',{p_action:action,p_input:input});
    if(error){
      if(Object.hasOwn(failures,error.message)){
        const [status,message]=failures[error.message];throw new ApiError(error.message,status,message);
      }
      if(error.code==='42501')throw new ApiError('OPERATION_FORBIDDEN',403,'Your role cannot perform this operation.');
      if(['22023','22P02','23502','23514'].includes(error.code))throw new ApiError('INPUT_INVALID',422,'Check the request format and try again.');
      throw new ApiError('DB_UNAVAILABLE',503,'Staff operations are unavailable.');
    }
    const parsed=schema.safeParse(data);
    if(!parsed.success)throw new ApiError('DB_UNAVAILABLE',503,'Staff operations are unavailable.');
    return parsed.data;
  }
  return {
    async alerts(token,status,limit){return (await call(token,'alerts',{status,limit},z.object({alerts:z.array(staffAlertSchema)}))).alerts;},
    async uncertain(token,limit){return (await call(token,'uncertain',{limit},z.object({deliveries:z.array(uncertainDeliverySchema)}))).deliveries;},
    resolve:(token,id,requestId,resolution)=>call(token,'resolve_alert',{id,request_id:requestId,resolution_code:resolution},alertResolveResultSchema),
    review:(token,id,requestId,action,resolution)=>call(token,action,{id,request_id:requestId,...(resolution?{resolution_code:resolution}:{})},deliveryReviewResultSchema),
  };
}
