import type { Acceptance, DeliveryClaim, DeliveryEnvelope, DeliveryStore, FailureCode, Reconciliation } from './store.ts';

export class SendFailure extends Error {
  code: FailureCode;
  uncertain: boolean;
  constructor(code:FailureCode,uncertain=false) { super(code);this.name='SendFailure';this.code=code;this.uncertain=uncertain; }
}
export type Sender = {
  send(claim:DeliveryClaim,envelope:DeliveryEnvelope):Promise<Acceptance>;
  reconcile(claim:DeliveryClaim):Promise<Reconciliation>;
};
export type MockBehavior = 'ok'|'timeout'|'server_error'|'not_on_whatsapp'|'template_unavailable'|'accepted_then_timeout';
export class RecordingMockSender implements Sender {
  private store:DeliveryStore;
  private behavior:(envelope:DeliveryEnvelope)=>MockBehavior;
  constructor(store:DeliveryStore,behavior:(envelope:DeliveryEnvelope)=>MockBehavior=()=> 'ok') {
    this.store=store;this.behavior=behavior;
  }
  async send(claim:DeliveryClaim,envelope:DeliveryEnvelope):Promise<Acceptance> {
    const mode=this.behavior(envelope);
    if(mode==='timeout')throw new SendFailure('WA_ACCEPTANCE_UNKNOWN',true);
    if(mode==='server_error')throw new SendFailure('WA_SEND_FAILED');
    if(mode==='not_on_whatsapp')throw new SendFailure('WA_NOT_ON_WHATSAPP');
    if(mode==='template_unavailable')throw new SendFailure('WA_TEMPLATE_UNAVAILABLE');
    // Acceptance and a fresh policy check happen atomically in the mock's durable ledger.
    const result=await this.store.mockAccept(claim);
    if(mode==='accepted_then_timeout'&&result.action==='accepted')throw new SendFailure('WA_ACCEPTANCE_UNKNOWN',true);
    return result;
  }
  reconcile(claim:DeliveryClaim) { return this.store.lookup(claim); }
}
