import { createClient } from '@supabase/supabase-js';
import { z } from 'zod';

const claimSchema = z.object({
  id: z.string().uuid(), clinic_id: z.string().uuid(), worker_id: z.string().uuid(),
  lease_token: z.string().uuid(), recovering: z.boolean(),
});
export type DeliveryClaim = z.infer<typeof claimSchema>;
const envelopeSchema = z.object({
  action: z.literal('send'), id: z.string().uuid(), clinic_id: z.string().uuid(), patient_id: z.string().uuid(),
  kind: z.enum(['template','text','interactive','document']), purpose: z.string(), payload: z.record(z.unknown()),
  attempt: z.number().int().positive(), idempotency_key: z.string(),
});
export type DeliveryEnvelope = z.infer<typeof envelopeSchema>;
const policyResultSchema = z.object({action: z.enum(['skip','defer']), code: z.string()});
const preparationSchema = z.union([envelopeSchema,policyResultSchema,z.object({action:z.literal('reconcile')})]);
const acceptanceSchema = z.union([z.object({action:z.literal('accepted'),wa_message_id:z.string().min(1)}),policyResultSchema]);
const reconciliationSchema = z.object({state:z.enum(['accepted','absent','unknown']),wa_message_id:z.string().nullable().optional()});
const settledSchema = z.object({action:z.enum(['sent','queued','failed','uncertain']),code:z.string().optional(),wa_message_id:z.string().optional()});
export type DeliveryPreparation = z.infer<typeof preparationSchema>;
export type Acceptance = z.infer<typeof acceptanceSchema>;
export type Reconciliation = z.infer<typeof reconciliationSchema>;
export type FailureCode = 'WA_SEND_FAILED'|'WA_NOT_ON_WHATSAPP'|'WA_TEMPLATE_UNAVAILABLE'|'WA_ACCEPTANCE_UNKNOWN'|'MOCK_ABSENT';
export type Receipt = {clinic_id:string;wa_message_id:string;status:'sent'|'delivered'|'read'|'failed';occurred_at:string;error_code?:string};
export type DeliveryRpc = (action:string,input:Record<string,unknown>)=>Promise<unknown>;

export class DeliveryStoreError extends Error {
  code: string;
  constructor(code:string) { super(code); this.name='DeliveryStoreError'; this.code=code; }
}
export function createDeliveryStore(rpc:DeliveryRpc) {
  return {
    async claim(workerId:string) {return claimSchema.nullable().parse(await rpc('claim',{worker_id:workerId}));},
    async prepare(claim:DeliveryClaim) {
      const result=preparationSchema.parse(await rpc('prepare',{...claim}));
      if(result.action==='send'&&(result.id!==claim.id||result.clinic_id!==claim.clinic_id))throw new DeliveryStoreError('DELIVERY_SCOPE_MISMATCH');
      return result;
    },
    async mockAccept(claim:DeliveryClaim) {return acceptanceSchema.parse(await rpc('mock_accept',{...claim}));},
    async lookup(claim:DeliveryClaim) {return reconciliationSchema.parse(await rpc('lookup',{...claim}));},
    async complete(claim:DeliveryClaim,providerId:string) {return settledSchema.parse(await rpc('complete',{...claim,wa_message_id:providerId}));},
    async fail(claim:DeliveryClaim,code:FailureCode) {return settledSchema.parse(await rpc('failure',{...claim,code}));},
    async receipt(receipt:Receipt) {return z.object({matched:z.boolean(),duplicate:z.boolean(),status:z.string().optional()}).parse(await rpc('receipt',{...receipt}));},
  };
}
export type DeliveryStore = ReturnType<typeof createDeliveryStore>;

// Optional server-side adapter only. No caller starts it, and no live provider sender is implemented.
export function createServiceDeliveryStore(config:{url:string;serviceKey:string;mode:'mock';fetch?:typeof fetch}) {
  if(config.mode!=='mock'||!config.serviceKey)throw new DeliveryStoreError('MOCK_MODE_REQUIRED');
  const fetcher=config.fetch??globalThis.fetch;
  const client=createClient(config.url,config.serviceKey,{
    auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},
    global:{fetch:(input,init)=>fetcher(input,{...init,signal:AbortSignal.any([AbortSignal.timeout(5000),...(init?.signal?[init.signal]:[])])})},
  });
  return createDeliveryStore(async(action,input)=>{
    const {data,error}=await client.rpc('tabiyo_delivery',{p_action:action,p_input:input});
    if(error)throw new DeliveryStoreError(['LEASE_LOST','NOT_PREPARED','ACCEPTANCE_UNVERIFIED'].includes(error.message)?error.message:'DELIVERY_DB_UNAVAILABLE');
    return data;
  });
}
