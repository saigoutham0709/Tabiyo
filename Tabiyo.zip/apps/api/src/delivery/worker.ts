import { SendFailure, type Sender } from './mock-sender.ts';
import { DeliveryStoreError, type DeliveryClaim, type DeliveryStore } from './store.ts';

export class DeliveryWorker {
  private store:DeliveryStore;
  private sender:Sender;
  private workerId:string;
  constructor(store:DeliveryStore,sender:Sender,workerId=crypto.randomUUID()) {
    this.store=store;this.sender=sender;this.workerId=workerId;
  }
  private async reconcile(claim:DeliveryClaim) {
    let result;
    try { result=await this.sender.reconcile(claim); }
    catch { return this.store.fail(claim,'WA_ACCEPTANCE_UNKNOWN'); }
    if(result.state==='accepted'&&result.wa_message_id)return this.store.complete(claim,result.wa_message_id);
    if(result.state==='absent')return this.store.fail(claim,'MOCK_ABSENT');
    return this.store.fail(claim,'WA_ACCEPTANCE_UNKNOWN');
  }
  async runOnce() {
    const claim=await this.store.claim(this.workerId);
    if(!claim)return {action:'idle'};
    try {
      if(claim.recovering)return await this.reconcile(claim);
      const envelope=await this.store.prepare(claim);
      if(envelope.action==='reconcile')return await this.reconcile(claim);
      if(envelope.action!=='send')return envelope;
      let accepted;
      try { accepted=await this.sender.send(claim,envelope); }
      catch(error) {
        if(error instanceof DeliveryStoreError)throw error;
        if(error instanceof SendFailure&&!error.uncertain)return await this.store.fail(claim,error.code);
        return await this.reconcile(claim);
      }
      if(accepted.action!=='accepted')return accepted;
      return await this.store.complete(claim,accepted.wa_message_id);
    } catch(error) {
      if(error instanceof DeliveryStoreError&&error.code==='LEASE_LOST')return {action:'lease_lost'};
      // A database failure leaves the lease/evidence intact for recovery; never invent a send result.
      throw error;
    }
  }
}
