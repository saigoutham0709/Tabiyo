import { z } from 'zod';
import { ApiError, patientRecordSchema, patientWriteResultSchema, type PatientRecord, type PatientWriteInput, type PatientWriteResult } from '@tabiyo/shared';
import { createUserClient, type AuthConfig } from './auth.ts';

export type PatientService = {
  get(token:string,id:string):Promise<PatientRecord>;
  search(token: string, mobile: string): Promise<PatientRecord[]>;
  write(token: string, operation: 'create' | 'update' | 'consent', input: PatientWriteInput, requestId: string, patientId?: string): Promise<PatientWriteResult>;
};
function databaseFailure(error: { code: string; message: string }): never {
  const failures: Record<string, [number, string]> = {
    STAFF_FORBIDDEN: [403, 'Active clinic membership is required.'],
    PATIENT_NOT_FOUND: [404, 'Patient not found.'],
    IDEMPOTENCY_CONFLICT: [409, 'This request key was already used for another operation.'],
    REQUEST_REPLAY_EXPIRED: [409, 'This saved response expired. Search patient records before creating another request.'],
    CONTACT_CHANGE_REQUIRES_VERIFICATION: [409, 'Changing a mobile number requires contact verification.'],
    INPUT_INVALID: [422, 'Check the patient details and try again.'],
  };
  if (Object.hasOwn(failures, error.message)) {
    const [status, message] = failures[error.message];
    throw new ApiError(error.message, status, message);
  }
  if (error.code === '42501') throw new ApiError('STAFF_FORBIDDEN', 403, 'Active clinic membership is required.');
  if (['22007','22008','22023','23502','23514'].includes(error.code)) throw new ApiError('INPUT_INVALID', 422, 'Check the patient details and try again.');
  throw new ApiError('DB_UNAVAILABLE', 503, 'Patient records could not be accessed.');
}
export function createPatientService(config: AuthConfig): PatientService {
  return {
    async get(token,id){
      const {data,error}=await createUserClient(config,token).rpc('tabiyo_patient_get',{p_id:id});
      if(error)databaseFailure(error);
      const parsed=patientRecordSchema.safeParse(data);
      if(!parsed.success)throw new ApiError('DB_UNAVAILABLE',503,'Patient records could not be accessed.');
      return parsed.data;
    },
    async search(token, mobile) {
      const { data, error } = await createUserClient(config, token).rpc('tabiyo_patient_search', { p_mobile: mobile });
      if (error) databaseFailure(error);
      const parsed = z.array(patientRecordSchema).safeParse(data);
      if (!parsed.success) throw new ApiError('DB_UNAVAILABLE', 503, 'Patient records could not be accessed.');
      return parsed.data;
    },
    async write(token, operation, input, requestId, patientId) {
      const { data, error } = await createUserClient(config, token).rpc('tabiyo_patient_write', {
        p_operation: operation, p_input: input, p_request_id: requestId, p_patient_id: patientId ?? null,
      });
      if (error) databaseFailure(error);
      const parsed = patientWriteResultSchema.safeParse(data);
      if (!parsed.success) throw new ApiError('DB_UNAVAILABLE', 503, 'Patient records could not be accessed.');
      return parsed.data;
    },
  };
}
