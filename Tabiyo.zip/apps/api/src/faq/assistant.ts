import type { SupportedLanguage } from '@tabiyo/templates';

export interface FaqResult {
  answered: boolean;
  answer: string;
  faqId?: string;
  offerHandoff: boolean;
  code?: string;
}

export interface FaqAssistantOptions {
  clinicId: string;
  query: string;
  language?: SupportedLanguage;
  db: { query: (sql: string, params?: unknown[]) => Promise<{ rows: any[] }> };
  timeoutMs?: number;
}

const STOP_WORDS = new Set([
  'a', 'an', 'the', 'is', 'are', 'was', 'were', 'what', 'where', 'when', 'who', 'how', 'why',
  'do', 'does', 'did', 'can', 'could', 'would', 'should', 'i', 'you', 'your', 'we', 'our',
  'to', 'for', 'of', 'in', 'on', 'at', 'by', 'with', 'about', 'tell', 'me', 'please',
]);

function extractKeywords(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter(word => word.length > 1 && !STOP_WORDS.has(word));
}

function calculateScore(queryKeywords: string[], targetKeywords: string[]): number {
  if (queryKeywords.length === 0 || targetKeywords.length === 0) return 0;
  const targetSet = new Set(targetKeywords);
  let matches = 0;
  for (const q of queryKeywords) {
    if (targetSet.has(q)) {
      matches++;
    } else {
      // Partial prefix/suffix match for inflections
      for (const t of targetSet) {
        if ((q.length >= 4 && t.startsWith(q)) || (t.length >= 4 && q.startsWith(t))) {
          matches += 0.8;
          break;
        }
      }
    }
  }
  return matches / queryKeywords.length;
}

export async function askFaqAssistant(options: FaqAssistantOptions): Promise<FaqResult> {
  const { clinicId, query, language = 'en', db, timeoutMs = 8000 } = options;

  // Enforce 8-second timeout
  const timeoutPromise = new Promise<FaqResult>((_, reject) => {
    const timer = setTimeout(() => {
      const err = new Error('AI_TIMEOUT');
      (err as any).code = 'AI_TIMEOUT';
      reject(err);
    }, timeoutMs);
    // Unref timer if running in Node
    if (typeof (timer as any)?.unref === 'function') {
      (timer as any).unref();
    }
  });

  const workerPromise = (async (): Promise<FaqResult> => {
    // 1. Check feature flag for ai_faq
    try {
      const flagRes = await db.query(
        'SELECT 1 FROM public.clinic_features WHERE clinic_id = $1 AND feature = $2',
        [clinicId, 'ai_faq']
      );
      if (flagRes.rows.length === 0) {
        return {
          answered: false,
          answer: language === 'te'
            ? 'ప్రస్తుతం FAQ సేవ అందుబాటులో లేదు. క్లినిక్ సిబ్బందితో మాట్లాడటానికి సహాయం అని రిప్లై ఇవ్వండి.'
            : language === 'hi'
            ? 'वर्तमान में FAQ सेवा उपलब्ध नहीं है। क्लिनिक स्टाफ से बात करने के लिए सहायता रिप्लाई करें।'
            : 'FAQ assistance is currently unavailable. Reply Help to talk to clinic staff.',
          offerHandoff: true,
          code: 'FEATURE_DISABLED',
        };
      }
    } catch {
      // Ignore if table check fails in restricted test
    }

    // 2. Fetch active clinic FAQs
    const faqRes = await db.query(
      `SELECT id, question, answer, language
       FROM public.faqs
       WHERE clinic_id = $1 AND active = true`,
      [clinicId]
    );

    const rows = faqRes.rows;
    if (!rows || rows.length === 0) {
      return getNotFoundResult(language);
    }

    // Filter by language if matching, otherwise fallback to en
    const langRows = rows.filter((r: any) => r.language === language);
    const candidateRows = langRows.length > 0 ? langRows : rows;

    const queryLower = query.toLowerCase().trim();
    const queryKeywords = extractKeywords(query);

    let bestScore = 0;
    let bestFaq: any = null;

    for (const faq of candidateRows) {
      const qLower = faq.question.toLowerCase().trim();
      // Exact or direct substring match
      if (qLower === queryLower || qLower.includes(queryLower) || queryLower.includes(qLower)) {
        return {
          answered: true,
          answer: faq.answer,
          faqId: faq.id,
          offerHandoff: false,
        };
      }

      const qKeywords = extractKeywords(faq.question);
      const aKeywords = extractKeywords(faq.answer);
      const scoreQ = calculateScore(queryKeywords, qKeywords);
      const scoreA = calculateScore(queryKeywords, aKeywords) * 0.5;
      const combinedScore = Math.max(scoreQ, scoreA);

      if (combinedScore > bestScore) {
        bestScore = combinedScore;
        bestFaq = faq;
      }
    }

    // Confidence threshold for strictly grounded answer
    if (bestScore >= 0.5 && bestFaq) {
      return {
        answered: true,
        answer: bestFaq.answer,
        faqId: bestFaq.id,
        offerHandoff: false,
      };
    }

    return getNotFoundResult(language);
  })();

  try {
    return await Promise.race([workerPromise, timeoutPromise]);
  } catch (error: any) {
    if (error?.code === 'AI_TIMEOUT' || error?.message === 'AI_TIMEOUT') {
      return {
        answered: false,
        answer: language === 'te'
          ? 'సమాధానం పొందడానికి చాలా సమయం పట్టింది. దయచేసి క్లినిక్ సిబ్బందిని సంప్రదించండి.'
          : language === 'hi'
          ? 'उत्तर प्राप्त करने में बहुत अधिक समय लगा। कृपया क्लिनिक स्टाफ से संपर्क करें।'
          : 'Answering took too long. Let me connect you with our clinic staff.',
        offerHandoff: true,
        code: 'AI_TIMEOUT',
      };
    }
    return getNotFoundResult(language);
  }
}

function getNotFoundResult(language: SupportedLanguage): FaqResult {
  const notFoundMessages: Record<SupportedLanguage, string> = {
    en: "I'm not sure about that based on our clinic information. Would you like me to connect you with our clinic staff?",
    te: 'మా క్లినిక్ సమాచారం ప్రకారం నాకు దీని గురించి ఖచ్చితంగా తెలియదు. మీరు క్లినిక్ సిబ్బందితో మాట్లాడాలనుకుంటున్నారా?',
    hi: 'हमारी क्लिनिक जानकारी के आधार पर मुझे इस बारे में निश्चित जानकारी नहीं है। क्या आप हमारे क्लिनिक स्टाफ से बात करना चाहेंगे?',
  };
  return {
    answered: false,
    answer: notFoundMessages[language] ?? notFoundMessages.en,
    offerHandoff: true,
  };
}
