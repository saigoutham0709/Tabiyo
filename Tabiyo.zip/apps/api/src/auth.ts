import { createClient } from '@supabase/supabase-js';
import { ApiError, clinicSchema, staffSchema, type StaffContext } from '@tabiyo/shared';

export type Authenticate = (token: string) => Promise<StaffContext>;
export type AuthConfig = { url: string; publishableKey: string; fetch?: typeof fetch };

export function createUserClient(config: AuthConfig, token: string) {
    const fetcher = config.fetch ?? globalThis.fetch;
    return createClient(config.url, config.publishableKey, {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
      global: {
        headers: { Authorization: `Bearer ${token}` },
        fetch: (input, init) => fetcher(input, {
          ...init,
          signal: AbortSignal.any([
            AbortSignal.timeout(5000),
            ...(init?.signal ? [init.signal] : []),
          ]),
        }),
      },
    });
}

export function createAuthenticator(config: AuthConfig): Authenticate {
  return async (token) => {
    const client = createUserClient(config, token);

    // Verify with Auth; neither decoded claims nor user_metadata grant authority.
    const { data: identity, error: authError } = await client.auth.getUser(token);
    if (authError || !identity.user || identity.user.is_anonymous) {
      if (authError && authError.status && authError.status >= 500) {
        throw new ApiError('AUTH_UNAVAILABLE', 503, 'Sign-in verification is unavailable.');
      }
      throw new ApiError('AUTH_REQUIRED', 401, 'A valid staff session is required.');
    }

    // Use the caller's token so database RLS independently constrains this lookup.
    const { data: row, error: membershipError } = await client
      .from('staff_users')
      .select('id,clinic_id,name,role,active')
      .eq('id', identity.user.id)
      .eq('active', true)
      .maybeSingle();
    if (membershipError) throw new ApiError('DB_UNAVAILABLE', 503, 'Staff membership could not be checked.');
    if (!row) throw new ApiError('STAFF_FORBIDDEN', 403, 'Active clinic membership is required.');
    const parsed = staffSchema.safeParse(row);
    if (!parsed.success || parsed.data.id !== identity.user.id) {
      throw new ApiError('STAFF_FORBIDDEN', 403, 'Active clinic membership is required.');
    }

    const { data: clinicRow, error: clinicError } = await client
      .from('clinics')
      .select('id,name,timezone,default_language')
      .eq('id', parsed.data.clinic_id)
      .maybeSingle();
    if (clinicError) throw new ApiError('DB_UNAVAILABLE', 503, 'Clinic details could not be checked.');
    const clinic = clinicSchema.safeParse(clinicRow);
    if (!clinic.success || clinic.data.id !== parsed.data.clinic_id) {
      throw new ApiError('STAFF_FORBIDDEN', 403, 'Active clinic membership is required.');
    }
    return { staff: parsed.data, clinic: clinic.data };
  };
}
