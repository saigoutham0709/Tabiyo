import {createClient} from '@supabase/supabase-js';
import {z} from 'zod';

export type IntakeGroup={phone_number_id:string|null;payload:Record<string,unknown>};
const claimSchema=z.object({id:z.string().uuid(),worker_id:z.string().uuid(),lease_token:z.string().uuid()});
export type GatewayClaim=z.infer<typeof claimSchema>;
export type GatewayRpc=(action:string,input:Record<string,unknown>)=>Promise<unknown>;
export class GatewayStoreError extends Error {
  code:string;
  constructor(code:string){super(code);this.name='GatewayStoreError';this.code=code;}
}
export function createGatewayStore(rpc:GatewayRpc){
  return {
    async intake(groups:IntakeGroup[]){return z.object({accepted:z.number().int(),duplicates:z.number().int()}).parse(await rpc('intake',{groups}));},
    async badSignature(gatewayId:string){return z.object({failures:z.number().int(),alert:z.boolean()}).parse(await rpc('bad_signature',{gateway_id:gatewayId}));},
    async claim(workerId:string){return claimSchema.nullable().parse(await rpc('claim',{worker_id:workerId}));},
    async process(claim:GatewayClaim){return z.object({action:z.enum(['processed','queued','failed','quarantined']),code:z.string().optional()}).parse(await rpc('process',{...claim}));},
    async replay(id:string){return z.object({action:z.literal('queued')}).parse(await rpc('replay',{id}));},
    async cleanup(){return z.object({deleted:z.number().int().nonnegative()}).parse(await rpc('cleanup',{}));},
  };
}
export type GatewayStore=ReturnType<typeof createGatewayStore>;
export function createServiceGatewayStore(config:{url:string;serviceKey:string;mode:'local-test';fetch?:typeof fetch}){
  if(config.mode!=='local-test'||!config.serviceKey)throw new GatewayStoreError('GATEWAY_MODE_REQUIRED');
  const fetcher=config.fetch??globalThis.fetch;
  const client=createClient(config.url,config.serviceKey,{
    auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},
    global:{fetch:(input,init)=>fetcher(input,{...init,signal:AbortSignal.any([AbortSignal.timeout(5000),...(init?.signal?[init.signal]:[])])})},
  });
  return createGatewayStore(async(action,input)=>{
    const {data,error}=await client.rpc('tabiyo_gateway',{p_action:action,p_input:input});
    if(error)throw new GatewayStoreError(['LEASE_LOST','REPLAY_FORBIDDEN'].includes(error.message)?error.message:'GATEWAY_DB_UNAVAILABLE');
    return data;
  });
}
