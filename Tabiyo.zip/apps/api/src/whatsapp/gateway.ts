import {createHmac,timingSafeEqual} from 'node:crypto';
import type {FastifyInstance} from 'fastify';
import {z} from 'zod';
import {ApiError} from '@tabiyo/shared';
import type {GatewayStore,IntakeGroup} from './store.ts';

export type GatewayConfig={mode:'local-test';appSecret:string;verifyToken:string;gatewayId:string;store:GatewayStore};
const settingsSchema=z.object({mode:z.literal('local-test'),appSecret:z.string().min(16).max(512),verifyToken:z.string().min(16).max(512),gatewayId:z.string().min(1).max(100)});
const valueSchema=z.record(z.unknown());
const payloadSchema=z.object({object:z.literal('whatsapp_business_account'),entry:z.array(z.object({
  changes:z.array(z.object({field:z.string(),value:valueSchema})).min(1).max(100),
})).min(1).max(50)});

function equalSecret(actual:string,expected:string){
  const a=Buffer.from(actual),b=Buffer.from(expected);
  return a.length===b.length&&timingSafeEqual(a,b);
}
export function verifyGatewaySignature(body:Buffer,signature:unknown,secret:string){
  if(typeof signature!=='string'||!/^sha256=[0-9a-f]{64}$/.test(signature))return false;
  const expected=createHmac('sha256',secret).update(body).digest();
  return timingSafeEqual(expected,Buffer.from(signature.slice(7),'hex'));
}
export function splitWebhook(body:Buffer):IntakeGroup[]{
  let parsed;
  try{parsed=payloadSchema.parse(JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(body)));}
  catch{throw new ApiError('WEBHOOK_INVALID',400,'Invalid webhook envelope.');}
  const groups:IntakeGroup[]=[];
  for(const entry of parsed.entry)for(const change of entry.changes){
    const metadata=z.object({phone_number_id:z.string().regex(/^\d{1,80}$/)}).safeParse(change.value.metadata);
    groups.push({phone_number_id:change.field==='messages'&&metadata.success?metadata.data.phone_number_id:null,payload:change.value});
  }
  if(groups.length>100)throw new ApiError('WEBHOOK_INVALID',400,'Invalid webhook envelope.');
  return groups;
}
export function registerGateway(app:FastifyInstance,config?:GatewayConfig){
  if(config)settingsSchema.parse(config);
  app.register((scope,_options,done)=>{
    scope.removeAllContentTypeParsers();
    scope.addContentTypeParser('application/json',{parseAs:'buffer',bodyLimit:256*1024},(_request,body,complete)=>complete(null,body));
    scope.addHook('onRequest',async(_request,reply)=>{
      if(!config)return reply.status(503).send({error:{code:'WEBHOOK_DISABLED',message:'WhatsApp ingress is not connected.'}});
    });
    scope.get('/webhooks/whatsapp',async(request,reply)=>{
      if(!config)throw new ApiError('WEBHOOK_DISABLED',503,'WhatsApp ingress is not connected.');
      const query=z.object({'hub.mode':z.literal('subscribe'),'hub.verify_token':z.string().max(512),'hub.challenge':z.string().min(1).max(255)}).safeParse(request.query);
      if(!query.success||!equalSecret(query.data['hub.verify_token'],config.verifyToken))throw new ApiError('WA_VERIFY_FAILED',403,'Webhook verification failed.');
      return reply.type('text/plain').send(query.data['hub.challenge']);
    });
    scope.post('/webhooks/whatsapp',{bodyLimit:256*1024},async(request)=>{
      if(!config)throw new ApiError('WEBHOOK_DISABLED',503,'WhatsApp ingress is not connected.');
      if(!Buffer.isBuffer(request.body)||!verifyGatewaySignature(request.body,request.headers['x-hub-signature-256'],config.appSecret)){
        try{await config.store.badSignature(config.gatewayId);}catch{request.log.error({code:'WA_SIGNATURE_MONITOR_UNAVAILABLE',requestId:request.id},'Signature monitoring unavailable');}
        throw new ApiError('WA_BAD_SIGNATURE',401,'Invalid webhook signature.');
      }
      const groups=splitWebhook(request.body);
      try{await config.store.intake(groups);}catch{throw new ApiError('WEBHOOK_UNAVAILABLE',503,'Webhook storage is unavailable.');}
      // Intake is durable. A separate bounded worker processes messages/receipts after acknowledgment.
      return {received:true};
    });
    done();
  });
}
