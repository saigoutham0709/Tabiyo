import {GatewayStoreError,type GatewayStore} from './store.ts';

export class GatewayWorker {
  private store:GatewayStore;
  private workerId:string;
  constructor(store:GatewayStore,workerId=crypto.randomUUID()){this.store=store;this.workerId=workerId;}
  async runOnce(){
    const claim=await this.store.claim(this.workerId);
    if(!claim)return {action:'idle'};
    try{return await this.store.process(claim);}
    catch(error){if(error instanceof GatewayStoreError&&error.code==='LEASE_LOST')return {action:'lease_lost'};throw error;}
  }
}
