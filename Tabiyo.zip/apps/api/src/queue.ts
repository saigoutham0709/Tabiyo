import {z} from 'zod';
import {ApiError,queueStatusSchema,queueReadSchema,queueResultSchema,type QueueStatus,type QueueRead,type QueueWrite,type QueueResult} from '@tabiyo/shared';
import {createUserClient,type AuthConfig} from './auth.ts';
export type QueueService={status(token:string):Promise<QueueStatus>;read(token:string,doctorId:string,date?:string):Promise<QueueRead>;
  write(token:string,doctorId:string,input:QueueWrite,key:string):Promise<QueueResult>};
const errors:Record<string,[number,string]>={
  STAFF_FORBIDDEN:[403,'Active clinic membership is required.'],FEATURE_DISABLED:[409,'The walk-in queue is disabled for this clinic.'],
  DOCTOR_NOT_FOUND:[404,'Doctor not found.'],PATIENT_NOT_FOUND:[404,'Patient not found.'],TOKEN_NOT_FOUND:[404,'Token not found.'],
  DOCTOR_UNAVAILABLE:[409,'The doctor is unavailable under the current hours, break or leave settings.'],
  QUEUE_CHANGED:[409,'The queue changed. Reload before calling the next patient.'],QUEUE_EMPTY:[409,'No patients are waiting.'],
  QUEUE_STATE_INVALID:[409,'This token cannot make that transition. Reload the queue.'],QUEUE_FULL:[409,'This queue has reached its daily limit.'],
  PATIENT_ALREADY_QUEUED:[409,'This patient already has an active token today.'],IDEMPOTENCY_CONFLICT:[409,'This request key was already used for another operation.'],
  INPUT_INVALID:[422,'Check the queue request.'],
};
export function createQueueService(config:AuthConfig):QueueService{
  async function call<T>(token:string,action:string,input:Record<string,unknown>,key:string|null,schema:z.ZodType<T>):Promise<T>{
    const {data,error}=await createUserClient(config,token).rpc('tabiyo_queue',{p_action:action,p_input:input,p_request_id:key});
    if(error){
      if(Object.hasOwn(errors,error.message)){const [status,message]=errors[error.message];throw new ApiError(error.message,status,message);}
      if(error.code==='42501')throw new ApiError('STAFF_FORBIDDEN',403,'Active clinic membership is required.');
      if(['22023','22007','22008','22P02','23502','23514'].includes(error.code))throw new ApiError('INPUT_INVALID',422,'Check the queue request.');
      throw new ApiError('DB_UNAVAILABLE',503,'The walk-in queue is unavailable.');
    }
    const parsed=schema.safeParse(data);if(!parsed.success)throw new ApiError('DB_UNAVAILABLE',503,'The walk-in queue is unavailable.');return parsed.data;
  }
  return {status:token=>call(token,'status',{},null,queueStatusSchema),
    read:(token,doctorId,date)=>call(token,'read',{doctor_id:doctorId,...(date?{date}:{})},null,queueReadSchema),
    write:(token,doctorId,{action,...input},key)=>call(token,action,{doctor_id:doctorId,...input},key,queueResultSchema)};
}
