import {z} from 'zod';
import type {FastifyInstance,FastifyRequest} from 'fastify';
import {ApiError,doctorAvailabilityWriteSchema,type StaffContext} from '@tabiyo/shared';
import type {AvailabilityService} from './availability.ts';
export function registerAvailability(app:FastifyInstance,config:{staffContext:(request:FastifyRequest)=>Promise<{token:string;context:StaffContext}>;service?:AvailabilityService}){
  for(const method of ['GET','PATCH'] as const)app.route({method,url:'/api/v1/doctors/:id/availability',handler:async request=>{
    const {token,context}=await config.staffContext(request);
    if(!config.service)throw new ApiError('SERVICE_UNAVAILABLE',503,'Doctor availability is unavailable.');
    const {id}=z.object({id:z.string().uuid()}).parse(request.params);z.object({}).strict().parse(request.query);
    const result=method==='GET'?await config.service.read(token,id):await config.service.write(token,id,doctorAvailabilityWriteSchema.parse(request.body),z.string().uuid().parse(request.headers['idempotency-key']));
    if(result.clinic_id!==context.clinic.id||result.doctor_id!==id)throw new ApiError('DB_UNAVAILABLE',503,'Doctor availability is unavailable.');
    return result;
  }});
}
