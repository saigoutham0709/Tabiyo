import Fastify, { LogController, type FastifyRequest } from 'fastify';
import { z, ZodError } from 'zod';
import { ApiError, clinicSchema, staffSchema, mobileSchema, patientCreateSchema, patientUpdateSchema, staffConsentSchema } from '@tabiyo/shared';
import type { Authenticate } from './auth.ts';
import type { PatientService } from './patients.ts';
import {registerGateway,type GatewayConfig} from './whatsapp/gateway.ts';
import {registerOperations} from './operations-routes.ts';
import type {OperationsService} from './operations.ts';
import {registerAppointments} from './appointment-routes.ts';
import type {AppointmentService} from './appointments.ts';
import {registerAvailability} from './availability-routes.ts';
import type {AvailabilityService} from './availability.ts';
import {registerQueue} from './queue-routes.ts';
import type {QueueService} from './queue.ts';
import {registerClinical} from './clinical-routes.ts';
import type {ClinicalService} from './clinical.ts';

export function buildApp(options: { authenticate: Authenticate; patients?: PatientService; operations?: OperationsService; appointments?: AppointmentService; availability?:AvailabilityService; queue?:QueueService; clinical?: ClinicalService; webhook?: GatewayConfig; logger?: boolean }) {
  const app = Fastify({
    logger: options.logger ? {
      redact: ['req.headers.authorization', 'req.headers.cookie', 'res.headers.set-cookie'],
    } : false,
    // Request URLs/query strings can contain patient identifiers; no automatic request logging.
    logController: new LogController({ disableRequestLogging: true }),
    bodyLimit: 16 * 1024,
    requestTimeout: 10_000,
    trustProxy: false,
  });
  app.addHook('onRequest', async (_request, reply) => {
    reply.header('Cache-Control', 'no-store');
    reply.header('X-Content-Type-Options', 'nosniff');
  });
  app.setErrorHandler((error, request, reply) => {
    const known = error instanceof ApiError;
    const inputError = error instanceof ZodError;
    const transportStatus = error instanceof Error && 'statusCode' in error && typeof error.statusCode === 'number' ? error.statusCode : undefined;
    const transportError = !known && !inputError && [400,413,415].includes(transportStatus ?? 0);
    const status = known ? error.status : inputError ? 422 : transportError ? transportStatus! : 500;
    const code = known ? error.code : inputError || transportError ? 'INPUT_INVALID' : 'INTERNAL_ERROR';
    // Never log raw error objects, tokens, names, phone numbers, or request bodies.
    if (status >= 500) request.log.error({ code, requestId: request.id }, 'API request failed');
    void reply.status(status).send({
      error: { code, message: known ? error.message : inputError || transportError ? 'Check the request format and try again.' : 'The request could not be completed.', requestId: request.id,...(known&&error.details?{details:error.details}:{}) },
    });
  });
  app.setNotFoundHandler((request, reply) => {
    void reply.status(404).send({ error: { code: 'NOT_FOUND', message: 'Route not found.', requestId: request.id } });
  });

  app.get('/health', async () => ({ status: 'ok', service: 'tabiyo-api', scope: 'liveness' }));
  async function staffContext(request: FastifyRequest) {
    const authorization = request.headers.authorization;
    const match = authorization?.match(/^Bearer ([^\s,]+)$/i);
    if (!match || match[1].length > 8192) {
      throw new ApiError('AUTH_REQUIRED', 401, 'A valid staff session is required.');
    }
    const context = await options.authenticate(match[1]);
    const staff = staffSchema.safeParse(context.staff);
    const clinic = clinicSchema.safeParse(context.clinic);
    if (!staff.success || !clinic.success || staff.data.clinic_id !== clinic.data.id) {
      throw new ApiError('STAFF_FORBIDDEN', 403, 'Active clinic membership is required.');
    }
    return { token: match[1], context: { staff: staff.data, clinic: clinic.data } };
  }
  app.get('/api/v1/me', async (request) => {
    return (await staffContext(request)).context;
  });

  function patientService() {
    if (!options.patients) throw new ApiError('SERVICE_UNAVAILABLE', 503, 'Patient records are unavailable.');
    return options.patients;
  }
  app.get('/api/v1/patients', async request => {
    const { token, context } = await staffContext(request);
    const query = z.object({ mobile: mobileSchema }).strict().parse(request.query);
    const patients = await patientService().search(token, query.mobile);
    if (patients.some(patient => patient.clinic_id !== context.clinic.id)) throw new ApiError('DB_UNAVAILABLE', 503, 'Patient records could not be accessed.');
    return { patients };
  });
  app.get('/api/v1/patients/:id',async request=>{
    const {token,context}=await staffContext(request),{id}=z.object({id:z.string().uuid()}).parse(request.params);
    const patient=await patientService().get(token,id);
    if(patient.clinic_id!==context.clinic.id||patient.id!==id)throw new ApiError('DB_UNAVAILABLE',503,'Patient records could not be accessed.');
    return {patient};
  });
  app.post('/api/v1/patients', async (request, reply) => {
    const { token, context } = await staffContext(request);
    const body = patientCreateSchema.parse(request.body);
    const requestId = z.string().uuid().parse(request.headers['idempotency-key']);
    const result = await patientService().write(token, 'create', body, requestId);
    if (result.patient.clinic_id !== context.clinic.id) throw new ApiError('DB_UNAVAILABLE', 503, 'Patient records could not be accessed.');
    return reply.status(result.replayed ? 200 : 201).send(result);
  });
  for (const operation of ['update', 'consent'] as const) {
    app.route({
      method: operation === 'update' ? 'PATCH' : 'POST',
      url: '/api/v1/patients/:id' + (operation === 'consent' ? '/consents' : ''),
      handler: async request => {
        const { token, context } = await staffContext(request);
        const { id } = z.object({ id: z.string().uuid() }).parse(request.params);
        const requestId = z.string().uuid().parse(request.headers['idempotency-key']);
        const body = (operation === 'update' ? patientUpdateSchema : staffConsentSchema).parse(request.body);
        const result = await patientService().write(token, operation, body, requestId, id);
        if (result.patient.clinic_id !== context.clinic.id || result.patient.id !== id) throw new ApiError('DB_UNAVAILABLE', 503, 'Patient records could not be accessed.');
        return result;
      },
    });
  }

  // Optional local-test wiring only. The server entry point supplies no webhook configuration.
  registerOperations(app,{staffContext,service:options.operations});
  registerAppointments(app,{staffContext,service:options.appointments});
  registerAvailability(app,{staffContext,service:options.availability});
  registerQueue(app,{staffContext,service:options.queue});
  registerClinical(app,{staffContext,service:options.clinical});
  registerGateway(app,options.webhook);
  return app;
}
