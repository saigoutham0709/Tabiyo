const config={
  transpilePackages:['@tabiyo/shared'],
  poweredByHeader:false,
  logging:{incomingRequests:false},
  async headers(){return [{source:'/:path*',headers:[
    {key:'Cache-Control',value:'no-store'},
    {key:'X-Content-Type-Options',value:'nosniff'},
    {key:'Referrer-Policy',value:'no-referrer'},
    {key:'X-Frame-Options',value:'DENY'},
    {key:'Permissions-Policy',value:'camera=(), microphone=(), geolocation=()'},
  ]}];},
};
export default config;
