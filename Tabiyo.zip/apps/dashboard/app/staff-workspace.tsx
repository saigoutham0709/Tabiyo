'use client';
import {useEffect,useRef,useState,useSyncExternalStore,type FormEvent} from 'react';
import {z} from 'zod';
import Link from 'next/link';
import {patientCreateSchema,patientUpdateSchema,patientRecordSchema,patientWriteResultSchema,staffSchema,clinicSchema,staffAlertSchema,uncertainDeliverySchema,deliveryReviewResultSchema,doctorRecordSchema,queueStatusSchema,type StaffContext,type PatientRecord,type StaffAlert,type UncertainDelivery,type DoctorRecord} from '@tabiyo/shared';
import {AppointmentsPanel,BookingForm} from './appointments-panel';
import {AvailabilityPanel} from './availability-panel';
import {QueuePanel,QueueAddForm} from './queue-panel';
import {ClinicalPanel} from './clinical-panel';
import {FAQsPanel} from './faqs-panel';
import {ReportsPanel} from './reports-panel';
import {PatientImportModal} from './patient-import-modal';

const languages={en:'English',te:'Telugu',hi:'Hindi'};
type Tab='appointments'|'patients'|'alerts'|'deliveries'|'availability'|'queue'|'faqs'|'reports';
type Draft={name:string;mobile_e164:string;date_of_birth:string;gender:string;language:'en'|'te'|'hi'};
const emptyDraft:Draft={name:'',mobile_e164:'+91',date_of_birth:'',gender:'',language:'en'};
const contextSchema=z.object({staff:staffSchema,clinic:clinicSchema});
const onlineSubscribe=(callback:()=>void)=>{window.addEventListener('online',callback);window.addEventListener('offline',callback);return()=>{window.removeEventListener('online',callback);window.removeEventListener('offline',callback);};};

export function StaffWorkspace(){
  const [context,setContext]=useState<StaffContext|null>(null),[checking,setChecking]=useState(true);
  const [phone,setPhone]=useState('+91'),[otp,setOtp]=useState(''),[codeSent,setCodeSent]=useState(false);
  const [tab,setTab]=useState<Tab>('patients'),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false);
  const [mobile,setMobile]=useState('+91'),[patients,setPatients]=useState<PatientRecord[]>([]),[selected,setSelected]=useState<PatientRecord|null>(null);
  const [draft,setDraft]=useState<Draft>(emptyDraft),[creating,setCreating]=useState(false);
  const [version,setVersion]=useState(''),[consent,setConsent]=useState<'granted'|'revoked'>('revoked'),[confirmed,setConfirmed]=useState(false);
  const [alerts,setAlerts]=useState<StaffAlert[]>([]),[deliveries,setDeliveries]=useState<UncertainDelivery[]>([]);
  const [doctors,setDoctors]=useState<DoctorRecord[]>([]);
  const [availabilityDoctor,setAvailabilityDoctor]=useState('');
  const [queueEnabled,setQueueEnabled]=useState(false),[queueDoctor,setQueueDoctor]=useState('');
  const [showImportModal,setShowImportModal]=useState(false);
  const pending=useRef<{fingerprint:string;key:string}|null>(null);
  const online=useSyncExternalStore(onlineSubscribe,()=>navigator.onLine,()=>true);
  const lastActivity=useRef(0);
  const sessionGeneration=useRef(0);

  function clearPrivateState(){setPatients([]);setSelected(null);setAlerts([]);setDeliveries([]);setDoctors([]);setAvailabilityDoctor('');setQueueDoctor('');setQueueEnabled(false);setDraft(emptyDraft);setVersion('');setConfirmed(false);setCreating(false);pending.current=null;}
  async function request(path:string,method='GET',body?:unknown,key?:string){
    const generation=sessionGeneration.current;
    const response=await fetch('/api/staff/'+path,{method,credentials:'same-origin',cache:'no-store',headers:{
      ...(body!==undefined?{'content-type':'application/json'}:{}),...(key?{'idempotency-key':key}:{}),
    },...(body!==undefined?{body:JSON.stringify(body)}:{})});
    const result=await response.json();
    if(generation!==sessionGeneration.current)throw new Error('Your staff session changed. Retry in the current session.');
    if(response.status===401){sessionGeneration.current++;setContext(null);clearPrivateState();setCodeSent(false);setOtp('');}
    if(!response.ok){const failure=z.object({error:z.object({message:z.string(),code:z.string().optional()})}).safeParse(result);
      if(failure.success&&failure.data.error.code==='FEATURE_DISABLED'){setQueueEnabled(false);setTab('patients');}
      throw new Error(failure.success?failure.data.error.message:'The request could not be completed.');}
    return result;
  }
  async function perform(action:()=>Promise<void>){
    if(!online){setNotice('You are offline. Reconnect before saving.');return;}
    setBusy(true);setNotice('');
    try{await action();}catch(error){setNotice(error instanceof Error?error.message:'The request could not be completed.');}
    finally{setBusy(false);}
  }
  async function write(path:string,method:string,body:unknown){
    const fingerprint=JSON.stringify([path,method,body]);
    const createKey='tabiyo.pending-create.'+context!.staff.id;
    if(!pending.current||pending.current.fingerprint!==fingerprint){
      // Persist only a random request ID. Never store patient bodies or bearer tokens in the browser.
      const previous=path==='patients'?sessionStorage.getItem(createKey):null;
      pending.current={fingerprint,key:previous??crypto.randomUUID()};
      if(path==='patients')sessionStorage.setItem(createKey,pending.current.key);
    }
    const requestKey=pending.current.key;
    try{
      const result=await request(path,method,body,requestKey);
      if(pending.current?.key===requestKey)pending.current=null;
      if(path==='patients')sessionStorage.removeItem(createKey);return result;
    }catch(error){
      if(path==='patients')throw new Error((error instanceof Error?error.message:'Save could not be confirmed.')+' Retry unchanged or search existing records before starting another create request.');
      throw error;
    }
  }
  useEffect(()=>{
    if(!context)return;
    let cancelled=false;
    const generation=sessionGeneration.current;
    fetch('/api/staff/queue/status',{cache:'no-store',credentials:'same-origin'}).then(async response=>{
      if(response.ok){const result=queueStatusSchema.parse(await response.json());if(!cancelled&&generation===sessionGeneration.current)setQueueEnabled(result.clinic_id===context.clinic.id&&result.enabled);}
    }).catch(()=>{});
    return()=>{cancelled=true;};
  },[context]);
  useEffect(()=>{
    let cancelled=false;
    fetch('/api/staff/me',{cache:'no-store',credentials:'same-origin'}).then(async response=>{
      if(response.ok){const result=contextSchema.parse(await response.json());if(!cancelled)setContext(result);}
    }).catch(()=>{}).finally(()=>{if(!cancelled)setChecking(false);});
    return()=>{cancelled=true;};
  },[]);
  useEffect(()=>{
    if(!context)return;
    let cancelled=false;
    const activity=()=>{
      if(document.visibilityState!=='visible'||Date.now()-lastActivity.current<60_000)return;
      lastActivity.current=Date.now();
      const generation=sessionGeneration.current;
      fetch('/api/staff/me',{cache:'no-store',credentials:'same-origin'}).then(async response=>{
        if(!cancelled&&generation===sessionGeneration.current&&response.status===401){sessionGeneration.current++;setContext(null);setPatients([]);setSelected(null);setAlerts([]);setDeliveries([]);setDraft(emptyDraft);setNotice('Your session ended. Sign in again.');}
        else if(response.ok){
          const fresh=contextSchema.parse(await response.json());
          if(!cancelled&&generation===sessionGeneration.current&&(fresh.staff.id!==context.staff.id||fresh.staff.role!==context.staff.role||fresh.clinic.id!==context.clinic.id)){
            sessionGeneration.current++;setPatients([]);setSelected(null);setAlerts([]);setDeliveries([]);setDoctors([]);setDraft(emptyDraft);pending.current=null;setTab('patients');setContext(fresh);
          }
        }
      }).catch(()=>{});
      fetch('/api/staff/queue/status',{cache:'no-store',credentials:'same-origin'}).then(async response=>{
        if(response.ok){const result=queueStatusSchema.parse(await response.json());if(!cancelled&&generation===sessionGeneration.current){
          const enabled=result.clinic_id===context.clinic.id&&result.enabled;setQueueEnabled(enabled);if(!enabled)setTab(current=>current==='queue'?'patients':current);
        }}
      }).catch(()=>{});
    };
    window.addEventListener('pointerdown',activity);window.addEventListener('keydown',activity);
    return()=>{cancelled=true;window.removeEventListener('pointerdown',activity);window.removeEventListener('keydown',activity);};
  },[context]);
  async function openTab(next:Tab){
    setTab(next);setSelected(null);setCreating(false);
    await perform(async()=>{
      if(next==='alerts')setAlerts(z.object({alerts:z.array(staffAlertSchema)}).parse(await request('alerts')).alerts);
      if(next==='deliveries')setDeliveries(z.object({deliveries:z.array(uncertainDeliverySchema)}).parse(await request('deliveries/uncertain')).deliveries);
    });
  }
  function selectPatient(patient:PatientRecord){
    setSelected(patient);setCreating(false);setConfirmed(false);setVersion('');pending.current=null;
    setDraft({name:patient.name,mobile_e164:patient.mobile_e164,date_of_birth:patient.date_of_birth??'',gender:patient.gender??'',language:patient.language});
    void request('doctors').then(value=>setDoctors(z.object({doctors:z.array(doctorRecordSchema)}).parse(value).doctors)).catch(()=>setNotice('Doctor availability could not be loaded. Reopen this patient to retry.'));
  }
  async function openPatient(id:string){
    await perform(async()=>{
      const {patient}=z.object({patient:patientRecordSchema}).parse(await request('patients/'+id));
      setTab('patients');setPatients([patient]);setMobile(patient.mobile_e164);selectPatient(patient);
    });
  }
  async function savePatient(event:FormEvent){
    event.preventDefault();await perform(async()=>{
      const input={name:draft.name,...(creating?{mobile_e164:draft.mobile_e164}:{}),date_of_birth:draft.date_of_birth||null,
        gender:draft.gender||null,language:draft.language};
      const parsed=(creating?patientCreateSchema:patientUpdateSchema).safeParse(input);
      if(!parsed.success)throw new Error('Check the patient name, mobile number, birth date and language.');
      const result=patientWriteResultSchema.parse(await write(creating?'patients':`patients/${selected!.id}`,creating?'POST':'PATCH',parsed.data));
      setMobile(result.patient.mobile_e164);setPatients(current=>[...current.filter(patient=>patient.id!==result.patient.id),result.patient]);
      selectPatient(result.patient);setNotice('Patient record saved.');
    });
  }
  if(checking)return <main className="sign-in"><p role="status">Checking your staff session…</p></main>;
  if(!context)return <main className="sign-in"><section className="login-card">
    <p className="eyebrow">TABIYO · CLINIC WORKSPACE</p><h1>Care starts with<br/>a clear day.</h1>
    <p className="muted">Sign in with your registered staff mobile number.</p>
    {!online&&<p role="alert" className="notice">You are offline. Reconnect to sign in.</p>}
    <form onSubmit={event=>{event.preventDefault();void perform(async()=>{
      if(codeSent){const result=contextSchema.parse(await request('session/verify','POST',{phone,code:otp}));sessionGeneration.current++;clearPrivateState();setContext(result);setTab('patients');setOtp('');setNotice('');}
      else{const result=z.object({message:z.string()}).parse(await request('session/request','POST',{phone}));setCodeSent(true);setNotice(result.message);}
    });}}>
      <label>Staff mobile number<input type="tel" autoComplete="tel" value={phone} onChange={event=>setPhone(event.target.value)} readOnly={codeSent} required pattern="\+91[6-9][0-9]{9}" placeholder="+91…"/></label>
      {codeSent&&<label>Sign-in code<input inputMode="numeric" autoComplete="one-time-code" value={otp} onChange={event=>setOtp(event.target.value)} required pattern="[0-9]{6}" maxLength={6}/></label>}
      <button className="primary" disabled={busy||!online}>{busy?'Please wait…':codeSent?'Open workspace':'Send sign-in code'}</button>
      {codeSent&&<button type="button" className="text-button" onClick={()=>{setCodeSent(false);setOtp('');}}>Use another number</button>}
    </form><p role="status" aria-live="polite" className="notice">{notice}</p>
    <small>For authorized clinic staff. Sign-in expires after 30 minutes without activity.</small>
  </section></main>;
  const canOperate=context.staff.role!=='doctor';
  return <div className="workspace">
    <aside><Link className="brand" href="/">Tabiyo<span>Care, every day.</span></Link><p className="eyebrow">WORKSPACE</p>
      <nav aria-label="Clinic sections"><button aria-current={tab==='appointments'?'page':undefined} onClick={()=>void openTab('appointments')}>Appointments</button><button aria-current={tab==='patients'?'page':undefined} onClick={()=>void openTab('patients')}>Patient records</button>
        {canOperate&&<button aria-current={tab==='alerts'?'page':undefined} onClick={()=>void openTab('alerts')}>Staff alerts</button>}
        {context.staff.role==='admin'&&<button aria-current={tab==='deliveries'?'page':undefined} onClick={()=>void openTab('deliveries')}>Delivery review</button>}
        {context.staff.role==='admin'&&<button aria-current={tab==='availability'?'page':undefined} onClick={()=>void openTab('availability')}>Doctor availability</button>}
        {queueEnabled&&<button aria-current={tab==='queue'?'page':undefined} onClick={()=>void openTab('queue')}>Walk-in queue</button>}
        <button aria-current={tab==='faqs'?'page':undefined} onClick={()=>void openTab('faqs')}>Clinic FAQs</button>
        <button aria-current={tab==='reports'?'page':undefined} onClick={()=>void openTab('reports')}>Reports & Metrics</button>
      </nav><div className="staff-card"><strong>{context.staff.name}</strong><span>{context.staff.role.replace('_',' ')}</span>
        <button className="text-button" disabled={busy} onClick={()=>void perform(async()=>{await request('session/logout','POST',{});sessionGeneration.current++;clearPrivateState();setContext(null);setCodeSent(false);})}>Sign out</button></div>
    </aside>
    <main><header><div><p className="eyebrow">{context.clinic.name}</p><h1>{tab==='appointments'?'Appointments':tab==='patients'?'Patient records':tab==='alerts'?'Staff alerts':tab==='availability'?'Doctor availability':tab==='queue'?'Walk-in queue':tab==='faqs'?'Clinic FAQs':tab==='reports'?'Reports & Metrics':'Delivery review'}</h1></div><span className="badge">{languages[context.clinic.default_language]}</span></header>
      {!online&&<p role="alert" className="notice warning">Offline. Changes cannot be saved until you reconnect.</p>}
      <p className="notice" role="status" aria-live="polite">{busy?'Working…':notice}</p>
      {tab==='appointments'&&<AppointmentsPanel request={request} write={write}/>}
      {tab==='availability'&&context.staff.role==='admin'&&<AvailabilityPanel key={availabilityDoctor} initialDoctor={availabilityDoctor} request={request} write={write} onAppointments={()=>void openTab('appointments')}/>}
      {tab==='queue'&&queueEnabled&&<QueuePanel key={queueDoctor} initialDoctor={queueDoctor} request={request} write={write}/>}
      {tab==='patients'&&<>
        <section className="panel"><h2>Find a patient</h2><p className="muted">Family members may share a mobile number. Choose the correct patient before making changes.</p>
          <form className="search-row" onSubmit={event=>{event.preventDefault();void perform(async()=>{
            const result=z.object({patients:z.array(patientRecordSchema)}).parse(await request('patients/search','POST',{mobile}));setPatients(result.patients);setSelected(null);setCreating(false);
            if(!result.patients.length)setNotice('No matching patients. Check the number or create a record.');
          });}}><label>Mobile number<input type="tel" value={mobile} onChange={event=>setMobile(event.target.value)} required pattern="\+91[6-9][0-9]{9}" placeholder="+91…"/></label><button className="primary" disabled={busy||!online}>Search patients</button>
          <button type="button" className="secondary" disabled={busy} onClick={()=>{setSelected(null);setCreating(true);setDraft({...emptyDraft,mobile_e164:mobile});pending.current=null;}}>New patient</button>
          <button type="button" className="secondary" disabled={busy} onClick={()=>setShowImportModal(true)}>Import CSV / Merge</button></form>
        </section>
        {patients.length>0&&<section className="panel"><h2>{patients.length} matching patient{patients.length===1?'':'s'}</h2><div className="patient-options">
          {patients.map(patient=><button className={selected?.id===patient.id?'patient selected':'patient'} key={patient.id} disabled={busy} onClick={()=>selectPatient(patient)} aria-pressed={selected?.id===patient.id}>
            <strong>{patient.name}</strong><span>{patient.date_of_birth??'Birth date not recorded'} · {languages[patient.language]}</span><small>{patient.opted_out?'WhatsApp stopped':patient.whatsapp_status==='ok'?'WhatsApp available':'WhatsApp status unverified'}</small>
          </button>)}
        </div></section>}
        {(selected||creating)&&<section className="panel"><h2>{creating?'New patient':'Patient details'}</h2>
          <form onSubmit={event=>void savePatient(event)}><div className="form-grid">
            <label>Patient name<input value={draft.name} onChange={event=>setDraft({...draft,name:event.target.value})} required maxLength={200}/></label>
            <label>Mobile number<input type="tel" value={draft.mobile_e164} onChange={event=>setDraft({...draft,mobile_e164:event.target.value})} readOnly={!creating} required pattern="\+91[6-9][0-9]{9}"/>{!creating&&<small>Contact changes require a separate verification workflow.</small>}</label>
            <label>Date of birth<input type="date" value={draft.date_of_birth} onChange={event=>setDraft({...draft,date_of_birth:event.target.value})}/></label>
            <label>Gender<select value={draft.gender} onChange={event=>setDraft({...draft,gender:event.target.value})}><option value="">Not recorded</option><option value="female">Female</option><option value="male">Male</option><option value="other">Other</option><option value="undisclosed">Undisclosed</option></select></label>
            <label>Preferred language<select value={draft.language} onChange={event=>setDraft({...draft,language:event.target.value as Draft['language']})}>{Object.entries(languages).map(([key,label])=><option key={key} value={key}>{label}</option>)}</select></label>
          </div><button className="primary" disabled={busy||!online}>Save patient</button>
          {creating&&<button type="button" className="text-button" disabled={busy} onClick={()=>{
            if(window.confirm('Start a new create request only after checking existing patient records. An earlier save may have completed. Have you checked?')){
              sessionStorage.removeItem('tabiyo.pending-create.'+context.staff.id);pending.current=null;setNotice('A new request key will be used. Check all patient details before saving.');
            }
          }}>I checked records; reset an earlier create request</button>}</form>
          {selected&&<div className="consent"><h3>Record a consent decision</h3><p className="muted">Record only a decision obtained from this patient. A shared number does not grant family-wide consent.</p>
            <form onSubmit={event=>{event.preventDefault();void perform(async()=>{
              if(!confirmed)throw new Error('Confirm that you recorded the patient’s decision.');
              const result=patientWriteResultSchema.parse(await write(`patients/${selected.id}/consents`,'POST',{status:consent,version,channel:'dashboard'}));
              selectPatient(result.patient);setPatients(current=>current.map(patient=>patient.id===result.patient.id?result.patient:patient));setNotice('Consent decision recorded.');
            });}}><div className="form-grid"><label>Consent notice version<input value={version} onChange={event=>setVersion(event.target.value)} required maxLength={100}/></label>
              <label>Patient decision<select value={consent} onChange={event=>setConsent(event.target.value as typeof consent)}><option value="revoked">Withdraw permission</option><option value="granted">Grant permission</option></select></label></div>
              <label className="checkbox"><input type="checkbox" checked={confirmed} onChange={event=>setConfirmed(event.target.checked)} required/>I recorded this patient’s decision for the stated notice version.</label>
              <button className="secondary" disabled={busy||!online}>Record decision</button>
            </form></div>}
          {selected&&<BookingForm key={selected.id} patientId={selected.id} doctors={doctors} request={request} write={write} onSaved={()=>setNotice('Appointment saved. Open Appointments to view the clinic day.')}/>}
          {selected&&queueEnabled&&<QueueAddForm key={'queue-'+selected.id} patientId={selected.id} doctors={doctors} write={write} onOpen={id=>{setQueueDoctor(id);void openTab('queue');}}/>}
          {selected&&<ClinicalPanel key={'clinical-'+selected.id} patientId={selected.id} isDoctor={context.staff.role==='doctor'||context.staff.role==='admin'} request={request} write={write} onNotice={setNotice}/>}
          </section>}
      </>}
      {tab==='faqs'&&<FAQsPanel isAdmin={context.staff.role==='admin'} request={request} write={write} onNotice={setNotice}/>}
      {tab==='reports'&&<ReportsPanel request={request} onNotice={setNotice}/>}
      {tab==='alerts'&&<section className="panel"><div className="section-head"><div><h2>Open alerts</h2><p className="muted">Review the issue before recording a resolution.</p></div><button className="secondary" disabled={busy} onClick={()=>void openTab('alerts')}>Refresh</button></div>
        {!alerts.length&&<p>No open alerts.</p>}{alerts.map(alert=><article className="record" key={alert.id}><div><h3>{alert.code.replaceAll('_',' ')}</h3><p>{new Date(alert.created_at).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'})}</p></div>
          {alert.patient_id&&<button className="text-button" disabled={busy} onClick={()=>void openPatient(alert.patient_id!)}>Open patient record</button>}
          {context.staff.role==='admin'&&alert.code==='DOCTOR_AVAILABILITY_REVIEW'&&alert.context?.doctor_id&&<button className="text-button" disabled={busy} onClick={()=>{setAvailabilityDoctor(alert.context!.doctor_id!);void openTab('availability');}}>Review doctor availability</button>}
          {queueEnabled&&alert.code==='QUEUE_NOTICE_REVIEW'&&alert.context?.doctor_id&&<button className="text-button" disabled={busy} onClick={()=>{setQueueDoctor(alert.context!.doctor_id!);void openTab('queue');}}>Open walk-in queue</button>}
          <form className="inline" onSubmit={event=>{event.preventDefault();const data=new FormData(event.currentTarget);void perform(async()=>{
            await write(`alerts/${alert.id}/resolve`,'POST',{resolution_code:String(data.get('resolution_code'))});setAlerts(current=>current.filter(item=>item.id!==alert.id));setNotice('Alert resolved.');
          });}}><label>Resolution<select name="resolution_code" required><option value="investigated">Investigated</option><option value="patient_contacted">Patient contacted</option><option value="configuration_fixed">Configuration fixed</option><option value="no_action_required">No action required</option></select></label><button className="secondary" disabled={busy||!online}>Resolve alert</button></form>
        </article>)}
      </section>}
      {tab==='deliveries'&&<section className="panel"><div className="section-head"><div><h2>Uncertain delivery</h2><p className="muted">Reconcile existing acceptance evidence. These actions never send another message.</p></div><button className="secondary" disabled={busy} onClick={()=>void openTab('deliveries')}>Refresh</button></div>
        {!deliveries.length&&<p>No deliveries awaiting review.</p>}{deliveries.map(delivery=><article className="record" key={delivery.id}><div><h3>{delivery.purpose.replaceAll('_',' ')}</h3><p>{delivery.attempts} attempt(s) · {delivery.has_mock_evidence?'Acceptance evidence available':'Acceptance not established'}</p><small>Reference: {delivery.id}</small></div>
          <button className="text-button" disabled={busy} onClick={()=>void openPatient(delivery.patient_id)}>Open patient record</button>
          <div className="review-actions"><button className="secondary" disabled={busy||!online} onClick={()=>void perform(async()=>{
            const result=deliveryReviewResultSchema.parse(await write(`deliveries/${delivery.id}/review`,'POST',{action:'reconcile_mock'}));
            if(result.status!=='uncertain')setDeliveries(current=>current.filter(item=>item.id!==delivery.id));
            setNotice(result.status==='uncertain'?'Acceptance is still unknown. Delivery remains held.':'Acceptance reconciled. No additional message was sent.');
          })}>Reconcile evidence</button>
          <form onSubmit={event=>{event.preventDefault();const data=new FormData(event.currentTarget);void perform(async()=>{
            const result=deliveryReviewResultSchema.parse(await write(`deliveries/${delivery.id}/review`,'POST',{action:'close_without_resend',resolution_code:String(data.get('resolution_code'))}));
            if(result.status==='failed')setDeliveries(current=>current.filter(item=>item.id!==delivery.id));setNotice('Closed without resending.');
          });}}><label>Closure reason<select name="resolution_code"><option value="patient_contacted">Patient contacted</option><option value="no_action_required">No resend required</option></select></label>
          <label className="checkbox"><input type="checkbox" required/>I reviewed this case and want to close it without resending.</label><button className="danger" disabled={busy||!online||delivery.has_mock_evidence}>Close without resend</button></form></div>
        </article>)}
      </section>}
    </main>
    {showImportModal&&<PatientImportModal existingPatients={patients} write={write} onClose={()=>setShowImportModal(false)} onSuccess={()=>{setShowImportModal(false);setNotice('Patient import or merge completed.');}} onNotice={setNotice}/>}
  </div>;
}
