'use client';
import {useState} from 'react';
import {z} from 'zod';
import {doctorRecordSchema,doctorAvailabilitySchema,doctorAvailabilityResultSchema,type DoctorAvailability,type DoctorRecord} from '@tabiyo/shared';
const weekdays=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
type Request=(path:string,method?:string,body?:unknown,key?:string)=>Promise<unknown>;
type Write=(path:string,method:string,body:unknown)=>Promise<unknown>;
export function AvailabilityPanel({request,write,initialDoctor='',onAppointments}:{request:Request;write:Write;initialDoctor?:string;onAppointments:()=>void}){
  const [doctors,setDoctors]=useState<DoctorRecord[]>([]),[doctor,setDoctor]=useState(initialDoctor),[data,setData]=useState<DoctorAvailability|null>(null);
  const [weekday,setWeekday]=useState(1),[start,setStart]=useState('09:00'),[end,setEnd]=useState('17:00'),[hasBreak,setHasBreak]=useState(false),[breakStart,setBreakStart]=useState('13:00'),[breakEnd,setBreakEnd]=useState('14:00');
  const [from,setFrom]=useState(''),[to,setTo]=useState(''),[reason,setReason]=useState('planned_leave'),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
  async function run(action:()=>Promise<void>){setBusy(true);setMessage('');try{await action();}catch(error){setMessage(error instanceof Error?error.message:'Availability could not be saved.');}finally{setBusy(false);}}
  async function load(){setData(doctorAvailabilitySchema.parse(await request(`doctors/${doctor}/availability`)));}
  async function save(body:Record<string,unknown>){
    if(!data)return;
    const result=doctorAvailabilityResultSchema.parse(await write(`doctors/${doctor}/availability`,'PATCH',{expected_revision:data.revision,...body}));
    await load();setMessage(result.affected_count?`Saved. ${result.affected_count} existing appointment(s) need review. Patient notices require staff follow-up.`:'Availability saved.');
  }
  return <><section className="panel"><h2>Doctor availability</h2><p className="muted">Changes affect new availability. Existing appointments stay recorded and must be reviewed when hours or leave conflict. Check the walk-in queue separately when changing today’s availability.</p>
    <form className="search-row" onSubmit={event=>{event.preventDefault();void run(load);}}>
      <label>Doctor<select value={doctor} required disabled={busy} onChange={event=>{setDoctor(event.target.value);setData(null);}}><option value="">Choose doctor</option>{initialDoctor&&!doctors.some(item=>item.id===initialDoctor)&&<option value={initialDoctor}>Doctor from alert</option>}{doctors.map(item=><option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
      <button className="secondary" type="button" disabled={busy} onClick={()=>void run(async()=>setDoctors(z.object({doctors:z.array(doctorRecordSchema)}).parse(await request('doctors')).doctors))}>Load doctors</button><button className="primary" disabled={busy||!doctor}>Load availability</button>
    </form><p className="notice" role="status" aria-live="polite">{busy?'Working…':message}</p>
  </section>{data&&<>
    <section className="panel"><h2>Weekly hours</h2><p className="muted">All hours use India Standard Time. Load current availability before overwriting another administrator’s change.</p>
      {data.schedules.length===0&&<p>No weekly hours configured.</p>}{data.schedules.map(item=><article className="record" key={item.id}><div className="section-head"><div><h3>{weekdays[item.weekday]}</h3><p>{item.start_time.slice(0,5)}–{item.end_time.slice(0,5)}{item.break_start?` · Break ${item.break_start.slice(0,5)}–${item.break_end?.slice(0,5)}`:''}</p></div><div className="inline">
        <button className="secondary" disabled={busy} onClick={()=>{setWeekday(item.weekday);setStart(item.start_time.slice(0,5));setEnd(item.end_time.slice(0,5));setHasBreak(!!item.break_start);setBreakStart(item.break_start?.slice(0,5)??'13:00');setBreakEnd(item.break_end?.slice(0,5)??'14:00');}}>Edit hours</button>
        <button className="text-button" disabled={busy} onClick={()=>{if(window.confirm('Close this weekday? Existing bookings will remain for review.'))void run(()=>save({action:'delete_schedule',weekday:item.weekday}));}}>Close weekday</button>
      </div></div></article>)}
      <form onSubmit={event=>{event.preventDefault();void run(()=>save({action:'schedule',weekday,start_time:start,end_time:end,break_start:hasBreak?breakStart:null,break_end:hasBreak?breakEnd:null}));}}>
        <div className="form-grid"><label>Weekday<select value={weekday} onChange={event=>setWeekday(Number(event.target.value))}>{weekdays.map((day,index)=><option key={day} value={index}>{day}</option>)}</select></label><label>Opens<input type="time" value={start} onChange={event=>setStart(event.target.value)} required/></label><label>Closes<input type="time" value={end} onChange={event=>setEnd(event.target.value)} required/></label></div>
        <label className="checkbox"><input type="checkbox" checked={hasBreak} onChange={event=>setHasBreak(event.target.checked)}/>Include a break</label>
        {hasBreak&&<div className="form-grid"><label>Break starts<input type="time" required value={breakStart} onChange={event=>setBreakStart(event.target.value)}/></label><label>Break ends<input type="time" required value={breakEnd} onChange={event=>setBreakEnd(event.target.value)}/></label></div>}
        <button className="primary" disabled={busy}>Save weekday hours</button>
      </form>
    </section><section className="panel"><h2>Leave</h2>{data.leaves.length===0&&<p>No current or upcoming leave.</p>}{data.leaves.map(leave=><article className="record" key={leave.id}><div className="section-head"><div><h3>{leave.date_from}–{leave.date_to}</h3><p>{leave.reason.replaceAll('_',' ')}</p></div><button className="secondary" disabled={busy} onClick={()=>{if(window.confirm('Remove this leave period? Appointment records will remain unchanged.'))void run(()=>save({action:'delete_leave',leave_id:leave.id}));}}>Remove leave</button></div></article>)}
      <form onSubmit={event=>{event.preventDefault();void run(()=>save({action:'leave',date_from:from,date_to:to,reason}));}}><div className="form-grid"><label>From<input type="date" required value={from} onChange={event=>setFrom(event.target.value)}/></label><label>Through<input type="date" required value={to} onChange={event=>setTo(event.target.value)}/></label><label>Reason<select value={reason} onChange={event=>setReason(event.target.value)}><option value="planned_leave">Planned leave</option><option value="clinic_change">Clinic change</option><option value="other">Other</option></select></label></div><button className="primary" disabled={busy}>Add leave</button></form>
    </section><section className="panel"><div className="section-head"><div><h2>Appointments needing review · {data.affected_count}</h2><p className="muted">Review and reschedule these bookings, then confirm changes with the patient. This screen shows up to 100 affected appointments.</p></div><button className="secondary" onClick={onAppointments}>Open appointments</button></div>
      {data.affected_appointments.map(appointment=><article className="record" key={appointment.id}><strong>{appointment.patient_name??'Patient'}</strong><span>{new Date(appointment.starts_at).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'})} · {appointment.status.replace('_',' ')}</span></article>)}
    </section>
  </>}</>;
}
