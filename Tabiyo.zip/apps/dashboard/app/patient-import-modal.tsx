'use client';
import { useState, type FormEvent } from 'react';
import type { PatientRecord, PatientImportRow } from '@tabiyo/shared';

interface PatientImportModalProps {
  existingPatients: PatientRecord[];
  write: (path: string, method: string, body: unknown) => Promise<any>;
  onClose: () => void;
  onSuccess: () => void;
  onNotice: (msg: string) => void;
}

export function PatientImportModal({ existingPatients, write, onClose, onSuccess, onNotice }: PatientImportModalProps) {
  const [mode, setMode] = useState<'import' | 'merge'>('import');
  const [csvText, setCsvText] = useState('');
  const [parsedRows, setParsedRows] = useState<PatientImportRow[]>([]);
  const [submitting, setSubmitting] = useState(false);

  // Merge state
  const [sourceId, setSourceId] = useState('');
  const [targetId, setTargetId] = useState('');
  const [mergeReason, setMergeReason] = useState('');

  function parseCSV() {
    if (!csvText.trim()) return;
    const lines = csvText.trim().split(/\r?\n/);
    const rows: PatientImportRow[] = [];
    
    // Check if line 1 has headers
    const startIdx = lines[0].toLowerCase().includes('name') ? 1 : 0;
    for (let i = startIdx; i < lines.length; i++) {
      const parts = lines[i].split(',').map(s => s.trim().replace(/^["']|["']$/g, ''));
      if (parts.length >= 2 && parts[0] && parts[1]) {
        let phone = parts[1].replace(/[\s\-]/g, '');
        if (!phone.startsWith('+91')) {
          if (phone.length === 10) phone = '+91' + phone;
          else if (phone.startsWith('91') && phone.length === 12) phone = '+' + phone;
        }
        rows.push({
          name: parts[0],
          mobile_e164: phone,
          date_of_birth: parts[2] || null,
          gender: (['female', 'male', 'other'].includes(parts[3]?.toLowerCase()) ? parts[3].toLowerCase() : 'undisclosed') as any,
          language: (['en', 'te', 'hi'].includes(parts[4]?.toLowerCase()) ? parts[4].toLowerCase() : 'en') as any,
        });
      }
    }
    setParsedRows(rows);
  }

  async function handleImport() {
    if (!parsedRows.length) return;
    setSubmitting(true);
    try {
      const res = await write('patients/import', 'POST', { rows: parsedRows });
      onNotice(`Import completed: ${res.imported_count ?? parsedRows.length} patients added.`);
      onSuccess();
      onClose();
    } catch (err) {
      onNotice(err instanceof Error ? err.message : 'Import failed.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleMerge(e: FormEvent) {
    e.preventDefault();
    if (!sourceId || !targetId || sourceId === targetId) {
      onNotice('Please select distinct source and target patient records.');
      return;
    }
    setSubmitting(true);
    try {
      await write('patients/merge', 'POST', {
        source_patient_id: sourceId,
        target_patient_id: targetId,
        reason: mergeReason.trim() || 'Duplicate patient identified by front desk staff.',
      });
      onNotice('Patient records merged successfully.');
      onSuccess();
      onClose();
    } catch (err) {
      onNotice(err instanceof Error ? err.message : 'Merge failed.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      backgroundColor: 'rgba(15, 23, 42, 0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 50, padding: '1rem'
    }}>
      <div style={{ background: '#fff', borderRadius: '8px', maxWidth: '640px', width: '100%', padding: '1.5rem', maxHeight: '90vh', overflowY: 'auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ margin: 0, fontSize: '1.15rem' }}>
            {mode === 'import' ? '📥 Import Patients (CSV)' : '🔀 Merge Duplicate Patients'}
          </h3>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <button
              type="button"
              className={mode === 'import' ? 'primary-btn' : 'secondary-btn'}
              onClick={() => setMode('import')}
              style={{ padding: '0.25rem 0.6rem', fontSize: '0.8rem' }}
            >
              CSV Import
            </button>
            <button
              type="button"
              className={mode === 'merge' ? 'primary-btn' : 'secondary-btn'}
              onClick={() => setMode('merge')}
              style={{ padding: '0.25rem 0.6rem', fontSize: '0.8rem' }}
            >
              Merge Duplicate
            </button>
            <button type="button" onClick={onClose} style={{ border: 'none', background: 'transparent', cursor: 'pointer', fontSize: '1.1rem', marginLeft: '0.5rem' }}>✕</button>
          </div>
        </div>

        {mode === 'import' ? (
          <div>
            <p style={{ fontSize: '0.85rem', color: '#64748b', margin: '0 0 0.75rem' }}>
              Paste CSV data with columns: <code>Name, Mobile, Date of Birth (YYYY-MM-DD), Gender, Language (en/te/hi)</code>
            </p>
            <textarea
              rows={5}
              placeholder={`Aarav Sharma, 9876543210, 1990-05-12, male, en\nFatima Begum, 9123456789, 1985-08-20, female, te`}
              value={csvText}
              onChange={e => setCsvText(e.target.value)}
              style={{ width: '100%', fontFamily: 'monospace', fontSize: '0.8rem', padding: '0.5rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
            />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '0.5rem' }}>
              <button type="button" className="secondary-btn" onClick={parseCSV} style={{ padding: '0.35rem 0.75rem', fontSize: '0.85rem' }}>
                Preview Parsed Rows
              </button>
              {parsedRows.length > 0 && (
                <span style={{ fontSize: '0.85rem', color: '#16a34a', fontWeight: 600 }}>
                  ✓ {parsedRows.length} valid rows parsed
                </span>
              )}
            </div>

            {parsedRows.length > 0 && (
              <div style={{ marginTop: '1rem', maxHeight: '180px', overflowY: 'auto', border: '1px solid #e2e8f0', borderRadius: '4px' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8rem' }}>
                  <thead>
                    <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                      <th style={{ padding: '0.4rem' }}>Name</th>
                      <th style={{ padding: '0.4rem' }}>Mobile</th>
                      <th style={{ padding: '0.4rem' }}>DOB</th>
                      <th style={{ padding: '0.4rem' }}>Lang</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parsedRows.map((r, idx) => (
                      <tr key={idx} style={{ borderBottom: '1px solid #f1f5f9' }}>
                        <td style={{ padding: '0.4rem' }}>{r.name}</td>
                        <td style={{ padding: '0.4rem' }}>{r.mobile_e164}</td>
                        <td style={{ padding: '0.4rem' }}>{r.date_of_birth || '—'}</td>
                        <td style={{ padding: '0.4rem' }}>{r.language}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '1.25rem' }}>
              <button type="button" onClick={onClose} style={{ padding: '0.4rem 0.8rem', border: 'none', background: 'transparent', cursor: 'pointer' }}>Cancel</button>
              <button
                type="button"
                className="primary-btn"
                disabled={submitting || !parsedRows.length}
                onClick={handleImport}
                style={{ padding: '0.4rem 1rem' }}
              >
                {submitting ? 'Importing...' : `Import ${parsedRows.length} Patients`}
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleMerge}>
            <p style={{ fontSize: '0.85rem', color: '#64748b', margin: '0 0 1rem' }}>
              Merge an accidental duplicate patient record into the canonical patient record. All appointments, prescriptions, and history will be retained under the target record.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div>
                <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Source Record (Duplicate to be merged)</label>
                <select
                  required
                  value={sourceId}
                  onChange={e => setSourceId(e.target.value)}
                  style={{ width: '100%', padding: '0.4rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
                >
                  <option value="">Select source patient...</option>
                  {existingPatients.map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.mobile_e164})</option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Target Record (Canonical patient to keep)</label>
                <select
                  required
                  value={targetId}
                  onChange={e => setTargetId(e.target.value)}
                  style={{ width: '100%', padding: '0.4rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
                >
                  <option value="">Select target patient...</option>
                  {existingPatients.filter(p => p.id !== sourceId).map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.mobile_e164})</option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Reason for Merge</label>
                <input
                  type="text"
                  placeholder="e.g. Duplicate registered under misspelled name"
                  value={mergeReason}
                  onChange={e => setMergeReason(e.target.value)}
                  style={{ width: '100%', padding: '0.4rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
                />
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '1.25rem' }}>
              <button type="button" onClick={onClose} style={{ padding: '0.4rem 0.8rem', border: 'none', background: 'transparent', cursor: 'pointer' }}>Cancel</button>
              <button
                type="submit"
                className="primary-btn"
                disabled={submitting || !sourceId || !targetId}
                style={{ padding: '0.4rem 1rem', background: '#dc2626' }}
              >
                {submitting ? 'Merging...' : 'Confirm & Merge Records'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
