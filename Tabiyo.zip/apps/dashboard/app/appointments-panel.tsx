'use client';
import {useState,type FormEvent} from 'react';
import {z} from 'zod';
import {appointmentRecordSchema,appointmentSlotSchema,appointmentWriteResultSchema,doctorRecordSchema,type AppointmentRecord,type DoctorRecord,type AppointmentSlot} from '@tabiyo/shared';
type Request=(path:string,method?:string,body?:unknown,key?:string)=>Promise<unknown>;
type Write=(path:string,method:string,body:unknown)=>Promise<unknown>;
const clinicToday=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const time=(value:string)=>new Date(value).toLocaleTimeString('en-IN',{timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit'});

export function BookingForm({patientId,doctors,request,write,appointment,onSaved}:{
  patientId:string;doctors:DoctorRecord[];request:Request;write:Write;appointment?:AppointmentRecord;onSaved:()=>void;
}){
  const [doctor,setDoctor]=useState(appointment?.doctor_id??''),[date,setDate]=useState(clinicToday);
  const [slots,setSlots]=useState<AppointmentSlot[]>([]),[chosen,setChosen]=useState(''),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
  async function run(action:()=>Promise<void>){setBusy(true);setMessage('');try{await action();}catch(error){setMessage(error instanceof Error?error.message:'This request could not be completed.');}finally{setBusy(false);}}
  async function availability(event:FormEvent){
    event.preventDefault();setChosen('');await run(async()=>{
      const result=z.object({slots:z.array(appointmentSlotSchema)}).parse(await request('availability','POST',{doctor_id:doctor,date,patient_id:patientId}));
      setSlots(result.slots);if(!result.slots.length)setMessage('No available times on this day. Choose another day.');
    });
  }
  return <div className="booking-form"><h3>{appointment?'Choose a replacement time':'Book an appointment'}</h3>
    <form onSubmit={event=>void availability(event)}><div className="form-grid"><label>Doctor<select value={doctor} required onChange={event=>{setDoctor(event.target.value);setChosen('');setSlots([]);}}><option value="">Choose doctor</option>{doctors.map(item=><option key={item.id} value={item.id}>{item.name} · {item.specialty}</option>)}</select></label>
      <label>Appointment date<input type="date" value={date} min={clinicToday()} required onChange={event=>{setDate(event.target.value);setChosen('');setSlots([]);}}/></label></div>
      <button className="secondary" disabled={busy||!doctor}>Find available times</button>
    </form>
    {slots.length>0&&<form onSubmit={event=>{event.preventDefault();void run(async()=>{
      const result=appointmentWriteResultSchema.parse(await write(appointment?`appointments/${appointment.id}`:'appointments',appointment?'PATCH':'POST',
        appointment?{action:'reschedule',doctor_id:doctor,starts_at:chosen}:{patient_id:patientId,doctor_id:doctor,starts_at:chosen,source:'phone'}));
      setMessage(result.replayed?'Saved appointment recovered.':'Appointment saved.');setChosen('');setSlots([]);onSaved();
    });}}><fieldset className="slots"><legend>Available times · India Standard Time</legend>{slots.map(slot=><label key={slot.starts_at} className={chosen===slot.starts_at?'slot chosen':'slot'}><input type="radio" name="slot" value={slot.starts_at} required checked={chosen===slot.starts_at} onChange={()=>setChosen(slot.starts_at)}/>{time(slot.starts_at)}</label>)}</fieldset>
      <p className="muted">Availability is checked again when you confirm. {appointment?'The original appointment remains until the replacement is saved.':'The clinic’s consent and delivery rules apply to confirmation messages.'}</p>
      <button className="primary" disabled={busy||!chosen}>{appointment?'Confirm replacement':'Confirm appointment'}</button>
    </form>}
    <p className="notice" role="status" aria-live="polite">{busy?'Checking…':message}</p>
  </div>;
}

export function AppointmentsPanel({request,write}:{request:Request;write:Write}){
  const [date,setDate]=useState(clinicToday),[doctors,setDoctors]=useState<DoctorRecord[]>([]),[appointments,setAppointments]=useState<AppointmentRecord[]>([]);
  const [rescheduling,setRescheduling]=useState<AppointmentRecord|null>(null),[busy,setBusy]=useState(false),[loaded,setLoaded]=useState(false),[message,setMessage]=useState('');
  async function load(){
    const [rows,staff]=await Promise.all([request('appointments?date='+encodeURIComponent(date)),request('doctors')]);
    setAppointments(z.object({appointments:z.array(appointmentRecordSchema)}).parse(rows).appointments);
    setDoctors(z.object({doctors:z.array(doctorRecordSchema)}).parse(staff).doctors);setLoaded(true);
  }
  async function run(action:()=>Promise<void>){setBusy(true);setMessage('');try{await action();}catch(error){setMessage(error instanceof Error?error.message:'This request could not be completed.');}finally{setBusy(false);}}
  async function transition(appointment:AppointmentRecord,action:string){
    if(action==='cancel'&&!window.confirm('Cancel this appointment? The clinic must confirm the cancellation notice with the patient.'))return;
    await run(async()=>{await write(`appointments/${appointment.id}`,'PATCH',{action});await load();});
  }
  return <><section className="panel"><h2>Clinic day</h2><form className="search-row" onSubmit={event=>{event.preventDefault();setRescheduling(null);void run(load);}}>
    <label>Date · India Standard Time<input type="date" value={date} onChange={event=>{setDate(event.target.value);setLoaded(false);setAppointments([]);}} required/></label><button className="primary" disabled={busy}>Load appointments</button>
  </form><p className="notice" role="status" aria-live="polite">{busy?'Loading…':message}</p>
  {!loaded&&<p className="muted">Choose a day to load the clinic’s appointments.</p>}
  {loaded&&!appointments.length&&<p>No appointments on this day.</p>}
  {appointments.map(appointment=><article className="record" key={appointment.id}><div className="section-head"><div><h3>{time(appointment.starts_at)} · {appointment.patient_name??'Patient'}</h3><p>{doctors.find(item=>item.id===appointment.doctor_id)?.name??'Doctor'} · {appointment.source.replace('_',' ')}</p></div><span className="badge">{appointment.status.replace('_',' ')}</span></div>
    <div className="inline">{appointment.status==='booked'&&<>
      {date===clinicToday()&&<button className="secondary" disabled={busy} onClick={()=>void transition(appointment,'check_in')}>Check in</button>}
      {new Date(appointment.ends_at)<new Date()&&<button className="secondary" disabled={busy} onClick={()=>void transition(appointment,'no_show')}>Mark no-show</button>}
      <button className="secondary" disabled={busy} onClick={()=>setRescheduling(appointment)}>Reschedule</button>
    </>}{appointment.status==='checked_in'&&<button className="primary" disabled={busy} onClick={()=>void transition(appointment,'complete')}>Complete visit</button>}
    {['booked','checked_in'].includes(appointment.status)&&<button className="text-button" disabled={busy} onClick={()=>void transition(appointment,'cancel')}>Cancel appointment</button>}</div>
  </article>)}
  </section>{rescheduling&&<section className="panel"><div className="section-head"><h2>Reschedule · {rescheduling.patient_name??'Patient'}</h2><button className="text-button" onClick={()=>setRescheduling(null)}>Close</button></div>
    <BookingForm key={rescheduling.id} patientId={rescheduling.patient_id} doctors={doctors} appointment={rescheduling} request={request} write={write} onSaved={()=>{setRescheduling(null);void run(load);}}/>
  </section>}</>;
}
