'use client';
import { useState, useEffect, type FormEvent } from 'react';
import type { PrescriptionRecord, PatientAdherence, VisitRecord, MedicationItem } from '@tabiyo/shared';

interface ClinicalPanelProps {
  patientId: string;
  isDoctor: boolean;
  request: (path: string, method?: string, body?: unknown, key?: string) => Promise<any>;
  write: (path: string, method: string, body: unknown) => Promise<any>;
  onNotice: (msg: string) => void;
}

export function ClinicalPanel({ patientId, isDoctor, request, write, onNotice }: ClinicalPanelProps) {
  const [adherence, setAdherence] = useState<PatientAdherence | null>(null);
  const [loading, setLoading] = useState(false);
  const [addingRx, setAddingRx] = useState(false);

  // Form state
  const [medicine, setMedicine] = useState('');
  const [dose, setDose] = useState('');
  const [times, setTimes] = useState<string[]>(['morning', 'night']);
  const [foodRelation, setFoodRelation] = useState<'before_food' | 'after_food' | 'with_food' | 'no_relation'>('after_food');
  const [startDate, setStartDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [endDate, setEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 5);
    return d.toISOString().slice(0, 10);
  });

  // Slip generation state
  const [slipLoading, setSlipLoading] = useState(false);
  const [slipUrl, setSlipUrl] = useState<string | null>(null);
  const [slipExpires, setSlipExpires] = useState<string | null>(null);

  useEffect(() => {
    if (!patientId) return;
    let cancelled = false;
    setLoading(true);
    request(`patients/${patientId}/adherence`)
      .then(res => {
        if (!cancelled && res?.adherence) {
          setAdherence(res);
        }
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
  }, [patientId]);

  async function handleAddPrescription(e: FormEvent) {
    e.preventDefault();
    if (!isDoctor) {
      onNotice('Only clinicians (doctors/admins) can create prescriptions.');
      return;
    }
    if (!medicine.trim() || !dose.trim() || !times.length) {
      onNotice('Medicine name, dose, and at least one time of day are required.');
      return;
    }

    const item: MedicationItem = {
      medicine: medicine.trim(),
      dose: dose.trim(),
      times,
      food_relation: foodRelation,
      start_date: startDate,
      end_date: endDate,
    };

    try {
      await write('prescriptions', 'POST', {
        patient_id: patientId,
        items: [item],
      });
      onNotice('Prescription and medication schedule created.');
      setAddingRx(false);
      setMedicine('');
      setDose('');
      // Refresh adherence
      const fresh = await request(`patients/${patientId}/adherence`);
      if (fresh?.adherence) setAdherence(fresh);
    } catch (err) {
      onNotice(err instanceof Error ? err.message : 'Could not save prescription.');
    }
  }

  async function handleGenerateSlip() {
    setSlipLoading(true);
    try {
      const res = await write('visits/slip', 'POST', {
        patient_id: patientId,
        notes: 'Consultation completed. Visit slip issued.',
      });
      if (res?.download_url) {
        setSlipUrl(res.download_url);
        setSlipExpires(res.expires_at);
        onNotice('Visit slip generated. Valid for 5 minutes.');
      }
    } catch (err) {
      onNotice(err instanceof Error ? err.message : 'Could not generate slip.');
    } finally {
      setSlipLoading(false);
    }
  }

  return (
    <div className="panel" style={{ marginTop: '1rem', padding: '1.25rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
        <div>
          <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 600 }}>Continuing Care & Prescriptions</h3>
          <p style={{ margin: 0, fontSize: '0.85rem', color: '#64748b' }}>
            Structured medicines, dose schedules, patient adherence, and visit slips.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button
            type="button"
            className="secondary-btn"
            onClick={handleGenerateSlip}
            disabled={slipLoading}
          >
            {slipLoading ? 'Generating...' : '📄 Generate Visit Slip'}
          </button>
          {isDoctor && (
            <button
              type="button"
              className="primary-btn"
              onClick={() => setAddingRx(!addingRx)}
            >
              {addingRx ? 'Cancel' : '+ Add Prescription'}
            </button>
          )}
        </div>
      </div>

      {slipUrl && (
        <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', padding: '0.75rem 1rem', borderRadius: '6px', marginBottom: '1rem' }}>
          <strong>Visit Slip Ready:</strong>{' '}
          <a href={slipUrl} target="_blank" rel="noopener noreferrer" style={{ color: '#16a34a', textDecoration: 'underline' }}>
            Download PDF Slip
          </a>
          <span style={{ fontSize: '0.8rem', color: '#64748b', marginLeft: '0.75rem' }}>
            Expires: {slipExpires ? new Date(slipExpires).toLocaleTimeString() : 'in 5 min'}
          </span>
        </div>
      )}

      {addingRx && (
        <form onSubmit={handleAddPrescription} style={{ background: '#f8fafc', padding: '1rem', borderRadius: '6px', marginBottom: '1rem', border: '1px solid #e2e8f0' }}>
          <h4 style={{ margin: '0 0 0.75rem 0', fontSize: '0.95rem' }}>New Prescription Schedule</h4>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.75rem' }}>
            <div>
              <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Medicine Name *</label>
              <input
                required
                type="text"
                placeholder="e.g. Metformin 500mg"
                value={medicine}
                onChange={e => setMedicine(e.target.value)}
                style={{ width: '100%', padding: '0.4rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
              />
            </div>
            <div>
              <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Dose *</label>
              <input
                required
                type="text"
                placeholder="e.g. 1 tablet"
                value={dose}
                onChange={e => setDose(e.target.value)}
                style={{ width: '100%', padding: '0.4rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
              />
            </div>
            <div>
              <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Food Relation</label>
              <select
                value={foodRelation}
                onChange={e => setFoodRelation(e.target.value as any)}
                style={{ width: '100%', padding: '0.4rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
              >
                <option value="after_food">After Food</option>
                <option value="before_food">Before Food</option>
                <option value="with_food">With Food</option>
                <option value="no_relation">No Food Relation</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Timing (Daily)</label>
              <div style={{ display: 'flex', gap: '0.5rem', paddingTop: '0.25rem' }}>
                {['morning', 'afternoon', 'night'].map(t => (
                  <label key={t} style={{ fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                    <input
                      type="checkbox"
                      checked={times.includes(t)}
                      onChange={e => {
                        if (e.target.checked) setTimes([...times, t]);
                        else setTimes(times.filter(x => x !== t));
                      }}
                    />
                    {t.charAt(0).toUpperCase() + t.slice(1)}
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Start Date</label>
              <input
                type="date"
                required
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                style={{ width: '100%', padding: '0.4rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
              />
            </div>
            <div>
              <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>End Date</label>
              <input
                type="date"
                required
                value={endDate}
                onChange={e => setEndDate(e.target.value)}
                style={{ width: '100%', padding: '0.4rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
              />
            </div>
          </div>
          <div style={{ marginTop: '0.75rem', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
            <button type="button" onClick={() => setAddingRx(false)} style={{ padding: '0.4rem 0.8rem', border: 'none', background: 'transparent', cursor: 'pointer' }}>Cancel</button>
            <button type="submit" className="primary-btn" style={{ padding: '0.4rem 1rem' }}>Save & Schedule Reminders</button>
          </div>
        </form>
      )}

      {loading ? (
        <p style={{ color: '#94a3b8', fontSize: '0.9rem' }}>Loading adherence records...</p>
      ) : adherence && adherence.adherence.length > 0 ? (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #e2e8f0', color: '#64748b' }}>
                <th style={{ padding: '0.5rem' }}>Medicine</th>
                <th style={{ padding: '0.5rem' }}>Dose</th>
                <th style={{ padding: '0.5rem' }}>Taken</th>
                <th style={{ padding: '0.5rem' }}>Missed</th>
                <th style={{ padding: '0.5rem' }}>Total Due</th>
                <th style={{ padding: '0.5rem' }}>Adherence</th>
                <th style={{ padding: '0.5rem' }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {adherence.adherence.map((row, i) => (
                <tr key={i} style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <td style={{ padding: '0.5rem', fontWeight: 600 }}>{row.medicine}</td>
                  <td style={{ padding: '0.5rem' }}>{row.dose}</td>
                  <td style={{ padding: '0.5rem', color: '#16a34a' }}>{row.taken}</td>
                  <td style={{ padding: '0.5rem', color: '#dc2626' }}>{row.missed}</td>
                  <td style={{ padding: '0.5rem' }}>{row.total_due}</td>
                  <td style={{ padding: '0.5rem' }}>
                    <span style={{ fontWeight: 600, color: row.adherence_rate >= 80 ? '#16a34a' : row.adherence_rate >= 50 ? '#d97706' : '#dc2626' }}>
                      {row.adherence_rate}%
                    </span>
                  </td>
                  <td style={{ padding: '0.5rem' }}>
                    <span style={{
                      padding: '0.2rem 0.5rem',
                      borderRadius: '4px',
                      fontSize: '0.75rem',
                      background: row.status === 'active' ? '#dcfce7' : row.status === 'completed' ? '#f1f5f9' : '#fee2e2',
                      color: row.status === 'active' ? '#15803d' : row.status === 'completed' ? '#475569' : '#b91c1c'
                    }}>
                      {row.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p style={{ color: '#94a3b8', fontSize: '0.85rem' }}>No active medication schedules for this patient.</p>
      )}
    </div>
  );
}
