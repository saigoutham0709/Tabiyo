'use client';
import { useState, useEffect, type FormEvent } from 'react';
import type { FAQRecord } from '@tabiyo/shared';

interface FAQsPanelProps {
  isAdmin: boolean;
  request: (path: string, method?: string, body?: unknown, key?: string) => Promise<any>;
  write: (path: string, method: string, body: unknown) => Promise<any>;
  onNotice: (msg: string) => void;
}

export function FAQsPanel({ isAdmin, request, write, onNotice }: FAQsPanelProps) {
  const [faqs, setFaqs] = useState<FAQRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [adding, setAdding] = useState(false);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [language, setLanguage] = useState<'en' | 'te' | 'hi'>('en');

  async function loadFaqs() {
    setLoading(true);
    try {
      const res = await request('faqs');
      if (res?.faqs) setFaqs(res.faqs);
    } catch (err) {
      onNotice(err instanceof Error ? err.message : 'Could not load FAQs.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadFaqs();
  }, []);

  async function handleCreate(e: FormEvent) {
    e.preventDefault();
    if (!isAdmin) {
      onNotice('Only clinic administrators can manage FAQs.');
      return;
    }
    try {
      await write('faqs', 'PUT', {
        question: question.trim(),
        answer: answer.trim(),
        language,
        active: true,
      });
      onNotice('FAQ entry saved.');
      setAdding(false);
      setQuestion('');
      setAnswer('');
      loadFaqs();
    } catch (err) {
      onNotice(err instanceof Error ? err.message : 'Could not save FAQ.');
    }
  }

  async function toggleActive(faq: FAQRecord) {
    if (!isAdmin) {
      onNotice('Only clinic administrators can update FAQs.');
      return;
    }
    try {
      await write('faqs', 'PUT', {
        id: faq.id,
        question: faq.question,
        answer: faq.answer,
        language: faq.language,
        active: !faq.active,
      });
      onNotice(`FAQ marked as ${!faq.active ? 'active' : 'inactive'}.`);
      loadFaqs();
    } catch (err) {
      onNotice(err instanceof Error ? err.message : 'Could not update FAQ.');
    }
  }

  return (
    <div className="panel" style={{ padding: '1.25rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
        <div>
          <h2 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 600 }}>Clinic FAQs & AI Knowledge Base</h2>
          <p style={{ margin: '0.25rem 0 0', fontSize: '0.85rem', color: '#64748b' }}>
            Official clinic responses used by the WhatsApp AI assistant. The AI answers strictly from these approved texts.
          </p>
        </div>
        {isAdmin && (
          <button type="button" className="primary-btn" onClick={() => setAdding(!adding)}>
            {adding ? 'Cancel' : '+ Add FAQ'}
          </button>
        )}
      </div>

      {adding && (
        <form onSubmit={handleCreate} style={{ background: '#f8fafc', padding: '1rem', borderRadius: '6px', marginBottom: '1.25rem', border: '1px solid #e2e8f0' }}>
          <h4 style={{ margin: '0 0 0.75rem', fontSize: '0.95rem' }}>Add Approved Clinic FAQ</h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <div>
              <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Language</label>
              <select
                value={language}
                onChange={e => setLanguage(e.target.value as any)}
                style={{ padding: '0.4rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
              >
                <option value="en">English</option>
                <option value="te">Telugu (తెలుగు)</option>
                <option value="hi">Hindi (हिन्दी)</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Patient Question *</label>
              <input
                required
                type="text"
                placeholder="e.g. What are the clinic consultation timings?"
                value={question}
                onChange={e => setQuestion(e.target.value)}
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
              />
            </div>
            <div>
              <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '0.25rem' }}>Approved Answer *</label>
              <textarea
                required
                rows={3}
                placeholder="e.g. Dr. Rao is available Mon-Sat 9 AM to 6 PM IST. Walk-in token queue opens at 8:30 AM."
                value={answer}
                onChange={e => setAnswer(e.target.value)}
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
              />
            </div>
          </div>
          <div style={{ marginTop: '0.75rem', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
            <button type="button" onClick={() => setAdding(false)} style={{ padding: '0.4rem 0.8rem', border: 'none', background: 'transparent', cursor: 'pointer' }}>Cancel</button>
            <button type="submit" className="primary-btn" style={{ padding: '0.4rem 1rem' }}>Save FAQ</button>
          </div>
        </form>
      )}

      {loading ? (
        <p style={{ color: '#94a3b8' }}>Loading clinic FAQs...</p>
      ) : faqs.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {faqs.map(faq => (
            <div key={faq.id} style={{ border: '1px solid #e2e8f0', borderRadius: '6px', padding: '1rem', background: faq.active ? '#fff' : '#f8fafc' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.4rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span style={{
                    fontSize: '0.7rem',
                    padding: '0.15rem 0.4rem',
                    borderRadius: '4px',
                    fontWeight: 600,
                    textTransform: 'uppercase',
                    background: faq.language === 'te' ? '#e0e7ff' : faq.language === 'hi' ? '#fef3c7' : '#f1f5f9',
                    color: faq.language === 'te' ? '#3730a3' : faq.language === 'hi' ? '#92400e' : '#334155'
                  }}>
                    {faq.language}
                  </span>
                  <strong style={{ fontSize: '0.95rem' }}>{faq.question}</strong>
                </div>
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => toggleActive(faq)}
                    style={{
                      fontSize: '0.75rem',
                      padding: '0.2rem 0.6rem',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      border: '1px solid #cbd5e1',
                      background: faq.active ? '#dcfce7' : '#f1f5f9',
                      color: faq.active ? '#15803d' : '#64748b'
                    }}
                  >
                    {faq.active ? 'Active' : 'Disabled'}
                  </button>
                )}
              </div>
              <p style={{ margin: 0, fontSize: '0.85rem', color: '#475569', lineHeight: 1.4 }}>{faq.answer}</p>
            </div>
          ))}
        </div>
      ) : (
        <p style={{ color: '#94a3b8', fontSize: '0.9rem' }}>No clinic FAQs configured yet. Add approved responses for patient queries.</p>
      )}
    </div>
  );
}
