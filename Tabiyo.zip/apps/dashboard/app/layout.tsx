import type {Metadata} from 'next';
import './staff.css';
export const metadata:Metadata={title:'Tabiyo · Staff workspace',description:'Secure clinic patient records and delivery operations.'};
export default function Layout({children}:{children:React.ReactNode}){
  return <html lang="en"><body>{children}</body></html>;
}
