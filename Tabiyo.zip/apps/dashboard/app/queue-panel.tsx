'use client';
import {useState} from 'react';
import {z} from 'zod';
import {doctorRecordSchema,queueReadSchema,queueResultSchema,type DoctorRecord,type QueueRead,type QueueResult} from '@tabiyo/shared';
type Request=(path:string,method?:string,body?:unknown,key?:string)=>Promise<unknown>;
type Write=(path:string,method:string,body:unknown)=>Promise<unknown>;
const notice=(state:QueueResult['notice_state'])=>state==='queued'?'Next-patient notice queued; delivery is not yet confirmed.':state==='review_required'?'Next-patient notice requires staff review. Check approved wording, consent and the messaging window.':state==='existing'?'The next-patient notice is already recorded.':'';
export function QueueAddForm({patientId,doctors,write,onOpen}:{patientId:string;doctors:DoctorRecord[];write:Write;onOpen:(doctorId:string)=>void}){
  const [doctor,setDoctor]=useState(''),[result,setResult]=useState<QueueResult|null>(null),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
  return <div className="consent"><h3>Add walk-in token</h3><p className="muted">Tokens track walk-in order. Appointment statuses are managed separately.</p>
    <form className="search-row" onSubmit={event=>{event.preventDefault();setBusy(true);setMessage('');void (async()=>{
      try{const saved=queueResultSchema.parse(await write(`doctors/${doctor}/queue`,'POST',{action:'add',patient_id:patientId}));setResult(saved);setMessage(`Token ${saved.token.token_number} is waiting. ${notice(saved.notice_state)}`);}
      catch(error){setMessage(error instanceof Error?error.message:'Token could not be saved.');}finally{setBusy(false);}
    })();}}><label>Doctor<select required value={doctor} disabled={busy} onChange={event=>{setDoctor(event.target.value);setResult(null);}}><option value="">Choose doctor</option>{doctors.map(item=><option key={item.id} value={item.id}>{item.name}</option>)}</select></label><button className="secondary" disabled={busy||!doctor}>Add token</button>
      {result&&<button type="button" className="secondary" onClick={()=>onOpen(result.token.doctor_id)}>Open queue</button>}
    </form><p className="notice" role="status" aria-live="polite">{busy?'Saving…':message}</p>
  </div>;
}
export function QueuePanel({request,write,initialDoctor=''}:{request:Request;write:Write;initialDoctor?:string}){
  const [doctor,setDoctor]=useState(initialDoctor),[doctors,setDoctors]=useState<DoctorRecord[]>([]),[data,setData]=useState<QueueRead|null>(null),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
  async function run(action:()=>Promise<void>){setBusy(true);setMessage('');try{await action();}catch(error){setMessage(error instanceof Error?error.message:'Queue could not be loaded.');}finally{setBusy(false);}}
  async function load(){setData(queueReadSchema.parse(await request(`doctors/${doctor}/queue`)));}
  async function change(body:Record<string,unknown>){const result=queueResultSchema.parse(await write(`doctors/${doctor}/queue`,'POST',body));await load();setMessage(notice(result.notice_state)||'Queue updated.');}
  const active=data?.tokens.find(token=>token.status==='called'),next=data?.tokens.find(token=>token.status==='waiting');
  return <><section className="panel"><h2>Walk-in queue</h2><p className="muted">Load the current queue before calling the next patient. Add walk-ins from their patient record.</p>
    <form className="search-row" onSubmit={event=>{event.preventDefault();void run(load);}}><label>Doctor<select required value={doctor} disabled={busy} onChange={event=>{setDoctor(event.target.value);setData(null);}}><option value="">Choose doctor</option>{initialDoctor&&!doctors.some(item=>item.id===initialDoctor)&&<option value={initialDoctor}>Selected doctor</option>}{doctors.map(item=><option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
      <button type="button" className="secondary" disabled={busy} onClick={()=>void run(async()=>setDoctors(z.object({doctors:z.array(doctorRecordSchema)}).parse(await request('doctors')).doctors))}>Load doctors</button><button className="primary" disabled={busy||!doctor}>Load queue</button>
    </form><p className="notice" role="status" aria-live="polite">{busy?'Working…':message}</p>
  </section>{data&&<section className="panel"><div className="section-head"><div><h2>{data.date} · India Standard Time</h2><p>{active?`Currently called: token ${active.token_number} · ${active.patient_name??'Patient'}`:'No token is currently called.'}</p><p className="muted">{data.tokens.filter(token=>token.status==='waiting').length} patient(s) waiting.</p></div>
    {next&&<button className="primary" disabled={busy} onClick={()=>void run(()=>change({action:'call_next',expected_called_id:active?.id??null,expected_next_id:next.id}))}>{active?'Complete current & call next':'Call next token'}</button>}
  </div>{!data.tokens.length&&<p>No walk-in tokens today.</p>}
    {data.tokens.map(token=><article className="record" key={token.id}><div className="section-head"><div><h3>Token {token.token_number} · {token.patient_name??'Patient'}</h3><span className="badge">{token.status}</span></div><div className="inline">
      {token.status==='called'&&<button className="secondary" disabled={busy} onClick={()=>void run(()=>change({action:'complete',id:token.id}))}>Complete token</button>}
      {['called','waiting'].includes(token.status)&&<button className="text-button" disabled={busy} onClick={()=>{if(window.confirm(`Skip token ${token.token_number}?`))void run(()=>change({action:'skip',id:token.id}));}}>Skip token</button>}
    </div></div></article>)}
  </section>}</>;
}
