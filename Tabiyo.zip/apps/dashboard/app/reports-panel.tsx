'use client';
import { useState, useEffect } from 'react';
import type { ReportSummary } from '@tabiyo/shared';

interface ReportsPanelProps {
  request: (path: string, method?: string, body?: unknown, key?: string) => Promise<any>;
  onNotice: (msg: string) => void;
}

export function ReportsPanel({ request, onNotice }: ReportsPanelProps) {
  const [report, setReport] = useState<ReportSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [from, setFrom] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().slice(0, 10);
  });
  const [to, setTo] = useState(() => new Date().toISOString().slice(0, 10));

  async function loadReport() {
    setLoading(true);
    try {
      const res = await request(`reports/summary?from=${from}&to=${to}`);
      if (res?.clinic_id) setReport(res);
    } catch (err) {
      onNotice(err instanceof Error ? err.message : 'Could not load reports.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadReport();
  }, [from, to]);

  return (
    <div className="panel" style={{ padding: '1.25rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '0.75rem' }}>
        <div>
          <h2 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 600 }}>Operational Reports & Pilot Metrics</h2>
          <p style={{ margin: '0.25rem 0 0', fontSize: '0.85rem', color: '#64748b' }}>
            Derived exclusively from immutable system events. Tracks attendance, no-shows, and messaging economics.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <label style={{ fontSize: '0.8rem', color: '#64748b' }}>From:</label>
          <input
            type="date"
            value={from}
            onChange={e => setFrom(e.target.value)}
            style={{ padding: '0.35rem', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '0.85rem' }}
          />
          <label style={{ fontSize: '0.8rem', color: '#64748b' }}>To:</label>
          <input
            type="date"
            value={to}
            onChange={e => setTo(e.target.value)}
            style={{ padding: '0.35rem', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '0.85rem' }}
          />
          <button type="button" className="secondary-btn" onClick={loadReport} style={{ padding: '0.35rem 0.75rem', fontSize: '0.85rem' }}>
            Refresh
          </button>
        </div>
      </div>

      {loading ? (
        <p style={{ color: '#94a3b8' }}>Aggregating event logs...</p>
      ) : report ? (
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
            <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
              <span style={{ fontSize: '0.8rem', color: '#64748b', display: 'block', marginBottom: '0.25rem' }}>Booked Appointments</span>
              <strong style={{ fontSize: '1.5rem', color: '#0f172a' }}>{report.appointments_booked}</strong>
            </div>
            <div style={{ background: '#f0fdf4', padding: '1rem', borderRadius: '6px', border: '1px solid #bbf7d0' }}>
              <span style={{ fontSize: '0.8rem', color: '#16a34a', display: 'block', marginBottom: '0.25rem' }}>Attended Visits</span>
              <strong style={{ fontSize: '1.5rem', color: '#15803d' }}>{report.appointments_attended}</strong>
            </div>
            <div style={{ background: '#fef2f2', padding: '1rem', borderRadius: '6px', border: '1px solid #fecaca' }}>
              <span style={{ fontSize: '0.8rem', color: '#dc2626', display: 'block', marginBottom: '0.25rem' }}>No-Shows</span>
              <strong style={{ fontSize: '1.5rem', color: '#b91c1c' }}>{report.no_shows}</strong>
            </div>
            <div style={{ background: '#fffbeb', padding: '1rem', borderRadius: '6px', border: '1px solid #fde68a' }}>
              <span style={{ fontSize: '0.8rem', color: '#d97706', display: 'block', marginBottom: '0.25rem' }}>No-Show Rate</span>
              <strong style={{ fontSize: '1.5rem', color: '#b45309' }}>{report.no_show_rate}%</strong>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <div style={{ border: '1px solid #e2e8f0', borderRadius: '6px', padding: '1rem' }}>
              <h4 style={{ margin: '0 0 0.5rem', fontSize: '0.9rem', color: '#334155' }}>WhatsApp Outreach Performance</h4>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0.4rem 0', borderBottom: '1px solid #f1f5f9', fontSize: '0.85rem' }}>
                <span style={{ color: '#64748b' }}>Reminders Sent:</span>
                <strong>{report.reminders_sent}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0.4rem 0', fontSize: '0.85rem' }}>
                <span style={{ color: '#64748b' }}>Confirmations Received:</span>
                <strong>{report.confirmations_received}</strong>
              </div>
            </div>

            <div style={{ border: '1px solid #e2e8f0', borderRadius: '6px', padding: '1rem' }}>
              <h4 style={{ margin: '0 0 0.5rem', fontSize: '0.9rem', color: '#334155' }}>Estimated Messaging Cost</h4>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0.4rem 0', borderBottom: '1px solid #f1f5f9', fontSize: '0.85rem' }}>
                <span style={{ color: '#64748b' }}>Total Estimated Cost:</span>
                <strong style={{ color: '#0f172a' }}>₹{report.estimated_wa_cost_inr.toFixed(2)}</strong>
              </div>
              <p style={{ margin: '0.5rem 0 0', fontSize: '0.75rem', color: '#94a3b8' }}>
                Calculated based on Meta utility template pricing (~₹0.40/conversation).
              </p>
            </div>
          </div>
        </div>
      ) : (
        <p style={{ color: '#94a3b8', fontSize: '0.9rem' }}>No event data available for this range.</p>
      )}
    </div>
  );
}
