import test from 'node:test';
import assert from 'node:assert/strict';
import {createDashboardGateway} from '../lib/gateway.ts';
const clinic='20000000-0000-4000-8000-000000000001',staff='10000000-0000-4000-8000-000000000001';
const context={staff:{id:staff,clinic_id:clinic,name:'Synthetic Staff',role:'admin',active:true},clinic:{id:clinic,name:'Synthetic Clinic',timezone:'Asia/Kolkata',default_language:'en'}};
function fixture(options={}){
  let time=Date.parse('2026-11-03T04:30:00Z'),refreshes=0,revocations=0;
  const calls=[];
  const provider={
    request:async()=>{},verify:async()=>({accessToken:'private-access',refreshToken:'private-refresh',expiresAt:time+3600_000}),
    refresh:async()=>{refreshes++;await new Promise(resolve=>setTimeout(resolve,10));return {accessToken:'rotated-private-access',refreshToken:'rotated-private-refresh',expiresAt:time+3600_000};},
    revoke:async()=>{revocations++;},...options.provider,
  };
  const handle=createDashboardGateway({apiOrigin:'http://127.0.0.1:3001',appOrigin:'https://staff.example.test',provider,now:()=>time,
    fetch:async(url,init)=>{calls.push({url:url.toString(),...init});return options.response?.(url,init)??Response.json(new URL(url).pathname==='/api/v1/me'?context:{patients:[]});},...options.gateway});
  const send=(path,method='GET',body,cookie,headers={})=>handle(new Request('https://staff.example.test/api/staff/'+path,{method,headers:{origin:'https://staff.example.test',
    ...(body!==undefined?{'content-type':'application/json'}:{}),...(cookie?{cookie}:{}),...headers},...(body!==undefined?{body:JSON.stringify(body)}:{})}),path.split('/'));
  const login=async()=>{
    const response=await send('session/verify','POST',{phone:'+919000000001',code:'123456'});
    assert.equal(response.status,200);return response.headers.get('set-cookie').split(';')[0];
  };
  return {send,login,calls,advance:ms=>{time+=ms;},refreshes:()=>refreshes,revocations:()=>revocations};
}
test('OTP verifies membership before issuing a secure opaque cookie and never returns tokens',async()=>{
  const f=fixture(),response=await f.send('session/verify','POST',{phone:'+919000000001',code:'123456'});
  const text=await response.text(),cookie=response.headers.get('set-cookie');
  assert.equal(response.status,200);assert.ok(cookie.includes('HttpOnly'));assert.ok(cookie.includes('Secure'));assert.ok(cookie.includes('SameSite=Strict'));
  assert.ok(!cookie.includes('private-'));assert.ok(!text.includes('private-'));assert.equal(response.headers.get('cache-control'),'no-store');
  assert.equal(JSON.parse(text).staff.id,staff);
});
test('cross-origin writes and malformed OTP inputs fail before provider calls',async()=>{
  let calls=0;const f=fixture({provider:{verify:async()=>{calls++;throw Error('must not be called');}}});
  assert.equal((await f.send('session/verify','POST',{phone:'+919000000001',code:'123456'},null,{origin:'https://attacker.example'})).status,403);
  assert.equal((await f.send('session/verify','POST',{phone:'+919000000001',code:'bad'})).status,422);
  assert.equal(calls,0);
});
test('idle expiry is enforced server-side at thirty minutes without a heartbeat',async()=>{
  const f=fixture(),cookie=await f.login();f.advance(30*60_000);
  const expired=await f.send('me','GET',undefined,cookie);assert.equal(expired.status,401);
  assert.equal(f.calls.length,1);assert.ok(expired.headers.get('set-cookie').includes('Max-Age=0'));
});
test('real user requests extend the idle window and refresh tokens only while active',async()=>{
  const f=fixture(),cookie=await f.login();
  f.advance(29*60_000);assert.equal((await f.send('me','GET',undefined,cookie)).status,200);
  f.advance(29*60_000);assert.equal((await f.send('me','GET',undefined,cookie)).status,200);
  f.advance(29*60_000);await Promise.all([f.send('me','GET',undefined,cookie),f.send('me','GET',undefined,cookie)]);
  assert.equal(f.refreshes(),1);assert.ok(f.calls.at(-1).headers.authorization.includes('rotated-private-access'));
});
test('sign-out invalidates local custody even when remote revocation fails',async()=>{
  const f=fixture({provider:{revoke:async()=>{throw Error('private-provider-fault');}}}),cookie=await f.login();
  assert.equal((await f.send('session/logout','POST',{},cookie)).status,200);
  assert.equal((await f.send('me','GET',undefined,cookie)).status,401);
});
test('inactive membership clears the session, while an ordinary permission denial does not',async()=>{
  let denied=false,revoked=false;
  const f=fixture({response:url=>{
    if(revoked)return Response.json({error:{code:'STAFF_FORBIDDEN',message:'Membership inactive.'}},{status:403});
    if(denied&&new URL(url).pathname.endsWith('/uncertain'))return Response.json({error:{code:'OPERATION_FORBIDDEN',message:'Admin only.'}},{status:403});
  }}),cookie=await f.login();denied=true;
  assert.equal((await f.send('deliveries/uncertain','GET',undefined,cookie)).status,403);
  assert.equal((await f.send('me','GET',undefined,cookie)).status,200);
  revoked=true;assert.equal((await f.send('me','GET',undefined,cookie)).status,401);
  assert.equal((await f.send('me','GET',undefined,cookie)).status,401);
});
test('proxy allowlist prevents arbitrary targets and ignores caller bearer tokens',async()=>{
  const f=fixture(),cookie=await f.login();
  assert.equal((await f.send('https://attacker.example','GET',undefined,cookie)).status,404);
  assert.equal((await f.send('admin/delete','POST',{},cookie)).status,404);
  const result=await f.send('patients/search','POST',{mobile:'+919000000001'},cookie,{authorization:'Bearer attacker'});
  assert.equal(result.status,200);assert.equal(f.calls.at(-1).headers.authorization,'Bearer private-access');
  assert.equal(f.calls.at(-1).method,'GET');assert.ok(f.calls.at(-1).url.startsWith('http://127.0.0.1:3001/api/v1/patients?'));
});
test('write proxy retains the exact idempotency key and rejects missing keys',async()=>{
  const f=fixture(),cookie=await f.login(),key=crypto.randomUUID(),body={name:'Synthetic Patient'};
  assert.equal((await f.send('patients','POST',body,cookie)).status,422);
  assert.equal((await f.send('patients','POST',body,cookie,{'idempotency-key':key})).status,200);
  assert.equal(f.calls.at(-1).headers['idempotency-key'],key);assert.equal(f.calls.at(-1).body,JSON.stringify(body));
});
test('OTP attempts are rate-limited and errors do not expose provider details',async()=>{
  const f=fixture({provider:{verify:async()=>{throw Error('secret private connection');}}});
  for(let n=0;n<5;n++){const response=await f.send('session/verify','POST',{phone:'+919000000001',code:'123456'});assert.equal(response.status,503);assert.ok(!(await response.text()).includes('secret'));}
  assert.equal((await f.send('session/verify','POST',{phone:'+919000000001',code:'123456'})).status,429);
});
test('membership failure revokes authentication instead of opening a non-staff session',async()=>{
  const f=fixture({response:()=>Response.json({error:{code:'STAFF_FORBIDDEN'}},{status:403})});
  assert.equal((await f.send('session/verify','POST',{phone:'+919000000001',code:'123456'})).status,403);
  assert.equal(f.revocations(),1);
});
test('oversized bodies are rejected before OTP dispatch',async()=>{
  const f=fixture();assert.equal((await f.send('session/request','POST',{phone:'+919000000001',extra:'x'.repeat(17_000)})).status,413);
});
test('API outage during login is reported as unavailable and never creates a session',async()=>{
  const f=fixture({response:()=>Response.json({error:{code:'DB_UNAVAILABLE',message:'Temporary outage.'}},{status:503})});
  const result=await f.send('session/verify','POST',{phone:'+919000000001',code:'123456'});
  assert.equal(result.status,503);assert.equal((await result.json()).error.code,'AUTH_UNAVAILABLE');assert.equal(f.revocations(),1);
});
test('availability uses a body on the browser route and preserves validated conflict alternatives',async()=>{
  let conflict=false;
  const f=fixture({response:url=>{
    if(conflict&&new URL(url).pathname==='/api/v1/appointments')return Response.json({error:{code:'SLOT_UNAVAILABLE',message:'Choose another time.',details:{alternatives:[{starts_at:'2026-11-04T04:30:00Z',ends_at:'2026-11-04T05:00:00Z'}]}}},{status:409});
  }}),cookie=await f.login(),doctor='30000000-0000-4000-8000-000000000001';
  assert.equal((await f.send('availability','POST',{doctor_id:doctor,date:'2026-11-04',patient_id:'40000000-0000-4000-8000-000000000001'},cookie)).status,200);
  assert.ok(f.calls.at(-1).url.includes('/doctors/'+doctor+'/slots?'));assert.equal(f.calls.at(-1).method,'GET');
  conflict=true;const result=await f.send('appointments','POST',{},cookie,{'idempotency-key':crypto.randomUUID()});
  assert.equal(result.status,409);assert.equal((await result.json()).error.details.alternatives.length,1);
});
test('schedule and queue proxy routes retain write keys and cannot target arbitrary services',async()=>{
  const f=fixture(),cookie=await f.login(),doctor='30000000-0000-4000-8000-000000000001',key=crypto.randomUUID();
  assert.equal((await f.send(`doctors/${doctor}/availability`,'PATCH',{action:'schedule'},cookie,{'idempotency-key':key})).status,200);
  assert.equal(f.calls.at(-1).headers['idempotency-key'],key);assert.equal(f.calls.at(-1).method,'PATCH');
  assert.equal((await f.send(`doctors/${doctor}/queue`,'POST',{action:'add'},cookie,{'idempotency-key':key})).status,200);
  assert.equal(f.calls.at(-1).headers['idempotency-key'],key);
  assert.equal((await f.send('queue/status','GET',undefined,cookie)).status,200);
  assert.equal((await f.send('queue/enable','POST',{},cookie,{'idempotency-key':key})).status,404);
});
