// Built-dashboard HTTP smoke check. Intentionally empty provider settings prevent OTP/network side effects.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createServer} from 'node:net';
import {once} from 'node:events';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../../../',import.meta.url));
const reservation=createServer();reservation.listen(0,'127.0.0.1');await once(reservation,'listening');
const port=reservation.address().port;await new Promise(resolve=>reservation.close(resolve));
const child=spawn(process.execPath,[fileURLToPath(new URL('../../../node_modules/next/dist/bin/next',import.meta.url)),
  'start','apps/dashboard','--hostname','127.0.0.1','--port',String(port)],{
  cwd:root,windowsHide:true,stdio:['ignore','ignore','ignore'],env:{...process.env,
    SUPABASE_URL:'',SUPABASE_PUBLISHABLE_KEY:'',TABIYO_API_ORIGIN:'',TABIYO_DASHBOARD_ORIGIN:'',NEXT_TELEMETRY_DISABLED:'1'},
});
const exit=once(child,'exit');const origin=`http://127.0.0.1:${port}`;
try{
  let ready=false;const deadline=Date.now()+20_000;
  while(Date.now()<deadline){
    if(child.exitCode!==null)throw new Error('DASHBOARD_SMOKE_START_FAILED');
    try{const response=await fetch(origin,{signal:AbortSignal.timeout(1000)});if(response.ok){ready=true;break;}}catch{/* process is still starting */}
    await new Promise(resolve=>setTimeout(resolve,100));
  }
  assert.ok(ready,'Built dashboard did not become ready.');
  const page=await fetch(origin);assert.equal(page.status,200);
  assert.ok((await page.text()).includes('Checking your staff session'));
  assert.equal(page.headers.get('x-frame-options'),'DENY');
  assert.ok(page.headers.get('content-security-policy').includes("frame-ancestors 'none'"));
  const auth=await fetch(origin+'/api/staff/session/request',{method:'POST',headers:{'content-type':'application/json',origin},body:JSON.stringify({phone:'+919000000001'})});
  assert.equal(auth.status,503);assert.equal((await auth.json()).error.code,'AUTH_UNAVAILABLE');
  assert.equal(auth.headers.get('cache-control'),'no-store');
  console.log(JSON.stringify({builtDashboard:'pass',securityHeaders:'pass',unconfiguredAuth:'disabled',physicalMessagesSent:0}));
}finally{child.kill();await exit;}
