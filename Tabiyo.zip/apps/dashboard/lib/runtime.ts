import {createClient,type Session} from '@supabase/supabase-js';
import {ApiError} from '@tabiyo/shared';
import {createDashboardGateway,type AuthSession} from './gateway.ts';

const convert=(session:Session|null):AuthSession=>{
  if(!session?.access_token||!session.refresh_token||!session.expires_at)throw new ApiError('AUTH_REQUIRED',401,'The sign-in code could not be verified.');
  return {accessToken:session.access_token,refreshToken:session.refresh_token,expiresAt:session.expires_at*1000};
};
function makeGateway(){
  const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_PUBLISHABLE_KEY;
  const apiOrigin=process.env.TABIYO_API_ORIGIN,appOrigin=process.env.TABIYO_DASHBOARD_ORIGIN;
  if(!url||!key||!apiOrigin||!appOrigin)return undefined;
  const configured=new URL(url);
  if(configured.protocol!=='https:'&&!(configured.protocol==='http:'&&['localhost','127.0.0.1'].includes(configured.hostname)))return undefined;
  const client=()=>createClient(url,key,{
    auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},
    global:{fetch:(input,init)=>fetch(input,{...init,signal:AbortSignal.timeout(10_000),redirect:'error'})},
  });
  return createDashboardGateway({apiOrigin,appOrigin,provider:{
    async request(phone){
      const {error}=await client().auth.signInWithOtp({phone,options:{shouldCreateUser:false}});
      if(error?.status===429)throw new ApiError('AUTH_RATE_LIMITED',429,'Too many attempts. Try again later.');
      // Generic response for unknown/non-invited numbers prevents staff-account enumeration.
      if(error&&error.status!==400&&error.status!==422)throw new ApiError('AUTH_UNAVAILABLE',503,'Sign-in is unavailable. Try again later.');
    },
    async verify(phone,code){
      const {data,error}=await client().auth.verifyOtp({phone,token:code,type:'sms'});
      if(error)throw new ApiError('AUTH_REQUIRED',401,'The sign-in code could not be verified.');
      return convert(data.session);
    },
    async refresh(session){
      const {data,error}=await client().auth.refreshSession({refresh_token:session.refreshToken});
      if(error)throw new Error('SESSION_REFRESH_FAILED');return convert(data.session);
    },
    async revoke(session){
      const auth=client().auth;
      const {error}=await auth.setSession({access_token:session.accessToken,refresh_token:session.refreshToken});
      if(!error)await auth.signOut({scope:'local'});
    },
  }});
}
// One process-local custody store survives route module reloads; no tokens are written to disk.
const state=globalThis as typeof globalThis&{tabiyoDashboardGateway?:ReturnType<typeof createDashboardGateway>};
export async function handleStaffRequest(request:Request,path:string[]){
  try{
    state.tabiyoDashboardGateway??=makeGateway();
    if(state.tabiyoDashboardGateway)return state.tabiyoDashboardGateway(request,path);
  }catch{/* Never print environment values or provider errors. */}
  return Response.json({error:{code:'AUTH_UNAVAILABLE',message:'Staff sign-in is not available yet. Contact your clinic administrator.'}},{status:503,headers:{'cache-control':'no-store'}});
}
