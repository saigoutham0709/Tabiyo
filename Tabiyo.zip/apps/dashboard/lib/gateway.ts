import {randomBytes,createHash} from 'node:crypto';
import {z} from 'zod';
import {ApiError,clinicSchema,staffSchema,mobileSchema} from '@tabiyo/shared';

export type AuthSession={accessToken:string;refreshToken:string;expiresAt:number};
export type AuthProvider={
  request(phone:string):Promise<void>;
  verify(phone:string,code:string):Promise<AuthSession>;
  refresh(session:AuthSession):Promise<AuthSession>;
  revoke(session:AuthSession):Promise<void>;
};
type StoredSession={auth:AuthSession;lastActive:number;refreshing?:Promise<void>};
const idleMs=30*60_000;
const cookieName='tabiyo_staff_session';
const json=(body:unknown,status=200,cookie?:string)=>new Response(JSON.stringify(body),{status,headers:{
  'content-type':'application/json','cache-control':'no-store','pragma':'no-cache','x-content-type-options':'nosniff',
  ...(cookie?{'set-cookie':cookie}:{}),
}});

/** Process-local session custody. Restart signs staff out; no tokens enter browser storage or artifacts. */
export function createDashboardGateway(config:{
  apiOrigin:string;appOrigin:string;provider:AuthProvider;fetch?:typeof fetch;now?:()=>number;maxSessions?:number;
}) {
  const api=new URL(config.apiOrigin),origin=new URL(config.appOrigin).origin;
  if(!['http:','https:'].includes(api.protocol)||api.username||api.password||api.search||api.hash||api.pathname!=='/'||
    (api.protocol==='http:'&&!['localhost','127.0.0.1','[::1]'].includes(api.hostname)))throw new Error('DASHBOARD_INVALID_API_ORIGIN');
  const fetcher=config.fetch??fetch,now=config.now??Date.now,sessions=new Map<string,StoredSession>();
  const attempts=new Map<string,{count:number;until:number}>();
  const cookie=(value:string,seconds=1800)=>`${cookieName}=${value}; HttpOnly; SameSite=Strict; Path=/api/staff; Max-Age=${seconds}${origin.startsWith('https:')?'; Secure':''}`;
  const sessionId=(request:Request)=>request.headers.get('cookie')?.split(';').map(v=>v.trim()).find(v=>v.startsWith(cookieName+'='))?.slice(cookieName.length+1)??'';
  const expired=()=>new ApiError('SESSION_EXPIRED',401,'Your session ended. Sign in again.');
  const readBody=async(request:Request)=>{
    if(!request.headers.get('content-type')?.startsWith('application/json'))throw new ApiError('INPUT_INVALID',415,'Use a JSON request.');
    const declared=Number(request.headers.get('content-length')??0);
    if(declared>16_384)throw new ApiError('INPUT_INVALID',413,'The request is too large.');
    // Read incrementally so chunked bodies cannot bypass the length limit.
    const reader=request.body?.getReader();if(!reader)return {};
    const decoder=new TextDecoder('utf-8',{fatal:true});let size=0,body='';
    try {
      while(true){const {value,done}=await reader.read();if(done)break;size+=value.byteLength;
        if(size>16_384){await reader.cancel();throw new ApiError('INPUT_INVALID',413,'The request is too large.');}
        body+=decoder.decode(value,{stream:true});}
      body+=decoder.decode();return body?JSON.parse(body):{};
    }catch(error){if(error instanceof ApiError)throw error;throw new ApiError('INPUT_INVALID',422,'Check the request format.');}
    finally{reader.releaseLock();}
  };
  function sweep(){
    for(const [id,record] of sessions)if(now()-record.lastActive>=idleMs)sessions.delete(id);
    for(const [key,bucket] of attempts)if(bucket.until<=now())attempts.delete(key);
  }
  function rateLimit(phone:string,action:string){
    sweep();const key=createHash('sha256').update(action+phone).digest('hex');
    const bucket=attempts.get(key);
    if(bucket&&bucket.count>=5)throw new ApiError('AUTH_RATE_LIMITED',429,'Too many attempts. Try again later.');
    if(!bucket&&attempts.size>=1000)throw new ApiError('AUTH_RATE_LIMITED',429,'Sign-in is busy. Try again later.');
    attempts.set(key,{count:(bucket?.count??0)+1,until:bucket?.until??now()+10*60_000});
  }
  async function apiCall(path:string,session:AuthSession,method='GET',body?:unknown,key?:string){
    return fetcher(new URL(path,api),{method,redirect:'error',cache:'no-store',signal:AbortSignal.timeout(10_000),headers:{
      authorization:'Bearer '+session.accessToken,...(body!==undefined?{'content-type':'application/json'}:{}),...(key?{'idempotency-key':key}:{}),
    },...(body!==undefined?{body:JSON.stringify(body)}:{})});
  }
  async function current(request:Request){
    const id=sessionId(request),record=sessions.get(id);
    if(!record||now()-record.lastActive>=idleMs){sessions.delete(id);throw expired();}
    if(record.auth.expiresAt<=now()+30_000){
      if(!record.refreshing)record.refreshing=config.provider.refresh(record.auth).then(auth=>{record.auth=auth;}).finally(()=>{record.refreshing=undefined;});
      try{await record.refreshing;}catch{sessions.delete(id);throw expired();}
    }
    if(sessions.get(id)!==record||now()-record.lastActive>=idleMs)throw expired();
    return {id,record};
  }
  return async function handle(request:Request,path:string[]):Promise<Response>{
    try{
      const method=request.method,route=path.join('/');
      if(!['GET','POST','PATCH'].includes(method))throw new ApiError('NOT_FOUND',404,'Route not found.');
      if(method!=='GET'&&request.headers.get('origin')!==origin)throw new ApiError('ORIGIN_FORBIDDEN',403,'This request is not allowed.');
      if(route==='session/request'&&method==='POST'){
        const {phone}=z.object({phone:mobileSchema}).strict().parse(await readBody(request));rateLimit(phone,'request');
        await config.provider.request(phone);
        return json({message:'If your staff account is enabled, a sign-in code will arrive.'});
      }
      if(route==='session/verify'&&method==='POST'){
        const {phone,code}=z.object({phone:mobileSchema,code:z.string().regex(/^\d{6}$/)}).strict().parse(await readBody(request));rateLimit(phone,'verify');
        const auth=await config.provider.verify(phone,code);
        let context;
        try{
          const response=await apiCall('/api/v1/me',auth);
          if(response.status>=500)throw new ApiError('AUTH_UNAVAILABLE',503,'Staff verification is unavailable. Try again later.');
          if(!response.ok)throw new ApiError('STAFF_FORBIDDEN',403,'Active clinic membership is required.');
          context=z.object({staff:staffSchema,clinic:clinicSchema}).parse(await response.json());
          if(context.staff.clinic_id!==context.clinic.id)throw new Error('SCOPE_MISMATCH');
          sweep();if(sessions.size>=(config.maxSessions??1000))throw new ApiError('AUTH_UNAVAILABLE',503,'Sign-in is busy. Try again later.');
        }catch(error){try{await config.provider.revoke(auth);}catch{/* local session was never created */}throw error;}
        sessions.delete(sessionId(request));
        const id=randomBytes(32).toString('hex');sessions.set(id,{auth,lastActive:now()});
        return json(context,200,cookie(id));
      }
      if(route==='session/logout'&&method==='POST'){
        const id=sessionId(request),record=sessions.get(id);sessions.delete(id);
        if(record)try{await config.provider.revoke(record.auth);}catch{/* local session is already invalid */}
        return json({signedOut:true},200,cookie('',0));
      }
      let target:string,body:unknown;
      if(route==='me'&&method==='GET')target='/api/v1/me';
      else if(route==='patients/search'&&method==='POST'){
        const {mobile}=z.object({mobile:mobileSchema}).strict().parse(await readBody(request));
        target='/api/v1/patients?'+new URLSearchParams({mobile});
      }else if(route==='availability'&&method==='POST'){
        const query=z.object({doctor_id:z.string().uuid(),date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),patient_id:z.string().uuid().optional()}).strict().parse(await readBody(request));
        target='/api/v1/doctors/'+query.doctor_id+'/slots?'+new URLSearchParams({date:query.date,...(query.patient_id?{patient_id:query.patient_id}:{})});
      }else if(route==='patients'&&method==='POST')target='/api/v1/patients';
      else if(/^patients\/[0-9a-f-]{36}$/.test(route)&&['GET','PATCH'].includes(method))target='/api/v1/'+route;
      else if(/^patients\/[0-9a-f-]{36}\/consents$/.test(route)&&method==='POST')target='/api/v1/'+route;
      else if(route==='alerts'&&method==='GET')target='/api/v1/alerts'+new URL(request.url).search;
      else if(/^alerts\/[0-9a-f-]{36}\/resolve$/.test(route)&&method==='POST')target='/api/v1/'+route;
      else if(route==='deliveries/uncertain'&&method==='GET')target='/api/v1/deliveries/uncertain';
      else if(/^deliveries\/[0-9a-f-]{36}\/review$/.test(route)&&method==='POST')target='/api/v1/'+route;
      else if(route==='doctors'&&method==='GET')target='/api/v1/doctors';
      else if(route==='queue/status'&&method==='GET')target='/api/v1/queue/status';
      else if(/^doctors\/[0-9a-f-]{36}\/queue$/.test(route)&&['GET','POST'].includes(method))target='/api/v1/'+route+(method==='GET'?new URL(request.url).search:'');
      else if(/^doctors\/[0-9a-f-]{36}\/availability$/.test(route)&&['GET','PATCH'].includes(method))target='/api/v1/'+route;
      else if(/^doctors\/[0-9a-f-]{36}\/slots$/.test(route)&&method==='GET')target='/api/v1/'+route+new URL(request.url).search;
      else if(route==='appointments'&&['GET','POST'].includes(method))target='/api/v1/appointments'+(method==='GET'?new URL(request.url).search:'');
      else if(/^appointments\/[0-9a-f-]{36}$/.test(route)&&method==='PATCH')target='/api/v1/'+route;
      else throw new ApiError('NOT_FOUND',404,'Route not found.');
      const {id,record}=await current(request);
      const isSearch=route==='patients/search'||route==='availability';
      if(method!=='GET'&&!isSearch)body=await readBody(request);
      const key=method!=='GET'&&!isSearch?z.string().uuid().parse(request.headers.get('idempotency-key')):undefined;
      const response=await apiCall(target,record.auth,isSearch?'GET':method,body,key);
      if(sessions.get(id)!==record)throw expired();
      const data=await response.json();
      const error=z.object({error:z.object({code:z.string(),message:z.string(),requestId:z.string().optional(),
        details:z.object({alternatives:z.array(z.object({starts_at:z.string().datetime({offset:true}),ends_at:z.string().datetime({offset:true})})).max(3)}).optional(),
      })}).safeParse(data);
      if(response.status===401||(response.status===403&&error.success&&error.data.error.code==='STAFF_FORBIDDEN')){
        sessions.delete(id);return json({error:{code:'SESSION_EXPIRED',message:'Your session ended. Sign in again.'}},401,cookie('',0));
      }
      if(response.ok){record.lastActive=now();return json(data,response.status,cookie(id));}
      // API already returns a stable redacted error; retain only its public fields.
      return json(error.success?error.data:{error:{code:'API_UNAVAILABLE',message:'The request could not be completed.'}},response.status);
    }catch(error){
      if(error instanceof ApiError)return json({error:{code:error.code,message:error.message}},error.status,error.status===401?cookie('',0):undefined);
      if(error instanceof z.ZodError)return json({error:{code:'INPUT_INVALID',message:'Check the request format.'}},422);
      return json({error:{code:'API_UNAVAILABLE',message:'The request could not be completed. Try again.'}},503);
    }
  };
}
